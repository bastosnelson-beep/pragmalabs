---
name: recherche-ahrefs
description: "Part d'une thématique et d'une carte des croyances pour ressortir 20 à 50 sujets et mots-clés que ta cible cherche vraiment (volume, difficulté, intention), rangés par thématique et croisés avec les croyances prioritaires. De la matière directe à livrables."
---

# Recherche Ahrefs : les sujets chauds du domaine

> **Objectif :** partir d'une thématique et d'une carte des croyances, et ressortir une liste de 20 à 50 sujets et mots-clés que ta cible cherche réellement (volume + difficulté + intention), rangée par thématique et croisée avec les croyances prioritaires.

Ta base marketing ne sort pas que de ta tête. Une fois que tu as ton ICP et ta carte des croyances, tu les branches sur la demande réelle : ce que les gens tapent vraiment dans la barre de recherche. Un mot-clé à fort volume, c'est une douleur ou une croyance que beaucoup de monde reconnaît. Donc c'est de la matière à livrables : un titre de page de vente, un objet d'email, un angle de pub, une vidéo YouTube.

Cette méthode reprend le principe du cocon SEO : un ensemble de sujets proches qui couvrent une niche en profondeur et se renvoient les uns aux autres. Ici on cherche les sujets qui viennent **confirmer ou enrichir** la carte des croyances, pas juste des idées de vidéos.

---

## Principe directeur

Tu pars de ce que les gens cherchent, pas de ce que tu as envie de dire. Trois règles :

1. **Le volume valide la douleur.** Si un mot-clé qui colle à une de tes croyances a du volume, c'est que la douleur est partagée. Tu tiens un angle qui parlera à beaucoup de monde, pas juste à une intuition.
2. **Tout mot-clé doit se rattacher à une croyance ou à l'offre.** Une liste SEO orpheline, déconnectée de la carte des croyances, ne sert à rien. Chaque sujet qui remonte se range en face d'une croyance à reframer ou se jette.
3. **Le maillage bat l'unité.** Le principe du cocon : un ensemble de sujets proches qui couvrent une niche en profondeur et se renvoient les uns aux autres, pas un mot-clé isolé.

---

## Input requis

- La thématique ou la niche du produit (en `$ARGUMENTS` si tu la passes, sinon on la clarifie).
- La fiche ICP de ton socle marketing (cible + niveau de conscience + vocabulaire).
- La carte des croyances de ton socle marketing (surtout le top 5 des croyances à reframer) : c'est elle qu'on vient confirmer.
- Un abonnement Ahrefs.

---

## Étape 1 : Setup Ahrefs et marché de travail

**Méthode :** prends un abonnement Ahrefs (offre Beginner, autour de 27 euros par mois) et ouvre le Keyword Explorer. Travaille en **anglais sur le marché US** : plus de volume, outil mieux entraîné. Tu traduiras ensuite les angles trouvés vers ton marché et ta langue de vente.

**Outils :** Ahrefs Keyword Explorer. Google et YouTube en parallèle pour recouper.

**Piège :** travailler directement en français quand le volume US est bien plus riche. Tu passes à côté de la moitié des intentions, et la difficulté affichée est moins fiable.

Concrètement : ouvre le Keyword Explorer, sélectionne le pays US, tape un premier terme racine tiré de ta thématique (le mot que ta cible utiliserait, repris de son vocabulaire dans la fiche ICP).

---

## Étape 2 : Lire les bons indicateurs

**Méthode :** pour chaque mot-clé, lis trois choses dans cet ordre.

| Indicateur | Ce qu'il te dit | Seuil de départ |
|---|---|---|
| **Volume** | Combien de personnes cherchent ce sujet par mois | Plus c'est haut, plus la douleur est partagée |
| **Keyword Difficulty (KD)** | À quel point c'est dur de se positionner dessus | Vise bas quand tu débutes, en dessous de 46 |
| **Intention** | Ce que la personne veut vraiment en tapant ça | Doit matcher ton offre, pas juste ta thématique |

**Outils :** la fiche du mot-clé dans Ahrefs (Volume, KD, et le SERP overview en dessous).

**Piège :** ne regarder que le volume. Un mot-clé à 50 000 recherches mais KD 80 et intention floue est moins bon qu'un mot-clé à 1 200 recherches, KD 20, intention claire qui matche une croyance de ta carte.

L'intention se lit en regardant le SERP : si les premiers résultats sont des comparatifs, l'intention est "je compare", si ce sont des tutos, l'intention est "je veux apprendre à faire", si ce sont des pages produit, l'intention est commerciale. C'est ce dernier type qui est le plus proche de l'achat.

---

## Étape 3 : Explorer les trois onglets

**Méthode :** pour faire émerger un maximum de sujets à partir d'un seul terme racine, explore systématiquement trois onglets du Keyword Explorer.

| Onglet | Ce qu'il fait remonter | À quoi ça sert |
|---|---|---|
| **Matching terms** | Tous les mots-clés qui contiennent ton terme | Couvre la largeur du sujet |
| **Related terms** | Des termes proches mais différents | Ouvre des angles adjacents auxquels tu n'aurais pas pensé |
| **Search suggestions** | Les vraies intentions tapées par les gens | Te donne les formulations exactes de la cible |

**Outils :** les trois onglets natifs d'Ahrefs Keyword Explorer.

**Piège :** s'arrêter à Matching terms. Les meilleures pépites sortent souvent de Search suggestions, parce que ce sont les mots de la cible, pas les tiens.

Search suggestions est le plus précieux pour le marketing : ce sont les formulations brutes que les gens tapent, donc des objets d'email et des titres de page de vente prêts à l'emploi.

---

## Étape 4 : Constituer la keyword list et recouper

**Méthode :** ajoute tout ce qui résonne à une **keyword list** dans Ahrefs au fil de l'exploration. Puis recoupe chaque candidat sérieux sur Google et YouTube : tape le mot-clé, regarde ce qui ressort déjà, et demande-toi comment te différencier de ce qui existe.

**Outils :** keyword list Ahrefs, Google, YouTube.

**Piège :** copier un sujet déjà ultra couvert sans angle propre. Si les dix premiers résultats disent tous la même chose, ton contenu se noie, sauf si tu apportes la perspective contrarienne de ta carte des croyances.

Le principe du cocon guide le recoupage : tu construis un maillage de sujets qui répondent à des questions proches et couvrent la niche en profondeur, pas une liste de mots-clés isolés.

---

## Étape 5 : Croiser avec la carte des croyances (spécifique bases marketing)

C'est l'étape qui distingue cette recherche d'un simple audit SEO. Un mot-clé n'a de valeur ici que s'il se rattache à ta carte.

**Méthode :** pour chaque mot-clé retenu, range-le en face d'une des croyances prioritaires de ta carte. Trois cas :

- Le mot-clé **confirme** une croyance déjà listée : son volume prouve que la douleur est massive, tu montes cette croyance dans le top des priorités.
- Le mot-clé **ajoute** une croyance que tu n'avais pas vue : tu l'intègres à la carte (en la marquant `[À VALIDER]` tant que tu n'as pas de verbatim).
- Le mot-clé n'a **aucun lien** avec une croyance ni avec l'offre : tu le jettes, même s'il a du volume.

**Outils :** la carte des croyances ouverte à côté, ta keyword list.

**Piège :** chasser les mots-clés "vanity" (gros volume, sujet vaguement lié, mais qui n'adresse aucune croyance d'achat). Ils gonflent la liste et ne convertissent jamais.

À la sortie, chaque mot-clé devient de la matière concrète : un titre de page de vente, un objet d'email de la séquence, un angle de pub, un sujet de vidéo. C'est là que la recherche Ahrefs alimente le Thème C (livrables marketing).

---

## Exemples

### Bon

Cas : produit PropertyFilter (outil pour investisseurs immobiliers au Royaume-Uni), croyance prioritaire de la carte = *"le vrai jeu c'est les motivated sellers, pas Rightmove"*.

> Mot-clé : **how to find motivated sellers** -> Volume élevé, KD bas, intention "je veux apprendre à faire".

Pourquoi c'est bon : volume élevé donc la douleur est largement partagée, difficulté basse donc atteignable, et surtout l'intention matche pile la croyance d'arrivée à reframer. Ce mot-clé devient directement un sujet de vidéo, un objet d'email et une section de page de vente. Il confirme et muscle une croyance déjà dans la carte.

### Mauvais

> Mot-clé : **uk property market 2026** -> Volume très élevé, mais intention "actualité générale", aucun lien avec une croyance d'achat.

Pourquoi c'est raté : gros volume vanity. La personne qui tape ça veut une news macro, pas une méthode pour acheter. Le mot-clé ne se rattache à aucune croyance prioritaire et ne pousse vers aucune action d'achat. Garder ça dans la liste, c'est se mentir sur la qualité du travail.

---

## Pièges

- **Liste SEO orpheline.** Tu sors 50 mots-clés sans jamais les recroiser avec la carte des croyances. Résultat : du SEO générique qui ne sert aucun livrable.
- **Tout au volume.** Tu trie uniquement par volume et tu ignores la difficulté et l'intention. Tu vises des mots-clés inatteignables ou hors sujet d'achat.
- **Travailler en français par défaut.** Tu te prives du volume et de la fiabilité du marché US, alors que tu peux traduire les angles ensuite.
- **S'arrêter à Matching terms.** Tu rates Search suggestions, là où sont les formulations exactes de la cible.
- **Copier l'existant sans angle.** Tu reprends un sujet saturé sans la perspective contrarienne de ta carte, ton contenu se noie.

---

## Références

- Formation vidéo : **Contenu YouTube** (`/plateforme/business-os/contenu-youtube`) -&gt; la même méthode Ahrefs y sert l'idéation de plus de 100 sujets de vidéos. Va la voir pour la version complète du cocon SEO appliquée au contenu.
- Formation vidéo : **Idées et Perspective** (`/plateforme/business-os/ides-et-perspective`) -&gt; pour trouver l'angle et la perspective différenciante qui te démarque sur les sujets saturés que la recherche fait remonter.

---

## Checklist rapide

- [ ] Abonnement Ahrefs actif, Keyword Explorer ouvert sur le marché US, en anglais.
- [ ] Termes racines tirés du vocabulaire réel de la fiche ICP.
- [ ] Chaque mot-clé lu sur Volume + Keyword Difficulty (sous 46) + intention.
- [ ] Les trois onglets explorés : Matching terms, Related terms, Search suggestions.
- [ ] Candidats ajoutés à une keyword list, recoupés sur Google et YouTube.
- [ ] Chaque mot-clé retenu rangé en face d'une croyance (confirme / ajoute / jette).
- [ ] Mots-clés vanity sans lien avec l'offre ou une croyance éliminés.
- [ ] Sortie : 20 à 50 sujets rangés par thématique, croisés avec les croyances prioritaires.
