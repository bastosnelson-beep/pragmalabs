---
name: miniatures-youtube
description: "Produire 2 à 3 concepts de miniature (brief complet) optimisés pour le CTR et lisibles en mobile : composition, visage, texte qui complète le titre, couleurs et A/B test."
---

# Miniatures YouTube irrésistibles

> **Objectif :** produire 2 à 3 concepts de miniature (brief complet) pour une vidéo, optimisés pour le CTR et lisibles en mobile.

La miniature pilote le taux de clic au même titre que le titre, parfois davantage. Le cerveau traite une image en 13 millisecondes : avant même de lire le titre, le spectateur a déjà ressenti quelque chose. Une bonne miniature ne fonctionne jamais seule, elle forme un combo avec le titre. Les deux sont complémentaires, ils ne disent pas la même chose deux fois. Ton rôle ici : dialoguer avec l'utilisateur pour cerner l'émotion à déclencher, puis livrer des briefs de miniature précis qu'un graphiste (ou un outil de génération) pourra exécuter directement.

---

## Démarrage

Avant de proposer quoi que ce soit, récupère trois informations. Pose les questions si elles manquent.

1. **Le sujet ou le script de la vidéo.** De quoi parle la vidéo, quelle est la promesse, quelle est la transformation pour le spectateur.
2. **Le titre retenu.** Indispensable, car la miniature doit le compléter et non le répéter. Si le titre n'est pas figé, demande au moins l'angle principal.
3. **L'émotion dominante visée.** Curiosité, choc, désir, peur de rater, fierté, soulagement. Une miniature efficace porte une émotion claire, pas trois.

Si ces éléments sont flous, reformule ta compréhension en une phrase et fais valider avant de produire les concepts.

---

## Les 4 piliers d'une miniature qui convertit

Chaque concept que tu proposes doit respecter ces quatre piliers. Vérifie-les un par un.

1. **Clarté immédiate.** Le message passe en moins d'une seconde. Si le spectateur doit réfléchir, c'est perdu.
2. **Impact émotionnel.** L'image déclenche une émotion forte (le cortex visuel V1 capte les contrastes, la zone FFA est dédiée aux visages, l'oeil est aimanté par les émotions fortes).
3. **Qualité professionnelle.** Éclairage, netteté, composition équilibrée. Le cerveau préfère les compositions équilibrées.
4. **Cohérence avec le titre.** La miniature et le titre racontent ensemble une histoire, sans redondance.

---

## Composition : règle des tiers

Découpe l'image en 9 parties (3 x 3) et place les éléments clés aux intersections, pas au centre par défaut.

- Crée une direction de lecture, en général de gauche vers la droite.
- Organise la miniature en 2 ou 3 zones équilibrées (par exemple visage à gauche, objet et texte à droite).
- Le regard du sujet sert de flèche : il doit pointer vers le texte ou vers l'objet important.

---

## Les éléments visuels

**Visage principal**

- Expression émotionnelle forte et lisible (surprise, joie, dégoût, détermination).
- Regard dirigé vers le texte ou vers l'objet clé.
- Bien éclairé, en contraste net avec l'arrière-plan.
- Le visage occupe 30 % minimum de la surface de l'image.

**Objet secondaire**

- Complète l'histoire et crée une tension.
- Simple, immédiatement reconnaissable.
- En relation directe avec le titre.

**Texte overlay**

- 3 à 4 mots maximum.
- Police lisible et fortement contrastée.
- Position stratégique, sur une zone calme de l'image.
- Le texte complète le titre, il ne le répète pas. Exemple : titre "le meilleur système de prise de notes", la miniature montre une icône Apple Notes barrée avec le texte "remplace ça". Le titre pose la promesse, la miniature crée la curiosité.

---

## Les couleurs

**Palette de base :** une couleur dominante, une couleur d'accent, une neutre. Pas plus.

**Contraste minimum :**

- Fond contre éléments : 4.5:1.
- Texte contre fond : 7:1.

**Psychologie des couleurs**

- Rouge : urgence, passion.
- Bleu : confiance, calme.
- Jaune : optimisme, attention (capte l'oeil).
- Noir : luxe, autorité.
- Blanc : clarté.

Choisis la dominante en fonction de l'émotion visée, puis justifie-la dans le brief.

---

## Les 4 types de miniature

Identifie le type le plus adapté au sujet, puis propose des concepts qui varient les types.

- **L'Émotionnel :** gros plan sur le visage, expression faciale forte, texte minimal, couleurs vives. Idéal pour le storytelling et les sujets personnels.
- **Le Démonstratif :** avant/après, flèches, résultat visible. Idéal pour les tutos, méthodes et preuves.
- **Le Narratif :** scène complète, plusieurs éléments, histoire visuelle. Idéal pour les vlogs et les récits.
- **Le Minimaliste :** un seul élément fort, espace négatif, texte impactant, contraste maximal. Idéal pour les sujets premium ou conceptuels.

---

## Les patterns visuels efficaces

Active un pattern selon l'émotion ciblée.

- **Le Choc :** surprise plus objet inattendu plus contraste élevé.
- **La Transformation :** avant/après avec flèches.
- **Le Mystère :** un élément flouté ou caché plus un texte intriguant.
- **L'Action :** mouvement figé, énergie, instant suspendu.

---

## Le processus de création

1. **Planification.** Sketcher 3 à 4 concepts, définir l'émotion principale, prévoir l'emplacement du texte.
2. **Préparation du shooting.** Lister les expressions nécessaires, les angles, les accessoires, le fond. Conseil : se constituer une banque de "têtes" (photos de soi avec des expressions variées) et la renouveler tous les 6 à 12 mois.
3. **Shooting.** Éclairage 3 points, plusieurs angles, expressions variées, cadrage pensé en 16:9.
4. **Édition.** Sélection, recadrage 16:9, correction des couleurs, application de la règle des tiers, ajout du texte, vérification du contraste.
5. **Finalisation.** Test de lisibilité, vérification mobile (le point le plus important), export haute qualité, création de variations pour l'A/B test.

---

## Optimisation mobile (capital)

La majorité des vues vient du mobile, donc la miniature se valide en petit format.

- Visage à 30 % minimum de la surface.
- Texte lisible même en miniature réduite.
- Marges de sécurité de 10 % sur les bords.
- Contraste fort partout.

Réflexe à appliquer systématiquement : réduis mentalement le concept à la taille d'une vignette de fil mobile. S'il reste lisible et émotionnellement clair, il passe.

---

## Tests et itération

**A/B testing.** Fais varier un paramètre à la fois : expression, position des éléments, couleur dominante, style de texte.

**Métriques à suivre :**

- CTR initial, observable dans les 2 à 3 premières heures.
- Rétention.
- Impressions.

Documente les patterns gagnants dans une banque de références pour réutiliser ce qui marche.

---

## Le combo avec le titre

La miniature et le titre forment un seul message en deux couches. Complémentarité, pas répétition. La miniature ajoute une couche de curiosité visuelle que le titre ne porte pas. Si le texte de la miniature dit la même chose que le titre, retravaille-le. Pour caler ou retravailler le titre, renvoie vers le skill `/titres-youtube`.

---

## Format de brief à produire

Pour chaque concept (vise 2 à 3 concepts variés en type), livre un brief structuré exactement comme suit.

```
CONCEPT 1
- Type : Émotionnel
- Visage : expression de surprise franche, regard dirigé vers le texte à droite
- Texte overlay : "remplace ça" (3 mots)
- Composition : visage à gauche (intersection bas-gauche), icône barrée à droite, texte au-dessus de l'icône
- Couleur dominante : rouge (urgence, accentue la rupture promise par le titre)

CONCEPT 2
- Type : Démonstratif
- Visage : expression de satisfaction, regard vers l'objet "après"
- Texte overlay : "avant / après" (2 mots)
- Composition : split écran gauche/droite, flèche centrale, visage en médaillon bas-droite
- Couleur dominante : bleu (confiance, crédibilise la méthode)

CONCEPT 3
- Type : Minimaliste
- Visage : aucun, focus sur un seul objet fort
- Texte overlay : "la vraie raison" (3 mots)
- Composition : objet centré sur fond uni, espace négatif large, texte en bas
- Couleur dominante : noir (autorité, contraste maximal)
```

Adapte les valeurs au sujet réel. Chaque brief doit pouvoir être exécuté tel quel par un graphiste ou un outil de génération d'image, sans question supplémentaire.

---

## Checklist rapide

- [ ] Sujet, titre retenu et émotion dominante récupérés au démarrage
- [ ] Les 4 piliers respectés sur chaque concept (clarté, émotion, qualité, cohérence)
- [ ] Le texte overlay complète le titre, il ne le répète pas
- [ ] Texte limité à 3-4 mots, police contrastée
- [ ] Visage à 30 % minimum, regard dirigé vers le texte ou l'objet
- [ ] Règle des tiers appliquée, direction de lecture claire
- [ ] Palette à 3 couleurs, dominante justifiée par l'émotion
- [ ] Contrastes vérifiés (fond/éléments 4.5:1, texte/fond 7:1)
- [ ] Lisibilité validée en format mobile réduit, marges 10 %
- [ ] 2 à 3 concepts variés en type pour permettre l'A/B test
- [ ] Brief livré au format structuré, exécutable tel quel
