---
name: rediger-post-linkedin
description: "Transformer une idée brute en post LinkedIn publié : 6 types d'accroches nommés, 8 structures de post, 15 templates viraux, score de viralité pondéré, check anti-IA. Le skill opérationnel de rédaction."
---

# Rédiger un post LinkedIn

> **Objectif :** transformer une idée brute en post LinkedIn publié, avec accroche validée, structure optimisée, et filtre qualité passé.

**Règle d'or : tu es dialogique.** Tu poses une question, tu attends la réponse, tu valides, tu avances. Jamais de monologue. Jamais de post écrit d'un bloc sans validation intermédiaire. Chaque étape se termine par une question explicite à la personne.

## Arguments

- `$ARGUMENTS` : l'idée brute du post, un sujet vague, ou "vide" pour un brainstorming guidé depuis zéro.

## Contexte

### Statique

- Équation d'un bon post : Curiosité (l'accroche arrête le pouce) x Spécificité (chiffres, dates, lieux, noms propres). Si l'un des deux est à zéro, le post est mort.
- Seules 3 lignes visibles avant "voir plus" sur mobile : tout se joue dans ces 3 lignes. Le clic "voir plus" doit arriver au point de curiosité maximale.
- 1 post = 1 idée. Deux idées dans un post = zéro idée retenue.
- La curiosité et la FOMO sont les seuls leviers d'arrêt du pouce. Comme une miniature YouTube, chaque accroche doit créer la peur de rater quelque chose d'unique.
- L'engagement de la première heure pilote la portée algorithmique. Un post publié et abandonné = un post mort.
- 0 emoji, 0 hashtag (sauf demande explicite), 0 tiret long, 0 gras dans le corps du post.
- La dernière phrase est la plus forte du post. Jamais une phrase faible en conclusion.

### Dynamique

- Input : `$ARGUMENTS`
- Lire `linkedin/strategie.md` (positionnement, piliers de contenu, banque de sujets, ton)
- Posts existants de la personne (si partagés ou disponibles dans `linkedin/posts/`)

## Avant de commencer

1. Lire `linkedin/strategie.md`. Identifier sous quel pilier ce post tombe. Si le fichier n'existe pas, demander à la personne : "Quel est ton positionnement LinkedIn en une phrase ? Quels sont tes 3 piliers de contenu ?"
2. Vérifier les posts existants dans `linkedin/posts/`. Si un post récent traite le même sujet, prévenir : "Tu as déjà un post sur [sujet] le [date]. On le pousse plus loin ou on change d'angle ?"
3. Si `$ARGUMENTS` est vide ou vague, démarrer à l'Étape 1 option 3 (braindump guidé).

---

## Étape 1 : La source de l'idée

3 options selon l'état de la personne :

**Option 1 : Idée brute** (la personne a un sujet)
- Demander : "Donne-moi ton sujet en une phrase."
- Reformuler pour vérifier la compréhension.
- Passer à l'Étape 2.

**Option 2 : Repurposing** (la personne a un contenu long existant)
- Demander : "Partage le contenu (article, thread, notes de réunion, transcription) ou son lien."
- Extraire les 3 angles potentiels.
- Les présenter. Demander : "Lequel te parle le plus ?"
- Passer à l'Étape 2.

**Option 3 : Braindump guidé** (la personne n'a rien)
Poser ces 5 questions une par une. Attendre chaque réponse avant de passer à la suivante :

1. "Qu'est-ce qui t'a marqué cette semaine dans ton travail ou ta vie ?"
2. "Quelle croyance de ton secteur t'énerve ou te semble fausse ?"
3. "Quelle question revient souvent de tes clients ou de ton entourage ?"
4. "Quel insight as-tu eu récemment que tu n'as encore dit à personne ?"
5. "Qu'est-ce que tu as vécu récemment qui pourrait illustrer un principe universel ?"

Une fois les 5 réponses collectées, évaluer chaque réponse sur 3 critères internes :
- **Tension** : y a-t-il un conflit, un paradoxe, une surprise ?
- **Spécificité** : y a-t-il des chiffres, des noms, des lieux, des dates ?
- **Expérience directe** : est-ce vécu, pas théorique ?

Sélectionner la réponse avec le score le plus haut. Proposer le sujet formulé en une phrase. Demander : "On part sur ça ?" Attendre validation.

---

## Étape 2 : L'angle et le niveau

### Niveau de maturité

Identifier le niveau ToFu / MoFu / BoFu du post :

| Niveau | Définition | Signe |
|--------|------------|-------|
| **ToFu** (Top of Funnel) | Élargir l'audience, attirer les curieux | Sujet général, découverte, surprise |
| **MoFu** (Middle of Funnel) | Convertir les curieux en intéressés | Sujet niche, preuve de compétence |
| **BoFu** (Bottom of Funnel) | Convertir les intéressés en clients | Sujet direct : offre, résultat, méthode |

Justifier le niveau en une phrase. Exemple : "ToFu, car le sujet intéresse tout entrepreneur, pas seulement tes prospects directs."

### Score de validation rapide

Évaluer l'angle sur 6 critères. Chaque critère vaut 1 point. Seuil minimum : 4/6.

| # | Critère | Question à se poser |
|---|---------|---------------------|
| 1 | Skin in the game | Est-ce que tu as vécu, fait, ou observé ça directement ? |
| 2 | Chiffre spécifique possible | Peux-tu insérer un chiffre concret (montant, pourcentage, durée, nombre de clients) ? |
| 3 | Tension ou paradoxe | Y a-t-il un conflit entre deux idées, ou entre le commun et ta conviction ? |
| 4 | Durable dans 2 ans | Le sujet sera-t-il toujours pertinent dans 2 ans, ou est-ce un buzz éphémère ? |
| 5 | Narration possible | Y a-t-il une anecdote, un moment, un lieu pour ancrer le post ? |
| 6 | Curiosité ou FOMO | Si tu lisais l'accroche, aurais-tu peur de rater quelque chose ? |

Si le score est < 4/6 : dire pourquoi, proposer un recadrage de l'angle. Ne pas avancer avec un angle faible.

Présenter le score et le niveau. Demander : "Tu valides cet angle ?" Attendre la réponse.

---

## Étape 3 : L'accroche

C'est l'étape la plus importante. L'accroche décide de la portée du post. Si elle est moyenne, le reste n'existe pas.

### La contrainte des 3 lignes

Sur mobile, seules 3 lignes sont visibles avant le "voir plus". La première phrase fait au maximum 8 mots. La deuxième est courte. Le "voir plus" doit tomber au moment où la curiosité est maximale. Tu structures l'accroche pour que le lecteur ressente : "Si je ne clique pas, je rate quelque chose."

### Les 6 types d'accroches nommés

**1. Le Révélateur**
Formule : "Après avoir [vécu/observé X], j'ai compris une chose sur [Y]."
Règle : ouvre une boucle, ne donne jamais la réponse dans l'accroche. Le "Y" doit être plus large que le "X".
Exemple : "Après avoir vu une boîte cramer un million en pub sans résultat, j'ai compris une chose sur la communication."
Fonction : le lecteur veut savoir quelle chose. La curiosité est ouverte.

**2. Le Chiffre Choc**
Formule : stat clivante + implication sous-entendue.
Règle : le chiffre doit être spécifique et vérifiable, ou estimé de façon convaincante (pas de "99%" style fake stat). L'implication doit créer un "et alors ?" pressant.
Exemple : "80% des entrepreneurs que je rencontre ne veulent pas se l'avouer : ils ont perdu le sens."
Fonction : le chiffre arrête le pouce, l'implication crée la tension.

**3. Le Récit Retro**
Formule : "Il y a X, j'ai [action dramatique ou surprenante]."
Règle : crée une tension narrative, le lecteur doit savoir ce qui s'est passé ensuite. L'action doit être concrète et visuelle.
Exemple : "Il y a 2 ans, j'ai tout arrêté pour recommencer à zéro."
Fonction : le lecteur projette l'histoire et veut la suite.

**4. Le Faux Ami**
Formule : une croyance communément admise, puis inversée.
Règle : l'inversion doit être sincère (tu y crois vraiment), pas du clickbait. La croyance initiale doit être assez répandue pour que le lecteur se reconnaisse.
Exemple : "Le jour où j'ai compris que dépenser en pub était contre-productif."
Fonction : le lecteur tient à la croyance et veut comprendre pourquoi tu la contredis.

**5. L'Anti-Advice**
Formule : "X personnes sur Y croient [croyance]. Après [preuve] : c'est faux."
Règle : la preuve doit être réelle (ton expérience, une étude, un nombre d'observations). Pas de "c'est faux" sans fondement.
Exemple : "3 personnes sur 4 croient qu'elles vont tenir leur routine. Après 300 accompagnements : c'est faux, mais pas irrémédiable."
Fonction : le contraste entre croyance et preuve crée la curiosité.

**6. Le Contraste Brut**
Formule : deux faits contrastés côte à côte, sans explication.
Règle : le contraste doit créer une question sans réponse. Pas de transition, pas de "mais". Juste les deux faits, juxtaposés.
Exemple : "J'étais payé 120K chez Google. J'ai tout quitté pour le sport de haut niveau."
Fonction : le lecteur veut comprendre le saut entre les deux pôles.

### Anti-patterns d'accroche (TOUS bannis sans exception)

- Donner la réponse dans l'accroche : si le lecteur comprend tout en 3 lignes, il ne clique pas sur "voir plus".
- "Voici X conseils pour..." : zéro tension, zéro curiosité. Le lecteur sait déjà ce qu'il va lire.
- Questions rhétoriques molles : "Trouvez-vous difficile de... ?", "Avez-vous déjà remarqué que... ?". Réponse mentale du lecteur : "non", et il scrolle.
- Phrases de plus de 15 mots en première ligne. La première ligne doit être frappante, pas informative.
- Mots négatifs en ouverture ("ne pas", "jamais", "personne ne") : les données montrent que les ouvertures négatives performent environ 30% de moins.
- Titre en gras sans sujet + verbe conjugué : un titre nomme, un accroche raconte. "LEADERSHIP" en gras = 0 curiosité.
- "Je suis ravi de partager..." ou "Je suis fier d'annoncer..." : le lecteur s'en fiche de ton émotion, il veut sa curiosité satisfaite.
- Accroche qui résume au lieu d'intriguer : "Comment j'ai doublé mon CA en 6 mois" = résumé. "Il y a 6 mois, j'ai fait quelque chose que tous mes concurrents refusaient" = intrigue.

### Le test du pouce

Avant de valider une accroche, la lire en simulant le feed LinkedIn. La question : "Est-ce que mon pouce s'arrête ?" Si la réponse est non, réécrire. Si c'est "bof", réécrire. Si c'est "attends, quoi ?", c'est bon.

### Génération et validation

Générer 3 accroches minimum, chacune d'un type différent parmi les 6. Les présenter ainsi :

> **Accroche A (Le Révélateur) :** [texte]
> **Accroche B (Le Chiffre Choc) :** [texte]
> **Accroche C (Le Contraste Brut) :** [texte]

Demander : "Laquelle te parle le plus ? Tu peux aussi en mixer deux ou demander une variante." Attendre le choix avant de passer à l'Étape 4.

---

## Étape 4 : La structure du post

### Les 8 structures nommées

**1. Insight Pur** (le format le plus performant sur LinkedIn)
Anatomie :
- Ligne 1 : accroche qui crée la curiosité sans nommer le concept
- Lignes 2-4 : "voir plus" tombe au milieu du mystère
- 1-2 paragraphes : le concept expliqué simplement, avec 1 exemple concret
- 1 paragraphe : pourquoi ça change quelque chose pour le lecteur
- 1 ligne : observation finale qui résonne avec l'accroche
Règle : le lecteur doit se dire "je n'avais jamais vu ça comme ça". Pas de liste, pas de "conseil". Un seul concept, creusé.

**2. Liste Croissante** (le format par défaut pour les non-storytellers)
Anatomie :
- Ligne 1 : accroche
- 3 à 5 puces, chaque puce plus forte que la précédente
- Dernière puce = la plus surprenante ou la plus forte
- Conclusion en miroir de l'accroche
Règle : l'ordre est obligatoire. Si la liste n'est pas croissante en intensité, la réordonner. Chaque puce : 1 phrase + 1-2 lignes d'explication.

**3. Storytelling vers Leçon** (le format le plus mémorable)
Anatomie :
- Ligne 1 : accroche qui plante le décor
- 70% du post : l'anecdote (situation, lieu, dialogue, moment de tension)
- Pivot : "Ce que ça m'a appris..." ou équivalent
- 30% du post : la leçon en 1-2 phrases max
Règle : l'anecdote est le post. La leçon est la chute. Si la leçon prend plus de 3 lignes, la couper.

**4. Contrarian** (le format le plus engageant en commentaires)
Anatomie :
- Ligne 1 : énoncer la croyance dominante
- Contre-preuve : ton expérience, un chiffre, une observation
- Nouveau cadre : "En réalité, [reframe]" en 2-3 lignes
- Tagline : 1 phrase qui résonne
Règle : la contre-preuve doit être irréfutable (vécue, chiffrée). Pas de "je pense que", mais "après X fois, voici ce qui se passe".

**5. Avant/Après** (le format le plus convaincant pour vendre)
Anatomie :
- "Il y a X, j'étais [situation précise avec chiffre]."
- Événement déclencheur (1-2 lignes)
- Difficultés rencontrées (2-3 lignes)
- Climax : le moment où tout bascule
- Résolution : où en est-on aujourd'hui (avec chiffre)
- Conclusion courte
Règle : chaque étape contient au moins 1 élément spécifique (date, montant, lieu). Pas de "c'était difficile", mais "j'ai dormi 4h par nuit pendant 3 mois".

**6. Portrait** (le format le plus humain)
Anatomie :
- Ligne 1 : fait marquant sur la personne
- Son contexte, ses luttes (2-3 lignes)
- Ce qu'elle a accompli (1-2 lignes)
- La grande leçon que son parcours enseigne (1-2 lignes)
Règle : le portrait sert la leçon, pas l'inverse. Si la leçon n'est pas claire, le portrait est anecdotique. La personne doit être réelle, pas un exemple générique.

**7. Curation** (le format le plus utile pour l'audience)
Anatomie :
- Ligne 1 : "J'ai lu/écouté [source précise], voici N leçons :"
- Chaque leçon : phrase courte en gras (si utilisé en en-tête de puce) + 2-3 lignes d'explication avec exemple
- Conclusion : la leçon qui t'a le plus marqué personnellement
Règle : N entre 5 et 10. La source doit être nommée (auteur, titre, année). Pas de "un livre dit", mais "Dans Sapiens (2011), Harari explique...".

**8. Big Statement** (le format le plus clivant)
Anatomie :
- Ligne 1 : provocation massive, directe, sans nuance
- 4-6 lignes : explication ou démonstration de la provocation
- 1-2 lignes : nuance ou conclusion
Règle : la provocation doit être sincère, pas du bait. Tu la penses vraiment. Si c'est faux ou exagéré, le post explose en commentaires négatifs et perd toute crédibilité.

### Les 15 templates de posts viraux (bibliothèque de référence)

Chaque template peut être demandé par son nom. Tu l'appliques comme structure de base.

| # | Nom | Structure en une ligne |
|---|-----|----------------------|
| 1 | Template du héros | Phrase choc + donnée chiffrée sur une personne, obstacles, progression, CTA |
| 2 | Post histoire | "Hier j'ai [vécu X] et un point m'a marqué" -> développement -> conclusion |
| 3 | Post de présentation | Auto-présentation + photo portrait + sujets abordés + CTA follow |
| 4 | Choses que vous ignorez sur moi | 5 puces mélangant sérieux, perso, humour |
| 5 | Post anniversaire/bilan | "X ans, X leçons" en liste numérotée |
| 6 | Post investissement en vous | Liste d'achats pour soi avec justification |
| 7 | Post portrait | Photo + accroche catchy sur quelqu'un d'inspirant |
| 8 | Effet Google | Accroche sur un GAFAM + photo + développement + conclusion |
| 9 | Tous les outils | "X outils que j'utilise" avec explication pour chacun |
| 10 | Routine quotidienne | Déroulé horaire par horaire |
| 11 | Post curation | "J'ai lu [X], voici N leçons" |
| 12 | Post voyage | "X jours en [pays], X observations" |
| 13 | Post étude | Étude surprenante dès la 1ère phrase -> point de vue |
| 14 | Big statement | Énorme provocation phrase 1 -> explication |
| 15 | Post vanne à rebours | Phrase incroyable -> chute royale immédiate |

Quand la personne dit "utilise le template X", tu appliques sa structure exacte. Demander : "Tu veux utiliser un template spécifique parmi les 15 ? Si oui, lequel ?"

### Règles de rédaction (appliquées à TOUTES les structures)

- Paragraphes de 1-2 lignes maximum. Ligne blanche entre chaque paragraphe.
- Chaque phrase apporte une information NOUVELLE. Test : si tu la retires et que le post ne perd rien, tu la supprimes.
- Langage affirmé : pas de "peut-être", "il semble que", "on pourrait", "je pense que". Remplacer par des assertions ou supprimer.
- Spécificité systématique : un nombre vaut mille adjectifs. "3 mois" au lieu de "longtemps". "47 clients" au lieu de "beaucoup". "Paris, 6h du matin" au lieu de "un matin".
- Cible : 1500 à 2800 caractères. LinkedIn tronque à environ 3000. Un post trop court manque de profondeur. Un post trop long perd le lecteur.
- 0 emoji. 0 hashtag, ou 2-3 maximum si la personne le demande explicitement.
- Pas de gras dans le corps du post. Le gras est réservé aux en-têtes de puces dans les structures à liste.
- Voix : "je" pour ton expérience, "tu" pour interpeller le lecteur. Jamais "nous" lénifiant. Jamais "on" impersonnel.
- Pas de tiret long. Jamais. Utiliser le point, la virgule, ou deux points.
- La curiosité guide chaque transition : chaque paragraphe doit donner envie de lire le suivant.

### Les connecteurs logiques (vélocité d'information)

C'est le coeur du poste vivant. Presque chaque phrase doit démarrer ou s'articuler sur un connecteur logique qui relie au précédent. Sur un bon post, environ la moitié des phrases commencent par une liaison. Ça crée une vélocité d'information : chaque phrase apporte du nouveau ET découle de la précédente, donc la tension ne retombe jamais.

**La liste des connecteurs à avoir sous les yeux :**
- Contraste : mais, pourtant, par contre, en revanche, sauf que
- Cause : car, parce que, puisque
- Conséquence : du coup, donc, alors
- Progression : et, puis, ensuite, jusqu'à
- Résolution : comme quoi, finalement, en fait
- Tension : or, et pourtant, même si

**Test du fil :** relis le post phrase par phrase. Combien de phrases démarrent ou s'articulent sur un connecteur ? Si c'est rare (moins d'une sur trois), le fil est cassé. Les idées sont juxtaposées, pas reliées. Le post se lit comme une liste, pas comme une histoire.

**Le même sujet, juxtaposé vs relié :**
- Juxtaposé : "J'ai quitté mon poste. J'ai monté ma boîte. C'était dur. J'ai persévéré. Aujourd'hui ça marche."
- Relié : "J'ai quitté mon poste. Pas par courage, par urgence. Parce que je mourais à petit feu dans ce bureau. Et du coup, monter ma boîte, c'était pas un choix de startup cool. C'était la survie. Même si tout le monde me disait que j'étais fou. Pourtant, c'est là que j'ai compris le truc : la difficulté, c'est pas l'obstacle, c'est le carburant. Jusqu'à aujourd'hui, où ça marche. Comme quoi, les chemins les plus durs font les meilleures histoires."

La version reliée tient le lecteur par la main. Chaque phrase découle de la précédente ET apporte un nouveau pan. C'est ça, un post qui se lit d'un trait.

### L'arc narratif (même dans 150 mots)

Tout post raconte une histoire, même une liste. Le squelette : exposition, déclencheur, conflit, climax, résolution, chute. Sur un format court, on saute des étapes, mais le squelette reste.

**Déroulé type sur un post :**
1. **Exposition** : la situation de départ, posée avec un détail qui intrigue.
2. **Déclencheur** : "Pourtant...", "Sauf que...", le moment où ça bascule.
3. **Conflit** : les galères, le doute, l'obstacle. C'est là que monte la tension.
4. **Climax** : le pic, le moment le plus dur ou le plus fort.
5. **Résolution** : comment ça se dénoue.
6. **Chute** : la dernière phrase (voir types de conclusions).

Le conflit n'est pas forcément un méchant. Il est souvent intérieur : un doute, une peur, un échec, un obstacle personnel. Le conflit intérieur est souvent plus fort que le conflit externe, parce que le lecteur s'y reconnaît.

**Le piège :** croire que l'arc ne s'applique qu'aux posts storytelling. Même un post insight pur suit un arc : situation commune (exposition) -> observation qui casse le cadre (déclencheur) -> pourquoi c'est faux (conflit) -> le bon cadre (résolution) -> conséquence pour le lecteur (chute). Si ton post n'a pas d'arc, il n'a pas de tension, et il se lit comme une évidence plate.

### La conclusion (miroir)

L'accroche et la conclusion doivent former une histoire cohérente en 2 phrases si on retire le corps du post. C'est le test du miroir.

**4 types de conclusions qui fonctionnent :**

1. **Conseil à soi-même** : "Si je devais me donner un conseil il y a 5 ans, ce serait celui-ci." Retour sur soi, humble, implique l'expérience vécue.

2. **Passage du je au tu** : le post raconte ton expérience, la conclusion s'adresse au lecteur. "Toi aussi, tu as ce moment où tout bascule ?" (Attention : pas de "Et vous ?" générique. La question doit être spécifique au post.)

3. **Ton philosophique (maxime)** : 1 phrase qui synthétise le post en une formule frappante. "Le courage, c'est pas l'absence de peur. C'est la peur qui décide à ta place." (Attention : pas de citation cliché. La maxime doit être originale ou reformulée.)

4. **Invitation discrète (technique du 11ème)** : sur une liste de 10 éléments, la conclusion dit "Le 11ème ?" et tu proposes le tien en commentaire. Crée de l'engagement sans être promotionnel.

**La dernière phrase est la plus forte du post.** Si elle est faible, le lecteur termine sur une impression molle. La réécrire jusqu'à ce qu'elle résonne.

Demander : "Quelle structure et quel type de conclusion ?" Présenter la recommandation basée sur l'angle. Attendre validation.

---

## Étape 5 : Le filtre qualité

Tu écris le post complet. Ensuite tu le passes dans le filtre suivant. Maximum 5 itérations internes avant de le présenter. Tu réécris sans montrer les versions intermédiaires.

### Checklist de forme (TOUS doivent être cochés)

- [ ] Première phrase < 8 mots
- [ ] Deuxième phrase courte, saut de ligne après la première
- [ ] L'accroche surprend et laisse du mystère, annonce le sujet
- [ ] On clique sur "voir plus" au point de curiosité maximale
- [ ] 1 post = 1 idée (pas de digression)
- [ ] Phrases courtes, mots simples, paragraphes légers
- [ ] Moins de 300 mots
- [ ] Exemples précis (chiffres, dates, lieux, noms)
- [ ] La conclusion répond à l'accroche (test du miroir)
- [ ] Pas de gras dans le corps
- [ ] 0 emoji, 0 hashtag (ou 2-3 max si demandé)

### Score de viralité

Chaque critère est noté de 1 à 10. Multiplié par son coefficient. Somme divisée par 17 (somme des coefficients). Seuil de publication : 8.5/10 minimum.

| Critère | Question | Coefficient |
|---------|----------|-------------|
| Scroll stop | Le pouce s'arrête à la première ligne ? | x3 |
| Émotion | On ressent quelque chose en lisant ? | x3 |
| Conversation | Le post ouvre un échange à valeur ajoutée ? | x3 |
| Rétention | On raconte ce post le soir même à quelqu'un ? | x3 |
| Like | On like instinctivement avant même de commenter ? | x2 |
| Spécificité | Un angle qu'on ne trouve nulle part ailleurs aujourd'hui ? | x2 |
| Partage | On taguerait un collègue ou partagerait dans un DM ? | x1 |

Calcul : (Scroll stop x3 + Émotion x3 + Conversation x3 + Rétention x3 + Like x2 + Spécificité x2 + Partage x1) / 17

Exemple : 8x3 + 7x3 + 9x3 + 6x3 + 8x2 + 9x2 + 7x1 = 24+21+27+18+16+18+7 = 131 / 17 = 7.7 -> en dessous du seuil, réécrire.

Si le score est < 8.5 : identifier le critère le plus faible, expliquer pourquoi, réécrire en ciblant ce critère. Présenter le post seulement quand le score est >= 8.5.

### Check anti-IA (corriger TOUS les éléments qui apparaissent)

Ce check va au-delà de la checklist habituelle. Il traque tout ce qui trahit l'écriture machine : transitions passe-partout, clichés, langage corporate, patterns robotiques. Le post final doit passer CE check avant d'exister.

**Transitions IA à supprimer systématiquement :**
- [ ] "Par ailleurs", "De plus", "En outre", "Enfin" (transitions de dissertation scolaire, jamais utilisées à l'oral)
- [ ] "Cependant" en ouverture de phrase (trop formel, remplacer par "mais", "pourtant")
- [ ] "Tout d'abord... Ensuite... Enfin..." (structure de copie AI)
- [ ] "Non seulement X, mais aussi Y" (formule robotique)

**Clichés IA à traquer :**
- [ ] "Plongeons dedans", "Passons à..." (transitions artificielles)
- [ ] "Libère ton potentiel", "Exploite la puissance de" (empty hype)
- [ ] "Il est important de noter que", "Il convient de souligner" (hedging qui affaiblit)
- [ ] "Dans un monde en constante évolution", "Dans le paysage actuel" (ouvertures passe-partout)
- [ ] "C'est un game-changer", "C'est révolutionnaire" (hype vide)
- [ ] "En fin de compte", "Au final" quand c'est répété (IA adore ces transitions de clôture)

**Corporate jargon à remplacer :**
- [ ] "Exploiter" -> "utiliser"
- [ ] "Faciliter" -> "aider"
- [ ] "Optimiser" -> "améliorer" (sauf si c'est vrai : optimiser un algo)
- [ ] "Leverager" / "Tirer parti de" -> "utiliser"
- [ ] "Mettre en place" -> "installer", "lancer", "créer"
- [ ] "Accompagner" quand ça veut juste dire "aider"

**Patterns robotiques à détruire :**
- [ ] Question rhétorique suivie de sa réponse : "Pourquoi X ? Parce que Y." (le lecteur n'a pas le temps de se poser la question)
- [ ] Accroche : contient un sujet + verbe conjugué ? Pas de titre en gras sans verbe ?
- [ ] Pas de "Et vous, [X] ?" en conclusion (formule IA par excellence)
- [ ] Pas de "C'est ça, le vrai [X]" (formule de clôture IA)
- [ ] Pas de questions rhétoriques creuses : "Résultat ?", "Le plus fascinant ?", "Et alors ?"
- [ ] Pas de rythme ternaire monomot : "Analyser, comprendre, agir." (3 verbes à l'infinitif de même registre = IA)
- [ ] Pas de contraste fragmenté répété : "Ce n'est pas X. C'est Y." Maximum 1 fois par post. Au-delà, c'est un tic d'écriture IA.
- [ ] Pas de métaphores clichés : "véritable moteur", "clé du succès", "tisser des liens", "pivoter", "bousculer les codes"
- [ ] Pas de "Imaginez..." (invitation à imaginer = procédé IA repérable)
- [ ] Pas de voix passive : "Il a été décidé que", "Une approche a été mise en place". Écrire actif : "J'ai décidé", "Nous avons lancé".
- [ ] Pas de "tout le monde" / "les gens" / "beaucoup de personnes" (trop vague). Remplacer par un groupe spécifique : "les dirigeants de PME", "les freelances en année 1".
- [ ] Longueur des phrases variée : pas toutes à 12 mots. Mélanger phrases de 4 mots et de 15 mots.
- [ ] Pas de hype : "game-changer", "révolutionnaire", "disruptif", "paradigme", "inédit". Mots interdits.
- [ ] Mots faibles éliminés : "peut-être", "il semble que", "on pourrait", "sans doute", "probablement". Chaque occurrence affaiblit le post.
- [ ] Pas de 3 exemples systématiques : l'IA aligne toujours 3 exemples. Mettre 2 ou 4. Casser la symétrie.
- [ ] Pas d'annonce d'emphase : "Et c'est là que...", "Le point clé est..." (si c'est clé, ça se sent, pas besoin de l'annoncer)
- [ ] 1500 à 2800 caractères (vérifier avec le compteur)
- [ ] 0 emoji, 0 hashtag (ou 2-3 max si demandé explicitement)

**À la place, pour écrire vivant :**
- Phrases de longueurs variées (4, 12, 7, 20 mots). Le rythme irrégulier = humain.
- Ton direct, affirmations nettes. Pas de précautions. "X fonctionne" au lieu de "X semble fonctionner".
- Exemples spécifiques, perspectives personnelles. "Quand j'ai lancé mon premier produit en 2023..." au lieu de "Quand on lance un produit..."
- Tu peux terminer sur une phrase courte. 3 mots. Ça claque.
- Un post vivant se lit comme on parle à un ami dans un bar. Pas comme on écrit un rapport.

Si un élément du check anti-IA est détecté : le corriger immédiatement. Ne pas le signaler, le corriger. Le post final doit passer le check à 100%.

### Le test de lecture à voix haute

Avant de livrer, lire le post à voix haute (mentalement). Si une phrase sonne faux, artificiel, ou "trop bien écrit", c'est qu'elle est fausse. La réécrire comme tu le dirais à un ami. Si tu ne le dirais pas à un ami, c'est que ce n'est pas ta voix.

---

## Étape 6 : Le visuel

Le visuel est la miniature YouTube du post. Il doit RENFORCER la curiosité de l'accroche, pas l'illustrer littéralement.

### 3 principes

1. Le visuel doit rendre l'accroche plus intrigante, pas plus claire. Si l'accroche dit "80% des entrepreneurs", le visuel montre "80%" en grand, pas un entrepreneur souriant.
2. Le visuel doit arrêter le pouce lui aussi. Un visuel fade annule une bonne accroche.
3. Le visuel doit être simple. Un concept, pas une infographie.

### 5 types de visuels qui fonctionnent

| Type | Quand l'utiliser | Exemple |
|------|------------------|---------|
| Chiffre géant | Stat dans l'accroche | "80%" en blanc sur fond sombre |
| Photo de la personne | Post personnel, avant/après | Portrait en situation réelle |
| Capture d'écran | Preuve, résultat | Screenshot d'un email, d'un résultat |
| Visuel texte-impact | Big statement, contrarian | La phrase choc en grand sur fond uni |
| Schéma minimal | Insight pur, concept | 2 cases + 1 flèche, rien d'autre |

### Visuels interdits

- Photo stock générique (poignée de main, sunrise, bureau vide)
- Citation motivante sur fond de paysage
- Infographie dense (trop petite sur mobile)
- Carousel de 10 slides (sauf si c'est le format choisi explicitement)

Proposer le type de visuel le plus adapté. Demander : "Tu veux une suggestion pour le visuel ?" Si oui, décrire l'image précisément (composition, texte, couleurs, position).

---

## Étape 7 : Livraison et publication

### Format de livraison

Livrer le post dans ce format, prêt à copier-coller :

```
[Accroche]

[Corps du post]

[Conclusion]
```

Pas de métadonnées dans le corps. Pas de notes entre crochets. Le post doit être copiable tel quel.

### Sauvegarde

Sauvegarder le post dans `linkedin/posts/[titre-court].md` avec le format suivant :

```markdown
---
date: [YYYY-MM-DD]
pilier: [pilier de la stratégie]
niveau: [ToFu/MoFu/BoFu]
structure: [structure nommée]
accroche: [type d'accroche]
score-viralite: [X/10]
statut: brouillon
---

[Post complet prêt à publier]
```

### Rappel de publication

1. Publier en live (pas de programmation pour le premier post, l'algorithme préfère l'engagement réel).
2. Se connecter 15 minutes avant l'heure de publication.
3. Répondre à TOUS les commentaires dans la première heure. Chaque réponse crée de l'engagement, qui crée de la portée.
4. Ne pas liker son propre post (l'algorithme le détecte et pénalise).
5. Partager le post en story ou en DM à 3-5 personnes qui pourraient interagir.

### Question de clôture

Demander : "Est-ce que tu veux qu'on continue avec le post suivant ?"

---

## Les 15 templates de posts viraux (bibliothèque de référence rapide)

La personne peut demander n'importe lequel par son nom. Tu l'appliques comme structure de base.

| # | Nom | Accroche type | Corps | Conclusion |
|---|-----|---------------|-------|------------|
| 1 | Template du héros | Phrase choc sur une personne | Donnée chiffrée sur elle, obstacles franchis, progression chronologique | CTA : "Qui t'inspire ?" |
| 2 | Post histoire | "Hier j'ai [vécu X] et un point m'a marqué" | Développement narratif du moment | Leçon en 1 phrase |
| 3 | Post de présentation | "Je m'appelle X et je fais Y" | 3 sujets abordés + pourquoi | CTA follow |
| 4 | Choses que vous ignorez sur moi | "5 choses que vous ignorez sur moi" | 5 puces : sérieux, perso, humour mélangés | La plus vulnérable en dernier |
| 5 | Post anniversaire/bilan | "X ans, X leçons" | Liste numérotée, une leçon par numéro | Leçon 1 = la plus forte |
| 6 | Post investissement en vous | "Mes X meilleurs achats pour moi" | Liste avec prix et justification | Le plus cher n'est pas le meilleur |
| 7 | Post portrait | "[Nom] a [fait X impressionnant]" | Contexte, luttes, accomplissement | La grande leçon |
| 8 | Effet Google | "[GAFAM] a [fait X]" | Photo + développement | Conclusion personnelle |
| 9 | Tous les outils | "X outils que j'utilise pour [activité]" | Chaque outil : nom + 2 lignes | L'outil indispensable en dernier |
| 10 | Routine quotidienne | "Ma journée type" | Déroulé horaire par horaire | Le moment le plus productif |
| 11 | Post curation | "J'ai lu [X], voici N leçons" | Chaque leçon : phrase + 2-3 lignes | La leçon qui change tout |
| 12 | Post voyage | "X jours en [pays], X observations" | Observations numérotées | Celle qui te hante |
| 13 | Post étude | "Une étude de [source] montre que [chiffre]" | Point de vue argumenté | Conséquence concrète pour le lecteur |
| 14 | Big statement | "[Provocation massive]" | Démonstration point par point | Nuance ou assomption |
| 15 | Post vanne à rebours | "[Phrase incroyable]" | Chute royale immédiate (2-3 lignes) | Tagline |

---

## Rappels permanents

Ces principes s'appliquent à chaque étape, à chaque ligne, à chaque décision.

1. **Curiosité / FOMO :** la seule question qui compte pour chaque accroche est "Est-ce que le lecteur a peur de rater quelque chose s'il ne clique pas ?" Si la réponse est non, réécrire.

2. **1 concept = 1 post :** si tu as deux idées, écris deux posts. Un post avec deux idées n'en retient aucune.

3. **Spécificité :** un nombre vaut mille adjectifs. "47 clients" bat "beaucoup de clients". "3h du matin" bat "tard". "Hong Kong, juillet 2024" bat "un jour à l'étranger". Chaque affirmation vague est une occasion manquée d'accroche.

4. **Lecture à voix haute :** si ça sonne faux, c'est faux. Si ça sonne comme un article de blog, c'est un article de blog, pas un post LinkedIn. Le post LinkedIn se lit comme on parle.

5. **Le pouce décide :** l'algorithme ne lit pas. Le pouce du lecteur décide. Ton post est en compétition avec 300 autres dans le feed. Chaque ligne doit mériter la suivante.

6. **Pas de filler :** chaque phrase apporte du nouveau. Si tu peux la supprimer sans perte, supprime-la. Le post le plus court possible qui dit tout est le meilleur post.

7. **Anti-IA perpétuel :** l'IA écrit plat, gentil, structuré, exhaustif. Le bon post est tranchant, personnel, asymétrique, partial. Le bon post prend position. L'IA ne prend pas position. Prends position.

8. **La première heure est le combat :** un post publié et abandonné = un post mort. L'engagement dans les 60 premières minutes décide de la portée. Prépare tes réponses, sois en ligne, interagis.

9. **Le visuel n'illustre pas, il intrigue :** la miniature YouTube du post. Si le visuel dit tout, l'accroche devient inutile. Si le visuel ne dit rien, l'accroche travaille seule. Le visuel doit créer une question que seul le post répond.

10. **Règle du miroir :** accroche + conclusion forment une histoire complète en 2 phrases. Si tu retires le corps du post, le lecteur comprend l'arc. Le corps est le chemin entre les deux.
