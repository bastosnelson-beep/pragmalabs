---
name: ideation-video
description: "Générer 100 idées de vidéos en combinant quatre méthodes : ce que j'ai à dire, les insights, le croisement valeurs x croyances x sujets, et le cocon SEO. Puis prioriser les premières à tourner."
---

# Idéation vidéo : trouver de nouvelles idées

> **Objectif :** générer une liste d'au moins 100 idées de vidéos, puis prioriser les premières à tourner, en combinant quatre méthodes complémentaires.

L'objectif de l'idéation n'est pas une idée, c'est un STOCK. Une réserve d'au moins 100 sujets dans laquelle tu piochera chaque semaine, au lieu de chercher dans l'angoisse de la page blanche. Stocke-les idéalement dans une carte mentale (plus lisible qu'une liste, elle montre dans quelle thématique tombe chaque idée).

**Règle d'or : tu es dialogique.** Tu fais faire les exercices à la personne, tu proposes, tu attends ses réponses, et tu enrichis sa carte au fil de l'eau.

## Arguments

- `$ARGUMENTS` : thématique ou niche de la chaîne (optionnel, sinon on la clarifie ensemble).

## Démarrage

Avant de générer, poser ces questions en une seule fois :

> "Pour t'aider à trouver tes idées, dis-moi :
> 1. C'est quoi ta niche et tes 3 à 5 grandes thématiques ?
> 2. Quelles sont tes valeurs fortes et tes croyances contrariennes sur ce sujet ?
> 3. Tu veux qu'on parte de toi (ce que tu as à dire), du marché (SEO), ou des deux ?"

Les quatre méthodes ci-dessous se combinent : la 1 et la 2 partent de toi, la 3 crée de l'original par croisement, la 4 part de la demande réelle du marché.

---

## Méthode 1 : Ce que j'ai à dire

C'est le vidage rapide de ce que tu sais déjà. Le plus simple, et le plus toi.

1. Carte mentale : au centre "idées de sujets". Autour, les grandes thématiques. Sous chacune, les sous-branches.
2. Pour chaque branche, mets un chrono de 2 minutes et vide tout ce que tu pourrais transmettre, sans t'arrêter avant la fin du temps.
3. Fais-le sur toutes les branches.

Résultat attendu : 50 à 100 sujets en une à deux heures. Propose à la personne de lancer le chrono branche par branche, et note tout ce qu'elle sort.

---

## Méthode 2 : Insights et valeurs

C'est l'approche la plus différenciante. Au lieu de demander "de quoi j'ai envie de parler ?", on cherche "quelle perspective neuve je peux apporter ?". Un insight crée un wow moment : le spectateur comprend quelque chose qu'il n'avait jamais vu sous cet angle.

Rappelle l'équation : Résonance (histoires, pertinence) x Nouveauté (perspective inédite). Un sujet banal avec un angle neuf bat un sujet brillant déjà vu cent fois.

```
Exemple :
- Plat : "Les meilleures applications de prise de notes."
- Avec insight : "Pourquoi les apps de notes par silo t'empêchent de penser."
```

Pour chaque sujet, demande : "c'est quoi MON insight original ici, ce que la plupart des gens ne disent pas ?".

---

## Méthode 3 : Le croisement valeurs x croyances x sujets

C'est le moteur à insights. On génère de l'original en croisant trois listes.

1. **Tes valeurs** : ce qui compte profondément pour toi (souveraineté, simplicité, lenteur, liberté...).
2. **Tes croyances contrariennes** : ce que tu penses et qui va contre le consensus de ta niche ("la plupart des gens font X, c'est une erreur").
3. **Tes sujets** : les thématiques de la méthode 1.

Puis on croise : prends un sujet, applique-lui une valeur ou une croyance, et regarde l'angle qui naît.

```
Sujet (prise de notes) x croyance ("prendre plus de notes ne sert à rien")
-> "Arrête de prendre des notes : voilà ce qui marche à la place."

Sujet (productivité) x valeur (lenteur)
-> "La productivité lente : faire moins pour produire plus."
```

Fais l'exercice avec la personne : liste valeurs et croyances, puis génère 10 à 20 angles par croisement. Ce sont souvent les meilleurs titres.

---

## Méthode 4 : Le cocon SEO

L'approche la plus pragmatique : elle part de ce que les gens cherchent, pas de ce que tu veux dire. C'est elle qui construit un socle de vidéos qui ramènent des abonnés pendant des années.

1. Prends un abonnement Ahrefs (offre Beginner, autour de 27 euros par mois) et ouvre le Keyword Explorer. Travaille en anglais sur le marché US : plus de volume, outil mieux entraîné.
2. Pour chaque mot-clé, lis : le **Volume** de recherche, la **Keyword Difficulty** (vise bas quand tu débutes, en dessous de 46) et l'intention derrière.
3. Explore trois onglets pour faire émerger des idées :
   - **Matching terms** : les mots-clés qui contiennent ton terme.
   - **Related terms** : les termes proches mais différents.
   - **Search suggestions** : les vraies intentions tapées par les gens.
4. Ajoute tout ce qui résonne à une keyword list, et recoupe sur YouTube en tapant le mot-clé pour voir ce qui ressort et comment te différencier.

Le principe du cocon : un maillage de vidéos qui répondent à des questions proches, qui se renvoient les unes aux autres et couvrent une niche en profondeur.

---

## Priorisation : par où commencer

Une fois la liste constituée, ne tourne pas dans le désordre.

- Commence par les vidéos **fondamentales et SEO** de ta niche : celles qui répondent aux questions les plus recherchées. Elles forment ton assise et ton flux d'abonnés régulier.
- Garde un oeil sur le ratio effort / potentiel : une vidéo à fort volume et faible difficulté passe avant une vidéo de niche pointue.
- Diversifie ensuite vers les sujets plus personnels, une fois le socle posé (par exemple tes 20 premiers sujets fondateurs).

Aide la personne à classer ses idées en trois piles : socle SEO à faire d'abord, sujets à insight forts, sujets plaisir pour plus tard.

---

## Sortie attendue

- Une carte mentale (ou liste) d'au moins 100 sujets, rangés par thématique.
- Pour les meilleurs, un angle et un insight associés (issus des méthodes 2 et 3).
- Une short-list de 20 sujets prioritaires, avec pour chacun son origine (SEO, insight, plaisir).

Quand un sujet est choisi, enchaîne avec le skill `/creer-video-youtube` pour le transformer en vidéo, puis `/titres-youtube` et `/miniatures-youtube` pour le packaging.

## Checklist rapide

- [ ] Carte mentale créée, grandes thématiques posées.
- [ ] Méthode 1 (chrono 2 min par branche) passée sur toutes les branches.
- [ ] Insights cherchés sur les meilleurs sujets (méthode 2).
- [ ] Valeurs et croyances listées, croisées avec les sujets (méthode 3).
- [ ] Cocon SEO exploré (volume, difficulté, matching / related / suggestions).
- [ ] Au moins 100 sujets, dont 20 prioritaires classés (socle SEO d'abord).
