---
status: active
start: 
end_estimated:
---

Période estimée : [start] - [end estimated]

## Objectif n°1
<!-- Rempli pendant /initialisation-entreprise : la chose la plus importante pour ce cycle. -->

## Mouvements clés
- [ ] [Mouvement 1]
- [ ] [Mouvement 2]
- [ ] [Mouvement 3]

## Contraintes
<!-- Temps disponible, budget, capacité de l'équipe, non-négociables. -->

## Definition of done
<!-- Qu'est-ce qui est vrai quand ce cycle se termine ? -->

## Stratégie par état

### Quand surchargé (firefighting)
- 

### Quand concentré
- 

### Quand en flow
- 

## Cadence de revue
- La revue hebdo s'aligne à ce cycle : [[Revues Hebdo/]]
- Log des décisions : [[Logs/]]
