---
type: context
status: active
---

# Cycles Stratégiques

## Description

Le système de journaling et de focus de l'entreprise, organisé par « cycles stratégiques ». Un cycle est une période de 2-3 mois avec un seul objectif dominant (n°1). Quand le focus change (nouvelle stratégie, nouveau marché, pivot), on ouvre un nouveau cycle.

## Principe

Chaque cycle a :
- Un **numéro** et un **nom évocateur**
- Une **intention de départ** (objectif n°1, mouvements clés, contraintes, definition of done)
- Des **revues hebdo** alignées dessus (dans `2 Domaines/Pilotage/Revues Hebdo/`)
- Une **revue de clôture** quand le cycle se termine (puis archivé ou gardé avec `status: completed`)

## Structure

```
Vision & Contexte/
└── Cycles Stratégiques/
    ├── Cycles Stratégiques.md          <- cet index
    ├── Cycle Stratégique - 1 [nom].md  <- intention du cycle actuel
    └── ...
Logs/                             <- log des décisions stratégiques (dossier frère)
```

## Commandes

- `/new-strategic-cycle-team-member` - bilan individuel d'un membre en fin de cycle (conclusion, leçons, constat sur les mouvements clés, intention pour le prochain cycle). Lancé par chaque membre. Output : `2 Domaines/Pilotage/Bilans de Cycle/[N] [nom]/Bilan Cycle - [membre].md`.
- `/new-strategic-cycle-manager` - reprend tous les bilans individuels, fait le bilan du manager, synthétise, et ouvre le prochain cycle. Lancé par le manager après les bilans de l'équipe. Output : `Synthèse Cycle - [N] [nom].md` plus le nouveau `Cycle Stratégique - [N+1] [nom].md`.

## Cycles

| # | Nom | Période | Statut |
|---|------|--------|--------|
| 1 | Initial | [défini pendant /initialisation-entreprise] | active |

## Cycle actuel

-> [[Cycle Stratégique - 1 Initial]]
