---
type: context
status: active
---

# Organigramme

## Description

Un fichier par membre de l'équipe dans ce dossier. Chaque fichier capture le rôle, le périmètre, les droits de décision, et le profil de voix (pour que l'IA calibre les comms par personne et que l'équipe sache qui décide quoi).

## Principe

- 1 fichier par personne, nommé `Prénom Nom.md`
- Rempli pendant /initialisation-entreprise, mis à jour quand les rôles changent
- Recoupé avec [[Vision]] avant les comms externes

## Équipe

| Nom | Rôle | Fichier |
|------|------|------|
| [Prénom Nom] | [rôle] | [[Prénom Nom]] |

## Qui décide quoi

<!-- Une matrice rapide : domaine de décision -> propriétaire. Rempli pendant l'init. -->
