---
type: value-engine
status: active
maj: 
---

# Moteur de Valeur

## Comment nous créons de la valeur

<!-- Rempli pendant /initialisation-entreprise. Le moteur de valeur est le système qui transforme l'attention du marché en chiffre récurrent et en réputation. -->

## Acquisition
<!-- Comment les clients nous trouvent : referrals, appels d'offres, contenu, site, partenariats. Ce qui marche le mieux. -->

## Ventes
<!-- Comment un prospect devient un projet signé : discovery call, proposition, négociation, closing. -->

## Delivery
<!-- Le parcours typique d'un projet de A à Z : brief -> ... -> handover. Jalons, qui fait quoi. -->

## Rétention
<!-- Comment on garde les clients et on gagne des projets récurrents : account management, qualité, upsell. -->

## La boucle
<!-- Comment la valeur se recrée : réputation -> referral -> nouveau projet. -->

## Goulots
<!-- Les points de blocage identifiés. Où le moteur cale. -->

## Canvas
<!-- Un Moteur de Valeur.canvas visualise ce flux. Généré pendant /initialisation-entreprise. -->
