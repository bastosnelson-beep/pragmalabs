---
type: vision
status: active
entreprise: ""
tagline: ""
juridiction: ""
cycle_strategique: ""
maj: 
---

# {{title}}

## En bref
<!-- Rempli pendant /initialisation-entreprise : qui, quoi, pour qui. 1 paragraphe. -->

## Positionnement
<!-- Les vrais différenciateurs, pas du marketing. -->

## Marché & clients
<!-- Segments, types de clients nommés, géographie. -->

## Historique
<!-- Les points de bascule, chronologique. -->

## North Star
<!-- La métrique qui nous dit qu'on gagne. -->

## Vision (5 ans)
<!-- Marché, effectifs, offre, géographie. -->

## Ce qui ne change jamais
<!-- Principes inviolables, la façon dont on livre. -->

## Voix de marque
<!-- Comment parle l'entreprise. Ton, registre, à faire et à ne pas faire. Référence pour toutes les comms externes et /de-ai-ify. -->
