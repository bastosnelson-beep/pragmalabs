---
type: index
status: active
---

# Services API, CLI et MCP disponibles

Le catalogue de services de l'entreprise. Une note par outil que l'équipe a connecté. C'est comme ça que marche le partage : quand un membre de l'équipe a besoin d'un outil, son IA scanne ce dossier, trouve la note du service, et installe l'outil localement en suivant les instructions.

## Comment utiliser ce dossier

**Pour connecter un nouvel outil :** lance `/connect-tool [outil]`. Le skill recherche la meilleure méthode, l'installe, et crée une note ici si l'outil est company-scoped.

**Pour installer un outil qu'un teammate a déjà configuré :** scanne ce dossier, ouvre la note de l'outil, suis la section « Comment installer ». Récupère les credentials depuis la source référencée (1Password, env var, ou le propriétaire). Ne colle jamais de secrets dans le vault.

## Services

| Outil | Méthode | Scope | Propriétaire | Note | Statut |
|------|--------|-------|-------|------|--------|
| [Outil] | [MCP / CLI / API / HTTP] | company | [propriétaire] | [[Outil]] | active |

<!-- Ajoute une ligne par service connecté. Créé par /connect-tool. -->
