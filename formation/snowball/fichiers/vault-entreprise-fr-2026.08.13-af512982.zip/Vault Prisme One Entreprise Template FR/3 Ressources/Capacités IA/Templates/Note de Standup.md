---
type: standup
date: {{date}}
run_by: ""
---

# {{date}}

## Sur quoi je travaille aujourd'hui

- 

## Blockers

- 

## Handoffs nécessaires

- À [personne] : [ce dont elle a besoin de moi / j'ai besoin d'elle]
