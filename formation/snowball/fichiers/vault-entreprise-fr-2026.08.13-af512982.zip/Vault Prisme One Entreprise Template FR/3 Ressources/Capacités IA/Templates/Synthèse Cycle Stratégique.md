---
type: cycle-synthesis
strategic_cycle: "[[Cycle Stratégique - nom]]"
prepared_by: "[manager]"
based_on_reviews: []
next_cycle: "[[Cycle Stratégique - prochain nom]]"
status: active
---

Période exacte : [start] - [Date fin]

## Bilan du manager

### Conclusion globale

[En quelques phrases, comment résumes-tu ce cycle, du point de vue du manager ?]

### Les leçons que j'ai apprises

-
-

### Constat factuel sur l'objectif n°1 et les mouvements clés

[Objectif n°1 et mouvements clés de l'intention du cycle, pré-remplis depuis l'intention, à valider.]

| Élément | Résultat |
|---|---|
| Objectif n°1 | [Atteint / Partiellement / Non atteint] |
| [Mouvement 1] | [Atteint / Partiellement / Non atteint] |
| [Mouvement 2] | [Atteint / Partiellement / Non atteint] |
| [Mouvement 3] | [Atteint / Partiellement / Non atteint] |

### Ce que j'aimerais améliorer pour le prochain cycle

-
-

## Synthèse des bilans d'équipe

### [[membre 1]] ([rôle])

- **Conclusion :**
- **Leçons :**
- **Constat sur les mouvements clés :**
- **Intention pour le prochain cycle :**
- **Ce dont il/elle a besoin :**

### [[membre 2]] ([rôle])

- **Conclusion :**
- **Leçons :**
- **Constat sur les mouvements clés :**
- **Intention pour le prochain cycle :**
- **Ce dont il/elle a besoin :**

## Synthèse globale

### Ce qui a marché

-

### Ce qui n'a pas marché / à améliorer

-

### État de l'objectif n°1 du cycle

[Atteint / Partiellement / Non atteint. Ce qui reste à faire.]

## Recommandations pour le prochain cycle

[Construites depuis la synthèse d'équipe + le bilan du manager + Vision. La définition détaillée du prochain cycle vit dans le fichier du cycle lui-même.]

### Objectif n°1 proposé

-

### Mouvements clés proposés

-
-
-

### Contraintes identifiées

-

### Definition of done proposée

-

## Prochain cycle

-> [[Cycle Stratégique - [N] [nom]]]
