---
type: meeting
date: {{date}}
meeting_type: ""
project: ""
attendees: []
---

# {{title}}

## Type

[standup / appel client / stratégie / revue de projet / 1:1]

## Participants

- 

## Résumé

[2-4 phrases : ce qui a été discuté, ce qui compte.]

## Décisions

- 

## Action items

| Action | Propriétaire | Échéance | Routé vers |
|--------|-------|-----|-----------|
|  |  |  | [[]] |

## Signal stratégique

[Si une décision est stratégique, la signaler pour le Cycle Stratégique et Logs/]
- [[]]

## Liens

- [[Projet ou Domaine]]
