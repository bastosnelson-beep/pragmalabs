---
type: cycle-review
strategic_cycle: "[[Cycle Stratégique - nom]]"
team_member: "[membre de l'équipe]"
role: "[rôle]"
status: active
---

Période exacte : [start] - [Date fin]

## Conclusion globale

[En quelques phrases, comment résumes-tu ce cycle, de ton périmètre ?]

## Les leçons que j'ai apprises

-
-
-

## Ce qui a marché / dont je suis fier

-
-
-

## Constat factuel sur les mouvements clés

[Mouvements clés de l'intention du cycle, filtrés à ton périmètre. Pré-rempli depuis l'intention du cycle, à valider.]

| Mouvement clé (de mon périmètre) | Résultat |
|---|---|
| [Mouvement 1] | [Atteint / Partiellement / Non atteint] |
| [Mouvement 2] | [Atteint / Partiellement / Non atteint] |
| [Mouvement 3] | [Atteint / Partiellement / Non atteint] |

## Ce que j'aimerais améliorer pour le prochain cycle

-
-
-

## Mon intention pour le prochain cycle

[Capturé ici puis déplacé vers le dossier du prochain cycle par le manager. Sera détaillé dans Intention - [membre].md du prochain cycle.]

### Objectif n°1 (de mon périmètre)

[La chose la plus importante que je veux accomplir au prochain cycle.]

### Mouvements clés que je propose

-
-
-

### Ce dont j'ai besoin du manager / de l'équipe

-
