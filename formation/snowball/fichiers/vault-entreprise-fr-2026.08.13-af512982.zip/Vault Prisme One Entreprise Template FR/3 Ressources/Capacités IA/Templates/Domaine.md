---
type: context
status: active
---

# {{title}}

## Description

[En 2-3 phrases, que représente ce domaine ? Quelle responsabilité ongoing ?]

## Propriétaire

[Qui possède ce domaine ? Rôle + nom]

## Responsabilités

- [Responsabilité 1]
- [Responsabilité 2]
- [Responsabilité 3]

## North Star

[Comment sait-on que ce domaine réussit ? La métrique ou le signal.]

## Activités récurrentes

- [Tâche quotidienne / hebdo / mensuelle]
- [Tâche quotidienne / hebdo / mensuelle]

## Outils & données

- [Outil 1 : ce qu'il contient]
- [Outil 2 : ce qu'il contient]

## Notes clés

- [[Note 1]]
- [[Note 2]]
