---
type: weekly-sync
week: {{week}}
prepared_by: "{{prepared_by}}"
strategic_cycle: ""
based_on_reviews: ""
status: active
---

# Sync Hebdo - {{week}}

## Contexte lu
- Vision : [1 ligne]
- Cycle Stratégique : [[]] - [objectif n°1, 1 ligne]
- Revues lues : [liste des membres dont les revues ont été lues, de quelle semaine]

## Recap de la semaine dernière (depuis les revues individuelles)

### Ce qui a été fait (par membre)
- [Membre 1] : [faits]
- [Membre 2] : [faits]

### Blockers ouverts (remontés au sync)
- [Blocker 1 - [membre] - [contexte/qui est nécessaire]]
- [Blocker 2 - [membre]]

## Agenda du sync (sujets à couvrir)
1. [Sujet 1] - [pourquoi]
2. [Sujet 2] - [pourquoi]

## Rushes de la semaine (priorités urgentes)
- [Rush 1] -> [[propriétaire]]
- [Rush 2] -> [[propriétaire]]

## Gros sujets de la semaine (important/stratégique)
- [Gros sujet 1] - [pourquoi ça compte]
- [Gros sujet 2] - [pourquoi ça compte]

## Plan suggéré pour la semaine (par membre, aligné au Cycle Stratégique)
### [[Membre 1]]
- Focus : [...]
- Rushes : [...]
- Plan : [...]

### [[Membre 2]]
- Focus : [...]
- Plan : [...]

## Alignement au Cycle Stratégique
- Cette semaine avance : [mouvement(s) clé(s)]
- Alerte : [un éventuel écart entre le plan et le cycle, ou « aucun »]
