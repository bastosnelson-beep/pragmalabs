---
type: context
status: active
deadline:
owner:
---

# {{title}}

## Description

[En 2-3 phrases, c'est quoi ce projet ?]

## Contexte

- [Élément de contexte 1]
- [Élément de contexte 2]

## Objectif

[Qu'est-ce qui est vrai quand c'est terminé ? L'output concret.]

## Roadmap

- [ ] [Step 1]
- [ ] [Step 2]
- [ ] [Step 3]

## Personnes

- **Propriétaire :** [nom/rôle]
- **Impliqués :** [noms/rôles]

## Notes clés

- [[Note 1]]
- [[Note 2]]
