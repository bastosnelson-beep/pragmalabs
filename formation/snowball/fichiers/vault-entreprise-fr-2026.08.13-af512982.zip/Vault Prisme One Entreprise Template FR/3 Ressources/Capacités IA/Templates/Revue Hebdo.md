---
type: weekly-review
week: {{week}}
team_member: "{{team_member}}"
role: "{{role}}"
strategic_cycle: ""
status: active
---

# Revue Hebdo - {{team_member}} - {{week}}

## Ce à quoi j'étais engagé (cette semaine)
[Mes responsabilités et les tâches que j'avais planifiées pour cette semaine]

## Ce que j'ai fait concrètement
[Concrètement, ce que j'ai accompli. Où j'en suis sur chaque engagement : terminé / en cours / pas commencé]

## Les questions qui me bloquent encore
[Ce qui m'empêche de commencer ou de finir. Les blockers sur lesquels j'ai besoin d'aide]

## Ce que je veux faire la semaine prochaine (focus)
[Mon focus pour la semaine prochaine]

## Ce que je veux remonter au sync hebdo
[Les points que je veux lever au sync du lundi. Les choses que l'équipe ou le lead doit savoir ou décider]
