---
type: person
status: active
role: ""
reports_to: ""
---

# {{title}}

## Rôle & périmètre

[1 phrase : de quoi cette personne est responsable.]

## Décide sur

- [Ce sur quoi elle décide seule]

## Consultée sur / sollicitée pour

- [Ce pour quoi les autres la sollicitent]

## Rend compte à

[[]]

## Profil de voix (pour les comms IA)

- Ton : [direct / chaleureux / formel / ...]
- Langue : 
- Préférences : [ce qu'elle aime / n'aime pas dans les comms écrites]

## North Star du rôle

[Comment sait-on que cette personne réussit dans son rôle ?]
