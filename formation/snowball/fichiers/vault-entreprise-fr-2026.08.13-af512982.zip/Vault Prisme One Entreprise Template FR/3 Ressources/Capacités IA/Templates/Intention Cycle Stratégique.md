---
type: cycle-intention
strategic_cycle: "[[Cycle Stratégique - nom]]"
team_member: "[membre de l'équipe]"
role: "[rôle]"
status: active
---

# Mon intention - [membre de l'équipe] - [N] [nom du cycle]

## Objectif n°1 (de mon périmètre)

[La chose la plus importante que je veux accomplir ce cycle. Si je n'accomplis que ça, c'est une réussite.]

## Mouvements clés que je m'engage à faire

- [ ] [Mouvement 1]
- [ ] [Mouvement 2]
- [ ] [Mouvement 3]

## Contraintes que j'anticipe

-

## Ce dont j'ai besoin du manager / de l'équipe

-
