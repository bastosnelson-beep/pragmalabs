---
type: reflection
subject:
created: {{date}}
owner: ""
---

# {{title}}

## Décision à prendre

[Quelle est la question ? Quel choix est sur la table ?]

## Contexte

[Qu'est-ce qui a déclenché cette réflexion ?]

## Les deux côtés

### Option A
- 

### Option B
- 

## Hypothèses à tester

- 

## Critères

- [Critère 1]
- [Critère 2]

## Réversibilité

[C'est réversible ? Porte à deux sens ou à sens unique ?]

## Alignement au Cycle Stratégique

[[]] - [est-ce que ça nous avance vers l'objectif n°1 ?]

## Conclusion

[Ce qu'on retient / décide]

## Actions

- [ ] [Action si applicable]

## Liens

- [[Note 1]]
