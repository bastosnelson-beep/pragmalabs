---
type: cycle-roadmap
strategic_cycle: "[[Cycle Stratégique - nom]]"
status: active
---

# Roadmap - [N] [nom du cycle]

Roadmap déclinée de la [[Cycle Stratégique - nom|lettre d'intention du cycle]]. Découpe l'objectif n°1 et les mouvements clés en jalons concrets sur la durée du cycle.

## Objectif n°1 du cycle

[Repris de la lettre d'intention.]

## Jalons

### Jalon 1 : [nom] ([semaine / date estimée])
- **Livré quand :** [critère concret]
- **Propriétaire :** [[personne]]
- **Mouvements clés avancés :** [lesquels]
- **Dépendances :** [ce qui doit être vrai avant]

### Jalon 2 : [nom] ([semaine / date estimée])
- **Livré quand :**
- **Propriétaire :** [[personne]]
- **Mouvements clés avancés :**
- **Dépendances :**

### Jalon 3 : [nom] ([semaine / date estimée])
- **Livré quand :**
- **Propriétaire :** [[personne]]
- **Mouvements clés avancés :**
- **Dépendances :**

## Dépendances transversales

- [Ce qui relie les jalons entre eux ou à d'autres projets/domaines.]

## Risques identifiés

- [Risque] -> [mitigation]

## Points de revue

- Revue hebdo : s'aligner sur les jalons en cours ([[/prepare-weekly]])
- En fin de cycle : bilan via [[/new-strategic-cycle-team-member]] puis synthèse via [[/new-strategic-cycle-manager]]
