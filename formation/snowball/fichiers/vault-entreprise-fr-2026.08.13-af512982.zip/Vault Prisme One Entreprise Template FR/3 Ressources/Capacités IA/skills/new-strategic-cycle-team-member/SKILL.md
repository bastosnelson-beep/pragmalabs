---
name: new-strategic-cycle-team-member
description: "Bilan de cycle stratégique individuel pour un membre de l'équipe, scopé à ses responsabilités. À lancer à la fin d'un cycle stratégique (avant que le manager n'ouvre le suivant). Capture, dans l'ordre : la conclusion globale du membre sur le cycle qui se termine, les leçons apprises, ce qui a marché, le constat factuel sur les mouvements clés (pré-rempli depuis l'intention du cycle), ce qui est à améliorer, puis l'intention du membre pour le prochain cycle. Output : 2 Domaines/Vision & Contexte/Cycles Stratégiques/[N] - [nom]/Bilan - [membre de l'équipe].md (dossier du cycle créé s'il est absent). Le manager lance ensuite /new-strategic-cycle-manager pour reprendre tous les bilans, faire le sien, synthétiser et ouvrir le prochain cycle. À utiliser quand « bilan de cycle », « ma revue de cycle », « clôturer mon cycle », « fin de cycle »."
---

# Bilan de Cycle Stratégique (par membre de l'équipe)

C'est le bilan de fin de cycle **individuel**, scopé à un membre de l'équipe et à ses responsabilités. Chaque membre le lance quand le cycle stratégique en cours touche à sa fin (2-3 mois). Il produit un fichier par personne dans le dossier du cycle qui se termine, pour que le manager puisse tous les lire et ouvrir le prochain cycle en un seul passage.

Ce n'est pas l'ouverture du prochain cycle. La synthèse et l'ouverture du prochain cycle sont faites par le manager (voir la dernière section), qui lit chaque bilan individuel du dossier du cycle.

## Structure du dossier du cycle

```
Cycles Stratégiques/
├── Cycles Stratégiques.md              <- index
├── [N] - [nom du cycle]/
│   ├── Cycle Stratégique - [N] [nom].md  <- intention globale (lettre d'intention)
│   ├── Roadmap - [N] [nom].md            <- roadmap déclinée
│   ├── Intention - [membre 1].md         <- intention individuelle pour ce cycle
│   ├── Intention - [membre 2].md
│   ├── Bilan - [membre 1].md             <- bilan individuel en fin de cycle (ce skill)
│   ├── Bilan - [membre 2].md
│   └── Synthèse - Cycle [N] [nom].md     <- synthèse du manager (fin de cycle)
```

## Process

### Step 1 : Qui fait ce bilan

Si tu ne sais pas, demande :

> « Qui fait ce bilan de cycle ? (prénom + rôle) »

Mappe le nom vers l'Organigramme : `2 Domaines/Vision & Contexte/Organigramme/[Personne].md`.

Ce nom devient le nom du fichier.

### Step 2 : Lire le contexte du membre et du cycle

Lis, pour l'alignement :

- Le fichier Organigramme du membre (`2 Domaines/Vision & Contexte/Organigramme/[Personne].md`) : rôle, périmètre, Domaines possédées, North Star du rôle.
- Le dossier du cycle actif. Détecte-le, ne le hardcode jamais :
  ```bash
  ls -d "2 Domaines/Vision & Contexte/Cycles Stratégiques/"*/ 2>/dev/null | sort -V | tail -1
  ```
- Dans ce dossier, lis :
  - `Cycle Stratégique - [N] [nom].md` (l'intention globale : objectif n°1, mouvements clés, contraintes, definition of done). C'est le cadre que le membre va évaluer dans son constat factuel.
  - `Intention - [membre de l'équipe].md` si elle existe (l'intention que le membre s'était fixée en début de cycle). C'est ce qu'on compare au résultat.
  - `Roadmap - [N] [nom].md` si elle existe (les jalons).
- Les Projets du membre : liste `1 Projets/`, lis les notes de contexte des projets que ce membre possède ou auxquels il est impliqué.
- Les Domaines du membre : les notes du Domaine des domaines qu'il possède.
- Les revues hebdo du cycle écoulé : skimme les dossiers `2 Domaines/Pilotage/Revues Hebdo/` des semaines du cycle, pour le membre. Ça rafraîchit la mémoire sur ce qui s'est vraiment passé.

Ça te dit sur quoi le membre était censé travailler pendant ce cycle, pour que le constat factuel (question 4) puisse être pré-rempli depuis l'intention du cycle et validé, pas inventé from scratch.

### Step 3 : Préparer le dossier

```bash
CYCLE_DIR=$(ls -d "2 Domaines/Vision & Contexte/Cycles Stratégiques/"*/ 2>/dev/null | sort -V | tail -1)
CYCLE_NAME=$(basename "$CYCLE_DIR")
echo "Cycle qui se termine : $CYCLE_NAME"
ls "$CYCLE_DIR" 2>/dev/null
```

Le dossier du cycle existe déjà (c'est le cycle actif). Annonce au membre :

> « On clôture le cycle "[nom du cycle]". C'est le moment de faire ton bilan individuel et ton intention pour le prochain. Le manager reprendra tous les bilans ensuite pour ouvrir le prochain cycle. »

### Step 4 : Vérifier si un bilan existe déjà pour ce membre

```bash
ls "$CYCLE_DIR/Bilan - [membre de l'équipe].md" 2>/dev/null
```

S'il existe déjà, demande au membre s'il veut le reprendre ou le réécrire. Ne l'écrase pas sans confirmation.

### Step 5 : Le bilan du cycle, question par question

Pose ces questions **dans l'ordre**, une à la fois, et attends la réponse entre chaque. Reformule ce que tu as compris avant de passer à la suivante. Le membre peut répondre en écrit ou à la voix (dictée). Travaille dans la langue de travail de l'équipe.

Annonce :

> « On traverse le bilan du cycle qui se termine, une question à la fois. C'est TON bilan, scopé à ton périmètre et à ton vécu du cycle. »

**Question 1 : Conclusion globale**

> « En quelques phrases, comment résumes-tu ce cycle, de ton périmètre ? »

Capture la conclusion, pas une liste de tâches. Le sentiment général, ce qui a compté.

**Question 2 : Les leçons que j'ai apprises**

> « Quelles leçons as-tu apprises pendant ce cycle ? »

Capture 2-4 leçons. Des leçons, pas des faits : ce que le membre en retire.

**Question 3 : Ce qui a marché / dont je suis fier**

> « Qu'est-ce qui a marché ? De quoi es-tu fier dans ce cycle, de ton périmètre ? »

Capture les réussites et les moments dont le membre est fier. Des faits concrets.

**Question 4 : Constat factuel sur les mouvements clés**

> « Constat factuel sur les mouvements clés du cycle, de ton périmètre. Pour chacun : atteint, partiellement, ou non atteint ? »

Pré-remplis depuis l'intention du cycle (Step 2) les mouvements clés pertinents pour le périmètre du membre, et valide. Si un mouvement clé n'est pas de son périmètre, laisse-le de côté. C'est des faits, pas du récit.

**Question 5 : Ce que j'aimerais améliorer pour le prochain cycle**

> « Qu'est-ce que tu aimerais améliorer pour le prochain cycle ? »

Capture 2-4 axes d'amélioration, du périmètre du membre.

### Step 6 : L'intention pour le prochain cycle, question par question

Passe maintenant à l'intention du membre pour le prochain cycle. Annonce :

> « Maintenant, ton intention pour le prochain cycle. Toujours scopé à ton périmètre. Le manager lira tout ça pour définir le prochain cycle global. Ton intention sera déplacée vers le dossier du prochain cycle quand le manager l'ouvrira. »

**Question 6 : Objectif n°1 (de mon périmètre)**

> « C'est quoi la chose la plus importante que tu veux accomplir au prochain cycle ? Si tu n'accomplis que ça, c'est une réussite. »

Capture l'objectif n°1 du membre, pas une liste. Une seule chose dominante.

**Question 7 : Mouvements clés que je propose**

> « Quels mouvements clés proposes-tu pour y arriver ? 2-3 mouvements concrets. »

Capture les mouvements proposés. Ce sont des suggestions pour le manager, pas des décisions.

**Question 8 : Ce dont j'ai besoin du manager / de l'équipe**

> « De quoi as-tu besoin du manager ou de l'équipe pour réussir ton objectif n°1 ? »

Capture les besoins. Ce sont les points que le manager devra prendre en compte dans la synthèse.

### Step 7 : Générer le fichier de bilan

Crée `2 Domaines/Vision & Contexte/Cycles Stratégiques/[N] - [nom]/Bilan - [membre de l'équipe].md` depuis le modèle `3 Ressources/Capacités IA/Templates/Bilan Cycle Stratégique`. Remplis chaque section avec les réponses capturées. Set le frontmatter : `strategic_cycle` (wikilink vers le cycle qui se termine), `team_member`, `role`, `status: active`.

### Step 8 : Mettre à jour les contextes

Avant de clôturer, fais le lien entre ce que le membre a dit et les notes de contexte du vault. Pour chaque projet ou domaine que le membre a mentionné dans son bilan (un projet qui a avancé, un problème, une modification, un truc qui n'a pas été fait) :

1. **Lis la note de contexte** du projet (`1 Projets/[projet]/[projet].md`) ou du domaine (`2 Domaines/[domaine]/[domaine].md`).
2. **Demande-toi : est-ce à jour ?** Ce que le membre vient de dire contredit-il, complète-il, ou invalide-il une information dans la note de contexte ?
3. **Si oui, propose une mise à jour.** Dis au membre ce que tu as trouvé et ce que tu proposes de modifier. Exemples :
   - « Tu dis que le projet X est passé en phase de test, mais la note de contexte dit encore "en conception". Je la mets à jour ? »
   - « Tu mentionnes un problème récurrent sur le domaine Y qui n'est pas dans la note de contexte. Je l'ajoute ? »
   - « La roadmap du projet Z liste encore une étape que tu dis terminée. Je la barre ? »
4. **Sur validation du membre, applique la modification** (édition chirurgicale, pas de réécriture complète).

Si rien n'est à mettre à jour, dis-le : « Rien à mettre à jour dans les contextes, tout est cohérent. »

### Step 9 : Confirmation

```
=== Bilan de cycle terminé ===

Fichier : 2 Domaines/Vision & Contexte/Cycles Stratégiques/[N] - [nom]/Bilan - [membre de l'équipe].md
Membre de l'équipe : [nom] ([rôle])
Cycle clôturé : [[nom]]
Objectif n°1 proposé pour le prochain cycle : [résumé en une ligne]

Contextes mis à jour : [liste des notes modifiées, ou "aucun"]
Ton bilan est sauvegardé dans le dossier du cycle. Le manager le lira à côté
de ceux de tout le monde pour faire sa synthèse et ouvrir le prochain cycle.
```

---

## Pour le manager : ouvrir le prochain cycle

Reprendre les bilans individuels de tout le monde et ouvrir le prochain cycle est un boulot distinct, géré par le skill `/new-strategic-cycle-manager`. Le manager le lance une fois que tous les membres ont soumis leur bilan (ou après un deadline raisonnable) : il lit Vision, le cycle qui se termine, chaque `Bilan - [membre de l'équipe].md` du dossier du cycle, fait son propre bilan, synthétise, puis définit le prochain cycle (lettre d'intention globale + roadmap) et l'ouvre. Les intentions que les membres ont écrites dans leur bilan seront déplacées vers le dossier du prochain cycle.

Voir `/new-strategic-cycle-manager` pour la procédure complète.

---

## Règles

- **Individuel et scopé.** C'est le bilan d'un membre de l'équipe sur son propre cycle, pas un bilan d'équipe. Scope à ses responsabilités, Domaines, et Projets.
- **Bilan d'abord, intention ensuite.** Les questions 1-5 regardent le cycle qui se termine; les questions 6-8 regardent le prochain. Ne les mélange pas.
- **Huit questions, dans l'ordre.** Ne les réordonne pas, ne les saute pas, ne les merge pas. Chaque capture une chose distincte.
- **Reformule après chaque réponse** avant de passer. Valide la compréhension.
- **Pré-remplis la question 4** depuis l'intention du cycle (les mouvements clés pertinents pour le périmètre du membre) et valide; n'invente pas le constat.
- **Des faits pas du récit.** La question 4 c'est le constat factuel sur les mouvements clés, y compris ce qui n'a pas été atteint.
- **Un fichier par membre par cycle**, nommé `Bilan - [membre de l'équipe].md`, dans le dossier du cycle `2 Domaines/Vision & Contexte/Cycles Stratégiques/[N] - [nom]/`.
- **Le dossier du cycle est l'espace partagé.** Tous les bilans des membres pour le même cycle vivent dans le même dossier. C'est ça qui rend la synthèse du manager possible en un seul passage.
- **Mets à jour les contextes.** Si le bilan révèle qu'une note de projet ou de domaine n'est plus à jour, propose la modification et applique-la sur validation. Une note de contexte figée devient fausse.
- **Mappe les noms vers l'Organigramme** avant d'écrire. N'invente jamais un teammate.
- **Utilise des [[wikilinks]]** vers les Domaines, Projets, le Cycle Stratégique, et les personnes de l'Organigramme quand c'est pertinent.
- **Pas de tirets longs** (utilise deux points, virgule, parenthèse, ou reformule).
- **Pas de tic rhétorique « pas X mais Y ».** Dis les choses directement.
- **Pas d'emojis.**

## Ce que tu ne fais pas

- Lancer ça comme un bilan au niveau de l'équipe. C'est individuel, scopé à un membre.
- Ouvrir le prochain cycle. C'est le rôle du manager via `/new-strategic-cycle-manager`.
- Mélanger les huit questions ou les poser dans le désordre.
- Inventer le constat du membre sur les mouvements clés; pré-remplis depuis l'intention du cycle et valide.
- Mettre le bilan ailleurs que dans le dossier du cycle `2 Domaines/Vision & Contexte/Cycles Stratégiques/[N] - [nom]/`.
- Nommer le fichier sans le nom du membre (le dossier tient un fichier par personne).
- Hardcoder le nom du Cycle Stratégique; détecte-le.
- Skipper la lecture du fichier Organigramme du membre, de l'intention du cycle, et de ses notes de Projet/Domaine avant le constat factuel.
- Skipper l'étape de mise à jour des contextes (Step 8). C'est ce qui garde le vault vivant.
- Confondre ce skill avec la synthèse du manager. Ce skill produit le bilan individuel; la synthèse et l'ouverture du prochain cycle sont un passage de lecture fait par le manager (décrit dans la dernière section).
