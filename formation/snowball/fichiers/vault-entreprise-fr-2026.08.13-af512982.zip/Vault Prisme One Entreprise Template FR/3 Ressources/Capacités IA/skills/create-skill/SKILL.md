---
name: create-skill
description: "Capture la méthode exacte d'un membre de l'équipe pour un process d'entreprise récurrent (SOP, tâche opérationnelle, workflow de delivery) et en fait un skill IA exécutable, plus une fiche de process lisible par un humain en option. Peut partir de zéro OU d'une Fiche de Process existante créée par /map-process. Extraction guidée : input, étapes avec méthode, bons/mauvais exemples, références. La méthode est le livrable, pas les étapes. Usage entreprise : documenter comment l'ÉQUIPE fait quelque chose pour que n'importe quel membre et l'IA puissent le reproduire fidèlement. À utiliser quand « crée un skill pour X », « documente notre SOP pour Y », « transforme ce process en skill », « capture comment on fait Z », « fais de cette fiche de process un skill »."
---

# Create Skill : Capturer une méthode d'équipe et la rendre exécutable

Tu captures la méthode EXACTE qu'un membre de l'équipe utilise pour un process d'entreprise donné, puis tu produis un skill IA exécutable (et optionnellement une fiche de process lisible par un humain). L'objectif : le skill reflète la façon authentique de faire de l'équipe, pour que n'importe quel teammate et l'IA puissent le reproduire de façon cohérente.

## Principe fondateur

Ce qui rend un skill utile, c'est la méthode embarquée. Un skill qui dit « écris un bon article » est inutile. Un skill qui dit :

> « Écris un article en 3 actes AIDA, avec un hook empirique dans les 2 premières phrases, jamais plus de 2 paragraphes par section, et voici 3 bons hooks qu'on a écrits »

est puissant.

Donc le coeur de ce skill est l'extraction de méthode. Les étapes sont le squelette; la méthode sur chaque étape est le livrable. Un skill sans méthode explicite et concrète est un skill à jeter.

## Spécificités entreprise

Un process d'entreprise diffère d'un process perso sur trois points. Capture-les toujours :
- **Propriétaire / rôle** : qui fait tourner ce process (nom ou rôle, ex « Ops Lead », « Account Manager »). Link la note du Domaine via [[wikilink]].
- **Handoff** : ce que le rôle ou l'étape suivante reçoit. Les process d'entreprise passent le relais à quelqu'un d'autre; capture ce que cette personne reçoit, dans quel format, pour quand.
- **Outils et accès** : quel outil, quels credentials, quelles permissions. Pointe vers [[Infrastructure]] au lieu de coller des secrets.

Écris le contenu capturé (fiche de process, exemples, prose du skill) dans la langue de travail de l'équipe choisie à `/initialisation-entreprise`. Ce SKILL.md reste en anglais; ses outputs suivent la langue du vault.

## Convention de stockage (partagée avec /map-process)

- **Note Process Map** : `3 Ressources/Process/[Employé]/Process Map de [Employé].md`
- **Fiches de Process** : `3 Ressources/Process/[Employé]/[Nom du process].md` (un dossier par employé, un fichier par process, pas de préfixe « Process - »)
- **Skills** : `3 Ressources/Capacités IA/skills/[nom-du-skill]/SKILL.md`

Le nom de fichier de la Fiche de Process est le nom du process (ex `Écrire Proposition.md`). Le nom du skill est en kebab-case (ex `ecrire-proposition`). Ce sont des fichiers différents, cross-linkés via wikilinks.

## Process

### Step 0 : Mode d'input (from scratch ou depuis une Fiche de Process existante)

Avant toute chose, détermine comment on entre dans ce skill. Demande :

> « On crée ce skill from scratch, ou depuis une Fiche de Process qui existe déjà (créée par /map-process) ? »

**Mode A : From scratch.** Va au Step 1, capture complète.

**Mode B : Depuis une Fiche de Process existante.** Demande quel employé et quel process (ou quel chemin). Puis :
```bash
ls "3 Ressources/Process/[Employé]/" 2>/dev/null
```
Ouvre la Fiche de Process à `3 Ressources/Process/[Employé]/[Nom du process].md` et **lis-la en entier**. La fiche contient déjà : Objectif, Inputs, Outputs attendus, Étapes (avec Ce que je fais / Méthode / Outils / Handoff par étape), Validation/contrôle qualité, Outils utilisés, Délégation/potentiel IA. C'est ta fondation. Dis au membre :

> « J'ai lu ta Fiche de Process [[Nom du process]]. Elle a déjà les étapes, la méthode, les outils, et les handoffs. On va l'utiliser comme base. Je valide la méthode avec toi, je creuse là où elle est fine, je capture des exemples concrets (que la fiche n'a pas), puis j'en fais un skill exécutable. »

Puis va au Step 2 (validation + enrichissement de la méthode), en skipant la re-capture du scope (Step 1). Le scope vient de la fiche.

### Step 1 : Scoper le process (Mode A seulement)

```
On va capturer la méthode de l'équipe pour un process. Dis-moi :

1. Nom : ex « Briefer un nouveau fournisseur », « Émettre un purchase order », « Faire tourner le standup ops hebdo »
2. Fonction business : Acquisition / Sales / Delivery (Operations) / Rétention / Support / Admin / HR
3. Domaine : à quelle note de [[Domaine]] ça appartient ? (links via wikilink)
4. Propriétaire / rôle : qui est accountable pour ce process ? Aussi : quel dossier employé tiendra la fiche ?
5. Trigger / fréquence : quand est-ce que ça tourne ? (quotidien / hebdo / mensuel / sur-déclencheur / manuel)
6. Input : qu'est-ce que le process reçoit ?
7. Output et handoff : qu'est-ce que ça produit, et qui ou quoi reçoit ensuite ? (format, deadline)
8. Temps actuel : combien de temps ça prend aujourd'hui ?
9. Douleur principale : qu'est-ce qui casse ou ralentit ?
```

### Step 2 : La méthode sur chaque étape (le livrable central)

C'est le coeur du skill. La méthode est ce qui rend le skill exécutable. Sans elle, tu as un checklist, pas un skill.

#### 2.1 Lister les étapes

Si Mode A : demande au membre de nommer les étapes du process, une par une (3 à 7 étapes idéales). Boucle jusqu'à ce que le process soit décrit en entier. Si plus de 7, propose de grouper. Si moins de 3, creuse plus (des étapes implicites se cachent probablement).

Si Mode B (depuis une fiche) : les étapes sont déjà dans la fiche. Restitue-les au membre depuis la fiche, et confirme : « Ta fiche a [N] étapes : [liste]. C'est toujours accurate, ou le process a changé depuis que tu l'as cartographié ? »

#### 2.2 Capturer (ou valider) la méthode sur chaque étape

Pour chaque étape, la méthode est le livrable. Pose ces questions et **creuse jusqu'à ce que la méthode soit concrète et reproductible** :

```
Étape [N] : [nom]

- Quoi : que fais-tu concrètement ?
- Méthode : comment tu le fais BIEN ? (LE coeur, creuse ici, voir la bank ci-dessous)
- Propriétaire : qui fait cette étape ? (rôle ou nom, si ça varie par étape)
- Outils : avec quoi ? (logiciel, modèle, doc de référence). Pointe vers [[Infrastructure]] pour l'accès.
- Handoff : qu'est-ce que l'étape suivante reçoit ? (artefact, format, où c'est stocké)
- Piège : qu'est-ce qui peut mal se passer ici ?
- Temps : combien de temps ça prend ?
```

#### La method bank (ton toolkit de creusage)

Le risque est que le membre réponde la méthode vaguement : « on fait de son mieux », « ça dépend », « on sait juste ». C'est ici que tu gagnes ton keep. Creuse avec ça, par ordre d'escalade :

**1. Intuition probe** (ce qu'ils décident vraiment)
> « C'est quoi ton intuition à cette étape ? Qu'est-ce que tu décides le plus souvent, concrètement ? »
> « Promène-moi à travers la dernière fois que tu as fait ça. Qu'est-ce que tu as décidé, et pourquoi ? »

**2. Concept / critère probe** (le principe qu'ils appliquent)
> « Sur quel concept ou critère bases-tu ton choix ici ? »
> « Qu'est-ce qui te fait décider A plutôt que B à cette étape ? »

**3. Réflexion probe** (la méthode derrière la méthode)
> « Y a-t-il des éléments de réflexion ou des méthodes que tu appliques à cet endroit précis ? Un mental model, une règle empirique, un framework ? »

**4. Judgment probe** (comment ils distinguent bon de mauvais)
> « Comment tu juges « bon » vs « pas bon » à cette étape ? À quoi ressemble un bon output, et à quoi ressemble un mauvais ? »

**5. New-hire probe** (l'escalation quand c'est vague)
Si la méthode reste vague après les 4 ci-dessus, recadre :
> « Imagine que tu formes un nouveau hire ce soir. Que lui dirais-tu de faire ici, concrètement, pour qu'il ne le rate pas ? »

**6. Anti-example probe** (fait émerger les règles implicites)
> « Qu'est-ce qu'un junior ferait de mal ici que tu ne ferais jamais ? C'est quoi l'erreur qu'il fait qui révèle qu'il n'a pas encore la méthode ? »

Règle d'or : n'accepte pas une méthode vague. Si après la bank la méthode est encore fine, demande un cas récent concret et reverse-engineer la méthode à partir de lui.

En Mode B, les champs `Method:` de la fiche sont ton point de départ. Restitue-les, valide, et creuse avec la bank là où ils sont fins. Souvent une fiche capture bien les étapes mais la méthode reste implicite. Ton boulot est de la rendre explicite.

### Step 3 : Exemples concrets (toujours nécessaires)

C'est le second livrable central. La méthode dit comment; les exemples montrent à quoi ressemble « bon » concrètement. `/map-process` ne capture PAS d'exemples, donc cette étape est ta principale valeur ajoutée par rapport à la fiche.

```
Donne-moi des exemples précis de ton travail sur ce process :

- 1 à 3 bons exemples : un output que tu considères excellent. Pour chacun : pourquoi c'est bon ?
- 1 à 2 mauvais exemples : un output médiocre ou raté. Pour chacun : pourquoi il a échoué ?

Si tu n'en as aucun sous la main : on regarde dans les notes existantes du vault, ou tu m'en montres un la prochaine fois et on enrichit le skill.
```

Stocke ces exemples VERBATIM dans le skill (copie exacte du texte, pas de reformulation). C'est ça qui laisse l'IA apprendre le goût de l'équipe.

### Step 4 : Références externes (optionnel, avec Firecrawl si disponible)

```
T'inspires-tu d'une méthode connue ? (AIDA, GTD, 5 Whys, un framework, un livre...)

- Si oui : je fais une recherche rapide pour extraire les points clés et les embarquer dans ton skill, avec la source.
- Si non : on skippe, ta propre méthode suffit.
```

Si le membre cite une méthode et que Firecrawl est disponible :
1. Cherche la méthode (3 à 5 résultats)
2. Scrape les 1 à 2 sources les plus authoritative
3. Extrais 3 à 5 points clés à embarquer dans le skill
4. Cite la source (URL)

Si Firecrawl n'est pas disponible : demande s'il veut coller un résumé de la méthode.

### Step 5 : Décider les artefacts

```
On a collecté la méthode et les exemples. Qu'est-ce qu'on produit ?

- Skill seulement : l'IA lance /[nom]. (Si Mode B, la fiche existe déjà; on la cross-link, on ne la recrée pas.)
- Skill + fiche : le skill pour l'IA, la fiche pour les teammates, cross-linkés. (En Mode A, on crée la fiche aussi.)
- Fiche seulement : 3 Ressources/Process/[Employé]/[Nom du process].md. Référence lisible par un humain, pas d'exécution IA.

Lequel ?
```

Guide de décision :
- Si le process implique un jugement reproductible que l'IA peut faire via tes exemples : skill.
- Si c'est purement humain (présence physique, conversation 1:1, jugement non textuel) : fiche de process seulement.

En Mode B, « fiche seulement » n'est en général pas pertinent (la fiche existe déjà). L'intérêt du chainage est d'ajouter le skill. Donc en Mode B les vrais choix sont « skill seulement » (juste ajouter le skill, cross-linker la fiche existante) ou « skill + enrichissement de fiche » (ajouter le skill ET enrichir la fiche existante avec les exemples et la table d'intégration IA).

### Step 6 : Valider le nom du skill

Valide le nom contre la regex OpenCode et Claude Code : `^[a-z0-9]+(-[a-z0-9]+)*$`, 1 à 64 chars, pas de `--` consécutifs, pas de `-` en début ou fin.

Si le nom proposé est invalide, propose une version corrigée (ex « Émettre Purchase Order » devient `emettre-purchase-order`).

### Step 7 : Génération

#### Si skill

Crée `3 Ressources/Capacités IA/skills/[nom-du-skill]/SKILL.md` :

```bash
mkdir -p "3 Ressources/Capacités IA/skills/[nom-du-skill]"
```

Squelette (adapté à la méthode capturée) :

```markdown
---
name: [nom-du-skill]
description: [1 à 1024 chars. Spécifique, pour que l'agent sache QUAND trigger. Inclure l'input attendu + l'output produit + le cas d'usage typique.]
---

# [Titre lisible]

[1 phrase : ce que fait le skill et dans quel contexte l'utiliser.]

## Propriétaire et Domaine
- Propriétaire / rôle : [rôle ou nom]
- Domaine : [[Domaine]]
- Dossier employé : 3 Ressources/Process/[Employé]/
- Fiche de Process : [[Nom du process]] (si une fiche existe)
- Trigger / fréquence : [quotidien / hebdo / mensuel / sur-déclencheur / manuel]

## Input
[Ce que l'agent reçoit ou doit demander : arguments, fichiers, contexte]

## Output et Handoff
[Ce que l'agent produit, et ce que le rôle ou l'étape suivante reçoit (format, où stocké, deadline)]

## Process

### Step 1 : [nom]

**Méthode :** [Comment bien faire : critères, principes d'équipe, l'intuition, le concept/critère, les éléments de réflexion. Verbatim quand possible. C'est le coeur.]
**Propriétaire :** [rôle ou nom]
**Outils :** [...]
**Handoff :** [ce que l'étape suivante reçoit]
**Piège :** [quoi éviter, spécifiquement]

[Instructions d'exécution précises : quoi faire, dans quel ordre, avec quelles validations intermédiaires]

### Step 2 : ...

## Exemples

### Bons exemples
1. [Titre] : [exemple cité en entier, verbatim]
   Pourquoi c'est bon : [...]

2. ...

### Mauvais exemples
1. [Titre] : [exemple verbatim]
   Pourquoi il a échoué : [...]

## Références
- [[Nom du process]] : fiche de process (3 Ressources/Process/[Employé]/)
- [Méthode publique X] : [URL]. Points clés : [...]

## Règles
- [Règle explicite 1]
- [Règle 2]

## Ce que tu ne fais pas
- [Anti-pattern 1]
- [Anti-pattern 2]
```

#### Si fiche de process (Mode A seulement)

Crée `3 Ressources/Process/[Employé]/[Nom du process].md` :

```bash
mkdir -p "3 Ressources/Process/[Employé]"
```

```markdown
---
type: process
employee: "[Employé]"
frequency: "[quotidien|hebdo|mensuel|sur-déclencheur]"
time_estimate: "[ex 45 min, x3/semaine]"
domain: "[[Nom du domaine]]"
related_skill: ""
status: active
---

# [Nom du process]

## Objectif
[1 phrase : ce que ce process produit / pourquoi il existe.]

## Inputs
- [Ce qui rentre, concrètement]

## Outputs attendus
- [Ce qui existe quand c'est terminé, concrètement]

## Étapes (la méthode)

### Step 1 : [nom]
- **Ce que je fais :** [action concrète]
- **Méthode :** [l'intuition, ce que je décide le plus souvent, le concept/critère, les éléments de réflexion]
- **Outils :** [outil(s) à cette étape]
- **Handoff :** [à qui je passe, dans quel format, pour quand, si applicable]

### Step 2 : ...

## Validation / contrôle qualité
[Comment je juge que l'output est bon avant de l'envoyer.]

## Outils utilisés
- [Outil 1 : pour quoi]

## Exemples
### Bons exemples
1. [exemple verbatim] : Pourquoi c'est bon : [...]

### Mauvais exemples
1. [exemple verbatim] : Pourquoi il a échoué : [...]

## Références
- [Méthode publique] : [URL + points clés]
- [[Autre process linké]]

## Délégation / potentiel IA
- **Note :** haut / moyen / bas
- **Ce que l'IA pourrait faire ou accélérer :** [sois spécifique]
- **Ce qui doit rester humain :** [sois spécifique]
- **Skill lié :** [[nom-du-skill]] (rempli quand un skill est créé depuis cette fiche)
```

#### Si les deux (Mode A) ou skill + enrichissement de fiche (Mode B)

En Mode A : génère les deux. Ajoute des cross wikilinks :
- Dans le skill : `Fiche de Process : [[Nom du process]]`
- Dans la fiche : `Skill lié : [[nom-du-skill]]`

En Mode B : la fiche existe déjà. Génère le skill, puis **update la fiche existante** à deux endroits :
1. Set le frontmatter `related_skill: "[[nom-du-skill]]"`
2. Ajoute les exemples et l'intégration IA (si capturés) à la fiche, sous les sections `## Exemples` et `## Délégation / potentiel IA` existantes. N'écrase pas la méthode de la fiche; enrichis-la.

### Step 8 : Updater la note Process Map et cross-linker

Cette étape garde l'index honest.

**8.1 Cross-linker la fiche (si un skill a été créé et qu'une fiche existe) :**
- Dans le skill : confirme que `Fiche de Process : [[Nom du process]]` est présent.
- Dans la fiche : set `related_skill: "[[nom-du-skill]]"` dans le frontmatter.

**8.2 Updater la note Process Map :**

Si `3 Ressources/Process/[Employé]/Process Map de [Employé].md` existe, update la colonne `Fiche` pour ce process pour indiquer qu'un skill existe maintenant, ex `[[Nom du process]] -> [[nom-du-skill]]` ou ajoute une coche. Garde-le léger; l'objectif est que scanner la map montre quels process sont maintenant exécutables par l'IA.

```bash
ls "3 Ressources/Process/[Employé]/Process Map de [Employé].md" 2>/dev/null
```

Si la note Process Map n'existe pas (aucun /map-process n'a été lancé pour cet employé), propose de la créer via `/map-process`. Ne la crée pas silencieusement.

### Step 9 : Test immédiat

Si un skill a été créé :

```
Skill /[nom-du-skill] créé.

On le teste maintenant sur un vrai cas ?
```

Si le membre de l'équipe est d'accord, lance une exécution de test avec un input qu'il donne, puis demande s'il faut ajuster le skill (ajouter un exemple, clarifier une étape, relâcher une règle trop rigide).

## Règles

- **La méthode avant tout** : un skill sans méthode explicite et concrète sur chaque étape (Step 2) doit être refusé. NE JAMAIS générer un skill générique. La méthode est le livrable; les étapes sont juste le squelette.
- **Creuse la méthode** : n'accepte jamais une méthode vague. Utilise la method bank (intuition, concept, réflexion, jugement, new-hire, anti-example) jusqu'à ce qu'elle soit concrète et reproductible.
- **Exemples verbatim** : reproduis les exemples donnés par le membre de l'équipe mot pour mot (pas de reformulation, même imparfaits). Ils encapsulent le goût de l'équipe.
- **Capture propriétaire, handoff, et outils sur chaque étape** : c'est ça qui rend un process reproductible entre les personnes.
- **Firecrawl pour enrichir, jamais pour remplacer** : les méthodes publiques complètent la méthode de l'équipe; elles ne s'y substituent jamais.
- **Valide le nom du skill** avec la regex avant toute création.
- **Frontmatter du skill** : seulement name et description (requis), plus license, compatibility, metadata (optionnel). Pas d'allowed-tools, pas d'autres champs.
- **Demande toujours validation** avant de créer des fichiers.
- **Cross-link toujours** fiche et skill quand les deux existent, via wikilinks (`[[Nom du process]]` dans le skill, `[[nom-du-skill]]` dans la fiche).
- **Pointe vers [[Infrastructure]]** pour les credentials et l'accès; ne colle jamais de secrets dans un skill ou une fiche.
- **La convention de stockage** est partagée avec `/map-process` : `3 Ressources/Process/[Employé]/` pour les fiches et la note Process Map. N'utilise jamais `3 Ressources/Références/Process/`.

## Ce que tu ne fais pas

- Créer un skill sans exemples concrets (le Step 3 est obligatoire)
- Créer un skill sans méthode concrète sur chaque étape (le Step 2 est obligatoire, et creuser est obligatoire)
- Générer un skill « internet best practices » sans la méthode de l'équipe
- En Mode B, re-capturer le scope et les étapes from scratch (la fiche les a; valide et enrichis à la place)
- En Mode B, écraser la méthode de la fiche existante (enrichis-la; ne la remplace pas)
- Stocker la fiche de process dans `3 Ressources/Références/Process/` (mauvais chemin; utilise `3 Ressources/Process/[Employé]/`)
- Référencer `[[Process - Nom]]` (mauvais format; utilise `[[Nom du process]]`, le vrai nom de fichier de la fiche)
- Updater un `2 Domaines/Pilotage/Process Map.md` qui n'existe pas (le vrai index est `3 Ressources/Process/[Employé]/Process Map de [Employé].md`)
- Créer dans `.opencode/commands/` ou `.claude/commands/` (formats obsolètes)
- Lancer Firecrawl de ton propre chef : seulement si le membre cite explicitement une méthode externe
- Écrire le frontmatter avec allowed-tools (pas reconnu pour les skills, ignoré)
- Coller des credentials ou des secrets dans le skill ou la fiche (link [[Infrastructure]] à la place)
