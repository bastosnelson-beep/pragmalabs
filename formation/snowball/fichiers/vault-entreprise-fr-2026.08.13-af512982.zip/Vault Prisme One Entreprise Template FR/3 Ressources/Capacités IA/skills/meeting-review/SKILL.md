---
name: meeting-review
description: "L'essence : stocker la note de réunion dans le bon dossier. Depuis un transcript de réunion ou des notes brutes, déterminer le bon dossier (le Projet ou le Domaine concerné), enrichir la note avec un résumé structuré, la classer là avec un nom descriptif, puis extraire les décisions et les action items avec leurs propriétaires nommés et les router vers le bon Projet ou Domaine. Signaler les décisions stratégiques pour le Cycle Stratégique. À utiliser quand un transcript ou des notes de réunion sont partagés, ou quand tu dois classer une note de réunion."
---

# Meeting Review

L'essence de ce skill est de stocker la note de réunion dans le **bon dossier**. Si un transcript ou une note a été fourni en input, il est enrichi avec un résumé structuré et classé au bon endroit (le Projet ou le Domaine concerné). L'extraction des décisions et action items, et leur routage, viennent par-dessus.

Une note de réunion qui traîne dans `0 Inbox/` ou dans un dossier générique est une note perdue. Le premier boulot est de savoir où elle appartient et de l'y mettre.

## Process

### Step 0 : Valider le contexte

Avant de lire quoi que ce soit, confirme avec l'utilisateur :

1. **Qui a assisté** (ou qui est capturé dans le transcript).
2. **Quel type de réunion** c'est : standup interne, appel client, réu stratégie, revue de projet, 1:1, autre.
3. **Quel Projet ou Domaine** ça concerne (le primaire, et tout secondaire). Si c'est pas clair, demande. Mappe les noms vers les personnes dans `2 Domaines/Vision & Contexte/Organigramme/` pour que les propriétaires soient bien orthographiés.
4. **Y a-t-il un fichier en input ?** (un chemin de transcript, une note dans `0 Inbox/`, ou des notes collées). Si oui, note le chemin. Si non, on crée la note from scratch au bon endroit.

Reformule la demande en une ligne pour confirmer la compréhension, puis procède.

### Step 1 : Déterminer le bon dossier (l'essence)

C'est la décision centrale. La note va dans un sous-dossier `Meetings/` du Projet ou du Domaine auquel elle appartient.

**Logique de routage :**

| Type de réunion | Dossier |
|---|---|
| Réunion de projet (incl. appels client pour ce projet) | `1 Projets/[projet]/Meetings/` |
| Réunion de domaine (opérationnelle, spécifique au domaine) | `2 Domaines/[domaine]/Meetings/` |
| Réunion de stratégie / transversale (touche le Cycle Stratégique) | `2 Domaines/Vision & Contexte/Meetings/` |
| Réunion opérationnelle récurrente (standup, hebdo) | `2 Domaines/Pilotage/Meetings/` |
| 1:1 | `2 Domaines/Pilotage/Meetings/` (ou `2 Domaines/Vision & Contexte/Organigramme/[Personne]/Meetings/` si c'est clairement du développement perso) |

Règles :
- Le Projet ou le Domaine primaire (du Step 0) décide du dossier. Si une réunion touche les deux, choisis celui où l'action vit; mentionne l'autre dans la note.
- S'il n'y a pas de Projet ou Domaine clair (vraiment transversal), default vers `2 Domaines/Pilotage/Meetings/` (le rythme opérationnel) sauf si c'est stratégique, alors `2 Domaines/Vision & Contexte/Meetings/`.
- Crée le sous-dossier `Meetings/` s'il n'existe pas.

**Nom du fichier :** `YYYY-MM-DD - [Type] - [Titre court].md`, ex `2026-03-22 - Appel Client - Acme Q3 Rollout.md`.

Présente le dossier et le nom déterminés à l'utilisateur :

> Cette note de réunion appartient dans `[dossier]/[nom]`. (Parce qu'elle concerne [[Projet/Domaine]].) Confirmes-tu, ou ajustes-tu ?

**ATTENDS LA VALIDATION** avant de bouger ou créer.

### Step 2 : Lire le transcript en entier (si un fichier a été fourni)

Si `$ARGUMENTS` est un fichier, lis-le en entier (TOUTES les lignes, pas de troncature). Si c'est tronqué, continue avec offset jusqu'à la fin.

Critique : ne résume jamais depuis le résumé auto-généré en haut de la note. Lis toujours le transcript brut et complet.

S'il n'y a pas de fichier en input (notes collées ou oral), utilise ce que l'utilisateur t'a donné au Step 0.

### Step 3 : Écrire le résumé structuré dans la note

Écris la note (au chemin déterminé) avec ce format. Adapte les valeurs du frontmatter à la langue de travail choisie à `/initialisation-entreprise`; garde les clés en anglais.

```markdown
---
type: meeting
meeting_type: standup | client_call | strategy | project_review | 1_1 | other
date: YYYY-MM-DD
participants: [liste, linkée avec des [[wikilinks]] vers les personnes de l'Organigramme quand connues]
project: [[Nom du Projet]]
domain: [[Nom du Domaine]]
facilitator: [[Personne]]
tags:
  - meeting
  - [slug projet ou domaine]
---

# [Titre descriptif de la réunion]

## Contexte
[1-2 phrases : pourquoi cette réunion, quel Projet ou Domaine, ce qui était attendu]

## Décisions
- [Décision 1]
- [Décision 2]

## Action items
### [[Propriétaire 1]]
- [ ] [Action 1] (échéance : YYYY-MM-DD, projet : [[Projet]], domaine : [[Domaine]])
- [ ] [Action 2]

### [[Propriétaire 2]]
- [ ] [Action 1]

### Non assignés / parking
- [ ] [Action qui a besoin d'un propriétaire]

## Points clés discutés
### [Sujet 1]
[Résumé de 2-3 phrases]

### [Sujet 2]
[Résumé de 2-3 phrases]

## Nombres et données mentionnées
- [Chiffre, métrique, date, ou citation notable]

## Signaux stratégiques
- [Décision ou sujet qui affecte le Cycle Stratégique / la roadmap / le plan de 2-3 mois, ou « Aucun »]

---

## Transcript
[Le transcript brut reste inchangé ci-dessous, si un fichier a été fourni]
```

Sois exhaustif sur les décisions et les action items, concis sur la discussion. Chaque action item a un propriétaire nommé. Les items non assignés vont sous « Non assignés / parking » et doivent être résolus au Step 5.

### Step 4 : Classer la note dans le bon dossier (l'essence, exécutée)

Maintenant place réellement la note là où elle appartient :

- **Si un fichier source a été fourni** (transcript dans `0 Inbox/` ou ailleurs) : déplace-le et renomme-le vers le chemin validé. Garde le transcript brut en bas de la note (Section « Transcript »).
  ```bash
  mkdir -p "[dossier déterminé]/Meetings"
  # écris la note enrichie à [dossier déterminé]/Meetings/[nom].md
  # déplace l'original vers 4 Archive/_meeting-sources/ pour la traçabilité (optionnel, demande)
  ```
- **Si pas de fichier source** : crée la note directement au chemin validé.

C'est l'essence : la note est maintenant dans le bon dossier, là où l'équipe et l'IA la trouveront en travaillant sur ce Projet ou ce Domaine.

### Step 5 : Valider les propriétaires et les action items

Affiche les action items extraits groupés par propriétaire et demande :

> Voici les action items que j'ai extraits, groupés par propriétaire :
>
> [[Propriétaire 1]] : [liste]
> [[Propriétaire 2]] : [liste]
> Non assignés : [liste]
>
> 1. C'est correct ? Ajoute, retire, ou réassigne ?
> 2. Confirme les échéances manquantes.
> 3. Ajoute une note ou une impression sur cette réunion (optionnel, stocké dans le résumé) ?

**ATTENDS LA VALIDATION** avant de continuer. Chaque action item doit avoir un propriétaire avant de procéder.

### Step 6 : Router les actions vers Projets, Domaines, et Organigramme

Pour chaque action item validé, place une entrée de tâche là où elle est vraiment possédée :

- Action scopée à un Projet -> ajoute à `1 Projets/[projet]/` (la liste de tâches du projet, la note kanban, ou la note de jalon actif). Utilise des [[wikilinks]] vers la note de réunion.
- Action scopée à un Domaine ou récurrente -> ajoute à `2 Domaines/[domaine]/` dans la note running pertinente ou la liste de tâches.
- Action perso qui vit sur le profil d'un membre de l'équipe -> ajoute un pointeur d'une ligne vers `2 Domaines/Vision & Contexte/Organigramme/[Personne].md` sous une section `## Actions` si le fichier personne existe.

Ne duplique pas. S'il existe déjà une tâche équivalente, link la note de réunion à elle au lieu d'en créer une seconde. Appende `(depuis réunion YYYY-MM-DD)` à côté des items nouvellement ajoutés.

Si un Projet ou un Domaine référencé n'existe pas encore, signale-le et demande s'il faut le créer (ne crée pas silencieusement).

Note : on ne met PAS à jour la Revue Hebdo ici. Les revues hebdo sont individuelles (`/weekly-review-team-member`), et chaque membre tire ses propres actions dans sa propre revue le vendredi. Le routage vers Projets, Domaines, et Organigramme suffit; les revues récupèrent à partir de là.

### Step 7 : Signaler les décisions stratégiques pour le Cycle Stratégique

Vérifie la section « Signaux stratégiques » de la réunion. Pour chaque décision stratégique non triviale :

- Détecte le Cycle Stratégique actif (ne jamais hardcoder) :
  ```bash
  ls "2 Domaines/Vision & Contexte/Cycles Stratégiques/"Cycle\ Stratégique\ -\ *.md 2>/dev/null | sort | tail -1
  ```
- Lis-le. Si la décision change le plan de 2-3 mois (nouvelles dates, nouvelles deadlines, changement de scope, nouvelle initiative, initiative tuée, pivot), update le Cycle Stratégique et ajoute une entrée d'une ligne à `2 Domaines/Vision & Contexte/Logs/` notant la réunion source.
- Si rien ne change au niveau macro, laisse le Cycle Stratégique tranquille.

Dis à l'utilisateur ce qui a été updaté (ou que rien n'avait besoin d'être updaté).

### Step 8 : Résumé final

```
=== Meeting Review terminé ===

Note classée : [dossier]/[nom]
Action items : X total (Propriétaire A : n, Propriétaire B : n, non assignés : 0)
Routés : Y items vers Projets, Z items vers Domaines, W pointeurs vers Organigramme
Cycle Stratégique : updaté / inchangé
```

## Règles

- **L'essence est de classer dans le bon dossier.** Détermine le dossier d'abord (Step 1), valide-le, et classe la note là (Step 4). Une note de réunion au mauvais endroit est une note perdue.
- Lis toujours le transcript COMPLET, jamais juste le résumé auto-généré.
- Chaque action item a un propriétaire nommé. Pas d'actions orphelines.
- La validation est OBLIGATOIRE au Step 1 (dossier), Step 5 (actions), et avant toute création de fichier.
- Ne supprime jamais le transcript brut de la note; il reste en bas.
- Utilise des [[wikilinks]] pour les projets, domaines, et personnes connus (Organigramme).
- Si un Projet, un Domaine, ou un fichier personne est référencé mais manquant, signale-le et demande. N'invente jamais d'entités.
- Détecte le Cycle Stratégique (ne jamais hardcoder le nom).
- Pas de tirets longs (utilise deux points, virgule, parenthèse, ou reformule).
- Pas de tic rhétorique « pas X mais Y ». Dis les choses directement.
- Pas d'emojis.
- Concis, pas de blabla.

## Ce que tu ne fais pas

- Laisser la note de réunion dans `0 Inbox/` ou un dossier générique. Classe-la dans le bon sous-dossier `Meetings/` de Projet ou Domaine.
- Déterminer le dossier après avoir écrit le résumé. Le dossier est la première décision (Step 1); le résumé est écrit dans la note à ce chemin (Step 3).
- Résumer depuis le résumé auto-généré en haut d'une note de transcript. Lis le transcript brut complet.
- Updater une Revue Hebdo individuelle. Les revues sont perso (une par membre de l'équipe); les actions sont routées vers Projets/Domaines/Organigramme, et chaque membre tire les siennes dans sa revue du vendredi.
- Hardcoder le nom du Cycle Stratégique. Détecte-le.
- Créer un Projet, un Domaine, ou un fichier personne silencieusement. Signale et demande.
- Supprimer le transcript brut. Garde-le en bas de la note pour la traçabilité.
- Inventer des participants, propriétaires, ou décisions de réunion. Si c'est pas clair, demande.
