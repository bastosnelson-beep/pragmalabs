---
name: map-process
description: "Cartographie chaque tâche d'un membre de l'équipe (quotidien, hebdo, mensuel, sur-déclencheur), combien de temps chacune prend, comment il la fait, avec quelle méthode et quels outils. Guidé, séquentiel, une phase à la fois. Produit une note Process Map par employé (groupée par fréquence) dans 3 Ressources/Process/[Employé]/, puis une Fiche de Process par process, une à la fois, sacré. L'objectif final : l'IA peut prendre le relais sur certaines de ces tâches, ou le membre divise son temps d'exécution par 2 à 10x parce que l'IA fait la tâche et il supervise. À lancer avec un membre de l'équipe à la fois."
---

# /map-process : Cartographier les process d'un membre de l'équipe

Tu cartographies les process d'un membre de l'équipe via une conversation guidée, puis tu les écris. L'objectif, énoncé d'emblée au membre :

> « À la fin de ça, tu auras listé explicitement chaque action que tu fais dans une semaine et un mois typiques, combien de temps chacune prend, comment tu la fais, avec quelle méthode et quels outils. Deux issues : soit l'IA prend le relais sur certaines de ces tâches pour toi, soit tu divises ton temps d'exécution par 2 à 10x parce que l'IA fait la tâche et tu supervises. Pour y arriver, on doit être maximalement concrets. »

C'est séquentiel. Une phase à la fois. Un process à la fois à la fin. Pas de surcharge de contexte. Ne saute pas en avant.

## Comment lancer

Tu lances ça avec UN membre de l'équipe à la fois. Demande qui tu cartographies (prénom + rôle) au tout début (ou vérifie dans 2 Domaines/Vision & Contexte/Organigramme). Tout ce que tu produis atterrit dans `3 Ressources/Process/[Employé]/`.

---

## Phase 0 : Scope (clarifier le périmètre)

Commence ici. Avant toute liste de tâches, capture le cadre.

S'il existe ici, 2 Domaines/Vision & Contexte/Organigramme alors juste confirme, sinon :

Demande :

> « C'est quoi ton scope dans l'entreprise ? Quelles sont tes responsabilités ? En une ou deux phrases, qu'est-ce que tu es là pour livrer ? »

Écoute. Reformule en 2-3 phrases. Demande : « C'est accurate ? Quelque chose à ajouter ou retirer ? »

Ce cadre guide tout ce qui suit. Garde-le en mémoire (il va dans la note Process Map plus tard).

Suivi optionnel si c'est vague : « Et à quoi ressemble « bien faire ton rôle » ? C'est quoi le North Star de ton rôle ? »

Ne passe pas à la Phase 1 avant que le scope soit clair et validé.

---

## Phase 1 : Jour, puis semaine, puis mois (le dump concret)

Explique le rythme, et donne la règle d'échelle d'emblée (avant qu'ils se mettent à parler) :

> « On va dans l'ordre : ta journée typique, puis ta semaine typique, puis ton mois. Sois aussi concret que possible. Nomme les vraies actions, pas des catégories. Je vais te donner des exemples pour calibrer le niveau de détail dont j'ai besoin.
>
> Une règle d'échelle, avant que tu commences : l'unité qu'on cartographie est une session de travail que tu peux faire en une seule fois. Pas un méta-projet. « Produire une vidéo YouTube » n'est pas un process, c'est quatre : trouver les idées, écrire le script, monter, scheduler et publier. « Écrire une proposition » est un process : prends le contenu de la réunion, clarifie la proposition, les étapes sont claires et tu le fais en une seule fois. Décharge librement, à cette échelle, sans contrainte. On affinera l'échelle et on vérifiera rien n'a été manqué après. »

Laisse-les parler et capture. N'interromps pas pour questionner l'échelle ou la complétude maintenant (c'est la Phase 2). Juste collecte, à peu près au niveau une-fois qu'ils te donnent.

### Phase 1a : La journée typique

Demande :

> « Prends une journée typique. Du moment où tu commences (arrives au bureau) au soir. Quelles sont les tâches que tu fais chaque jour, sans exception ? »

Donne des exemples pour calibrer (prends-en quelques-uns, ne récite pas tout) :
- Répondre aux emails
- Contacter un fournisseur
- Vérifier le statut des commandes / projets que tu gères
- Créer un report
- Créer du contenu
- Checker le dashboard
- Faire le standup

Laisse-les parler. Capture la liste au fur et à mesure. N'interromps pas avec des questions clarifiantes maintenant (c'est la Phase 2). Juste collecte.

### Phase 1b : La semaine typique

Demande :

> « Maintenant la semaine. Dans une semaine typique, quelles sont toutes les tâches que tu fais qui sont dans ton scope ? Des choses qui ne sont pas quotidiennes mais qui reviennent chaque semaine. Très concret. »

Donne des exemples pour calibrer :
- Prospecter : appeler X clients, envoyer Y follow-ups
- Envoyer une proposition par email
- Vérifier le statut des commandes
- Répondre aux tickets de support client
- Créer les scripts des vidéos YouTube
- Shooter les vidéos YouTube
- Monter les vidéos YouTube
- Faire tourner la réunion d'équipe hebdo
- Updater le CRM
- Revoir le pipeline

Capture la liste.

### Phase 1c : Le mois

Demande :

> « Et chaque mois, que fais-tu que tu ne fais pas chaque semaine ? Reports mensuels, compta, revues, planning, factures, inventaires, etc. »

Capture la liste.

À la fin de la Phase 1, tu as trois listes brutes : quotidien, hebdo, mensuel. Ne structure pas encore.

---

## Phase 2 : Échelle, puis complétude

Le seul objectif de cette phase est deux choses, dans cet ordre :
1. Chaque process est à la bonne échelle (une seule fois).
2. Rien n'a été oublié.

Ne capture pas méthode, étapes, outils, ou handoffs ici. C'est la Phase 4. Ici, tu ajustes seulement l'échelle et tu balaies pour la complétude.

### Phase 2a : Mets chaque process à la bonne échelle

Traverse les trois listes que tu as capturées. Pour chaque item, juge-le contre la règle une-fois :

- **Si c'est un méta-process** (s'étale sur plusieurs fois), split-le. Promène le membre à travers le split.
- **Si c'est déjà une fois**, garde-le tel quel.
- **Si deux items sont en fait le même process dit deux fois**, merge-les.

Annonce :

> « Maintenant je traverse ce que tu m'as dit et j'ajuste l'échelle. L'unité est une session de travail que tu peux faire en une seule fois. Si quelque chose que tu as listé est en fait plusieurs fois, on le split. Si c'est déjà une fois, on le garde. »

L'exemple canonique pour ancrer la règle :

> « « Produire une vidéo YouTube » n'est pas un process, c'est quatre : trouver les idées, écrire le script, monter, scheduler et publier. Chacun est une fois. « Écrire une proposition » est un process : prends le contenu de la réunion, clarifie la proposition, tu le fais en une fois. »

Pour chaque méta-process que tu repères, nomme le split et valide-le avec le membre :

> « Tu as dit « produire la vidéo YouTube ». C'est un méta-process. Les process une-fois à l'intérieur sont : trouver les idées, écrire le script, monter, scheduler et publier. C'est le bon cut pour toi, ou tu le coupes différemment ? »

Reformule la liste splitée, groupée par fréquence (quotidien / hebdo / mensuel / sur-déclencheur). Valide.

### Phase 2b : Balayage de complétude

Maintenant assure-toi que rien n'a été manqué. Ne passe pas à la suite avant que le membre ait vraiment cherché.

Annonce :

> « Voilà ce que j'ai capturé jusqu'ici. Y a-t-il quelque chose que tu fais qui n'est pas écrit là ? Creuse dans ta tête. Ferme les yeux, visualise-toi dans une journée, puis dans une semaine. Y a-t-il quelque chose que tu fais qui n'est pas listé ici, et des responsabilités que tu as qui ne sont pas ajoutées ? »

Laisse-leur le silence pour réfléchir. Puis capture ce qui vient.

Si le membre sèche, un nudge optionnel (utilise avec parcimonie, seulement s'il est bloqué) :

> « Une lentille rapide à travers les 6 fonctions business : Acquisition (comment les clients te trouvent), Sales (comment un prospect signe), Delivery/Operations (comment tu livres), Rétention (comment tu gardes les clients), Support (comment tu gères les problèmes), Admin/HR (le reste). Y a-t-il quelque chose dans ton scope qui touche l'une de ces fonctions qu'on n'a pas capturé ? »

### Fin de la Phase 2

Tu as maintenant une liste où chaque process est à l'échelle une-fois et rien n'a été oublié, groupée par fréquence.

Reformule toute la liste au membre une dernière fois, et demande : « C'est la liste complète, à la bonne échelle ? Quelque chose à ajouter, splitter, ou merger ? »

Passe à la Phase 3 seulement quand le membre confirme.

---

## Phase 3 : Créer la note Process Map

Maintenant tu écris la note maîtresse qui tient toute la map, groupée par fréquence.

### Où elle vit

`3 Ressources/Process/[Employé]/Process Map de [Employé].md`

Crée le dossier s'il n'existe pas :
```bash
mkdir -p "3 Ressources/Process/[Employé]"
```

### La structure de la note

```markdown
---
type: process-map
employee: "[Employé]"
role: "[rôle]"
domain: "[[Nom du domaine]]"
last_mapped: [date du jour]
status: active
---

# Process Map de [Employé]

## Scope
[2-3 phrases de la Phase 0 : les responsabilités de cette personne et le North Star.]

## Quotidien
| Process | Ce que c'est | Temps | x/jour | Fiche |
|---------|-----------|------|------|-------|
| [[Process 1]] | [une ligne] | [ex 30 min] | [ex 3] | link |
| [[Process 2]] | ... | ... | ... | ... |

## Hebdo
| Process | Ce que c'est | Temps | x/semaine | Fiche |
|---------|-----------|------|--------|-------|

## Mensuel
| Process | Ce que c'est | Temps | x/mois | Fiche |
|---------|-----------|------|---------|-------|

## Sur-déclencheur
| Process | Ce que c'est | Temps | Trigger | Fiche |
|---------|-----------|------|---------|-------|

## Budget temps
[Somme approximative : où va la semaine. « Sur ~40h, ~15h en delivery, ~10h en sales, ~8h en support, ~7h en admin. » Ça drive la priorité IA ci-dessous.]

## Délégation / priorité IA
[Top 3 process par potentiel de prise en charge IA, classés, avec une ligne de pourquoi. Ce sont les candidats à transformer en skills via /create-skill ou à automatiser via /new-automation.]
1. [[Process X]] : [pourquoi]
2. [[Process Y]] : [pourquoi]
3. [[Process Z]] : [pourquoi]
```

Les wikilinks `[[Process N]]` sont rouges (non créés) pour l'instant. La Phase 4 crée les fiches, une par une, et les links deviennent live.

Montre la note au membre. Valide la structure et le budget temps. Puis passe à la Phase 4.

---

## Phase 4 : Fiches de process, une à la fois (sacré, séquentiel)

C'est le coeur. Tu traverses la note Process Map ligne par ligne, process par process, et pour chacun tu crées une Fiche de Process dédiée. **Une à la fois. Sacré. Pas de surcharge.**

Annonce la discipline :

> « Maintenant on va process par process. Je crée une fiche pour chacun, on la remplit ensemble, je valide avec toi, puis et seulement puis on passe au suivant. Un à la fois, pour rester précis. »

### Où vit chaque fiche

`3 Ressources/Process/[Employé]/[Nom du process].md`

### Pour chaque process

Ouvre la conversation avec :

> « Cartographions [[Nom du process]]. J'ai besoin : les inputs, l'output attendu, les étapes que tu traverses (avec la méthode à chaque étape), et les outils que tu utilises par étape. »

Puis capture, à travers la conversation, ce qui suit. Ne pose pas toutes les questions d'un coup : suis le membre, creuse la méthode.

**1. Objectif** (1 phrase) : ce que ce process produit, pourquoi il existe.

**2. Inputs** (ce qui rentre) : une demande, un document, un trigger, de la data d'un autre système, un handoff de quelqu'un. Sois spécifique.

**3. Outputs attendus** (ce qui devrait exister quand c'est fait) : un email envoyé, une proposition signée, une vidéo publiée, un record updaté, un fichier validé. Sois spécifique et concret.

**4. Étapes (la méthode)** : le coeur. Traverse les étapes une par une. Pour une proposition, les étapes pourraient être : scoper le contenu, drafter, reformuler, valider, envoyer. Pour chaque étape, capture :

- **Ce que je fais :** l'action concrète.
- **La méthode :** comment le membre décide quoi faire ici. C'est la partie la plus importante. Pour faire émerger la méthode, demande :
  - « C'est quoi ton intuition à cette étape ? Qu'est-ce que tu décides le plus souvent ? »
  - « Sur quel concept ou critère bases-tu ton choix ici ? »
  - « Y a-t-il des éléments de réflexion ou des méthodes que tu appliques à cet endroit précis ? »
  - « Y a-t-il une façon dont tu juges « bon » vs « pas bon » à cette étape ? »
- **Outils :** le ou les outils utilisés à cette étape (très important, rends-le explicite).
- **Handoff :** si le membre passe à quelqu'un d'autre à cette étape, qui, dans quel format, pour quand (si applicable).

**5. Validation / contrôle qualité** (le juge final) : comment le membre sait que l'output est bon avant qu'il parte. Ce qu'il vérifie, ce que « bon » veut dire, les critères contre lesquels il juge. (C'est souvent la dernière étape, mais signale-le explicitement.)

**6. Outils utilisés** (résumé) : la stack d'outils pour ce process, avec à quoi sert chacun.

**7. Délégation / potentiel IA** : quelle partie l'IA pourrait faire ou accélérer, et quelle partie doit rester humaine. Note-la haut / moyen / bas, avec une ligne de pourquoi. C'est le pont vers `/create-skill` et `/new-automation`.

### Le modèle de Fiche de Process

Écris la fiche depuis ce modèle :

```markdown
---
type: process
employee: "[Employé]"
frequency: "quotidien|hebdo|mensuel|sur-déclencheur"
time_estimate: "[ex 45 min, x3/semaine]"
domain: "[[Nom du domaine]]"
status: active
---

# [Nom du process]

## Objectif
[1 phrase : ce que ce process produit / pourquoi il existe.]

## Inputs
- [Ce qui rentre, concrètement]

## Outputs attendus
- [Ce qui existe quand c'est terminé, concrètement]

## Étapes (la méthode)

### Step 1 : [nom]
- **Ce que je fais :** [action concrète]
- **Méthode :** [l'intuition, ce que je décide le plus souvent, le concept/critère sur lequel je base mon choix, les éléments de réflexion / méthodes que j'applique ici]
- **Outils :** [outil(s) à cette étape]
- **Handoff :** [à qui je passe, dans quel format, pour quand, si applicable]

### Step 2 : [nom]
- **Ce que je fais :** ...
- **Méthode :** ...
- **Outils :** ...
- **Handoff :** ...

[... autant d'étapes que le process a ...]

## Validation / contrôle qualité
[Comment je juge que l'output est bon avant qu'il parte. Ce que je vérifie, ce que « bon » veut dire, les critères.]

## Outils utilisés
- [Outil 1 : pour quoi]
- [Outil 2 : pour quoi]

## Délégation / potentiel IA
- **Note :** haut / moyen / bas
- **Ce que l'IA pourrait faire ou accélérer :** [sois spécifique]
- **Ce qui doit rester humain :** [sois spécifique]
```

### Après chaque fiche

1. Écris le fichier à `3 Ressources/Process/[Employé]/[Nom du process].md`.
2. Update la note Process Map : remplace le placeholder `[[Process N]]` dans la table par le vrai wikilink `[[Nom du process]]` (maintenant live).
3. Valide avec le membre : « Voici la fiche pour [[Nom du process]]. Ça matche comment tu le fais vraiment ? Quelque chose à corriger ? »
4. Applique les corrections.
5. Seulement alors, passe au process suivant. Annonce : « Suivant : [[Process 2]]. »

### Discipline

- **Un process à la fois.** Ne batch pas. Ne drafe pas 5 fiches puis valide 5. Une fiche, validée, puis la suivante.
- **Reste concret.** Si le membre dit « je prépare la proposition », demande « Promène-moi à travers ce que tu ouvres et fais vraiment. » La méthode vit dans le concret, pas dans la catégorie.
- **Fais émerger la méthode.** Le risque est de capturer les étapes sans la méthode. Pour chaque étape, pose les questions intuition/concept/critère. La méthode est ce qui permet à l'IA de reproduire ou accélérer la tâche.
- **N'invente jamais.** Si une étape ou un outil n'est pas clair, demande. Ne remplis pas avec « probablement » ou « en général ».

---

## Fin de la commande

Quand chaque process de la note Process Map a sa fiche, la commande est terminée.

Dis au membre :

> « Terminé. Tu as maintenant une Process Map de [[Employé]] et [N] Fiches de Process, une par process. Chaque étape, méthode, et outil est explicite.
>
> Deux issues sont maintenant possibles :
> 1. L'IA peut prendre le relais sur certaines de ces tâches (celles à haut potentiel).
> 2. Tu peux diviser ton temps d'exécution par 2 à 10x sur le reste, parce que l'IA fait la tâche et tu supervises.
>
> Prochaines étapes :
> - Lance `/create-skill` sur les 1 à 3 process du top de la liste Délégation / priorité IA, pour en faire des skills exécutables que l'IA peut lancer.
> - Lance `/new-automation` sur tout process qui est un candidat automation clair (récurrent, basé sur outil, rule-driven).
> - Relance `/map-process` chaque fois que ton scope change ou chaque trimestre, pour garder la map honest. »

Log la session dans `2 Domaines/Pilotage/Logs de Session/` via `/done`.

---

## Règles

- **Séquentiel.** Phase 0, puis 1a, 1b, 1c, puis 2, puis 3, puis 4. Ne saute pas en avant. Ne commence pas la Phase 4 avant que la note de la Phase 3 soit validée.
- **Un process à la fois** en Phase 4. Sacré. Pas de batch, pas de surcharge.
- **Concret plutôt que catégoriel.** « Envoyer une proposition par email » pas « gérer les sales ». « Checker les 3 spreadsheets fournisseurs et emailer le bid le plus bas » pas « gérer les fournisseurs ».
- **Fais émerger la méthode.** Pour chaque étape, demande l'intuition, le concept, le critère, ce qu'ils décident le plus souvent. La méthode est le livrable.
- **Le temps compte.** Capture une estimation de temps approximative par process. Ça drive la priorité IA.
- **Reformule** après chaque phase pour valider avant de passer.
- **N'invente jamais.** Si quelque chose n'est pas clair, demande.
- **Respecte le style** : pas de tirets longs, pas de tic « pas X mais Y », direct, concis, [[wikilinks]] dans les notes.

## Ce que tu ne fais pas

- Skipper la Phase 0 (scope). Sans le cadre, la liste de tâches est sans bornes.
- Lancer le questionnement comme un checklist rigide. Suis le membre, creuse ce qui est riche, skippe ce qui est clair.
- Passer à la Phase 4 avant que le membre confirme que la liste est complète.
- Batcher les fiches de process. Une à la fois, validée, puis la suivante.
- Capturer les étapes sans la méthode. Les étapes seules ne permettent pas à l'IA de reproduire ou accélérer la tâche.
- Mettre les fiches de process ailleurs que dans `3 Ressources/Process/[Employé]/`.
- Oublier de wikilinker chaque fiche depuis la note Process Map (c'est l'index).
- Stocker des secrets dans les fiches. Référence les outils, ne colle jamais les credentials.
