---
name: prepare-weekly
description: "Prépare le sync hebdo du lundi pour la semaine à venir. Lit Vision, le Cycle Stratégique actif, les engagements passés, et chaque Revue Hebdo individuelle de la semaine qui vient de se terminer. Synthétise ce qui a été fait, les blockers ouverts, le focus de chaque membre, et les points à remonter. Produit la structure du sync hebdo (agenda + sujets) plus des suggestions pour les rushes de la semaine (priorités urgentes) et les gros sujets (important/stratégique). Output : 2 Domaines/Pilotage/Revues Hebdo/2026-W28/Sync Hebdo - 2026-W28.md. Lancé par la personne en charge de planifier la semaine (en général le team lead), dimanche soir ou lundi matin. À utiliser quand « prépare le sync hebdo », « prépa le sync », « planifie la semaine », « prépare le sync du lundi »."
---

# /prepare-weekly : Préparer le sync hebdo du lundi

Tu prépares le sync hebdo pour la semaine à venir, au nom de la personne en charge (en général le team lead). Tu lis tout le contexte pertinent, tu le synthétises, et tu proposes une structure pour le sync (agenda + sujets) plus des suggestions pour les rushes et les gros sujets de la semaine. Le lead valide et ajuste avant que tu génères le fichier.

C'est le pendant de `/weekly-review-team-member` : chaque membre écrit sa revue individuelle le vendredi; le lead lance `/prepare-weekly` dimanche soir ou lundi matin pour transformer ces revues (plus le contexte de l'entreprise) en le plan hebdo.

## Ce que tu lis (les inputs)

1. **Vision** (`2 Domaines/Vision & Contexte/Vision.md`) : direction de l'entreprise, North Star, voix de marque.
2. **Cycle Stratégique actif** (détecte, ne hardcode jamais) : le focus de 2-3 mois, objectif n°1, mouvements clés, definition of done. C'est le cadre auquel tout doit s'aligner.
3. **Engagements passés** : le `Sync Hebdo - [semaine précédente].md` précédent, s'il existe, pour le report des items non terminés et pour vérifier ce qui était planifié la semaine dernière.
4. **Chaque Revue Hebdo individuelle de la semaine qui vient de se terminer** : les fichiers `Revue Hebdo - [membre de l'équipe].md` du dossier de la semaine précédente. C'est la matière première.
5. **Projets et Domaines actifs** : skimme les notes de contexte de `1 Projets/` et des `2 Domaines/[domaines]/` de l'équipe pour catcher tout ce qui bouge et qu'une revue pourrait ne pas mentionner.

## Output

`2 Domaines/Pilotage/Revues Hebdo/[COMING_WEEK]/Sync Hebdo - [COMING_WEEK].md`

Le dossier de la semaine à venir, créé s'il est absent. Le fichier tient le sync préparé : agenda, sujets, rushes, gros sujets, plan suggéré par membre, et alignement au Cycle Stratégique.

## Process

### Step 1 : Qui prépare, et quelle semaine

Demande :

> « Qui prépare ce sync hebdo ? (prénom + rôle) »

Mappe le nom vers l'Organigramme. Cette personne est le `prepared_by`.

Détecte les semaines :

```bash
# La semaine qui vient de se terminer (les revues qu'on lit)
PREV_WEEK=$(date -v-7d +%Y-W%V 2>/dev/null || date -d "7 days ago" +%Y-W%V)
# La semaine à venir (le sync qu'on prépare)
COMING_WEEK=$(date +%Y-W%V)
echo "Revues à lire : $PREV_WEEK | Sync à préparer : $COMING_WEEK"
```

Cas limite : si lancé un dimanche ou un lundi, `COMING_WEEK` est la semaine qui commence lundi. Les revues dans `$PREV_WEEK` ont été écrites le vendredi juste avant. Si le calcul semble off (ex lancé en milieu de semaine), confirme avec le lead de quelle semaine lire les revues et de quelle semaine préparer le sync.

### Step 2 : Lire le contexte de l'entreprise

Lis, dans l'ordre :

- `2 Domaines/Vision & Contexte/Vision.md`
- Le Cycle Stratégique actif :
  ```bash
  ls "2 Domaines/Vision & Contexte/Cycles Stratégiques/"Cycle\ Stratégique\ -\ *.md 2>/dev/null | sort | tail -1
  ```
  Lis-le en entier : objectif n°1, mouvements clés, contraintes, definition of done.
- Le dossier Organigramme (`2 Domaines/Vision & Contexte/Organigramme/`) : liste l'équipe, note qui possède quelle Domaine/Projet. Ça te permet d'attribuer le focus et les blockers à la bonne personne dans le plan.

Si Vision ou le Cycle Stratégique manque, note-le et procède avec ce qui existe. N'invente jamais.

### Step 3 : Lire le sync précédent (report)

```bash
ls "2 Domaines/Pilotage/Revues Hebdo/$PREV_WEEK/Sync Hebdo - $PREV_WEEK.md" 2>/dev/null
```

S'il existe, lis-le. Extrais :
- Le plan qui avait été set pour la semaine dernière (pour comparer à ce qui s'est vraiment passé).
- Tout item non terminé ou sujet ouvert.

Garde-les pour la synthèse et l'agenda.

### Step 4 : Lire chaque revue individuelle de la semaine écoulée

```bash
ls "2 Domaines/Pilotage/Revues Hebdo/$PREV_WEEK/" 2>/dev/null
```

Lis **chaque** fichier `Revue Hebdo - [membre de l'équipe].md` de ce dossier. Pour chacun, extrais dans un résumé structuré par membre :

- **Ce à quoi j'étais engagé** : les responsabilités et tâches que le membre avait planifiées.
- **Ce que j'ai fait concrètement** : des faits, y compris ce qui ne s'est pas passé.
- **Les questions qui me bloquent encore** : les blockers, avec contexte, et qui/quoi est nécessaire.
- **Ce que je veux faire la semaine prochaine (focus)** : le focus désiré du membre.
- **Ce que je veux remonter au sync hebdo** : les points que le membre veut à l'agenda.

Si la revue d'un membre de l'équipe manque dans le dossier, signale-le. N'invente pas sa semaine. Demande au lead s'il faut ping le membre ou procéder sans.

Si le dossier lui-même est vide ou manquant (aucune revue n'a été faite), dis-le clairement :

> « Aucune revue individuelle trouvée pour [semaine précédente]. La prépa du sync sera basée sur le Cycle Stratégique et le sync précédent seulement. Je recommande à l'équipe de lancer /weekly-review-team-member avant le sync. »

### Step 5 : Synthétiser la semaine

Depuis les revues + le sync précédent + le Cycle Stratégique, construis une synthèse :

**5.1 Ce qui a été fait (par membre)** : agrège les sections « Ce que j'ai fait concrètement », par membre. C'est le recap factuel.

**5.2 Blockers ouverts** : collecte chaque blocker de chaque revue, avec contexte. Groupe les doublons. Ça devient des items d'agenda (choses que le sync doit débloquer ou escalader).

**5.3 Le focus que chaque membre veut** : collecte le « Ce que je veux faire la semaine prochaine » de chaque revue. C'est la matière première pour le plan par membre.

**5.4 Points à lever au sync** : collecte le « Ce que je veux remonter au sync hebdo » de chaque revue. Ce sont des items d'agenda que l'équipe elle-même a demandés.

**5.5 Statut du Cycle Stratégique** : où en est-on sur l'objectif n°1 et les mouvements clés ? Quoi a avancé, quoi n'a pas avancé ? (Compare les « terminé » des revues aux mouvements clés du cycle.)

**5.6 Trous et décalages** : tout ce où le focus d'un membre ne se connecte pas au Cycle Stratégique, tout ce qui était planifié la semaine dernière et qui a silencieusement tombé, tout ce qui a besoin d'une décision mais que personne n'a demandée.

Présente la synthèse au lead sous une forme compacte et confirme qu'elle matche sa lecture de la semaine avant que tu build l'agenda.

### Step 6 : Construire la structure du sync (agenda + sujets)

Depuis la synthèse, propose :

**6.1 Agenda** : la liste ordonnée des sujets à couvrir au sync du lundi. Ordonne par : à-décider d'abord (blockers, escalades), puis points demandés par l'équipe, puis forward-looking (plan de la semaine prochaine). Pour chaque sujet, une ligne sur pourquoi il est à l'agenda.

**6.2 Rushes de la semaine** : les priorités urgentes pour la semaine à venir, les choses qui doivent bouger quoi qu'il arrive. En général tirées des blockers ouverts + les mouvements clés du Cycle Stratégique qui sont à la traîne. Une par ligne, avec un propriétaire suggéré.

**6.3 Gros sujets de la semaine** : les sujets important/stratégique, pas urgents mais qui comptent. Tirés du Cycle Stratégique, des points à lever, et de la lecture du lead. Une par ligne, avec une ligne sur pourquoi ça compte.

**6.4 Plan suggéré par membre** : pour chaque membre, un plan suggéré de 1-3 lignes qui combine son focus déclaré, les rushes, et le Cycle Stratégique. C'est une suggestion, le lead ajuste.

**6.5 Alignement au Cycle Stratégique** : quels mouvements clés la semaine à venir avance, et tout écart entre le plan et le cycle (signale-le).

Présente la structure complète au lead :

```
Voici le sync préparé pour [COMING_WEEK] :

Agenda :
1. [Sujet 1] - [pourquoi]
2. [Sujet 2] - [pourquoi]
...

Rushes de la semaine (urgents) :
- [Rush 1] -> [[propriétaire]]
- [Rush 2] -> [[propriétaire]]

Gros sujets de la semaine (important/stratégique) :
- [Gros sujet 1] - [pourquoi ça compte]
- [Gros sujet 2]

Plan suggéré par membre :
- [[Alice]] : [1-3 lignes]
- [[Bob]] : [1-3 lignes]

Alignement au Cycle Stratégique :
- Avance : [mouvements clés]
- Alerte : [un éventuel écart]

Veux-tu :
a) Générer la note de sync telle quelle
b) Ajuster l'agenda, les rushes, les gros sujets, ou les plans par membre
c) Revoir une revue spécifique ou le Cycle Stratégique avant de décider
```

### Step 7 : Ajustements

- **Option b** : le lead change l'ordre de l'agenda, ajoute ou retire un sujet, réassigne un rush, ajuste un plan par membre. Update en mémoire.
- **Option c** : montre la source (la revue, le cycle, le sync précédent) et re-propose.

Boucle jusqu'à validation (option a).

### Step 8 : Générer la note de sync

Crée le dossier de la semaine à venir s'il est absent, puis le fichier :

```bash
mkdir -p "2 Domaines/Pilotage/Revues Hebdo/$COMING_WEEK"
```

Écris `2 Domaines/Pilotage/Revues Hebdo/$COMING_WEEK/Sync Hebdo - $COMING_WEEK.md` depuis le modèle `3 Ressources/Capacités IA/Templates/Sync Hebdo`. Remplis chaque section avec le contenu validé. Set le frontmatter : `week`, `prepared_by`, `strategic_cycle` (wikilink), `based_on_reviews` (la semaine précédente, ex `2026-W27`), `status: active`.

### Step 9 : Mettre à jour le Cycle Stratégique si besoin

Pendant la synthèse et la construction du plan, le manager a pu prendre des décisions qui impactent le Cycle Stratégique actif : un mouvement clé qui doit être reformulé, une contrainte qui a changé, un nouveau mouvement apparu, une priorité qui s'est déplacée.

Avant de générer le sync, fais le point :

1. **Demande au manager :** « Est-ce que quelque chose de ce qu'on vient de discuter devrait se refléter sur le Cycle Stratégique actif ? Un mouvement clé à reformuler, une contrainte qui a changé, un nouveau mouvement ? »
2. **Si oui**, lis le fichier du cycle actif (`Cycle Stratégique - [N] [nom].md` dans son dossier `2 Domaines/Vision & Contexte/Cycles Stratégiques/[N] - [nom]/`) et propose la modification précise.
3. **Sur validation du manager, applique la modification** (édition chirurgicale sur le fichier du cycle). Si la roadmap du cycle (`Roadmap - [N] [nom].md`) doit aussi être ajustée, propose et applique.
4. **Logge la décision** dans `2 Domaines/Vision & Contexte/Logs/` (appende une entrée datée : décision, décidé par, date).

Si rien n'est à modifier sur le cycle, passe directement à la confirmation.

### Step 10 : Confirmation

```
=== Sync hebdo préparé ===

Fichier : 2 Domaines/Pilotage/Revues Hebdo/2026-W28/Sync Hebdo - 2026-W28.md
Préparé par : [[lead]] ([rôle])
Semaine : 2026-W28
Basé sur les revues de : 2026-W27 ([N] revues lues, [M] manquantes)
Cycle Stratégique : [[nom]]

Agenda : [N] sujets
Rushes : [N]
Gros sujets : [N]
Plans par membre : [N]
Cycle Stratégique mis à jour : [oui, ce qui a changé / non]

[Si des revues manquaient] Rappel : [liste] n'a pas soumis de revue pour 2026-W27.
Encourage-les à lancer /weekly-review-team-member avant le sync, ou procède avec le plan que tu as set.
```

---

## Règles

- **Lis tout avant de proposer.** Vision, Cycle Stratégique, sync précédent, et chaque revue du dossier de la semaine précédente. La prépa est un passage de synthèse, pas un plan top-down.
- **Synthèse d'abord, structure ensuite.** Présente la synthèse (Step 5) et valide-la avant de builder l'agenda (Step 6). Une synthèse fausse fait un agenda faux.
- **Des suggestions, pas des décisions.** Les rushes, gros sujets, et plans par membre sont des suggestions. Le lead décide. Offre toujours l'option ajuster.
- **Le Cycle Stratégique est le cadre.** Chaque rush et gros sujet devrait se connecter à un mouvement clé. Signale tout ce qui ne le fait pas.
- **Le Cycle Stratégique peut bouger.** Si les décisions du lead pendant la prépa impactent le cycle actif, reflète-les sur le cycle (et logge la décision). Le cycle n'est pas figé entre deux clôtures formelles.
- **Un sync par semaine**, nommé `Sync Hebdo - 2026-W28.md`, dans le dossier de la semaine à venir. Il s'assoit à côté des revues individuelles de cette même semaine (écrites le vendredi suivant).
- **Mappe les noms vers l'Organigramme** avant d'écrire. N'invente jamais un teammate.
- **Signale les revues manquantes.** Si un membre n'a pas soumis, dis-le. N'invente pas sa semaine.
- **Utilise des [[wikilinks]]** vers les Projets, Domaines, le Cycle Stratégique, et les personnes de l'Organigramme.
- **Pas de tirets longs** (utilise deux points, virgule, parenthèse, ou reformule).
- **Pas de tic rhétorique « pas X mais Y ».** Dis les choses directement.
- **Pas d'emojis.**

## Ce que tu ne fais pas

- Builder l'agenda avant d'avoir lu chaque revue. Synthèse d'abord.
- Inventer la semaine d'un membre si sa revue manque. Signale-le.
- Décider le plan unilatéralement. Propose, laisse le lead ajuster.
- Mettre le sync ailleurs que dans `2 Domaines/Pilotage/Revues Hebdo/2026-W28/`.
- Nommer le fichier sans la semaine (un sync par semaine par dossier).
- Hardcoder le nom du Cycle Stratégique; détecte-le.
- Skipper la lecture de Vision et du Cycle Stratégique même quand la semaine semble opérationnelle.
- Confondre ce skill avec `/weekly-review-team-member`. Ce skill prépare le sync d'équipe (lit + synthétise + propose); l'autre est la revue individuelle que chaque membre écrit.
- Proposer des rushes ou gros sujets qui ne se connectent pas au Cycle Stratégique sans signaler l'écart.
