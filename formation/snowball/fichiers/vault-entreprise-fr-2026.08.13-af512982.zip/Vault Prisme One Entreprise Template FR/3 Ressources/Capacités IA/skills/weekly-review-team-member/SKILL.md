---
name: weekly-review-team-member
description: "Revue hebdo individuelle pour un membre de l'équipe, scopée à ses responsabilités. À lancer en fin de semaine (typiquement vendredi). Capture, dans l'ordre : ce à quoi j'étais engagé cette semaine, ce que j'ai fait concrètement, les questions qui me bloquent encore, le focus que je veux la semaine prochaine, et les points que je veux remonter au sync hebdo. Output : 2 Domaines/Pilotage/Revues Hebdo/2026-W28/Revue Hebdo - [membre de l'équipe].md (dossier de la semaine créé s'il est absent). La personne qui prépare le sync du lundi lit toutes les revues du dossier de la semaine pour construire le plan hebdo. À utiliser quand « revue hebdo », « ma revue hebdo », « passe en revue ma semaine »."
---

# Revue Hebdo (par membre de l'équipe)

C'est la revue hebdo **individuelle**, scopée à un membre de l'équipe et à ses responsabilités. Chaque membre la lance en fin de semaine (typiquement vendredi soir). Elle produit un fichier par personne et par semaine, tous rassemblés dans le même dossier de semaine, pour que la personne qui prépare le sync du lundi puisse toutes les lire et construire le plan hebdo en un seul passage.

Ce n'est pas le sync hebdo d'équipe. La préparation du sync est faite par la personne en charge (voir la dernière section), qui lit chaque revue individuelle du dossier de la semaine.

## Pourquoi individuelle + scopée

Une revue d'équipe perd ce que chaque personne a vraiment vécu. En scopant au membre, la revue capture à quoi il était engagé, ce qu'il a vraiment fait, ce qui le bloque, ce qu'il veut ensuite, et ce qu'il veut remonter. Agrégées dans un dossier, ces revues deviennent la matière première d'un plan hebdo holistique, sans que personne ait à chasser cinq personnes pour avoir un statut.

## Process

### Step 1 : Qui lance cette revue

Si tu ne sais pas, demande :

> « Qui fait cette revue hebdo ? (prénom + rôle) »

Mappe le nom vers l'Organigramme : `2 Domaines/Vision & Contexte/Organigramme/[Personne].md`.

Ce nom devient le nom du fichier et le frontmatter `team_member`.

### Step 2 : Lire le contexte du membre

Lis, pour l'alignement :

- Le fichier Organigramme du membre (`2 Domaines/Vision & Contexte/Organigramme/[Personne].md`) : rôle, périmètre, Domaines possédées, North Star du rôle.
- Le Cycle Stratégique actif : détecte-le, ne le hardcode jamais.
  ```bash
  ls "2 Domaines/Vision & Contexte/Cycles Stratégiques/"Cycle\ Stratégique\ -\ *.md 2>/dev/null | sort | tail -1
  ```
- Les Projets du membre : liste `1 Projets/`, lis les notes de contexte des projets que ce membre possède ou auxquels il est impliqué (recoupe les propriétaires dans les notes de projet).
- Les Domaines du membre : les notes du Domaine des domaines qu'il possède.

Ça te dit sur quoi le membre était censé travailler cette semaine, pour que la question 1 du Step 4 (à quoi j'étais engagé) puisse être pré-remplie et validée, pas inventée from scratch.

### Step 3 : Détecter la semaine et préparer le dossier

```bash
CURRENT_WEEK=$(date +%Y-W%V)
PREV_WEEK=$(date -v-7d +%Y-W%V 2>/dev/null || date -d "7 days ago" +%Y-W%V)
WK_DIR="2 Domaines/Pilotage/Revues Hebdo/$CURRENT_WEEK"
echo "Actuelle : $CURRENT_WEEK | Précédente : $PREV_WEEK"
mkdir -p "$WK_DIR"
ls "$WK_DIR" 2>/dev/null
```

Crée le dossier de la semaine s'il n'existe pas. Le nom du dossier est la semaine ISO, ex `2026-W28`. Toutes les revues de cette semaine, de tous les membres, atterrissent dans ce même dossier.

### Step 4 : Report depuis la revue précédente de ce membre

Cherche la revue de la semaine précédente **pour ce membre spécifique** :

```bash
PREV_DIR="2 Domaines/Pilotage/Revues Hebdo/$PREV_WEEK"
ls "$PREV_DIR/Revue Hebdo - [membre de l'équipe].md" 2>/dev/null
```

Si elle existe, lis-la. Extrais les items ouverts du « Ce que je veux faire la semaine prochaine » et tous les blockers non résolus. Garde-les : ils nourrissent la question 1 (à quoi j'étais engagé) et la question 3 (les questions qui me bloquent encore).

Si la revue précédente n'existe pas, skippe. N'invente pas de report.

### Step 5 : Les cinq questions, une par une

Pose ces questions **dans l'ordre**, une à la fois, et attends la réponse entre chaque. Reformule ce que tu as compris avant de passer à la suivante. Le membre peut répondre en écrit ou à la voix (dictée). Travaille dans la langue de travail de l'équipe.

Annonce :

> « On traverse cinq questions, une à la fois. C'est TA revue, scopée à tes responsabilités et à ta semaine. »

**Question 1 : Ce à quoi j'étais engagé (cette semaine)**

> « Quelles étaient tes responsabilités et les tâches que tu avais planifiées pour cette semaine ? »

Pré-remplis depuis le Step 2 (les Domaines, Projets, report du membre) et valide. Capture : les responsabilités (les Domaines / rôles) et les tâches concrètes planifiées pour la semaine.

**Question 2 : Ce que j'ai fait concrètement**

> « Concrètement, qu'est-ce que tu as accompli ? Pour chaque engagement : terminé, en cours, ou pas commencé ? »

Laisse le membre traverser. Capture la réalité, y compris ce qui ne s'est pas passé. C'est des faits, pas du récit.

**Question 3 : Les questions qui me bloquent encore**

> « Qu'est-ce qui t'empêche de commencer ou de finir ? Sur quels blockers as-tu besoin d'aide ? »

Capture les questions et les blockers, avec assez de contexte pour que la personne qui prépare le sync puisse agir dessus. Si un blocker a besoin d'une personne ou d'une décision spécifique, nomme-la.

**Question 4 : Ce que je veux faire la semaine prochaine (focus)**

> « C'est quoi ton focus pour la semaine prochaine ? »

Capture le focus, pas une liste de tâches complète. Une à trois choses sur lesquelles le membre veut se concentrer.

**Question 5 : Ce que je veux remonter au sync hebdo**

> « Quels points veux-tu lever au sync du lundi ? Des choses que l'équipe ou le lead doit savoir ou décider. »

Capture les points à lever. Ce sont les items que la personne qui prépare le sync devrait mettre à l'agenda.

### Step 6 : Générer le fichier de revue

Crée `2 Domaines/Pilotage/Revues Hebdo/$CURRENT_WEEK/Revue Hebdo - [membre de l'équipe].md` depuis le modèle `3 Ressources/Capacités IA/Templates/Revue Hebdo`. Remplis les cinq sections avec les réponses capturées. Set le frontmatter : `week`, `team_member`, `role`, `strategic_cycle` (wikilink vers le cycle actif), `status: active`.

```markdown
---
type: weekly-review
week: 2026-W28
team_member: "[membre de l'équipe]"
role: "[rôle]"
strategic_cycle: "[[Cycle Stratégique - nom]]"
status: active
---

# Revue Hebdo - [membre de l'équipe] - 2026-W28

## Ce à quoi j'étais engagé (cette semaine)
[capturé]

## Ce que j'ai fait concrètement
[capturé]

## Les questions qui me bloquent encore
[capturé]

## Ce que je veux faire la semaine prochaine (focus)
[capturé]

## Ce que je veux remonter au sync hebdo
[capturé]
```

### Step 7 : Mettre à jour les contextes

Avant de clôturer, fais le lien entre ce que le membre a dit et les notes de contexte du vault. Pour chaque projet ou domaine que le membre a mentionné dans sa revue (un projet qui a avancé, un problème, une modification, un truc qui n'a pas été fait) :

1. **Lis la note de contexte** du projet (`1 Projets/[projet]/[projet].md`) ou du domaine (`2 Domaines/[domaine]/[domaine].md`).
2. **Demande-toi : est-ce à jour ?** Ce que le membre vient de dire contredit-il, complète-il, ou invalide-il une information dans la note de contexte ?
3. **Si oui, propose une mise à jour.** Dis au membre ce que tu as trouvé et ce que tu proposes de modifier. Exemples :
   - « Tu dis que le projet X est passé en phase de test, mais la note de contexte dit encore "en conception". Je la mets à jour ? »
   - « Tu mentionnes un problème récurrent sur le domaine Y qui n'est pas dans la note de contexte. Je l'ajoute ? »
   - « La roadmap du projet Z liste encore une étape que tu dis terminée. Je la barre ? »
4. **Sur validation du membre, applique la modification** (édition chirurgicale, pas de réécriture complète).

Si rien n'est à mettre à jour, dis-le : « Rien à mettre à jour dans les contextes, tout est cohérent. »

### Step 8 : Confirmation

```
=== Revue Hebdo terminée ===

Fichier : 2 Domaines/Pilotage/Revues Hebdo/2026-W28/Revue Hebdo - [membre de l'équipe].md
Membre de l'équipe : [nom] ([rôle])
Semaine : 2026-W28
Cycle Stratégique : [[nom]]

Ta revue est sauvegardée dans le dossier de la semaine. La personne qui prépare le
sync du lundi la lira à côté de celles de tout le monde pour construire le plan hebdo.
Contextes mis à jour : [liste des notes modifiées, ou "aucun"]
```

---

## Pour la personne qui prépare le sync hebdo du lundi

Préparer le sync hebdo d'équipe à partir des revues individuelles de tout le monde est un boulot distinct, géré par le skill `/prepare-weekly`. Lance `/prepare-weekly` avant le sync du lundi (dimanche soir ou lundi matin) : il lit Vision, le Cycle Stratégique actif, les engagements passés, et chaque `Revue Hebdo - [membre de l'équipe].md` du dossier de la semaine précédente, puis propose la structure du sync (agenda + sujets) plus des suggestions pour les rushes et les gros sujets de la semaine. Output : `2 Domaines/Pilotage/Revues Hebdo/2026-W28/Sync Hebdo - 2026-W28.md`.

L'idée : tout a déjà été reporté par chaque membre dans sa propre revue. La prépa est un passage de lecture et synthèse, pas un passage de chasse-cinq-personnes-pour-le-statut. Voir `/prepare-weekly` pour la procédure complète.

---

## Règles

- **Individuelle et scopée.** C'est la revue d'un membre de l'équipe sur sa propre semaine, pas une revue d'équipe. Scope à ses responsabilités, Domaines, et Projets.
- **Cinq questions, dans l'ordre.** Ne les réordonne pas, ne les saute pas, ne les merge pas. Chaque capture une chose distincte.
- **Reformule après chaque réponse** avant de passer. Valide la compréhension.
- **Pré-remplis la question 1** depuis le contexte du membre (Domaines, Projets, report) et valide; n'invente pas les engagements.
- **Des faits pas du récit.** La question 2 c'est ce qui s'est vraiment passé, y compris ce qui n'a pas été fait.
- **Un fichier par membre par semaine**, nommé `Revue Hebdo - [membre de l'équipe].md`, dans le dossier de la semaine `2 Domaines/Pilotage/Revues Hebdo/2026-W28/`.
- **Le dossier de la semaine est l'espace partagé.** Toutes les revues des membres pour la même semaine vivent dans le même dossier. C'est ça qui rend la prépa du sync du lundi possible en un seul passage.
- **Mappe les noms vers l'Organigramme** avant d'écrire. N'invente jamais un teammate.
- **Utilise des [[wikilinks]]** vers les Domaines, Projets, le Cycle Stratégique, et les personnes de l'Organigramme quand c'est pertinent.
- **Mets à jour les contextes.** Si la revue révèle qu'une note de projet ou de domaine n'est plus à jour, propose la modification et applique-la sur validation. Une note de contexte figée devient fausse.
- **Pas de tirets longs** (utilise deux points, virgule, parenthèse, ou reformule).
- **Pas de tic rhétorique « pas X mais Y ».** Dis les choses directement.
- **Pas d'emojis.**

## Ce que tu ne fais pas

- Lancer ça comme une revue au niveau de l'équipe. C'est individuel, scopé à un membre.
- Mélanger les cinq questions ou les poser dans le désordre.
- Inventer les engagements du membre; pré-remplis depuis son contexte et valide.
- Mettre la revue ailleurs que dans `2 Domaines/Pilotage/Revues Hebdo/2026-W28/`.
- Nommer le fichier sans le nom du membre (le dossier tient un fichier par personne).
- Hardcoder le nom du Cycle Stratégique; détecte-le.
- Skipper la lecture du fichier Organigramme du membre et de ses notes de Projet/Domaine avant la question 1.
- Confondre ce skill avec la prépa du sync du lundi. Ce skill produit la revue individuelle; la prépa est un passage de lecture et synthèse fait par la personne en charge (décrit dans la dernière section).
- Skipper l'étape de mise à jour des contextes. C'est ce qui garde le vault vivant.
