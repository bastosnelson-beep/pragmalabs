---
name: clean-context
description: "Nettoie le contexte d'un Domaine ou d'un Projet : analyse toutes les notes d'un dossier, détecte les contradictions, les répétitions, les notes obsolètes, les infos à ajouter et les infos mal rangées, puis propose un plan de nettoyage concret (corriger, fusionner, archiver, déplacer). Lecture seule jusqu'à validation : propose, l'utilisateur décide. À utiliser par le responsable d'un Domaine ou d'un Projet pour maintenir son contexte à jour. Usage : /clean-context [chemin du dossier]."
---

# Clean Context : nettoyer le contexte d'un dossier

Le propriétaire d'un Domaine ou d'un Projet est responsable de garder son contexte à jour. Un contexte figé devient faux, et une IA qui lit du faux produit du faux avec assurance. `/clean-context` analyse un dossier et propose un plan de nettoyage concret. Lecture seule : rien n'est touché sans validation.

## Usage

```
/clean-context [chemin du dossier]
```

Le dossier est un Domaine (`2 Domaines/[domaine]`) ou un Projet (`1 Projets/[projet]`). Si aucun chemin n'est donné, demande-le et n'invente rien.

## Process

### Step 1 : Lister et lire les notes du dossier

```bash
find "[dossier]" -name "*.md" -type f | sort
```

Lis chaque note en entier. Un dossier de Domaine contient sa note de contexte principale (même nom que le dossier) plus les notes liées (process, running notes, sous-dossiers). Un dossier de Projet contient sa note de contexte, sa roadmap, ses livrables et ses logs.

Si le dossier est vide ou n'existe pas, dis-le et stoppe.

### Step 2 : Recomposer l'état actuel

Pour chaque note, extrais ce qu'elle dit vraiment aujourd'hui. Dégage la direction réelle du Domaine/Projet, au-delà des notes qui traînent depuis longtemps. C'est la référence contre laquelle on juge le reste.

### Step 3 : Analyser sur 5 axes

1. **Contradictions** : notes qui se contredisent (deux statuts, deux deadlines, deux prix, deux owners, deux versions d'un même process). Pour chacune, propose laquelle garder (la plus récente, la plus fiable) et laquelle corriger ou archiver. En cas de doute sur la vérité, signale-le plutôt que de trancher au hasard.

2. **Répétitions** : information dupliquée entre notes. Indique les notes concernées et propose une version synthétique. Chaque info vit une seule fois au bon endroit (principe PDRA : « à quoi ça sert ? »).

3. **Notes obsolètes** : notes qui ne sont plus alignées avec la direction actuelle (ancienne version, projet fini, process remplacé, référence périmée). Propose l'archive vers `4 Archive/`. Le doute tranche vers l'archive.

4. **À ajouter / améliorer** : notes incomplètes ou infos manquantes manifestes (un Projet sans roadmap ou sans owner, un Domaine sans North Star à jour, un process sans responsable). Propose des ajouts concrets, pas des vœux vagues.

5. **Mal rangées** : infos qui serviraient mieux ailleurs. Pour chacune, propose la destination :
   - Un autre Domaine (la responsabilité vit là)
   - Un autre Projet (l'info est sur une initiative temporaire)
   - `3 Ressources/Références/` (matériel de référence brut, inactif)
   - `2 Domaines/Vision & Contexte/` (si c'est stratégique : vision, décision, membre de l'Organigramme)
   - `0 Inbox/` (si tu ne sais pas, l'humain retriera)

### Step 4 : Proposer le plan

Affiche un rapport structuré sur les 5 axes, puis un plan d'action concret :

```
=== Plan de nettoyage : [dossier] ===
Responsable : [[Personne]] (si connu depuis l'Organigramme ou la note de contexte)

Contradictions :
- [note A] dit X, [note B] dit Y -> garder Y (plus récent), corriger A ligne [n]

Répétitions :
- [note A] + [note B] -> fusionner, version synthétique proposée

À archiver (4 Archive/) :
- [note X] : [raison]
- [note Y] : [raison]

À ajouter / améliorer :
- [note Z] : ajouter section [section] (owner, deadline, statut)

À déplacer :
- [info dans note W] -> [destination] (raison)

Valider pour exécuter ? (oui / non / ajuster)
```

Attends la validation. N'applique rien tant que l'utilisateur n'a pas dit oui.

### Step 5 : Exécuter (après validation)

Une fois validé, applique le plan chirurgicalement :

- Corrige les contradictions dans les notes (édition d'une ligne, pas de réécriture complète).
- Fusionne les répétitions dans la note la mieux placée, retire les doublons.
- Déplace les notes obsolètes vers `4 Archive/` (crée le sous-dossier `4 Archive/[domaine ou projet]/` si besoin).
- Ajoute les sections manquantes dans les notes concernées.
- Déplace les infos mal rangées vers leur destination. Si la destination n'existe pas, signale-le au lieu de l'inventer.

### Step 6 : Loguer

Conserve un log minimal dans `2 Domaines/Pilotage/Logs de Session/YYYY-MM-DD.md` (appende un bloc de session, comme /done) :

```markdown
## Session [HH:MM]

**Fait tourner par :** [[Personne]]
**Scope :** clean-context sur [dossier]

**Accompli :**
- [n] contradictions résolues
- [n] notes archivées
- [n] infos déplacées
- [n] sections ajoutées
```

## Règles

- Lecture seule jusqu'à validation. Tu proposes, l'utilisateur décide.
- Sois direct. Propose des actions concrètes, pas des analyses abstraites.
- Si tu hésites entre deux options, dis-le clairement. Ne tranche pas au hasard.
- Préfère archiver plutôt que garder « au cas où ». Le doute tranche vers l'archive.
- Chaque info vit une seule fois au bon endroit (ontologie d'intention PDRA).
- Édition chirurgicale : corrige une ligne, fusionne, déplace. Pas de réécritures complètes sans raison.
- Lis toujours une note avant de la modifier.
- Pas de tirets longs (U+2014). Pas de tic rhétorique « pas X mais Y ». Dis directement ce que tu veux.
- Pas d'emojis. Utilise des [[wikilinks]] vers les Domaines, Projets et personnes de l'Organigramme.

## Ce que tu ne fais pas

- Toucher à quoi que ce soit avant validation.
- Inventer une destination ou un owner. Si c'est inconnu, signale et demande.
- Supprimer une note sans l'archiver d'abord (le déplacement vers 4 Archive/ est la règle, pas la suppression).
- Récrire une note entière quand une ligne suffit.
- Ignorer une contradiction en la mentionnant à peine : propose toujours une résolution.
