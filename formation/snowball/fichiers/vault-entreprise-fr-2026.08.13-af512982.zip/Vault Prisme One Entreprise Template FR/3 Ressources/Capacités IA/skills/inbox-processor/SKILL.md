---
name: inbox-processor
description: "Trie les notes déposées dans l'inbox du vault partagé (0 Inbox/ et 0 Inbox/_Import/). Pour chaque note propose une destination (1 Projets/, 2 Domaines/[domaine]/, 3 Ressources/Références/, 4 Archive/) et demande une validation par note. Prend en compte le vault partagé : route les notes vers le domaine d'un teammate et note la propriété. Fait un premier passage spécial sur les docs de _Import/ déposés pendant /initialisation-entreprise pour les classer dans le bon Domaine, le bon Projet, ou la bonne Référence. À utiliser quand « traite l'inbox », « trie 0 Inbox », « classe les docs _Import », « nettoie la zone de capture »."
---

# Inbox Processor (vault partagé)

Trie la zone de capture du Business Brain partagé. Les items dans `0 Inbox/` et `0 Inbox/_Import/` sont temporaires : ils ne devraient pas rester plus de quelques jours. Traite-les un par un, propose une destination, route au bon endroit, et note la propriété quand un item appartient au domaine d'un teammate.

## Contexte

Ce vault est partagé par une équipe. Un item d'inbox peut appartenir au domaine de n'importe quel membre, pas seulement à celui qui fait ce tri. Route toujours vers le bon propriétaire et enregistre-le.

`0 Inbox/_Import/` contient les documents déposés pendant `/initialisation-entreprise` (PDFs, docs, notes déposées au setup). Ils sont traités comme un premier passage spécial (Step 2) avant le tri normal de l'inbox.

## Avant de commencer

1. Lis le contexte de l'entreprise :
   - `2 Domaines/Vision & Contexte/Vision.md` pour la direction.
   - `2 Domaines/Vision & Contexte/Organigramme/` pour connaître les teammates et leurs domaines (pour le routage de propriété).
2. Liste les Projets actifs (`1 Projets/*/`) et les Domaines (`2 Domaines/*/`).
3. Scanne le contenu de `0 Inbox/` et `0 Inbox/_Import/`.

Si l'Organigramme est vide ou un teammate est inconnu, demande qui possède un domaine donné plutôt que de deviner.

## Process

### Step 1 : Scanner l'inbox et le _Import

```bash
INBOX="0 Inbox"
IMPORT="$INBOX/_Import"
echo "=== Racine de l'inbox ==="; ls -1 "$INBOX" 2>/dev/null | grep -v "^_Import$"
echo "=== _Import ==="; ls -1 "$IMPORT" 2>/dev/null
```

Présente :

```
J'ai trouvé [X] items dans l'inbox :

Racine de l'inbox ([n]) :
1. [Fichier 1] : [preview 1-2 lignes]
2. [Fichier 2] : [preview 1-2 lignes]

_Import ([m], passage spécial) :
3. [Fichier 3] : [preview 1-2 lignes]
...

On traite _Import d'abord (passage spécial), puis la racine de l'inbox ?
```

Attends le go. Fais toujours le passage `_Import/` d'abord (Step 2), puis la racine de l'inbox (Step 3 et suite).

### Step 2 : Passage spécial sur _Import/ (docs d'init)

`_Import/` contient les documents déposés pendant `/initialisation-entreprise` (PDFs, docx, txt, notes déposées). Ils ont tendance à être plus volumineux et lourds en références. Classe chacun dans le bon Domaine, le bon Projet, ou la bonne Référence, pas dans le flux de la racine de l'inbox.

Pour chaque fichier dans `_Import/` :

1. Lis-le en entier (utilise le bon outil selon le format : Read pour text/md, parsing PDF pour les PDFs, etc.).
2. Identifie ce que c'est : doc d'entreprise, brief client, offre, organigramme, doc de process, article de référence, note historique, archive.
3. Propose une destination :
   - Doc d'entreprise / org / vision -> `2 Domaines/Vision & Contexte/` (ou un Domaine spécifique qu'il informe).
   - Doc client ou d'initiative -> `1 Projets/[projet]/` (crée le Projet si c'en est clairement un et qu'il n'existe pas; demande d'abord).
   - Doc de process / SOP -> `3 Ressources/Références/Process/` et propose de le capturer comme un skill via `/create-skill`.
   - Référence / article / note de livre -> `3 Ressources/Références/`.
   - Obsolète ou supersédé -> `4 Archive/`.
4. Note le propriétaire : à qui appartient ce doc (rôle ou personne, linké via [[wikilink]] vers l'Organigramme).

Présente la classification proposée pour tous les items de `_Import/` d'un coup, puis demande validation avant de bouger quoi que ce soit :

```
Proposition de classification _Import :

- [fichier1.pdf] : Brief client -> 1 Projets/[projet]/ | propriétaire : [[Personne]] | renommer en [nom descriptif]
- [fichier2.docx] : Doc de process -> 3 Ressources/Références/Process/ | propriétaire : [[Rôle]] | puis proposer /create-skill
- [fichier3.txt] : Note de vision -> 2 Domaines/Vision & Contexte/ | propriétaire : [[Personne]]

On applique cette classification ? Des ajustements ?
```

Attends la validation. Puis exécute : déplace/renomme chaque fichier, et pour tout doc de process, propose `/create-skill` en follow-up (ne le lance pas silencieusement).

### Step 3 : Triage par item (racine de l'inbox)

Pour chaque item restant dans la racine de l'inbox, présente :

```
Item : [nom du fichier]

Contenu : [résumé 1-2 phrases]

Type détecté : Idée / Tâche / Référence / Réflexion / Autre

Actions possibles :
1. -> Projet nouveau ou existant (1 Projets/)
2. -> Attacher à un Domaine (2 Domaines/[domaine]/)
3. -> Classer comme Référence (3 Ressources/Références/)
4. -> Archiver (4 Archive/)
5. -> Supprimer (pas de valeur)
6. -> Développer maintenant (creuse avec moi)

Propriétaire : [[Personne ou rôle]] (à qui ça appartient)

Qu'est-ce que tu veux faire ?
```

Attends le choix par item. Ne batch pas la validation entre items sauf si l'utilisateur le demande explicitement.

### Step 4 : Exécuter l'action

Selon l'action choisie :

**-> Projet :**
- Identifie le Projet cible. S'il existe, ajoute le contenu (ou un pointeur) à la note de contexte du Projet ou à une sous-note.
- S'il n'existe pas et que l'item est clairement une nouvelle initiative avec une deadline, propose de le créer (utilise le modèle Projet) et demande validation avant de créer.
- Retire l'item de l'inbox une fois classé.

**-> Domaine :**
- Identifie le domaine cible. Ajoute le contenu à la note de Domaine existante ou à une sous-note.
- Si l'item appartient au domaine d'un teammate, route-le là et enregistre le propriétaire dans la note de Domaine.
- Retire l'item de l'inbox une fois classé.

**-> Référence :**
- Propose un sous-dossier sous `3 Ressources/Références/` (ex `Process/`, `Articles/`, `Lectures/`).
- Renomme si nécessaire (descriptif, daté si pertinent).
- Déplace le fichier.

**-> Archiver :**
- Déplace vers `4 Archive/`. Garde le fichier accessible; ne supprime pas.

**-> Supprimer :**
- Confirme avant de supprimer. Seulement pour les doublons, notes vides, ou items sans valeur.

**-> Développer :**
- Passe en mode thinking-partner pour explorer l'idée avec le membre.
- Puis classa le résultat avec l'une des actions ci-dessus.

Pour chaque item classé, enregistre le propriétaire quand pertinent (dans la note de destination, comme un champ frontmatter ou une ligne inline `Propriétaire : [[Personne]]`). Le vault partagé dépend de savoir qui possède quoi.

### Step 5 : Récap

```
=== Inbox traité ===

Passage _Import :
- [n] -> Projets
- [n] -> Domaines (Vision & Contexte ou domaine)
- [n] -> Références
- [n] -> Archive
- [n] docs de process signalés pour /create-skill

Racine de l'inbox :
- [n] -> Projets
- [n] -> Domaines
- [n] -> Références
- [n] -> Archive
- [n] -> Supprimés
- [n] -> Développés puis classés

Propriétaires enregistrés : [liste de [[Personne]] par item classé, quand pertinent]
Items restants : [n]

Ton inbox est [vide / presque vide / encore chargée].
```

## Règles de routage

### -> Projet si :
- C'est une initiative avec un objectif clair et une deadline (même floue).
- Ça nécessite plusieurs actions coordonnées.
- Ça a un output défini à livrer.

### -> Domaine si :
- Ça se rapporte à une responsabilité ongoing (un domaine que l'équipe possède en continu).
- C'est une note de process, méthode, ou réflexion liée à un rôle.
- Ça concerne le domaine d'un teammate (route là, enregistre le propriétaire).

### -> Référence si :
- C'est une référence utile (article, note de livre, méthode publique, modèle).
- C'est une idée à garder pour plus tard, pas à actionner maintenant.

### -> Archiver si :
- C'est obsolète ou déjà traité.
- Ça ne servira probablement jamais mais doit rester accessible.

### -> Supprimer si :
- C'est un doublon.
- C'est vide ou inintelligible.
- Ça n'a pas de valeur.

### -> Développer si :
- C'est trop vague à classer. Creuse d'abord, puis classa le résultat.

## Règles

- Fais le passage `_Import/` d'abord, puis la racine de l'inbox.
- Lis en entier chaque doc de `_Import/` avant de le classer. Ne classe jamais depuis le seul nom de fichier.
- La validation est par item pour la racine de l'inbox, et par batch pour `_Import/` (Step 2) sauf si l'utilisateur demande autre chose.
- Dans un vault partagé, enregistre toujours le propriétaire quand une note appartient au domaine d'un teammate.
- Préfère l'action rapide : classer imparfaitement vaut mieux que laisser les items traîner. Dans le doute, demande.
- Si un item est trop vague, propose de le développer ou de le supprimer; ne le laisse pas dans l'inbox.
- Pour tout doc de process dans `_Import/`, propose `/create-skill` en follow-up; ne le lance pas silencieusement.
- Utilise des [[wikilinks]] vers les Projets, Domaines, et personnes de l'Organigramme.
- Pas de tirets longs (utilise deux points, virgule, parenthèse, ou reformule).
- Pas de tic rhétorique « pas X mais Y ». Dis les choses directement.
- Pas d'emojis.

## Ce que tu ne fais pas

- Supprimer un item de l'inbox sans confirmation.
- Créer un Projet silencieusement parce qu'un item ressemble à un Projet; propose et valide d'abord.
- Deviner un propriétaire. Si le domaine ou le teammate est inconnu, demande.
- Classer un PDF de `_Import/` depuis son nom de fichier; ouvre-le et lis-le.
- Laisser les docs de process dans Références sans proposer `/create-skill`.
- Batch-valider les items de la racine de l'inbox sauf si l'utilisateur opte explicitement.
- Router la note d'un teammate vers ton propre domaine par défaut; route vers le propriétaire et enregistre-le.
