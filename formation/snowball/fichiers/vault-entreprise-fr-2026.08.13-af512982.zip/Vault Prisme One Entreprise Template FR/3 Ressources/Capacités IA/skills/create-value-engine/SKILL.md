---
name: create-value-engine
description: "Construit le Master Value Board de l'entreprise : la représentation visuelle du moteur de valeur (value engine), le business mappé du côté du client, du moment où un prospect découvre l'entreprise jusqu'au referral. Par domaine, les activités (les choses qu'on fait) ; par activité, les process à l'échelle d'une session de travail ; et les KPI posés dessus (un North Star par domaine, un KPI par process). Première question : les process sont-ils déjà mappés via /map-process ? Si oui, les fiches alimentent le board ; sinon, questions simples domaine par domaine. Produit un Moteur de Valeur.canvas (le board) + un Moteur de Valeur.md structuré. À utiliser quand « construis mon value engine », « crée le master value board », « représente mon business en board », « cartographie ma chaîne de valeur »."
---

# /create-value-engine : Construire le Master Value Board

Tu construis la représentation visuelle du moteur de valeur de l'entreprise : le **Master Value Board**. Un canvas qui montre tout ce qui produit de la valeur, du moment où un prospect découvre l'entreprise jusqu'au moment où un client la recommande : les domaines, les activités de chaque domaine, les process de chaque activité, et les KPI posés dessus.

Ce mapping se fait **du côté du client** : tu cartographies la chaîne de valeur, ce que le business fait pour que le client avance de la découverte au referral. C'est complémentaire du mapping interne fait par `/map-process`, qui liste les process du point de vue de chaque employé. Les deux se combinent : si les process sont déjà mappés, le board les réutilise ; sinon, tu construis par la conversation.

L'objectif, énoncé d'emblée à l'utilisateur :

> « À la fin de ça, tu auras un board visuel de ton business entier : chaque domaine, chaque chose que vous faites dedans, chaque process à l'échelle d'une session de travail, et les KPI posés dessus. Ce board donne une méta-clarté à l'IA sur ce qui se passe dans la boîte, à chaque employé sur où son travail s'insère, et à toi pour piloter. »

C'est séquentiel et dialogique. Un domaine à la fois. Reformule et valide à chaque étape.

## Les trois niveaux du board (la règle d'échelle)

```
NIVEAU 1 : DOMAINE      Un moteur du business (Acquisition, Vente, Delivery, Fidélisation)
                        ou le socle qui fait tourner le tout (Support, Admin & Pilotage).

NIVEAU 2 : ACTIVITÉ     Une chose qu'on fait dans le domaine, en continu.
                        Exemples : « Vidéos YouTube », « Posts LinkedIn », « Publicité »,
                        « Onboarding client ».

NIVEAU 3 : PROCESS      Une session de travail qui produit un livrable utilisable.
                        L'unité de base du board.
```

La règle d'échelle du niveau 3, non négociable : **un process = une session de travail qui livre un livrable utilisable.** L'exemple canonique :

> « Créer une vidéo YouTube » est une activité qui contient cinq process : écrire le script, packager (titre + miniature), tourner, monter, publier. Chacun se fait en une session et livre quelque chose de fini.

Et une quatrième couche, posée sur les trois : **les KPI**. Un North Star par domaine, un KPI par process. C'est ce qui transforme la carte en instrument de pilotage.

## Output

- `2 Domaines/Vision & Contexte/Moteur de Valeur.canvas` : le Master Value Board (JSON Canvas). Gros cubes = domaines, sous-cubes = activités, cartes = process avec leur KPI.
- `2 Domaines/Vision & Contexte/Moteur de Valeur.md` : la même structure en note (domaines, activités, process, KPI, goulots).

## Process

### Step 1 : La première question, toujours

Demande :

> « Est-ce que vous avez déjà mappé vos process ? Est-ce que toi ou tes employés avez lancé `/map-process` ? Si oui, où sont les fiches ? »

**Si OUI** : lis les Process Maps et les Fiches de Process indiquées (par défaut `3 Ressources/Process/[Employé]/`). Elles alimentent directement le board : tu regroupes les process par domaine et par activité, et les cartes du board pointeront vers ces fiches. Tu ne refais jamais le travail, tu le représentes.

**Si NON** : tu construis par la conversation, avec des questions simples, domaine par domaine :

> « Comment vous faites l'acquisition ? Comment les gens vous découvrent ? »
> « Comment vous vendez ? Comment un prospect devient client ? »
> « Comment vous livrez la valeur ? »
> « Comment vous fidélisez, et comment les clients vous recommandent ? »
> « Qui gère le support, l'admin, le pilotage ? »

Dans les deux cas, lis aussi ce qui existe : `2 Domaines/Vision & Contexte/Moteur de Valeur.md` (la version narrative de `/initialisation-entreprise`), `Vision.md`, et l'Organigramme. Annonce ce que tu as trouvé avant de continuer.

### Step 2 : Poser les domaines

Propose la structure par défaut, puis adapte aux vrais noms de l'entreprise :

- **Les 4 moteurs**, dans l'ordre du parcours client : Acquisition, Vente, Delivery, Fidélisation & Referral.
- **Le socle** : Support, Admin & Pilotage.

Demande : « Ces domaines matchent ton business ? Certains se splittent chez toi ? » Suis la vraie structure. La seule contrainte : la chaîne doit couvrir tout le parcours client, de la découverte au referral. Un domaine vide est un diagnostic, jamais une case à inventer.

### Step 3 : Par domaine, les activités (les choses qu'on fait)

**Un domaine à la fois**, dans l'ordre du parcours client. Ouvre avec :

> « [Domaine]. Qu'est-ce que vous faites, concrètement, dedans ? On fait des vidéos YouTube, on fait des posts LinkedIn, on fait de la pub : liste tout, même l'informel. »

Pour chaque activité : le nom, une phrase, le propriétaire (croise avec l'Organigramme, une activité orpheline est un signal). Reformule la liste, valide, passe au domaine suivant.

### Step 4 : Par activité, les process

Pour chaque activité :

> « [Activité]. Quels sont les process qui vous permettent d'y arriver, à l'échelle d'une session de travail ? »

Applique la règle d'échelle : splitte les méta-process, remonte les sous-étapes dans leur process parent, merge les doublons. Si une Fiche de Process couvre déjà ce process, référence-la telle quelle.

Pour chaque process, une ligne : nom (verbe à l'infinitif), livrable, durée approximative de la session.

### Step 5 : Poser les KPI

Le board porte les KPI, c'est ce qui le rend pilotable. Deux cas :

- **Des KPI existent déjà** (le workflow Review des KPI a tourné) : rattache-les. Un North Star par domaine, un KPI par process, tel que défini.
- **Aucun KPI défini** : propose, pour chaque domaine, un North Star évident (coût par lead pour l'acquisition, taux de closing pour la vente, churn pour la fidélisation), et pour chaque process un KPI candidat. Marque-les « à valider » et renvoie l'utilisateur vers le cours Review des KPI du Business OS pour la définition rigoureuse et la lecture.

N'invente pas de chiffres. Le board porte les noms des indicateurs, jamais des valeurs imaginées.

### Step 6 : Balayer les goulots

Avant de générer, balaye la carte :

> « Où le moteur cale-t-il ? Quel domaine bloque la croissance ? Quelles activités n'ont aucun process clair ? »

Note les trous et les goulots : un domaine sans activité ou une activité sans process documenté est une information, le board doit la montrer.

### Step 7 : Générer le board (le canvas)

Génère `2 Domaines/Vision & Contexte/Moteur de Valeur.canvas` (JSON Canvas, spec jsoncanvas.org) :

- **Un node texte titre** en haut : `# MASTER VALUE BOARD` + nom de l'entreprise + la légende (gros cubes = domaines, sous-cubes = activités, cartes = process d'une session avec leur KPI).
- **Un group par domaine**, label = nom du domaine, contenant un node texte d'en-tête (`## DOMAINE` + phrase de mission + `North star : [KPI]`).
- **Un group par activité** dans le domaine, avec un node texte d'en-tête (`### Activité` + description + propriétaire) puis une carte par process.
- **Les cartes process** : nodes fichier si la Fiche de Process existe (chemin relatif à la racine du vault), nodes texte sinon. Chaque carte porte : nom, `1 session · livrable : [X]`, `KPI : [indicateur]`. Cartes width 400.
- **Les 4 moteurs sur une ligne, le socle en dessous.**
- **4 edges entre les moteurs** : Acquisition vers Vente (« Leads »), Vente vers Delivery (« Clients »), Delivery vers Fidélisation (« Clients livrés »), Fidélisation vers Acquisition par le haut (« Referral : la boucle qui relance le moteur »).
- **Couleurs** : une couleur par domaine sur l'en-tête et le group. Les cartes process restent blanches.

Vérifie que le JSON est valide et que chaque node enfant est dans les bounds de son group parent.

### Step 8 : Mettre à jour Moteur de Valeur.md

Réécris la note avec la même structure que le board :

```markdown
---
type: value-engine
status: active
maj: [date du jour]
---

# Moteur de Valeur

## Comment nous créons de la valeur
[2-3 phrases : la chaîne, de la découverte au referral.]

## [Domaine 1 : Acquisition] · North star : [KPI]
[Phrase de mission.]

### [Activité A] ([[propriétaire]])
[1 phrase.]
- [[Process 1]] · livrable : [X] · KPI : [indicateur]
- [[Process 2]] · livrable : [X] · KPI : [indicateur]

## [Domaine 2 : Vente] · North star : [KPI]
...

## Goulots
[Les points de blocage, par domaine.]
```

Montre le fichier, valide, applique les corrections.

### Step 9 : Clôture

> « Ton Master Value Board est posé : la carte de ta chaîne de valeur, avec les KPI dessus. Elle donne à l'IA et à l'équipe la vue complète de la machine.
>
> Trois usages complémentaires :
> - `/map-process` avec un membre de l'équipe quand une zone du board est restée floue : ses fiches viendront s'y brancher.
> - `/create-skill` sur un process que tu veux confier à l'IA : sa méthode est capturée, le board pointe dessus.
> - Le workflow Review des KPI du Business OS pour lire le board : définir rigoureusement les indicateurs, les traquer, les afficher, générer les hypothèses.
>
> Relance `/create-value-engine` à chaque changement de structure (nouvelle offre, nouveau canal, nouvelle personne) : le board doit rester honnête. »

## Règles

- **La première question d'abord.** Le diagnostic `/map-process` (Step 1) précède tout : il détermine si tu représentes de l'existant ou si tu construis par la conversation.
- **Tu représentes, tu ne réinventes pas.** Les Fiches de Process existantes sont référencées telles quelles. Le board est une vue, jamais un doublon.
- **Le point de vue est celui du client.** La chaîne va de la découverte au referral. Les process internes qui ne touchent aucune étape du parcours vont dans le socle.
- **La règle d'échelle est sacrée.** Un process = une session de travail, un livrable.
- **Les KPI portent des noms, jamais des valeurs inventées.**
- **Le concret plutôt que la catégorie.** « Écrire le script YouTube » et jamais « faire du contenu ».
- **Les trous comptent autant que le plein.** Un domaine vide, une activité orpheline : le board doit le montrer.
- **N'invente jamais.** Si une info manque, demande.
- **Utilise des [[wikilinks]]** vers les fiches, les personnes, les domaines.
- **Pas de tirets longs.** Pas de tic « pas X mais Y ». Pas d'emojis.

## Ce que tu ne fais pas

- Sauter le Step 1. Sans le diagnostic, tu risques de refaire un travail déjà fait par `/map-process`.
- Réécrire ou modifier les Fiches de Process existantes.
- Descendre au niveau des sous-étapes. La maille la plus fine du board est le process d'une session.
- Inventer des valeurs de KPI ou des baselines. Le board porte les indicateurs, la lecture vit dans le workflow Review des KPI.
- Remplir un domaine « parce qu'il devrait exister ». Si l'entreprise n'a rien en fidélisation, le board le montre, c'est sa valeur.
- Transformer les process en skills toi-même. C'est le travail de `/create-skill`.
- Mettre le canvas ou la note ailleurs que dans `2 Domaines/Vision & Contexte/`.
