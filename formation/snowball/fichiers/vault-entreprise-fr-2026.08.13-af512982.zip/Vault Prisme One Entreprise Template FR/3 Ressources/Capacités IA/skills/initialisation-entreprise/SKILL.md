---
name: initialisation-entreprise
description: Initialise le vault Business Brain de l'entreprise via une conversation guidée avec le CEO/team lead. Pédagogie PDRA entreprise, dépôt de documents à tout moment (pitch deck, organigramme, propositions, docs de process, liste d'outils, roadmap), décharge complète du contexte de l'entreprise (identité, vision, organigramme, moteur de valeur, domaines, projets, outils, cycle stratégique). Écrit chaque artefact à la fin de son étape (pas tout à la fin), pour garder une fidélité maximale. Clôture avec une passe de relecture qui vérifie la cohérence transversale et génère le triage CLAUDE.md, les canvas, et la première revue hebdo.
---

# /initialisation-entreprise : Initialiser le Business Brain

Tu initialises ce vault d'entreprise avec le contexte de l'équipe via une conversation guidée avec l'initiateur (en général le CEO ou team lead). En même temps, tu **expliques** ce qu'on construit et pourquoi, pour que l'équipe comprenne ce qu'elle fait, pas juste ce qu'elle remplit.

C'est le miroir entreprise du `/initialisation` personnel. Même arc (prélude pédagogique, nommer l'IA, sections de décharge, relecture, génération), transposé à une organisation.

## Règle transversale : dépôt de documents

**À tout moment** pendant les sections de décharge (Steps 3 à 10), l'initiateur peut déposer des fichiers pour compléter ou remplacer une réponse vocale/écrite : pitch deck, brochure, one-pager, organigramme (slide, doc, LinkedIn), liste des employés avec rôles, grilles offres/pricing, propositions récentes, SOPs/wiki/exports SharePoint existants, liste d'outils, roadmap, docs d'immatriculation.

À chaque section majeure, rappelle cette affordance :

> « Tu peux aussi déposer ici des fichiers qui couvrent cette section : pitch deck, organigramme, propositions, docs de process, liste d'outils. Je les lis et j'extrais ce qui compte. »

Quand un fichier est déposé :
1. **Lis-le en entier** (Read pour .md/.txt, outils PDF pour .pdf, etc.)
2. **Extrais** l'information relevant pour la section courante
3. **Résume** à l'initiateur ce que tu as compris et demande validation ou les gaps
4. **Continue** la section avec les gaps restants (si le doc ne couvrait pas tout)

## Principe transversal : écrire au fur et à mesure

On écrit chaque artefact à la **fin de son étape**, pas tout à la fin. Ça garde une fidélité maximale : on écrit depuis la décharge fraîche et brute de chaque section, pas depuis un recap compressé 2-4 heures plus tard.

- Les artefacts self-contained (fichiers personne de l'Organigramme, notes de Domaine, notes de Projet, notes d'Infrastructure, Cycle Stratégique, Vision.md, Moteur de Valeur.md) sont écrits à la fin de leur étape, juste après la décharge + validation de cette étape.
- Les artefacts transversaux (triage AGENTS.MD, les deux canvas, la première revue hebdo) sont générés à la fin, pendant la passe de relecture (Step 11), parce qu'ils agrègent ou vérifient plusieurs sections.

Chaque étape clôture sur une sous-étape « Écrire ». Annonce-le : « Maintenant j'écris [fichier] avec tout ce qu'on a capturé. Voilà ce que je mets dedans. » Écris, puis demande à l'initiateur de confirmer rapidement avant de passer à l'étape suivante.

---

## Step 1 : Prélude pédagogique (expliquer le système)

Dis à l'initiateur (adapte le ton, ne récite pas mot pour mot, converse) :

```
Bienvenue. On va initialiser le Business Brain de l'entreprise.

## Où on est

Tu es dans un WORKSPACE : la racine du vault. Les dossiers PDRA (0 Inbox, 1 Projets,
2 Domaines, 3 Ressources, 4 Archive) vivent directement ici. L'équipe peut aussi ajouter
d'autres projets à côté : un site, une app, un repo client, un repo partagé, et l'IA
aura accès à tout depuis le même endroit.

Aujourd'hui on se concentre sur le Business Brain (le vault d'entreprise partagé).

## Le deal

Ce que je propose de faire maintenant, en trois temps :

  1. Je présente ce qu'on met en place et pourquoi (5 min)
  2. Tu décharges : tout ce qu'il faut pour peupler le contexte de l'entreprise (2-4h, adaptable)
  3. J'écris chaque artefact à la fin de sa section, puis une passe de relecture tout à la fin

Tu peux répondre en écrit, à la voix (dictée), ou déposer des documents à chaque étape.
On prend le temps qu'il faut.

## Pourquoi un Business Brain

La puissance de l'IA émerge de TON contexte.

  IA sans contexte    = réponses génériques, réinvente la roue à chaque prompt,
                        ne connaît ni ton entreprise, ni tes offres, ni tes clients, ni tes gens.

  IA avec ton contexte = une extension de l'équipe, connaît les projets, les offres,
                        l'organigramme, le moteur de valeur. Exécute dans ton cadre, pas hors contexte.

L'équation : qualité IA = qualité du contexte x qualité du modèle.
Le modèle, tu le choisis une fois. Le contexte, on le construit maintenant.

## PDRA : organiser par utilité

La vraie question n'est pas « de quoi ça parle ? » mais « à quoi ça sert ? »

  Par thème (Marketing, Finance, Operations)     tu cherches partout, tout se mélange, l'IA se perd.

  Par utilité (PDRA)                             tu vois tout de suite ce qui est actionnable vs ce qui dort.

Les 5 dossiers PDRA (édition entreprise) :

  0 Inbox        Tout ce qui arrive, avant le triage. Tampon temporaire.
  1 Projets     Initiatives transversales sur lesquelles tu travailles activement (deadline, archive après).
  2 Domaines        Tes responsabilités permanentes (Sales, Operations, Finance, People, plus
                 la Vision & Contexte always-on et le rythme Pilotage).
  3 Ressources    Référence utile mais inactive. Aussi : Capacités IA (skills + modèles),
                 Infrastructure (outils, credentials).
  4 Archive      Terminé ou inactif (mais accessible).

### Projet vs Domaine : la distinction clé

  PROJET  = temporaire, a une deadline, un output défini.
            Exemple : « Lancer le nouveau site », « Migrer le CRM ». Deadline, puis archive.

  DOMAINE     = permanent, une zone de responsabilité, sans fin.
            Exemple : « Sales », « Operations », « People ». Il vit tout le temps.

### Les deux domaines transversaux que chaque entreprise a

  Vision & Contexte  = la couche stratégique always-on : qui on est, comment on crée de la valeur,
                      qui fait quoi, sur quoi on se concentre ce cycle.
  Pilotage           = le rythme opérationnel : revues hebdo, standups, logs de session.

## Le principe qu'on ne lâche jamais

**On amplifie, on ne remplace pas.** On n'invente pas de nouveaux usages externes. On mappe ce que
l'équipe fait déjà, ce qui produit de la valeur, et on l'amplifie avec l'IA.

---

Des questions avant qu'on commence ? Sinon, on commence par nommer l'IA.
```

Attends une confirmation ou une question. Réponds aux questions. Puis passe au Step 2.

---

## Step 2 : Nommer l'IA, l'entreprise, la langue de travail, l'initiateur

Pose ces questions, une par une, attends la réponse entre chacune :

```
1. C'est quoi le nom de l'entreprise ? (le nom légal ou de marque, celui qu'on utilise partout)
2. Comment tu veux m'appeler ? (tu donnes un nom à l'IA : celui que tu invoqueras
   quand tu ouvres le vault)
3. Quelle est la langue de travail de l'équipe pour tout ce qui est interne ?
   (français par défaut; anglais, mandarin, etc. si l'équipe travaille dans une autre langue)
4. Qui initie ? (prénom + rôle, en général le CEO ou team lead)
5. Pour les livrables externes/clients, quelle langue ?
```

Une fois collecté :
- Le **nom de l'entreprise** remplacera les placeholders `[Entreprise]` / `{{title}}` dans `Vision.md` et `AGENTS.md`.
- Le **nom de l'IA** remplacera `[nom IA]` dans `AGENTS.md` à la racine du vault.
- La **langue de travail** devient le défaut pour toutes les notes du vault et les outputs des skills à partir de maintenant. Bascule dessus immédiatement après cette étape.
- L'**initiateur** est enregistré comme la personne qui a lancé l'initialisation (dans le log de session).

### Écrire : patcher AGENTS.md

Maintenant, patche `AGENTS.md` à la racine du vault :

```bash
sed -i '' "s/\[nom IA\]/[nom IA choisi]/g; s/\[Entreprise\]/[nom de l'entreprise]/g" AGENTS.md
```

Dis à l'initiateur :

> « J'ai enregistré le nom de l'IA et le nom de l'entreprise dans AGENTS.md. À partir de maintenant je réponds en [langue de travail]. »

Puis passe au Step 3.

---

## Step 3 : L'entreprise en bref

Annonce (dans la langue de travail) :

```
On commence par « l'entreprise en bref ». C'est la section la plus importante, prends le temps.
Tu peux déposer des fichiers ici : pitch deck, brochure, one-pager, docs d'immatriculation, l'URL du site.
J'extrais ce qui compte et on complète ensemble avec ce qui manque.
```

Pose ces questions **une par une**, attends la réponse entre chacune :

1. **L'entreprise en un paragraphe.** Qui, quoi, pour qui. Sois précis : industrie, ce que tu vends, qui achète, géographie, effectifs, années d'existence. Pas « on est une boîte de procurement » mais « Five Keys est une boîte de procurement hospitality (FF&E + OS&E) pour hôtels, résidentiel et co-working, basée à Hong Kong, 10+ ans, 30+ projets, 100+ manufacturers, 5 personnes dans le bureau HK. »

2. **Positionnement.** Quels sont les vrais différenciateurs (pas la ligne marketing) ? Pourquoi les clients te choisissent vs l'alternative ? C'est quoi le « pourquoi toi » qu'un client récurrent dirait ?

3. **Marché & clients.** Segments, types de clients nommés (tu peux nommer de vrais clients ou des archétypes), géographie. Où le chiffre se concentre-t-il ?

4. **Historique.** Les points de bascule, chronologique. Quand fondée, pivots clés, moments de croissance. Pas une brochure corporate : la vraie histoire avec des dates et des chiffres.

5. **Offres et produits.** Qu'est-ce que tu vends, l'offre exacte.

Après chaque réponse : reformule ce que tu as compris en 2-3 phrases, demande si c'est juste, puis passe à la question suivante. Rappelle l'affordance de documents.

**N'écris pas encore.** Vision.md est écrit à la fin du Step 4 (il agrège Steps 3 + 4). Tiens le contenu capturé en mémoire.

---

## Step 4 : Vision, North Star, ce qui ne change jamais

Annonce :

```
Maintenant la vision. Sans une vision claire, l'entreprise absorbe les opportunités au lieu de
les choisir : la vision est le phare qui guide les décisions. Tu peux déposer un
manifeste, un doc de vision, une roadmap long terme si tu en as un.
```

Pose **une par une** :

1. **Mission.** À quoi sert vraiment l'entreprise ? Quel problème résout-elle, pour qui, qui ne serait pas résolu de la même façon sans toi ?

2. **North Star.** La métrique unique qui te dit que l'entreprise gagne. Pas le chiffre (c'est un résultat lagging) : l'indicateur leading de création de valeur. (Exemples : nombre de projets livrés à temps, taux de clients récurrents, NPS, semaines de couverture de pipeline.)

3. **Vision à 5 ans.** Marché, effectifs, offre, géographie. Sois concret : qu'est-ce qui est vrai dans 5 ans si tout se passe bien ?

4. **Ce qui ne change jamais.** Les principes inviolables. La façon dont tu livres que tu ne troquerais pas contre la croissance. Les 3-5 lignes que tu ne franchis jamais.

5. **Voix de marque.** Comment parle l'entreprise ? Ton (direct / chaleureux / formel / expert), registre, à faire et à ne pas faire, mots que tu n'utilises jamais. Ça devient la référence pour toutes les comms externes et le skill `/de-ai-ify`.

Après chaque réponse : reformule, valide, passe.

### Écrire : remplir `2 Domaines/Vision & Contexte/Vision.md`

Maintenant écris Vision.md avec tout ce qui a été capturé aux Steps 3 et 4. Utilise le modèle `3 Ressources/Capacités IA/Templates/Vision.md`. Remplis chaque section. Garde le frontmatter (`type: vision`, `status: active`) et set `entreprise`, `tagline`, `juridiction`, `cycle_strategique` (sera set au Step 10, laisse vide pour l'instant), `maj` (date du jour). Remplace `{{title}}` par le nom de l'entreprise.

Dis à l'initiateur :

> « J'ai écrit Vision.md avec l'entreprise en bref, le positionnement, le marché, l'historique, les offres, la mission, le North Star, la vision, ce qui ne change jamais, et la voix de marque. Quick check : ça matche ? Quelque chose à corriger ? »

Applique les corrections, puis passe au Step 5.

---

## Step 5 : Organigramme & rôles

Annonce :

```
Maintenant les gens. Un fichier par membre de l'équipe, plus un organigramme visuel (Obsidian Canvas).
Tu peux déposer un organigramme (slide, doc, export LinkedIn) ou une liste avec les rôles.
Pour chaque personne je capture : le rôle, le périmètre, sur quoi ils décident seuls, et leur profil
de voix (pour que l'IA calibre les comms par personne).
```

### 5.1 : Lister l'équipe

Demande à l'initiateur de lister les membres de l'équipe (prénom + rôle). Pour une petite équipe (under ~15), liste tout le monde. Pour une équipe plus grande, liste le leadership + les gens que l'initiateur veut que l'IA connaisse personnellement; le reste peut être groupé par fonction.

Reformule la liste pour validation avant de remplir.

### 5.2 : Par personne, ouvrir la conversation

**Pour chaque personne, une par une**, ouvre avec :

> « Parle-moi de [Prénom Nom]. C'est quoi son rôle, c'est quoi son périmètre, sur quoi il décide seul ? »

Écoute. Puis pose **des questions clarifiantes adaptées à ce que tu entends, pas un checklist fixe**. L'objectif est que l'IA puisse router une demande à la bonne personne et calibrer les comms à sa voix.

**Banque d'inspiration** (prends ce qui manque, ne lance pas mécaniquement) :

- Qu'est-ce que « bien faire ce rôle » veut dire ici ?
- Qu'est-ce qu'il décide seul vs ce qui a besoin de validation, et de qui ?
- À qui rend-il compte ? Qui rend compte à lui ?
- Pour quoi les autres l'appellent-ils ? (le « go-to person for X »)
- C'est quoi son profil de voix pour les comms écrites ? (ton, langue, préférences)
- C'est quoi le North Star de son rôle ?

Tiens tout en mémoire. N'écris pas encore les fichiers personne.

### 5.3 : Planifier le canvas

Planifie le canvas maintenant (il sera généré à la fin, Step 11) :
- 1 noeud par personne (label = Prénom Nom, sous-label = rôle)
- Edges pour les lignes de reporting (reports-to)
- Groupe les noeuds par domaine (groupes Canvas)
- Place le CEO/initiateur en haut

### Écrire : créer tous les fichiers de l'Organigramme

À la fin du Step 5, crée tous les fichiers personne d'un coup :

```bash
mkdir -p "2 Domaines/Vision & Contexte/Organigramme"
```

Pour chaque membre de l'équipe, crée `2 Domaines/Vision & Contexte/Organigramme/[Prénom Nom].md` depuis le modèle `Personne.md`, rempli avec les données du Step 5.

Update l'index `Organigramme/Organigramme.md` : remplis la table de l'équipe et la matrice « qui décide quoi ».

Dis à l'initiateur :

> « J'ai créé [N] fichiers personne dans Organigramme/ et updaté l'index. Quick check : ça matche ? Quelque chose à corriger ? »

Applique les corrections, puis passe au Step 6. Le canvas lui-même est généré à la fin (Step 11).

---

## Step 6 : Le Moteur de Valeur

Annonce :

```
Maintenant le moteur de valeur : comment l'entreprise crée de la valeur, vue comme un système. La boucle
acquisition -> ventes -> delivery -> rétention, et la boucle qui recrée la valeur.
Tu peux déposer un sales playbook, un SOP de delivery, une client journey map, des propositions récentes.
```

Pose **une par une** :

1. **Acquisition.** Comment les clients te trouvent-ils ? (referrals, appels d'offres, contenu, le site, partenariats, relations existantes). Qu'est-ce qui marche le mieux ? Qu'est-ce que tu veux grower ?

2. **Ventes.** Comment un prospect devient-il un projet signé ? (discovery call, qualification, proposition, négociation, closing). Qui est impliqué ? C'est quoi la durée typique du cycle ?

3. **Delivery.** Le parcours typique d'un projet de A à Z. Les jalons, qui fait quoi à chaque étape, ce qui est automatisé vs manuel. Sois concret : pas « on livre bien » mais « brief -> sourcer 3 manufacturers -> spec -> approbation échantillon -> logistique -> install -> snag list -> handover ».

4. **Rétention.** Comment gardes-tu les clients et gagnes-tu des projets récurrents ? Account management, suivi qualité, upsell, communauté.

5. **La boucle.** Comment la valeur se recrée-t-elle ? (réputation -> referral -> nouveau projet). C'est quoi la flywheel ?

6. **Goulots.** Où le moteur cale-t-il aujourd'hui ? Quelle fonction bloque la croissance ? (Ça nourrit la liste de priorité `/map-process` plus tard.)

Après chaque réponse : reformule, valide, passe. Rappelle l'affordance de documents.

### Écrire : remplir `2 Domaines/Vision & Contexte/Moteur de Valeur.md`

Remplis `Moteur de Valeur.md` avec les 6 sections (acquisition, ventes, delivery, rétention, boucle, goulots).

Dis à l'initiateur :

> « J'ai écrit Moteur de Valeur.md. Quick check : ça matche ? Quelque chose à corriger ? »

Applique les corrections, puis passe au Step 7. Le canvas lui-même est généré à la fin (Step 11).

---

## Step 7 : Domaines & process principaux

Annonce :

```
Maintenant les domaines : les responsabilités permanentes de l'entreprise, mappées par fonction business.
On utilise les 6 fonctions : Acquisition, Sales, Delivery/Operations, Rétention, Support,
Admin/HR. Toutes les entreprises n'ont pas les 6 explicites; on mappe ce qui existe.
Pour chaque domaine : propriétaire, responsabilités, North Star, activités récurrentes, process principaux,
et les gaps (ce qui n'est pas encore processé). Les process prioritaires deviendront des skills plus tard
via /create-skill et /map-process.
```

### 7.1 : Lister les domaines

Demande à l'initiateur de lister les domaines de l'entreprise. Ils mapent souvent aux 6 fonctions mais avec des noms spécifiques à l'entreprise (ex « Commercial », « Operations », « Sourcing », « Logistique », « Finance & Admin », « People »). Reformule pour validation.

Note : certaines entreprises splitent une fonction en plusieurs domaines (Delivery = Sourcing + Logistique + Install). Suis la vraie structure de l'entreprise, pas une grille rigide.

### 7.2 : Par domaine, ouvrir la conversation

**Pour chaque domaine, une par une**, ouvre avec :

> « Parle-moi de [Domaine]. Qui le possède, qu'est-ce qu'il couvre, quels sont les process principaux ? »

Écoute. Puis pose **des questions clarifiantes adaptées** :

**Banque d'inspiration** (prends ce qui manque) :
- Qui possède ce domaine ? (rôle + nom, recoupe l'Organigramme)
- Qu'est-ce que « bien faire ce domaine » veut dire ? (North Star du domaine)
- Quelles sont les activités récurrentes ? (quotidien / hebdo / mensuel / sur-déclencheur)
- Quels sont les process principaux, même informels, même « au feeling » ? Liste-les.
- Qu'est-ce qui n'est pas encore un process ? (les gaps, les trous)
- Quels outils ce domaine utilise-t-il, et où vit la data ? (CRM, ERP, sheets, SharePoint, Drive)
- Quels 1-3 process sont prioritaires à documenter comme skills ? (les plus répétés, les plus douloureux, les plus error-prone)

Rappelle l'affordance de documents : « Tu peux déposer des SOPs, des checklists, un export wiki, un doc de process pour ce domaine. »

**Suis l'énergie** : skippe ce qui est déjà clair, creuse ce qui est riche. Reformule à la fin pour validation, puis passe au domaine suivant. Tiens tout en mémoire. N'écris pas encore les fichiers de domaine.

### Écrire : créer toutes les notes de Domaine

À la fin du Step 7, crée tous les fichiers de domaine d'un coup :

Pour chaque domaine identifié :
```bash
mkdir -p "2 Domaines/[Domaine]"
```
Écris `2 Domaines/[Domaine]/[Domaine].md` depuis le modèle `Domaine.md`, rempli avec : propriétaire, responsabilités, North Star, activités récurrentes, outils & data, notes clés (wikilinks vers les process principaux).

Dis à l'initiateur :

> « J'ai créé [M] notes de domaine dans 2 Domaines/. Quick check : ça matche ? Quelque chose à corriger ? »

Applique les corrections, puis passe au Step 8.

---

## Step 8 : Projets en cours

Annonce :

```
Maintenant les projets actifs : initiatives transversales avec une deadline. Un projet a une
fin. Pour chacun : objectif, deadline, prochaines étapes, propriétaire, gens impliqués, et le contexte
« need-to-know » du projet. Tu peux déposer des briefs, roadmaps, decks, contrats, docs d'onboarding client.
```

### 8.1 : Lister les projets

Demande à l'initiateur de lister les projets actifs. Reformule pour validation.

### 8.2 : Par projet, ouvrir la conversation

**Pour chaque projet, un par un**, ouvre avec :

> « Parle-moi de [Projet]. De quoi il s'agit, où tu en es, qu'est-ce que tu vises ? »

**Banque d'inspiration** (prends ce qui manque) :
- C'est quoi l'output concret ? Qu'est-ce que tu livres ?
- Deadline ou horizon ?
- Qui travaille dessus ? Qui joue quel rôle ?
- Où en es-tu exactement : dernières avancées, prochaine étape concrète ?
- Qu'est-ce qui te bloque là tout de suite ?
- Sous quel domaine ce projet se situe-t-il ? (link via wikilink)
- Le contexte « need-to-know » : client, périmètre, enjeux, contraintes, tout ce que l'IA doit savoir pour aider sur ce projet.

Rappelle l'affordance de documents. Reformule à la fin pour validation, puis passe. Tiens tout en mémoire. N'écris pas encore les fichiers de projet.

### Écrire : créer toutes les notes de Projet

À la fin du Step 8, crée tous les fichiers de projet d'un coup :

Pour chaque projet :
```bash
mkdir -p "1 Projets/[Projet]"
```
Écris `1 Projets/[Projet]/[Projet].md` depuis le modèle `Projet.md`, rempli avec : description, contexte, objectif, roadmap, personnes, notes clés.

Dis à l'initiateur :

> « J'ai créé [P] notes de projet dans 1 Projets/. Quick check : ça matche ? Quelque chose à corriger ? »

Applique les corrections, puis passe au Step 9.

---

## Step 9 : Outils & infrastructure

Annonce :

```
Maintenant les outils et l'infrastructure : la stack, où vit la data, et où trouver quoi.
Tu peux déposer une liste d'outils, une feuille de credentials (on référencera, jamais de secrets en
clair dans un vault partagé), une map SharePoint/Drive.
```

Pose **une par une** :

1. **La stack.** Liste les outils que l'équipe utilise au quotidien : CRM, ERP, compta, gestion de projet, comms, fichiers, production. Pour chacun : à quoi ça sert, où vit la data, qui y accède.

2. **Où trouver quoi.** Où est la master data pour chaque chose ? (contacts, entreprises, projets, documents, factures, transcripts). L'objectif : une map « où trouver quoi », comme un inventaire des sources documentaires.

3. **Credentials & accès.** Quels credentials/tokens l'IA doit-elle savoir qu'ils existent (référencés, pas en clair) ? Où sont-ils stockés ? (1Password, un fichier de credentials, env vars sur le serveur.)

4. **Automations déjà en place.** Des n8n, MCP, cron, scripts qui tournent déjà ? Brièvement, ce qu'ils font et qui les maintient.

### Écrire : remplir les notes d'Infrastructure

À la fin du Step 9, crée les deux notes d'Infrastructure :

- `3 Ressources/Infrastructure/Outils & accès.md` : la stack (outil, à quoi, où vit la data, qui accède).
- `3 Ressources/Infrastructure/Où trouver quoi.md` : la map des sources documentaires (où est la master data pour les contacts, projets, documents, factures, transcripts).

Dis à l'initiateur :

> « J'ai écrit les deux notes d'Infrastructure (Outils & accès, Où trouver quoi). Quick check : ça matche ? Quelque chose à corriger ? »

Applique les corrections, puis passe au Step 10. Le triage CLAUDE.md (qui combine outils + où-trouver-quoi + règles) est généré à la fin (Step 11).

---

## Step 10 : Le Cycle Stratégique actuel

Annonce :

```
Dernier bloc de décharge : le cycle stratégique actuel. L'équivalent entreprise d'une
« phase de vie » personnelle : le focus de 2-3 mois. Si tout se passe bien, c'est quoi la chose
la plus importante pour ce cycle ? Tu peux déposer une roadmap, un doc OKR, un plan trimestriel.
```

Pose **une par une** :

1. **Nommer le cycle.** Un nom court et évocateur pour le focus actuel (ex « Scale HK », « Launch Logistique », « Projet Qualité », « Founder off the floor »).

2. **Objectif n°1.** La chose la plus importante. Si on n'accomplit que ça, le cycle est une réussite.

3. **Mouvements clés.** Les 2-3 mouvements concrets qui nous y amènent.

4. **Contraintes.** Temps disponible, budget, capacité de l'équipe, non-négociables.

5. **Definition of done.** Qu'est-ce qui est vrai quand ce cycle se termine ?

6. **Stratégie par état.** Que fait-on quand surchargé (firefighting) / concentré / en flow ?

### Écrire : remplir le Cycle Stratégique

À la fin du Step 10 :

```bash
mkdir -p "2 Domaines/Vision & Contexte/Cycles Stratégiques"
```

Remplis `2 Domaines/Vision & Contexte/Cycles Stratégiques/Cycle Stratégique - 1 [nom].md` (renomme `Cycle Stratégique - 1 Initial.md` en le vrai nom du cycle) depuis le Step 10 (objectif n°1, mouvements clés, contraintes, definition of done, stratégie par état). Set `start` à aujourd'hui.

Update l'index `2 Domaines/Vision & Contexte/Cycles Stratégiques/Cycles Stratégiques.md` (remplace « Initial » par le vrai nom du cycle, statut active).

Update le frontmatter `cycle_strategique` de `Vision.md` avec le nom du cycle.

Dis à l'initiateur :

> « J'ai écrit le Cycle Stratégique et updaté l'index + Vision.md. Quick check : ça matche ? Quelque chose à corriger ? »

Applique les corrections, puis passe au Step 11 (la passe de relecture).

---

## Step 11 : Passe de relecture (le relecteur)

Tous les artefacts self-contained sont maintenant écrits : Vision.md, fichiers personne de l'Organigramme, Moteur de Valeur.md, notes de Domaine, notes de Projet, notes d'Infrastructure, Cycle Stratégique. Cette étape est le relecteur : il lit tout, vérifie la cohérence transversale, pose des questions de clarification, puis génère les artefacts transversaux qui agrègent ou vérifient plusieurs sections (triage CLAUDE.md, les deux canvas, la première revue hebdo, configs Obsidian).

### 11.1 : Lire tout ce qui a été écrit jusqu'ici

Lis :
- `2 Domaines/Vision & Contexte/Vision.md`
- `2 Domaines/Vision & Contexte/Moteur de Valeur.md`
- `2 Domaines/Vision & Contexte/Organigramme/` (chaque fichier personne + l'index)
- `2 Domaines/Vision & Contexte/Cycles Stratégiques/Cycle Stratégique - *.md`
- Chaque `2 Domaines/[Domaine]/[Domaine].md`
- Chaque `1 Projets/[Projet]/[Projet].md`
- `3 Ressources/Infrastructure/Outils & accès.md` + `Où trouver quoi.md`

### 11.2 : Vérifier la cohérence transversale

Vérifie, et signale tout mismatch :

- **Domaines vs Moteur de Valeur** : les domaines couvrent-ils chaque étape du moteur de valeur (acquisition, ventes, delivery, rétention) ? Y a-t-il un domaine sans propriétaire dans l'Organigramme ? Y a-t-il un propriétaire dans l'Organigramme sans domaine ?
- **Projets vs Domaines** : chaque projet se situe-t-il sous un domaine (wikilink) ? Les propriétaires de projet existent-ils dans l'Organigramme ?
- **Cycle Stratégique vs Vision** : l'objectif n°1 mène-t-il au North Star et à la vision 5 ans ? Les mouvements clés touchent-ils les bons domaines ?
- **Infrastructure vs Domaines** : les outils référencés dans les notes de domaine existent-ils dans `Outils & accès.md` ? Y a-t-il un outil dans la stack qu'aucun domaine n'utilise ?
- **Voix de marque vs Vision** : la section voix de marque est-elle remplie et utilisable comme référence pour `/de-ai-ify` ?

### 11.3 : Questions de clarification

Pose 2-5 questions pour clarifier les dernières ambiguïtés. Exemples :
- « Je vois un domaine « Sourcing » et un domaine « Operations » mais le Moteur de Valeur traite la delivery comme une seule étape. On les garde séparés ou on merge ? »
- « Le Projet X n'a pas de propriétaire dans l'Organigramme. Qui le possède ? »
- « Le Cycle Stratégique mentionne une initiative logistique mais il n'y a pas de domaine Logistique. Doit-on en créer un ? »

Continue jusqu'à ce que la cohérence soit clean. Applique les corrections aux fichiers affectés directement.

### 11.4 : Générer les artefacts transversaux

Maintenant génère les artefacts qui agrègent ou vérifient plusieurs sections :

**a. CLAUDE.md (le triage)**

Écrase `CLAUDE.md` à la racine du vault (l'alias `@AGENTS.md`) avec le fichier de triage complet. Il contient :
- Un court header : « Business Brain de [Entreprise]. Partagé par [N] personnes : [noms + rôles]. Langue de travail : [langue]. »
- Une table « Où trouver quoi » qui mappe chaque besoin à la bonne note/dossier (build depuis `Où trouver quoi.md` + la structure du vault).
- Une table « Outils connectés (où vit la master data) » : outil, à quoi, où vit la data, note (build depuis `Outils & accès.md`).
- Les règles d'interaction (pas de tiret long, pas de tic « pas X mais Y », n'invente jamais, vérifie les noms avant les comms externes, validation avant envoi externe : qui valide quoi, pas d'action destructive sans confirmation).

**b. Organigramme.canvas**

Génère `2 Domaines/Vision & Contexte/Organigramme.canvas` (JSON Canvas) :
- 1 noeud texte par personne (label = Prénom Nom, sous-label = rôle)
- Edges pour les lignes de reporting (fromNode = personne, toNode = son manager, label = « reports to »)
- Groupe les noeuds par domaine (groupes Canvas)
- Place l'initiateur/CEO en haut

Utilise le skill `json-canvas` s'il est disponible, ou écris le JSON Canvas directement selon la spec (jsoncanvas.org).

**c. Moteur de Valeur.canvas**

Génère `2 Domaines/Vision & Contexte/Moteur de Valeur.canvas` (JSON Canvas) :
- 5 noeuds texte : Acquisition, Ventes, Delivery, Rétention, Boucle, connectés comme un flux (Acquisition -> Ventes -> Delivery -> Rétention -> Boucle -> Acquisition)
- 1 noeud rouge « Goulots » qui liste les goulots identifiés
- Dispose-les de gauche à droite avec des coords x/y sensées

**d. Première revue hebdo (log de l'initialisation)**

```bash
mkdir -p "2 Domaines/Pilotage/Revues Hebdo/$(date +%Y-W%V)"
```

Crée `2 Domaines/Pilotage/Revues Hebdo/2026-W28/Revue Hebdo - [Initiateur].md` depuis le modèle `Revue Hebdo.md`, puis appende un log d'initialisation :

```markdown
---

## Log IA / Session d'initialisation

**Accompli :**
- Business Brain initialisé via `/initialisation-entreprise`
- Vision.md, Moteur de Valeur (+ canvas), Organigramme (+ canvas), Cycle Stratégique remplis
- [M] domaines, [P] projets créés
- Triage CLAUDE.md généré (outils + où trouver quoi)
- Nom de l'IA « [Nom] » enregistré dans AGENTS.md

**Extrait :**
- Langue de travail : [langue]
- Équipe : [N] personnes
- Cycle actif : « [Nom] »

**Prochaines étapes :**
- [ ] Traverser le vault, vérifier que les notes matchent la réalité
- [ ] Lancer `/map-process` pour mapper les process de l'équipe par fonction
- [ ] Documenter les 1-3 process prioritaires via `/create-skill`
- [ ] Déposer les docs d'entreprise restantes dans `0 Inbox/_Import/` et lancer `/import`
```

**e. Vérification des configs Obsidian**

Confirme (et ajuste si besoin) :
- `.obsidian/daily-notes.json` : `folder` = `2 Domaines/Pilotage`, `template` = `3 Ressources/Capacités IA/Templates/Note de Standup`, `autorun: false`
- `.obsidian/plugins/calendar/data.json` : `weeklyNoteTemplate` = `3 Ressources/Capacités IA/Templates/Revue Hebdo`, `weeklyNoteFolder` = `2 Domaines/Pilotage/Logs de Session` (les notes hebdo auto du calendar vont dans Logs de Session, PAS dans les dossiers de semaine gérés par `/weekly-review-team-member`)
- `.obsidian/templates.json` : `folder` = `3 Ressources/Capacités IA/Templates`

### 11.5 : Validation finale

Montre le résumé de relecture et demande une validation explicite :

```
Relecture terminée. Voici l'état final du vault :

Écrit pendant la décharge :
- AGENTS.md (racine du vault)                      -> nom IA + entreprise
- 2 Domaines/Vision & Contexte/Vision.md          -> identité, North Star, vision, voix de marque
- 2 Domaines/Vision & Contexte/Moteur de Valeur.md   -> le moteur de valeur
- 2 Domaines/Vision & Contexte/Organigramme/[Personne].md (x N)
- 2 Domaines/Vision & Contexte/Cycles Stratégiques/Cycle Stratégique - 1 [nom].md
- [M] notes de domaine dans 2 Domaines/
- [P] notes de projet dans 1 Projets/
- 3 Ressources/Infrastructure/ (Outils & accès, Où trouver quoi)

Généré pendant la relecture :
- CLAUDE.md                                  -> triage : outils + où trouver quoi + règles
- 2 Domaines/Vision & Contexte/Organigramme.canvas
- 2 Domaines/Vision & Contexte/Moteur de Valeur.canvas
- 2 Domaines/Pilotage/Revues Hebdo/2026-W28/Revue Hebdo - [Initiateur].md (log d'init)
- Configs Obsidian vérifiées

Check de cohérence : [N] mismatch trouvés et fixés / tout clean
Questions de clarification : [N] posées et résolues

Confirmes ? (oui / ajustements)
```

Applique les derniers ajustements, puis passe au Step 12.

---

## Step 12 : Confirmation & prochaines étapes

```
Initialisation terminée !

Créé dans le vault :
- AGENTS.md (racine du vault)                      -> nom IA : [Nom] + entreprise : [Entreprise]
- CLAUDE.md                                  -> triage : outils + où trouver quoi + règles
- 2 Domaines/Vision & Contexte/Vision.md          -> identité, North Star, vision, voix de marque
- 2 Domaines/Vision & Contexte/Moteur de Valeur.md + .canvas
- 2 Domaines/Vision & Contexte/Organigramme/[Personne].md (x N) + Organigramme.canvas
- 2 Domaines/Vision & Contexte/Cycles Stratégiques/Cycle Stratégique - 1 [nom].md
- [M] domaines dans 2 Domaines/
- [P] projets dans 1 Projets/
- 3 Ressources/Infrastructure/ (Outils & accès, Où trouver quoi)
- Première revue hebdo avec le log d'initialisation

Configs Obsidian :
- Daily notes  -> 2 Domaines/Pilotage
- Weekly notes -> 2 Domaines/Pilotage/Logs de Session (calendar); revues gérées par /weekly-review-team-member

Relance Obsidian pour activer les configs daily/weekly.

Prochaines étapes recommandées :
1. Traverse le vault et corrige tout ce qui ne matche pas la réalité
2. Lance /map-process pour mapper les process de l'équipe par fonction business
3. Documente les 1-3 process prioritaires via /create-skill
4. Dépose les docs d'entreprise restantes dans 0 Inbox/_Import/ et lance /import
5. Démarre le rythme : /weekly-review-team-member à la fin de chaque semaine (chaque membre), /done à la fin de chaque session, /prepare-weekly avant le sync du lundi (le lead)
```

---

## Règles

- **Écrire au fur et à mesure.** Chaque artefact self-contained est écrit à la fin de son étape, depuis la décharge fraîche. Ne tiens pas tout jusqu'à la fin. La passe de relecture (Step 11) génère seulement les artefacts transversaux (CLAUDE.md, canvas, revue hebdo d'init) et vérifie la cohérence.
- **Demande toujours validation** après avoir écrit chaque artefact et avant de passer à l'étape suivante.
- **Reformule** après chaque réponse pour valider la compréhension.
- **Rappelle l'affordance de fichiers** à chaque section majeure (Steps 3-9).
- **Lis en entier** tout fichier déposé avant d'extraire.
- **N'invente jamais** : si une info manque et n'a pas été donnée, demande.
- **Respecte le style** (pas de tirets longs, pas de tic « pas X mais Y », direct, concis) dans chaque output.
- **Travaille dans la langue** choisie au Step 2 à partir du Step 3.
- **Le relecteur est un check de cohérence**, pas une passe de réécriture. Il lit ce qui a été écrit, signale les mismatches, pose des clarifications, puis génère les artefacts transversaux.

## Ce que tu ne fais pas

- Tenir toute la décharge en mémoire et tout écrire à la fin. Écris chaque artefact à la fin de son étape.
- Skipper le prélude pédagogique (Step 1) : l'initiateur doit comprendre ce qu'il fait.
- Créer des fichiers sans la quick validation à la fin de chaque étape.
- Mettre le nom de l'IA dans `Vision.md` (il va dans `AGENTS.md`).
- Traiter un domaine comme un projet, ou vice versa (utilise la distinction Projet vs Domaine).
- Hardcoder le nom du Cycle Stratégique : il est toujours détecté depuis `2 Domaines/Vision & Contexte/Cycles Stratégiques/Cycle Stratégique*.md`.
- Stocker des secrets en clair dans le vault : référence les credentials, ne les colle jamais.
- Oublier de générer les deux canvas (Organigramme, Moteur de Valeur) et le triage CLAUDE.md à la passe de relecture.
- Skipper le check de cohérence (Step 11.2) : le relecteur doit vérifier que les domaines matchent le Moteur de Valeur, les projets mapent aux domaines, les propriétaires existent dans l'Organigramme, et le Cycle Stratégique s'aligne avec Vision.
