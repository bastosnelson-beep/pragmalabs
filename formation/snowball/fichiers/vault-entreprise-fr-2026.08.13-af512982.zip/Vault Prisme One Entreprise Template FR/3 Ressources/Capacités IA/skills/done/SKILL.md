---
name: done
description: "Clôt chirurgicalement une session de travail d'équipe : diff d'état, micro-patches, log minimal. Extrait les décisions, faits, contradictions et ressources de la session, log qui l'a fait tourner et ce qui a été accompli, route les updates vers les bonnes notes de contexte de Projet ou Domaine, signale les handoffs aux autres membres de l'équipe, et référence le Cycle Stratégique actif si quelque chose de stratégique a bougé. À utiliser à la fin de n'importe quelle session de travail (membre seul ou équipe)."
---

# Done : Clôturer une session de travail chirurgicalement

Clôt la session de travail en cours avec un passage minimal et chirurgical : extraire ce qui compte, le loguer une fois, patcher les notes de contexte qui ont vraiment changé, et faire émerger les handoffs. L'inverse d'un brain dump : seul ce qui a bougé va quelque part.

Une session peut être faite tourner par un seul membre de l'équipe ou un groupe. Capture qui l'a faite tourner dans les deux cas.

## Process

### Step 1 : Analyser la conversation

Relis la session et extrais les **5 types d'information** :

1. **Décisions** : choix enactés qui affectent le process, l'org, la roadmap, ou un Projet/Domaine
   - ex « On bouge le CRM vers NocoDB », « On tue l'initiative X », « Le propriétaire de Y est maintenant [Personne] »
2. **Préférences** : feedback sur la façon dont l'agent doit se comporter pour cette équipe/membre
   - ex « Sois plus direct », « Ne demande pas à valider chaque étape », « Résumés en français par défaut »
3. **Faits** : nouvelle info factuelle (métriques, statut client, changements d'org, prix, effectifs)
   - ex « Le client Z a signé », « Le prix a changé à X », « L'équipe est maintenant 30 personnes »
4. **Contradictions** : incohérences entre ce qui est documenté dans le vault et ce qui a été dit
   - ex la note de projet dit « deadline mars » mais la session a parlé de « deadline juin »
5. **Ressources** : liens, références, outils, concepts mentionnés qu'il faut enregistrer

Identifie aussi :
- **Fichiers créés ou modifiés** pendant la session
- **Tâches terminées** (items qu'on peut cocher quelque part dans le vault)
- **Prochaines étapes** identifiées mais pas encore exécutées
- **Handoffs** : tout ce qu'un teammate doit reprendre (avec propriétaire et échéance si connus)

### Step 2 : Localiser la destination du log

Choisis l'emplacement du log selon le scope :

```bash
# Session transversale ou scopée à un Domaine -> log Pilotage
RUN_DIR="2 Domaines/Pilotage/Logs de Session"
mkdir -p "$RUN_DIR"

# Session scopée à un Projet -> log de projet (utiliser seulement si la session était clairement liée à un Projet)
# PROJ_DIR="1 Projets/[projet]/Logs"
```

Par défaut : `2 Domaines/Pilotage/Logs de Session/YYYY-MM-DD.md`. Utilise un log de projet seulement quand toute la session était à l'intérieur d'un seul Projet.

Date du jour :

```bash
date +%Y-%m-%d
```

### Step 3 : Écrire le log de session (Niveau 2, obligatoire)

Trouve ou crée le fichier de log du jour. S'il existe, appende un nouveau bloc de session (plusieurs sessions peuvent atterrir le même jour). S'il n'existe pas, crée-le.

Chemin : `2 Domaines/Pilotage/Logs de Session/YYYY-MM-DD.md`

Appende à la fin :

```markdown
---

## Session [HH:MM]

**Fait tourner par :** [[Personne ou rôle]]
**Scope :** [[Projet]] | [[Domaine]] | transversal

**Accompli :**
- [Action 1]
- [Action 2]

**Extractions :**
- Décisions : [liste des décisions enactées]
- Faits : [nouveaux faits appris]
- Préférences : [feedback sur le comportement de l'agent]
- Contradictions : [incohérences détectées et résolues]
- Ressources : [liens, outils, concepts à garder]

**Fichiers modifiés :**
- `[chemin/fichier1.md]`
- `[chemin/fichier2.md]`

**Handoffs :**
- [ ] [Tâche] -> [[Propriétaire]] (échéance : YYYY-MM-DD)
- [ ] [Tâche] -> [[Propriétaire]]

**Prochaines étapes :**
- [ ] [TODO 1]
- [ ] [TODO 2]
```

Si la session était très courte (une seule question, une edit rapide), écris un bloc minimal : fait tourner par, accompli (une ligne), prochaines étapes. Pas de sections vides.

### Step 4 : Patcher les notes de contexte de Projet et Domaine (Niveau 3, obligatoire, sans validation)

Pour chaque extraction de type Décision, Fait, ou Contradiction qui concerne un Projet ou un Domaine :

1. Lis la note de contexte du Projet ou du Domaine pertinent.
2. Vérifie si l'info est déjà présente, ou si elle contredit quelque chose.
3. Update la note directement :
   - `1 Projets/[Projet]/[Projet].md` -> avancement, roadmap, statut, propriétaires
   - `2 Domaines/[domaine]/[domaine].md` -> nouvelle info, responsabilités, updates North Star

Si une **contradiction** est détectée : résous-la en faveur de ce qui a été dit pendant la session (l'info la plus récente gagne). Note la résolution brièvement dans la note de contexte.

Garde les patches chirurgicaux : ajoute une ligne, update un statut, fixe une date. Pas de réécritures.

### Step 5 : Cocher les tâches terminées

Cherche dans le vault (Revue Hebdo active, listes de tâches de Projet, notes running de Domaine) les tâches qui ont été terminées pendant cette session. Coche-les (`- [x]`). Link vers le log de session quand c'est utile.

### Step 6 : Router les handoffs (Niveau 3, obligatoire)

Pour chaque handoff identifié au Step 1 :

- Place la tâche là où elle est vraiment possédée : la liste de tâches du Projet pertinent, la note running de Domaine, ou le profil de la personne dans `2 Domaines/Vision & Contexte/Organigramme/[Personne].md` sous une section `## Actions` (si le fichier existe).
- Appende `(handoff depuis la session YYYY-MM-DD)` à côté du nouvel item.
- Si le propriétaire est inconnu ou le fichier de destination n'existe pas, signale-le dans le log et demande à l'utilisateur (n'invente pas un propriétaire).

Ne duplique pas. S'il existe déjà une tâche équivalente, link le log de session à elle au lieu d'en créer une seconde.

### Step 7 : Updater le contexte global (Niveau 4, avec validation)

Pour les extractions de type Préférence, ou toute info qui change le contexte global, vérifie si des updates sont nécessaires dans :

- `2 Domaines/Vision & Contexte/Vision.md` -> vision, valeurs, direction stratégique
- `2 Domaines/Vision & Contexte/Organigramme/[Personne].md` -> changements de rôle, nouvelles responsabilités
- `2 Domaines/Vision & Contexte/Cycles Stratégiques/Cycle Stratégique.md` -> seulement si une décision a bougé le plan de 2-3 mois (nouvelles dates, changement de scope, initiative ajoutée ou tuée, pivot)

Si un changement est pertinent, montre le diff et demande validation :

```
Je propose d'updater [fichier] :

- Ajouter : [contenu]
- Changer : [ancien] -> [nouveau]

OK ?
```

S'il n'y a rien à updater, ne propose rien.

Pour le Cycle Stratégique spécifiquement : update seulement quand une décision du Step 1 bouge vraiment le plan macro. Sinon laisse-le tranquille.

### Step 8 : Confirmation

Affiche un résumé minimal :

```
=== Session loguée ===

Fait tourner par : [[Personne ou rôle]]
Log : 2 Domaines/Pilotage/Logs de Session/[date].md (session [HH:MM])
Niveau 3 patché : [liste des fichiers modifiés]
Handoffs routés : [n] (vers [[Propriétaire 1]], [[Propriétaire 2]])
Niveau 4 (global) : [updaté / pas de changement]
Cycle Stratégique : [updaté / inchangé]

Extractions :
- [n] décisions
- [n] faits
- [n] préférences
- [n] contradictions résolues
- [n] ressources

Handoffs ouverts ayant encore besoin d'un propriétaire : [n] (listés dans le log)
```

## Règles

- Le Niveau 3 (notes de contexte Projet/Domaine) est appliqué directement, sans validation.
- Le Niveau 4 (Vision, Organigramme, Cycle Stratégique) nécessite une validation.
- Sois concis dans les logs. Pas de blabla.
- Utilise des [[wikilinks]] vers les Projets, Domaines, et personnes de l'Organigramme quand ils sont connus.
- Une session très courte a un log minimal (fait tourner par + accompli + prochaines étapes). Pas de sections vides.
- Un fichier de log par jour, un bloc par session (appende, n'écrase pas).
- Résous les contradictions en faveur de la session (l'info la plus récente gagne) et note la résolution.
- N'invente jamais un propriétaire pour un handoff. Si c'est inconnu, signale et demande.
- Pas de tirets longs (utilise deux points, virgule, parenthèse, ou reformule).
- Pas de tic rhétorique « pas X mais Y ». Dis les choses directement.
- Pas d'emojis.

## Ce que tu ne fais pas

- Rouvrir du travail terminé ou ré-expliquer ce qui a été fait; logue-le et passe à la suite.
- Créer un nouveau fichier de log si celui du jour existe déjà; appende un bloc de session à la place.
- Updater le Cycle Stratégique pour des décisions opérationnelles qui ne bougent pas le plan de 2-3 mois.
- Patcher une note de contexte sans l'avoir lue d'abord (lis toujours, puis édite chirurgicalement).
- Laisser un handoff sans propriétaire et sans le signaler.
- Écrire des sections vides dans un log de session minimal.
