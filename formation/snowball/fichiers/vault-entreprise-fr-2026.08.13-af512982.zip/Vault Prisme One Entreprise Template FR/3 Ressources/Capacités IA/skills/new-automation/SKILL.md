---
name: new-automation
description: "Conçoit et documente une nouvelle automation (n8n, MCP, cron, script) pour l'équipe. Scope le trigger, les inputs, les étapes, les outputs, les outils/credentials, et le propriétaire. Documente dans le vault pour que l'équipe puisse la faire tourner et la maintenir. Arc chirurgical : scope, build, test, documente."
---

# New Automation

Tu aides l'équipe à concevoir et créer une automation (workflow n8n, serveur MCP, cron job, ou script).

## Arguments

- `$ARGUMENTS` : Nom du process ou de l'automation (optionnel)

## Avant de commencer

1. Lis le contexte stratégique de l'entreprise (`[[Vision]]`, Cycle Stratégique actif) dans `2 Domaines/Vision & Contexte/`
2. Si un process est mentionné, lis sa note de process dans le Domaine pertinent
3. Vérifie les automations existantes dans `3 Ressources/Infrastructure/` pour éviter les doublons

## Process

### Step 1 : Identifier l'automation

Si `$ARGUMENTS` est fourni :
- Trouve la note de process correspondante (linkée depuis son Domaine)
- Utilise-la comme point de départ

Sinon :

```
Quelle automation veux-tu créer ?

Exemples :
- "Quand un paiement Stripe est reçu, créer le compte client"
- "Chaque lundi, générer un draft de revue hebdo"
- "Quand un fichier atterrit dans l'inbox, le classer"
- "Sync les nouveaux leads du site vers le CRM"

Décris ce que tu veux automatiser.
```

### Step 2 : Définir le trigger

```
Qu'est-ce qui déclenche cette automation ?

Schedule (temps) :
- Tous les jours à [heure]
- Toutes les semaines le [jour] à [heure]
- Tous les mois le [date]
- Toutes les [X] minutes/heures

Webhook (événement externe) :
- Paiement reçu (Stripe, PayPal...)
- Email reçu
- Formulaire soumis
- Nouveau fichier (Google Drive, Dropbox...)
- Appel API depuis un autre service

Événement interne :
- Changement dans une base de données
- Fin d'un autre workflow

Lequel ?
```

### Step 3 : Cartographier les actions

```
Quelles actions doivent tourner en séquence après le trigger ?

Liste les étapes dans l'ordre :
1. [Action 1] : Quoi ? Vers où ?
2. [Action 2] : Quoi ? Vers où ?
3. ...

Pour chaque action, précise :
- Le service (Gmail, Notion, Supabase, Slack...)
- L'input
- L'output
```

### Step 4 : Gérer les conditions et les erreurs

```
Y a-t-il des conditions ou des cas particuliers ?

Conditions :
- Si [condition] -> fais [action A]
- Sinon -> fais [action B]

Erreurs :
- Si ça échoue -> [que doit-il se passer ?]

Validation humaine :
- Y a-t-il une étape où un humain doit valider avant de continuer ?
- Si oui, comment doit-il être notifié ? (Slack, email, SMS...)
```

### Step 5 : Identifier les credentials et le propriétaire

```
De quel accès as-tu besoin ?

Services identifiés dans le workflow :
- [ ] [Service 1] : clé API / OAuth ?
- [ ] [Service 2] : clé API / OAuth ?

Ces credentials sont-ils déjà configurés (dans n8n, dans le serveur MCP, sur le host) ?

Qui possède et maintient cette automation ?
- Propriétaire : [nom/rôle]
- Mainteneur : [nom/rôle, si différent]
```

### Step 6 : Concevoir le workflow

Produis un schéma textuel du workflow :

```
## Workflow : [Nom]

### Trigger
[Type] : [Détail]

### Actions

+-------------------------------------+
| 1. [Trigger]                        |
|    Type : [Schedule/Webhook/...]     |
|    Config : [Détails]                |
+----------------+--------------------+
                 |
                 v
+-------------------------------------+
| 2. [Action 1]                       |
|    Service : [Nom]                  |
|    Input : [...]                     |
|    Output : [...]                    |
+----------------+--------------------+
                 |
                 v
          [Condition ?]
              /   \
            /       \
           v         v
    [Action A]   [Action B]
                 |
                 v
+-------------------------------------+
| N. [Action finale]                  |
|    Service : [Nom]                  |
|    Output : [Résultat final]        |
+-------------------------------------+

### Gestion des erreurs
[Ce qui se passe en cas d'échec]

### Credentials requis
- [Service 1] : [type d'auth]
- [Service 2] : [type d'auth]

### Propriétaire
- Propriétaire : [nom/rôle]
- Mainteneur : [nom/rôle]
```

Demande une validation avant de continuer.

### Step 7 : Builder le workflow

```
Je vais maintenant builder cette automation.

Prérequis :
1. La cible est accessible (instance n8n, host MCP, serveur cron, environnement de script)
2. Les credentials sont configurés

Veux-tu que je la build maintenant ?
```

Si oui, build sur la cible.

Pour n8n, utilise l'API n8n pour créer le workflow. Structure :

```json
{
  "name": "[Nom du workflow]",
  "nodes": [
    {
      "name": "[Nom du noeud]",
      "type": "[type de noeud n8n]",
      "position": [X, Y],
      "parameters": {
      }
    }
  ],
  "connections": {
    "[Noeud source]": {
      "main": [
        [
          {
            "node": "[Noeud destination]",
            "type": "main",
            "index": 0
          }
        ]
      ]
    }
  }
}
```

Pour un serveur MCP, documente les tools exposés et le transport. Pour un cron job ou un script, écris le script et l'entrée crontab. Garde chaque automation petite; split en plusieurs si elle devient trop complexe.

### Step 8 : Documenter dans le vault

Crée ou mets à jour la documentation dans le vault.

Si l'automation est liée à un process cartographié, ajoute une entrée dans la section « AI Integration » de la note de process :

```markdown
## AI Integration

| Étape | Levier | Solution | Statut | Propriétaire |
|------|-------|----------|--------|-------|
| X. [Étape automatisée] | Automation | Workflow n8n "[Nom]" | Actif | [propriétaire] |
```

Si c'est une automation standalone, crée `3 Ressources/Infrastructure/Automation - [Nom].md` (crée le dossier s'il n'existe pas) :

```markdown
# Automation : [Nom]

**Créée le :** [DATE]
**Statut :** Actif / En test / Inactif
**Propriétaire :** [nom/rôle]
**Mainteneur :** [nom/rôle]

---

## Trigger
[Type] : [Détail]

## Actions
1. [Action 1]
2. [Action 2]
3. ...

## Validation (si applicable)
[Comment l'humain intervient]

## Gestion des erreurs
[Ce qui se passe en cas d'échec]

## Credentials
- [Service 1] : configuré dans [n8n / host MCP / env]
- [Service 2] : configuré dans [n8n / host MCP / env]

## Lié

- [[Note de process]] (le process d'équipe que ça automatise)
- [[Skill]] (le skill qui le fait tourner ou le déclenche, s'il y en a un)

## Logs

| Date | Changement |
|------|--------|
| [DATE] | Création initiale |
```

Link l'automation au process qu'elle automatise et à tout skill qui la fait tourner, via wikilinks, pour que l'équipe puisse tracer la chaîne complète.

### Step 9 : Tester

```
Automation buildée.

Prochaines étapes :
1. Ouvre n8n -> Workflows -> "[Nom]" (ou la cible pertinente)
2. Active-la
3. Teste avec de la vraie data
4. Vérifie qu'elle marche de bout en bout

Si ça échoue :
- Vérifie les credentials
- Lis les logs d'exécution
- Reviens avec l'erreur

Veux-tu tester maintenant ?
```

## Noeuds n8n courants

| Action | Noeud n8n |
|--------|----------|
| Schedule trigger | `n8n-nodes-base.scheduleTrigger` |
| Webhook | `n8n-nodes-base.webhook` |
| HTTP Request | `n8n-nodes-base.httpRequest` |
| Gmail | `n8n-nodes-base.gmail` |
| Slack | `n8n-nodes-base.slack` |
| Notion | `n8n-nodes-base.notion` |
| Google Sheets | `n8n-nodes-base.googleSheets` |
| Supabase | `n8n-nodes-base.httpRequest` (REST) ou le noeud Supabase |
| Code (JS) | `n8n-nodes-base.code` |
| IF condition | `n8n-nodes-base.if` |
| Switch | `n8n-nodes-base.switch` |
| Merge | `n8n-nodes-base.merge` |
| Set | `n8n-nodes-base.set` |

## Règles

- Valide toujours le schéma avant de builder
- Planifie la gestion des erreurs
- Documente dans le vault
- Propose un test après la création
- Nomme un propriétaire pour chaque automation

## Ce que tu ne fais jamais

- Builder un workflow sans validation
- Skipper la gestion des erreurs
- Builder des workflows trop complexes (split-les à la place)
- Supposer que les credentials sont configurés : demande toujours
- Laisser une automation sans propriétaire documenté
