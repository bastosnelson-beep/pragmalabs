---
name: de-ai-ify
description: "Retire les patterns générés par l'IA et restaure la voix de marque de l'entreprise plus la voix personnelle de l'auteur. Passage chirurgical avant/après sur n'importe quel texte qu'un membre de l'équipe a drafté avec un outil d'IA. À utiliser quand un texte sonne robotique, générique, ou hors marque."
---

# De-AI-ify : Restaurer la voix de marque et de l'auteur

Retire les patterns typiques de l'IA et réécrit le texte dans la voix de marque de l'entreprise (définie dans `2 Domaines/Vision & Contexte/Vision.md`) combinée avec la voix personnelle de l'auteur (capturée dans `2 Domaines/Vision & Contexte/Organigramme/[Personne].md` quand un profil de voix existe).

## Traitement : $ARGUMENTS

Je produis une version de-AI-ifiée de ton texte.

## Avant de commencer : charger les voix

1. Lis `2 Domaines/Vision & Contexte/Vision.md` pour la définition de la **voix de marque** (ton, vocabulaire, ce que l'entreprise dit et ne dit pas, formulations signature).
2. Identifie l'auteur. Si l'auteur est connu (depuis le frontmatter de la note, le chemin du fichier sous Organigramme, ou l'utilisateur), lis `2 Domaines/Vision & Contexte/Organigramme/[Personne].md` pour un **profil de voix personnel**.
3. Si l'un ou l'autre fichier manque ou n'a pas de section voix, dis-le explicitement et procède avec la voix de marque seule. N'invente jamais de profil de voix.

Adapte la réécriture au matériel de voix disponible. Quand les deux existent, mélange la voix de marque (principale) avec la voix de l'auteur (secondaire, pour les passages à la première personne).

## Ce qui est retiré

### 1. Transitions mécaniques
- "Moreover," "Furthermore," "In addition," "Nevertheless," "Nonetheless"
- Surutilisation de "However" et "That said"
- Ouvrants systématiques en "Although X, Y"

### 2. Clichés d'IA
- "In today's fast-paced world"
- "In a world where X"
- "It is worth noting that"
- "It should be mentioned that"
- "Leverage the potential of"
- "Tap into"
- "Unlock unprecedented"
- "Game-changing," "paradigm shift," "delve into," "navigate the landscape"

### 3. Phrases connecteurs creuses
- "It is important to note that"
- "It is worth mentioning"
- Quantificateurs vagues : "various," "numerous," "multiple," "a wide range of"
- "Indeed" utilisé comme béquille

### 4. Jargon corporate
- "optimize" -> "améliorer"
- "implement" -> "mettre en place"
- "capitalize on" -> "utiliser"
- "synergy" -> collaboration / lien
- "scalable" -> "peut grandir"
- "leverage" -> "utiliser"
- "robust" -> "solide" (ou couper)

### 5. Patterns robotiques
- Questions rhétoriques répondues immédiatement par la phrase suivante
- Structures parallèles obsessionnelles
- Toujours exactement trois exemples
- Annoncer ce qu'on va dire avant de le dire
- Conclusions qui reformulent exactement ce qui vient d'être dit
- Listes à puces avec des préfixes emoji

### 6. Indices structurels (règles dures)
- **Pas de tirets longs.** Remplace par deux points, virgule, parenthèse, ou reformule.
- **Pas de tic rhétorique « pas X mais Y ».** Énonce le positif directement. (« We do not just build tools, we build systems » devient « We build systems. »)

## Ce qui est ajouté

### Voix naturelle
- Longueurs de phrases variées
- Ton conversationnel, direct
- Assertions simples
- Exemples concrets, spécifiques
- Première personne quand l'auteur parle (utiliser le profil de voix de l'auteur)

### Rythme humain
- Transitions naturelles, ou pas de transition du tout
- Assertions confiantes
- Perspective personnelle quand c'est pertinent
- Formulations authentiques issues des profils de voix de marque et de l'auteur

## Process

1. **Lis le fichier original** (`$ARGUMENTS`) en entier.
2. **Charge les voix** (voix de marque Vision.md + voix auteur Organigramme/[Personne].md), selon la section ci-dessus.
3. **Crée une copie avec le suffixe "-HUMAN"** (ex `Brief.md` -> `Brief-HUMAN.md`).
4. **Applique la de-AI-ification** dans la voix de marque plus la voix de l'auteur.
5. **Produis un changelog** des modifications.

## Output

Tu obtiens :
- Un nouveau fichier avec un texte naturel, dans la marque, dans la voix
- Un changelog qui montre ce qui a été changé et pourquoi
- Une liste des endroits qui gagneraient à recevoir des exemples concrets ou des spécificités

## Exemples de transformation

**Avant (IA) :** "In today's fast-paced world, where artificial intelligence continues to evolve at an unprecedented pace, it is crucial to understand that leveraging AI effectively is not about deploying the most advanced technology. It is about unlocking its transformative potential to capitalize on unprecedented opportunities."

**Après (humain, voix de marque) :** "L'IA marche le mieux sur des tâches spécifiques. Pointe-la sur ce qu'elle fait bien : écrire du code, analyser de la data, répondre à des questions."

**Avant (IA, avec tiret long et tic) :** "We do not just build dashboards, we build decision systems, empowering teams to navigate complexity with confidence."

**Après (humain) :** "On construit des systèmes de décision. Les équipes les utilisent pour trancher avec confiance."

## Règles

- Pas de tirets longs nulle part dans l'output.
- Pas de tic rhétorique « pas X mais Y ». Dis le positif directement.
- Si la voix de marque ou le profil de voix de l'auteur manque, dis-le. N'invente pas de voix.
- Préserve le sens et le contenu factuel. Réécris l'expression, pas le fond.
- Garde la même langue que le texte source. La structure de ce skill est en anglais, le texte réécrit suit la langue de la source.
- Pas d'emojis.
- Concis, pas de blabla.
