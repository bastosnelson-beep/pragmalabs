---
name: connect-tool
description: Connecte un outil, service, ou API externe au setup IA de l'équipe. Recherche la meilleure méthode de connexion (serveur MCP, install CLI, clé API + skill, ou endpoint HTTP), demande si l'outil est user-scoped ou company-scoped, puis installe dans les bons configs (OpenCode, Claude Code, Claude Desktop, pi) et, si company-scoped, le documente dans 3 Ressources/Infrastructure/Services API, CLI et MCP disponibles pour que les autres membres de l'équipe puissent le découvrir et l'installer localement. À utiliser quand « connecte X », « ajoute X à mon IA », « installe le X MCP », « donne accès à X à mon IA », « comment connecter X ».
---

# /connect-tool : Connecter un outil à l'IA de l'équipe

Tu recherches la meilleure façon de connecter un outil donné, tu l'installes dans les bons configs, et tu le documentes s'il est partagé à l'échelle de l'entreprise.

## Argument

`$ARGUMENTS` = nom ou description de l'outil à connecter (ex « firecrawl », « supabase », « le GitHub MCP », « Notion », « linear », « web scraping », « le NocoDB de l'entreprise »).

Si vide, demande quel outil le membre de l'équipe veut connecter avant de continuer.

## L'idée centrale

Tous les outils ne devraient pas être un MCP. Parfois une CLI est plus simple. Parfois une clé API plus un petit skill est plus flexible. Parfois tu documentes juste un endpoint HTTP.

Ce skill trouve la meilleure méthode, demande si c'est juste pour l'utilisateur courant ou pour toute l'entreprise, l'installe au bon endroit, et le documente si c'est partagé.

## Convention de stockage

- **Config utilisateur** (la machine de chaque personne, gitignorée) : `~/.config/opencode/opencode.json`, `~/.claude.json`, `~/Library/Application Support/Claude/claude_desktop_config.json`, `~/.pi/agent/mcp.json`. Les secrets vivent ici (sur chaque machine), jamais dans le vault.
- **Services partagés entreprise** : `3 Ressources/Infrastructure/Services API, CLI et MCP disponibles/[Nom de l'outil].md`. Une note par service. C'est comme ça que marche le partage : les IA des autres membres scannent ce dossier, trouvent un service, et l'installent localement.
- **Ne jamais** coller de secrets dans le vault. La note d'Infrastructure référence où vivent les secrets (1Password, nom de l'env var, propriétaire à qui demander), jamais les secrets eux-mêmes.

---

## Phase 0 : Recherche de la meilleure méthode de connexion

Découvre ce que l'outil offre. Ne suppose rien, cherche.

### 0.1 Recherche

Utilise Firecrawl ou webfetch si pas disponible :

1. Cherche `"<tool> MCP server"` et `"<tool> MCP npm"` pour vérifier un MCP officiel ou communautaire.
2. Cherche `"<tool> CLI"` pour vérifier un outil en ligne de commande.
3. Cherche `"<tool> API documentation"` pour vérifier une API REST/HTTP.
4. Cherche `"<tool> npm package"` ou `"<tool> python sdk"` pour vérifier un SDK.
5. Si un MCP est trouvé, fetch son README pour avoir la config exacte (package, transport, env vars).

### 0.2 Évaluer et recommander

Juge l'outil contre les 4 méthodes. Choisis le meilleur fit.

| Méthode | Quand l'utiliser | Ce que tu produis |
|--------|----------|------------------|
| **Serveur MCP** | Il existe un MCP bien maintenu (officiel ou communautaire populaire), et l'équipe a besoin d'un accès riche et structuré à l'outil (opérations multiples, inputs typés) | Entrée de config dans le(s) client(s) IA. Le meilleur pour : bases de données, CRM, outils de design, gestion de projet, tout ce qui a beaucoup d'opérations. |
| **Install CLI** | Il existe une bonne CLI, et l'usage consiste surtout à lancer des commandes | Installe la CLI (brew/npm/pip), crée optionnellement un skill qui wrap les commandes courantes. Le meilleur pour : outils de build, de deploy, scrapers, utilitaires système. |
| **Clé API + skill** | Il existe une API REST mais pas de MCP/CLI, et l'équipe a besoin d'opérations reproductibles | Un petit skill dans `3 Ressources/Capacités IA/skills/[nom]/` qui appelle l'API, avec la clé référencée depuis env/Infrastructure. Le meilleur pour : services one-off, APIs internes, SaaS simple. |
| **Endpoint HTTP (documenter seulement)** | Usage simple one-off, ou l'équipe a juste besoin de connaître l'endpoint et l'auth | Une note dans Infrastructure documentant l'endpoint, l'auth, et l'usage. Le meilleur pour : dashboards internes, webhooks, APIs simples en lecture seule. |

### 0.3 Présenter la recommandation

```
J'ai recherché [outil]. Voilà ce qu'il offre :

- MCP : [oui/non, quel package, comment maintenu]
- CLI : [oui/non, laquelle]
- API : [oui/non, REST/GraphQL]
- SDK : [oui/non, lequel]

Ma recommandation : [méthode]. [1 ligne pourquoi.]

Tu es d'accord, ou tu veux une autre méthode ?
```

Attends la confirmation. Seulement alors passe à la suite.

---

## Phase 1 : Déterminer le scope (utilisateur vs entreprise)

Demande :

```
Cet outil est pour toi seulement, ou pour toute l'entreprise ?

- User-scoped : juste pour toi. Je l'installe dans ton/tes config(s). Pas de doc dans le vault.
- Company-scoped : toute l'équipe en a besoin. Je l'installe dans ton/tes config(s) ET je le documente
  dans 3 Ressources/Infrastructure/Services API, CLI et MCP disponibles/ pour que les IA des autres
  membres puissent le trouver et l'installer localement aussi.
```

Si company-scoped, demande qui possède l'outil (qui l'a configuré, qui le maintient, à qui demander pour les credentials).

---

## Phase 2 : Rassembler les credentials

Si la connexion nécessite des credentials (clé API, token, etc.) :

- Dis au membre exactement quelle(s) variable(s) sont nécessaires
- Explique où les obtenir (depuis le README que tu as scrapé, ou la page de settings de l'outil)
- Demande au membre de les fournir
- Ne continue pas sans eux s'ils sont obligatoires

```
Cette connexion nécessite :
- VARIABLE_NAME : [courte explication, ex « ta clé API Firecrawl, disponible sur app.firecrawl.dev »]

Fournis ces valeurs pour que je puisse configurer la connexion.
```

**Règles de gestion des credentials :**
- Les vraies valeurs vont dans les fichiers de config utilisateur (sur la machine du membre). C'est OK; ces fichiers sont gitignorés.
- Si company-scoped, la note d'Infrastructure référence OÙ vit le secret (chemin du vault 1Password, nom de l'env var, ou « demande à [propriétaire] »), jamais le secret lui-même.
- Si l'équipe utilise un gestionnaire de secrets partagé (1Password, Bitwarden), référence ce chemin.

---

## Phase 3 : Installer

### 3.1 Détecter les systèmes IA installés

Lance ça pour voir quels systèmes sont présents :

```bash
echo "=== Détection des systèmes IA ==="

# OpenCode
if [ -f "$HOME/.config/opencode/opencode.json" ]; then
  echo "OpenCode: DÉTECTÉ ($HOME/.config/opencode/opencode.json)"
else
  echo "OpenCode: absent"
fi

# Claude Code CLI
if [ -f "$HOME/.claude.json" ]; then
  echo "Claude Code CLI: DÉTECTÉ ($HOME/.claude.json)"
else
  echo "Claude Code CLI: absent"
fi

# Claude Desktop (macOS)
if [ -f "$HOME/Library/Application Support/Claude/claude_desktop_config.json" ]; then
  echo "Claude Desktop (macOS): DÉTECTÉ"
elif [ -f "$APPDATA/Claude/claude_desktop_config.json" ] 2>/dev/null; then
  echo "Claude Desktop (Windows): DÉTECTÉ"
elif [ -f "$HOME/.config/Claude/claude_desktop_config.json" ]; then
  echo "Claude Desktop (Linux): DÉTECTÉ"
else
  echo "Claude Desktop: absent"
fi

# pi
if [ -f "$HOME/.pi/agent/mcp.json" ]; then
  echo "pi: DÉTECTÉ ($HOME/.pi/agent/mcp.json)"
else
  echo "pi: absent"
fi

# jq
if command -v jq &>/dev/null; then
  echo "jq: disponible"
else
  echo "jq: ABSENT (fallback Python sera utilisé)"
fi
```

Demande au membre quels systèmes il utilise (il peut en avoir plusieurs; ne suppose pas que tous les détectés sont utilisés).

### 3.2 Patcher le config pour chaque système choisi

Le format diffère par système. N'écrase jamais un config existant : lis toujours, ajoute la clé, réécris.

#### OpenCode (`~/.config/opencode/opencode.json`)

Clé wrapper : `mcp`. `command` est un **tableau**. Clé env : `environment`. Type : `local` / `remote`. Besoin de `enabled: true`.

**stdio (local) :**
```json
{
  "mcp": {
    "<name>": {
      "type": "local",
      "command": ["npx", "-y", "<package>"],
      "environment": { "KEY": "VALUE" },
      "enabled": true
    }
  }
}
```

**http (remote) :**

```json
{
  "mcp": {
    "<name>": {
      "type": "remote",
      "url": "https://mcp.example.com/sse",
      "headers": { "Authorization": "Bearer TOKEN" },
      "enabled": true
    }
  }
}
```

Patch :
```bash
mkdir -p "$HOME/.config/opencode"
[ ! -f "$HOME/.config/opencode/opencode.json" ] && echo '{"$schema":"https://opencode.ai/config.json","mcp":{}}' > "$HOME/.config/opencode/opencode.json"

jq '.mcp["NAME"] = {
  "type": "local",
  "command": ["npx", "-y", "PACKAGE"],
  "environment": {"KEY": "VALUE"},
  "enabled": true
}' "$HOME/.config/opencode/opencode.json" > /tmp/oc.json && mv /tmp/oc.json "$HOME/.config/opencode/opencode.json"
```

#### Claude Code CLI (`~/.claude.json`) et Claude Desktop

Clé wrapper : `mcpServers`. `command` est une **chaîne**, `args` est un tableau séparé. Clé env : `env`. Pas de champ `type` pour stdio.

**stdio (local) :**
```json
{
  "mcpServers": {
    "<name>": {
      "command": "npx",
      "args": ["-y", "<package>"],
      "env": { "KEY": "VALUE" }
    }
  }
}
```

**http (remote) :** Claude Code/Desktop ne supporte pas le MCP HTTP remote nativement. Utilise le bridge `mcp-remote` :
```json
{
  "mcpServers": {
    "<name>": {
      "command": "npx",
      "args": ["-y", "mcp-remote", "https://mcp.example.com/sse", "--header", "Authorization:Bearer TOKEN"]
    }
  }
}
```

Patch Claude Code CLI (chemin : `~/.claude.json`). Patch Claude Desktop (chemin varie selon l'OS, voir détection ci-dessus).

```bash
[ ! -f "$HOME/.claude.json" ] && echo '{"mcpServers":{}}' > "$HOME/.claude.json"

jq '.mcpServers["NAME"] = {
  "command": "npx",
  "args": ["-y", "PACKAGE"],
  "env": {"KEY": "VALUE"}
}' "$HOME/.claude.json" > /tmp/cc.json && mv /tmp/cc.json "$HOME/.claude.json"
```

Claude Desktop : même format, chemin différent. Claude Desktop ne recharge pas le config automatiquement : relance l'app après le patch.

#### pi (`~/.pi/agent/mcp.json`)

Clé wrapper : `mcpServers`. Supporte `type: "http"` (avec `url`, `headers`) et `type: "stdio"` (avec `command`, `args`, `env`).

**stdio (local) :**

```json
{
  "mcpServers": {
    "<name>": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "<package>"],
      "env": { "KEY": "VALUE" }
    }
  }
}
```

**http (remote) :**
```json
{
  "mcpServers": {
    "<name>": {
      "type": "http",
      "url": "https://mcp.example.com/mcp",
      "headers": { "Authorization": "Bearer TOKEN" }
    }
  }
}
```

Patch :
```bash
mkdir -p "$HOME/.pi/agent"
[ ! -f "$HOME/.pi/agent/mcp.json" ] && echo '{"mcpServers":{}}' > "$HOME/.pi/agent/mcp.json"

jq '.mcpServers["NAME"] = {
  "type": "stdio",
  "command": "npx",
  "args": ["-y", "PACKAGE"],
  "env": {"KEY": "VALUE"}
}' "$HOME/.pi/agent/mcp.json" > /tmp/pi.json && mv /tmp/pi.json "$HOME/.pi/agent/mcp.json"
```

#### Fallback Python (si jq absent)

Même pattern que ci-dessus mais en utilisant `python3 -c` pour lire, modifier, et écrire le JSON. Exemple pour OpenCode :

```bash
python3 - <<'EOF'
import json, os
path = os.path.expanduser("~/.config/opencode/opencode.json")
os.makedirs(os.path.dirname(path), exist_ok=True)
config = json.load(open(path)) if os.path.exists(path) else {"$schema":"https://opencode.ai/config.json","mcp":{}}
config.setdefault("mcp", {})["NAME"] = {
    "type": "local",
    "command": ["npx", "-y", "PACKAGE"],
    "environment": {"KEY": "VALUE"},
    "enabled": True
}
json.dump(config, open(path, "w"), indent=2)
print("OpenCode patched.")
EOF
```

Adapte la clé wrapper (`mcp` vs `mcpServers`), la forme de command, et la clé env par système (voir les tables ci-dessus).

### 3.3 Aide-mémoire de compatibilité des formats

| Champ | OpenCode | Claude Code / Desktop | pi |
|-------|----------|----------------------|----|
| Clé wrapper | `mcp` | `mcpServers` | `mcpServers` |
| Command | `command: ["npx", "-y", "pkg"]` (tableau) | `command: "npx"` + `args: ["-y", "pkg"]` (split) | `command: "npx"` + `args: ["-y", "pkg"]` (split) |
| Env vars | `environment: {}` | `env: {}` | `env: {}` |
| Type (stdio) | `type: "local"` | (aucun) | `type: "stdio"` (optionnel) |
| Type (http) | `type: "remote"` + `url` + `headers` | bridge `mcp-remote` dans args | `type: "http"` + `url` + `headers` |
| Activation | `enabled: true` | toujours actif | toujours actif |

L'erreur la plus courante est de confondre la command tableau d'OpenCode avec la command split de Claude/pi. Vérifie deux fois avant d'écrire.

---

## Phase 4 : Documenter (company-scoped seulement)

Si l'outil est company-scoped, crée une note dans `3 Ressources/Infrastructure/Services API, CLI et MCP disponibles/[Nom de l'outil].md`.

```bash
mkdir -p "3 Ressources/Infrastructure/Services API, CLI et MCP disponibles"
```

Utilise ce modèle :

```markdown
---
type: infrastructure
service: "[Nom de l'outil]"
method: "MCP | CLI | clé API + skill | endpoint HTTP"
scope: company
owner: "[nom/rôle]"
status: active
added: [date du jour]
---

# [Nom de l'outil]

## Ce qu'il fait
[1-2 phrases : ce qu'est l'outil, à quoi l'équipe l'utilise.]

## Méthode de connexion
[La méthode choisie en Phase 0 : MCP / CLI / clé API + skill / endpoint HTTP. Une ligne pourquoi cette méthode.]

## Comment installer (pour n'importe quel membre de l'équipe)

### Prérequis
- [ex Node.js pour npx, Python pour pip, brew pour macOS]

### Credentials
- Où les obtenir : [chemin du vault 1Password / nom de l'env var / « demande à [propriétaire] »]
- Env vars requises :
  - `VARIABLE_NAME` : [ce que c'est, où l'obtenir]
- **Ne jamais committer de secrets dans le vault.** Récupère-les depuis la source ci-dessus.

### Commande d'install / config

[La commande d'install exacte ou le bloc de config à ajouter, par système. Montre le format pour chaque système IA que l'équipe utilise : OpenCode, Claude Code, Claude Desktop, pi. Utilise l'aide-mémoire ci-dessus.]

OpenCode (`~/.config/opencode/opencode.json`) :
```json
[le bloc de config]
```

Claude Code (`~/.claude.json`) :
```json
[le bloc de config]
```

pi (`~/.pi/agent/mcp.json`) :
```json
[le bloc de config]
```

[Ou, pour une CLI : la commande d'install brew/npm/pip + comment vérifier.]

[Ou, pour une clé API + skill : l'env var à setter + le skill à lancer.]

## Usage
[2-4 lignes : comment l'équipe utilise cet outil. Opérations courantes, ou le skill à lancer.]

## Propriétaire
- Configuré par : [nom]
- Maintenu par : [nom/rôle]
- Questions : [à qui demander]

## Statut
- [ ] Actif
- [ ] Déprécié (date, remplacement)
```

Après avoir créé la note, dis au membre :

```
Documenté dans 3 Ressources/Infrastructure/Services API, CLI et MCP disponibles/[Nom de l'outil].md.

C'est comme ça que marche le partage : quand l'IA d'un autre membre a besoin de cet outil, elle scanne
ce dossier, trouve la note, et installe l'outil localement en suivant les instructions. Les secrets
sont référencés (où les obtenir), jamais collés dans le vault.
```

---

## Phase 5 : Vérifier et résumer

### 5.1 Vérifier

**OpenCode :** ouvre OpenCode, tape `/mcp` dans le chat. Le nouveau MCP doit apparaître.

**Claude Code CLI :** `claude mcp list`. Le MCP doit apparaître.

**Claude Desktop :** relance l'app. Dans une nouvelle conversation, le MCP doit apparaître dans la liste des tools.

**pi :** relance pi ou ouvre une nouvelle session. Les tools du MCP doivent être disponibles (vérifie avec le tool gateway `mcp` ou en listant les tools disponibles).

**Test :** si possible, lance une opération simple via l'outil pour confirmer qu'il répond. Ex : pour un MCP de scraping, scrape une URL simple. Pour un MCP de base de données, liste une table.

### 5.2 Résumer

```
Outil connecté : [outil] via [méthode].

Scope : [utilisateur / entreprise]

Installé dans :
- OpenCode : [oui / non détecté]
- Claude Code CLI : [oui / non détecté]
- Claude Desktop : [oui (relance requise) / non détecté]
- pi : [oui / non détecté]

Credentials :
- VARIABLE_NAME : setté dans [fichiers de config]
- [Si company-scoped] Référencé dans la note Infrastructure (1Password / demande à [propriétaire])

[Si company-scoped] Documenté : 3 Ressources/Infrastructure/Services API, CLI et MCP disponibles/[Nom de l'outil].md

Vérification : [testé / non testé, résultat]
```

Si une étape a échoué, dis-le clairement et propose le fix.

---

## Cas particuliers

### Install CLI (pas un MCP)

Si la meilleure méthode est une CLI :
1. Installe la CLI (`brew install`, `npm install -g`, `pip install`, etc.)
2. Vérifie : `which <cli>` ou `<cli> --version`
3. Si l'équipe a besoin de commandes reproductibles, crée un skill dans `3 Ressources/Capacités IA/skills/[nom]/SKILL.md` qui wrap les commandes courantes (avec la method bank de `/create-skill`)
4. Si company-scoped, documente dans Infrastructure : la commande d'install, la version, et la référence au skill

### Clé API + skill (pas de MCP, pas de CLI)

Si la meilleure méthode est une clé API + un skill :
1. Demande la clé API, stocke-la comme env var (ou référence 1Password)
2. Crée un skill dans `3 Ressources/Capacités IA/skills/[nom]/SKILL.md` qui documente comment appeler l'API (endpoint, header d'auth, opérations courantes), pointant vers [[Infrastructure]] pour l'emplacement de la clé
3. Si company-scoped, documente l'endpoint, l'auth, et la référence au skill dans Infrastructure

### Endpoint HTTP (documenter seulement)

Si la meilleure méthode est juste de documenter un endpoint HTTP :
1. Crée la note Infrastructure directement (modèle Phase 4), skippe le patching de config (Phase 3)
2. Documente : URL de l'endpoint, méthode d'auth, headers, exemple de requête, propriétaire

---

## Règles

- **Recherche avant d'installer.** Ne suppose pas qu'un outil a un MCP. Évalue les 4 méthodes et recommande le meilleur fit. Confirme avec le membre avant d'installer.
- **Demande le scope.** User-scoped va dans le config seulement. Company-scoped va dans le config ET Infrastructure. Ne saute jamais cette question.
- **Ne colle jamais de secrets dans le vault.** La note d'Infrastructure référence où vivent les secrets (1Password, nom de l'env var, propriétaire), jamais les secrets eux-mêmes. Les secrets vivent dans les fichiers de config utilisateur (gitignorés) ou un gestionnaire de secrets.
- **N'écrase jamais un config existant.** Lis toujours, ajoute la clé, réécris. Utilise `jq` ou Python, jamais d'écriture aveugle.
- **Respecte le format par système.** OpenCode utilise des commandes tableau + `environment` + `enabled`. Claude/pi utilisent command split + `env`. pi supporte `type: "http"` nativement; Claude utilise le bridge `mcp-remote`. Vérifie deux fois l'aide-mémoire avant d'écrire.
- **Vérifie après l'install.** Ne clame pas le succès sans vérifier que l'outil apparaît et répond.
- **Documente pour le partage.** Le dossier Infrastructure est le catalogue de services de l'entreprise. Les IA des autres membres s'y appuient pour découvrir et installer les outils. Garde les notes complètes et à jour.

## Ce que tu ne fais pas

- Installer un MCP sans rechercher si un MCP est vraiment la meilleure méthode.
- Installer sans confirmer le scope (utilisateur vs entreprise).
- Coller des secrets dans le vault ou dans la note Infrastructure.
- Écraser un fichier de config existant au lieu de le patcher.
- Confondre la command tableau d'OpenCode avec la command split de Claude/pi.
- Utiliser le bridge `mcp-remote` pour pi (pi supporte `type: "http"` nativement).
- Oublier de relancer Claude Desktop après le patch (il ne recharge pas automatiquement).
- Skipper l'étape de vérification.
- Pour les outils company-scoped, oublier de créer la note Infrastructure (c'est tout l'intérêt du partage).
- Stocker la note du service ailleurs que dans `3 Ressources/Infrastructure/Services API, CLI et MCP disponibles/`.
