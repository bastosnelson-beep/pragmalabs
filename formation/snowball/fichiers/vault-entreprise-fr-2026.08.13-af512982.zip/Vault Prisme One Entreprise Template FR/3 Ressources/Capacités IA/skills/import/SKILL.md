---
name: import
description: "Import intelligent de la connaissance de l'entreprise dans le Business Brain partagé par passes intentionnelles. Membrane forte : faire entrer le moins possible dans le système, le boulot principal est d'enrichir les notes de contexte existantes (Vision, Projets, Domaines) en lisant les fichiers importés, garder seulement ce qui est encore relevant pour les Projets et Domaines actifs, archiver ou discarder le reste. Conversation d'alignement profonde d'abord, découverte LS par l'agent principal, délégation à des sub-agents briefés, mode PLAN puis mode BUILD, quatre verdicts (EXTRACT_CONTEXT par défaut / KEEP_NOTE rarement / SUMMARIZE / ARCHIVE), boucle de feedback. Aussi le moteur derrière le passage _Import/ référencé par /initialisation-entreprise."
---

# Intelligent Import (vault partagé)

Importe la connaissance de l'entreprise dans le Business Brain partagé par petites passes intentionnelles : une source ou un thème à la fois, ~100 items max. Conversation d'alignement profonde d'abord, puis l'agent principal scanne et découvre, briefe des sub-agents, présente un plan (MODE PLAN), exécute après validation (MODE BUILD), et clôture avec une boucle de feedback.

Ce skill est aussi le moteur derrière le passage `_Import/` référencé par [[initialisation-entreprise]]. Pendant l'init, les documents d'entreprise déposés dans `0 Inbox/_Import/` sont routés à travers cette méthode.

## La membrane : importer le moins possible

C'est le principe fondateur, au-dessus de tout le reste.

L'objectif de l'import n'est PAS de faire entrer des fichiers dans le vault. L'objectif est de faire entrer le MOINS POSSIBLE dans le système. La plupart du temps, le vrai boulot de l'import est d'ENRICHIR les notes de contexte existantes (Vision.md, une note de contexte de Projet, une note de Domaine) en lisant le contenu des fichiers que le membre a apportés, et de discarder ou archiver les fichiers eux-mêmes.

Une membrane forte filtre ce qui entre :

- **Entre** : seulement ce qui est encore relevant aujourd'hui, pour des Projets et Domaines encore actifs, et qui apporte du contexte à ce sur quoi l'équipe travaille maintenant.
- **Ne rentre pas** : tout le reste. Laisse-le dans `_Import/`, ou archive-le. Ne fais pas rentrer du bruit dans le vault. Un vault avec beaucoup de notes et peu de signal est un vault mort.

La décision n'est presque jamais « faire entrer la source entière ». C'est : lis la source, extrais le contexte qui sert les Projets et Domaines actifs, patche les notes de contexte existantes, et laisse le reste dehors.

### L'exemple canonique

> Déverser tout le SharePoint dans le vault ne sert à rien. C'est du bruit.
> Importer des fichiers spécifiques du SharePoint, oui : le brief client pour un projet actif, le contrat fournisseur encore en vigueur, le mémo de pricing que l'équipe utilise encore. Et même alors, l'objectif n'est pas de classer le fichier : c'est de le lire, extrais le contexte qui enrichit la note de Projet ou de Domaine, et archive l'original.

### Comment lire ce skill avec la membrane

- `EXTRACT_CONTEXT` est le verdict par défaut, de loin. L'outcome principal d'un import est des notes de contexte enrichies.
- `KEEP_NOTE` est rare : seulement quand une note a une vraie valeur autonome ET est encore relevant pour un Projet ou un Domaine actif. Une note qui juste traîne dans un dossier et n'est jamais relue est du bruit; ne la garde pas.
- `SUMMARIZE` quand plusieurs items tiennent ensemble du contexte pour un Projet/Domaine actif : une note de synthèse propre bat dix fichiers poussiéreux.
- `ARCHIVE` pour tout ce qui n'est plus relevant, même si c'était important une fois. Projets fermés, anciens fournisseurs, mémos outdated. La règle Bruce Lee : ne garde pas ce qui ne sert plus.

Dans le doute entre garder et archiver : archive. Le coût de faire entrer du bruit est plus élevé que le coût de rater une note.

---

## Le principe : importer par passes intentionnelles

Énonce cette règle à l'utilisateur au tout début :

```
On recommande d'importer par petites passes thématiques, pas tout d'un coup.

Exemple de sequencing sain :
- Passe 1 : le dump SharePoint / Google Drive / Dropbox
- Passe 2 : l'export de l'ancien wiki d'entreprise
- Passe 3 : les exports CRM (deals + contacts)
- Passe 4 : les exports Notion
- Passe 5 : un dossier d'ancien projet spécifique
- Passe 6 : les transcripts de réunions
- Passe 7 : les catalogues et contrats fournisseurs

Pourquoi ? Si tu déverses des milliers de notes d'un coup, le contexte se dilue,
la finesse baisse, et tu valides un plan dans la fatigue que tu n'as pas eu
le temps de penser à fond.

Une passe = une source ou un thème, ~100 items max. Sois intentionnel.
Cette commande est conçue pour être relancée à chaque passe : tu vides
`_Import/`, tu déposes la source suivante, tu relances `/import`.
```

Si l'utilisateur a déjà déversé un volume mixte important dans `_Import/`, propose de splitter en plusieurs passes avant de commencer.

## Sources entreprise (ce qu'on importe)

De la connaissance d'entreprise, pas des notes perso. Sources typiques :

- Dump SharePoint / Google Drive / Dropbox (drives partagés, dossiers d'équipe)
- Export de l'ancien wiki d'entreprise (Confluence, Notion, wiki interne)
- Exports CRM (deals, contacts, accounts, snapshots de pipeline)
- Exports de workspace Notion
- Anciens dossiers de projet (initiatives legacy, projets fermés)
- Transcripts et notes de réunions
- Catalogues et contrats fournisseurs
- Docs de sales enablement, playbooks, one-pagers
- Anciens exports Slack (cas spécial, voir Step 2.2)
- Dumps de chats IA (exports Claude / ChatGPT, cas spécial, voir Step 2.2)

## Process

### Step 1 : Conversation d'alignement profonde

Avant d'ouvrir un seul fichier, capture le contexte humain. Pose ces questions, dans cet ordre :

```
Avant de toucher à quoi que ce soit, dis-moi dans tes propres mots :

1. Qu'est-ce qu'il y a dans `_Import/` pour cette passe ?
   Sois aussi précis que possible. Exemples de réponses riches :
   - « Notre dump SharePoint de 2022-2024. Surtout les dossiers Sales et
      Delivery, plus un peu de bruit admin. »
   - « 800 records de deals CRM exportés. Plein de closed-won de
      l'année dernière, plus le pipeline actuel. »
   - « Des PDFs : un audit financier 2024, deux briefs client, et
      des contrats fournisseurs pour le vendor X. »

2. C'est quoi ton objectif pour cette passe ?
   a) Classer note par note dans Projets / Domaines / Ressources
   b) Surtout extraire l'info utile dans le contexte (Vision.md,
      une note de contexte de projet, une note de Domaine) et archiver le reste
   c) Trier : ce qui sert encore vs ce qui ne sert plus (Bruce Lee)
   d) Un mix (précise lequel)

   Hypothèse par défaut : (b). Le boulot principal est d'enrichir les notes
   de contexte existantes en lisant les fichiers importés, pas de classer des fichiers. Confirme.

3. Y a-t-il quelque chose que tu sais déjà qui devrait être archivé directement ?
   (un projet fermé en 2022, un fournisseur avec qui on ne travaille plus,
   un sujet sur lequel on ne revient jamais)

4. Quel Projet ou Domaine est central à cette passe ?
   (ça me dit où regarder d'abord)

5. As-tu un budget de tokens limité ? Si oui, je peux router le scan
   à travers une clé OpenRouter DeepSeek (~10x moins cher).
```

**Reformule** ce que tu as compris en 4 lignes max, et obtiens une validation avant de continuer. Ce résumé briefe chaque sub-agent au Step 5.

### Step 2 : Préparation automatique de `_Import/`

Travail de fond, pas de questions à l'utilisateur (sauf install ou erreur).

#### 2.1 Convertir les formats lourds via MarkItDown

Détecte les formats à convertir :

```bash
find "0 Inbox/_Import/" -type f \( -iname "*.pdf" -o -iname "*.docx" -o -iname "*.pptx" -o -iname "*.xlsx" \) 2>/dev/null
```

Si tu trouves des fichiers :

1. **Vérifie que markitdown est installé** : `command -v markitdown`
2. **S'il n'est pas installé, installe-le toi-même** :
   - Détecte l'OS (`uname -s`) et ce qui est disponible (`python3`, `pip`, `uv`, `brew`).
   - Source officielle : `https://github.com/microsoft/markitdown` (consulte-la si tu n'es pas sûr de la méthode actuelle).
   - Méthodes par ordre de préférence :
     - `uvx markitdown` (si `uv` disponible, le plus clean)
     - `pip install 'markitdown[all]'`
     - `pipx install 'markitdown[all]'`
   - **Demande confirmation avant** : « J'ai trouvé [N] PDF / Word / PPT à convertir. Je vais installer markitdown via [méthode]. OK ? »
   - Lance, vérifie avec `markitdown --help`.
3. **Convertis chaque fichier** en `.md` à côté :
   ```bash
   markitdown "file.docx" > "file.md"
   ```
4. **Déplace les originaux** vers `0 Inbox/_Import/_originaux/`.

#### 2.2 Cas spéciaux : dumps de chats IA et exports Slack (discret)

Ceux-ci sont secondaires pour l'import entreprise mais apparaissent quand même. Détecte les exports JSON :

```bash
find "0 Inbox/_Import/" -maxdepth 2 -type f -name "*.json" 2>/dev/null
```

Pour chaque JSON :

1. **Détecte le format** depuis la structure :
   - **Claude** : array d'objets avec `uuid`, `name`, `created_at`, `chat_messages[]`
   - **ChatGPT** : array d'objets avec `id`, `title`, `create_time`, `mapping{}`
   - **Slack** : export basé sur des channels avec messages et user maps
2. **Règles pour le contenu de chat** :
   - Le titre auto-généré est rarement utile. Réécris-le depuis le contenu.
   - Le contenu utile est souvent **diffus dans le dialogue** : une conversation de 2h peut tenir seulement 3 idées qui méritent `EXTRACT_CONTEXT`. Presque jamais route une conversation entière en `KEEP_NOTE` sans résumer ou extraire.
   - Les échanges courts (< 5 messages) méritent rarement d'être gardés : `ARCHIVE` par défaut.
3. **Parse et split** : crée **un fichier `.md` par conversation** (ou par channel Slack) dans `0 Inbox/_Import/_chats/` :
   - Nom : `YYYY-MM-DD - [titre court réécrit].md`
   - Contenu : frontmatter (`source: claude | chatgpt | slack`, `original_title:`, `date:`, `nb_messages:`), puis la conversation nettoyée.
4. **Déplace le JSON original** vers `_Import/_originaux/`.

À partir d'ici, les items de chat sont des fichiers `.md` comme les autres et passent par le même scan (Step 5) avec les mêmes quatre verdicts.

#### 2.3 Rapport de préparation

Annonce :

```
Préparation terminée :
- [X] Fichiers Markdown / texte / notes
- [Y] Documents Office convertis (PDF, Word, PPT, Excel)
- [Z] Items Claude / ChatGPT / Slack splités en notes individuelles

Total à traiter cette passe : [X+Y+Z] items.
```

Si le total dépasse **150**, avertis :

```
Attention : [N] items c'est beaucoup pour une passe.
Je recommande de splitter. Options :
a) Continuer quand même
b) Laisse-moi proposer un split en plusieurs passes
   (par source, par projet, par date)
```

### Step 3 : Scan initial par l'agent principal (discovery LS)

Avant de déléguer aux sub-agents, **toi (l'agent principal) regarde** ce qu'il y a vraiment. Pas en détail, juste assez pour steer.

1. **Listing complet** :
   ```bash
   ls -laR "0 Inbox/_Import/" | head -200
   ```
   (exclus `_originaux/` et `_chats/` si déjà walkés implicitement, garde-les pour le scan)

2. **Échantillon** : lis le contenu de ~5 items représentatifs (1 note random, 1 dump de chat, 1 PDF converti, 1 export Notion, 1 record CRM) pour comprendre le **style** du corpus.

3. **Produis un mapping interne** :
   ```
   Discovery du corpus :
   - Types de fichiers : [liste]
   - Volume par type : [nombres]
   - Style général : [ex « notes de brainstorming courtes », « docs wiki structurés avec h1/h2 », « drafts de propositions long-form »]
   - Sujets dominants apparents : [tags récurrents]
   - Lien avec ce que l'utilisateur a annoncé au Step 1 : [match / gap]
   ```

4. **Décide des tailles de batch** pour les sub-agents :
   - Notes courtes : ~50 items par batch
   - Items chat / Slack : ~10 items par batch
   - PDFs convertis longs : ~15 items par batch

### Step 4 : Table de routage du vault

Pour briéfer les sub-agents, tu dois connaître le vault.

1. **Contexte entreprise** : `2 Domaines/Vision & Contexte/Vision.md` (direction, North Star).
2. **Cycle Stratégique actif** :
   ```bash
   ls "2 Domaines/Vision & Contexte/Cycles Stratégiques/"Cycle\ Stratégique\ -\ *.md 2>/dev/null | sort | tail -1
   ```
   Lis-le pour le plan actif de 2-3 mois (priorités actuelles, deadlines, initiatives).
3. **Projets actifs** : liste `1 Projets/`, lis chaque note de contexte de projet.
4. **Domaines** : liste `2 Domaines/` (domaines), lis chaque note de contexte de Domaine.
5. **Organigramme** : liste `2 Domaines/Vision & Contexte/Organigramme/` pour connaître les teammates et les propriétaires.

**Produis un résumé interne compact** :

```
Contexte entreprise :
- Vision : [résumé 1 ligne]
- Cycle Stratégique : [nom]. Focus : [résumé 1 ligne]

Projets actifs ([X]) :
- [Projet 1] : [1 ligne + statut + mots-clés associés]
- ...

Domaines ([Y]) :
- [Domaine 1] : [1 ligne + mots-clés associés]
- ...

Équipe / propriétaires (Organigramme, [Z]) :
- [[Personne 1]] : [rôle / domaine]
- ...
```

Note les **mots-clés** soigneusement : ils aident les sub-agents à matcher un item à un Projet ou un Domaine.

### Step 5 : Délégation à des sub-agents briefés

Pour chaque batch défini au Step 3, lance **un sub-agent** via `Agent` (en parallèle : un message avec plusieurs calls).

#### Brief complet à passer à chaque sub-agent

```
Tu reçois un batch d'items à classer pour un import dans un vault
Obsidian partagé (PDRA-entreprise, Business Brain).

CONTEXTE DU VAULT (où router)
[Colle ici le résumé du Step 4 : Cycle Stratégique, Projets avec mots-clés,
Domaines avec mots-clés, propriétaires d'équipe]

INTENTION UTILISATEUR (capturée au Step 1)
[Colle ici le résumé reformulé et validé du Step 1]

DISCOVERY DU CORPUS (style général)
[Colle ici le mapping interne du Step 3]

TON BOULOT
Pour chaque item du batch, produis un objet JSON avec :

- `source` : chemin relatif depuis la racine du vault
- `title` : titre (réécris si pas clair)
- `summary` : 1-2 phrases sur ce que l'item contient
- `created_hint` : date probable ou "unknown"
- `verdict` : un parmi
  - `KEEP_NOTE` : garder tel quel comme une note dans un Projet / Domaine / Références
  - `EXTRACT_CONTEXT` : extraire l'info utile dans Vision.md / une note
    de contexte de projet / une note de Domaine, archiver l'original
  - `SUMMARIZE` : grouper dans une note de synthèse avec d'autres items du même groupe
  - `ARCHIVE` : obsolète, discard Bruce Lee
- `verdict_reason` : 1 ligne pour justifier
- `destination` :
  - `1 Projets/[Projet]/`
  - `2 Domaines/[domaine]/`
  - `3 Ressources/Références/`
  - `4 Archive/`
  - `0 Inbox/` (seulement si vraiment impossible à router, < 5%)
- `owner` : [[Personne ou rôle]] qui possède cet item (link via wikilink vers
  l'Organigramme quand connu)
- `context_patch` : si verdict = `EXTRACT_CONTEXT`, le patch de texte à append
- `summarize_group` : si verdict = `SUMMARIZE`, un slug commun pour grouper
- `rename_suggestion` : nom de fichier clean (ou null)
- `confidence` : haut / moyen / bas
- `notes` : doublon, sensible, à merger, etc.

RÈGLES DE ROUTAGE (la membrane)
- LE VERDICT PAR DÉFAUT EST EXTRACT_CONTEXT. Le boulot principal de l'import est d'enrichir
  les notes de contexte existantes (Vision.md, une note de contexte de projet, une note de Domaine) en
  lisant l'item, PAS de classer l'item. Dans le doute, extrais et archive.
- KEEP_NOTE EST RARE. Seulement quand la note a une vraie valeur autonome ET est encore
  relevant pour un Projet ou un Domaine actif. Une note qui reste non lue est du bruit.
- PORTE DE PERTINENCE : seuls les items relevant pour un Projet ou un Domaine actif passent. Si
  le Projet/Domaine est fermé ou l'item est obsolète, ARCHIVE-le. Dans le doute
  entre garder et archiver, ARCHIVE.
- Préfère attacher à un Projet ou un Domaine existant plutôt que de créer un nouveau dossier.
- Si une note semble vouloir un nouveau Domaine : note-le dans `notes` et route vers `0 Inbox/`.
- `0 Inbox/` est une exception (< 5%).
- Quand l'info d'un item est plus utile à l'intérieur du contexte d'un projet que comme une
  note standalone, utilise `EXTRACT_CONTEXT`.
- Pour les dumps chat / Slack : `EXTRACT_CONTEXT` ou `SUMMARIZE` sont presque toujours
  meilleurs que `KEEP_NOTE`. La valeur est dans les idées, pas dans le verbatim.
- Dans un vault partagé, set toujours un `owner`. Si inconnu, laisse null et signale-le.
- NE FAIS PAS entrer la source entière. Lis-la, extrais le contexte qui sert les Projets
  et Domaines actifs, et discard ou archive le reste.

ITEMS À ANALYSER
[Liste des chemins dans le batch]

Retourne un strict tableau JSON.
```

> Si l'utilisateur a fourni une clé OpenRouter (Step 1), route ces sub-agents vers DeepSeek via OpenRouter. Annonce-le.

#### Collecte

Chaque sub-agent retourne un **rapport JSON**. Agrège tous les rapports dans une seule liste pour le Step 6.

### Step 6 : L'agent principal expose le plan complet (MODE PLAN)

À ce stade : **pas d'écritures, seulement un plan**. Format détaillé groupé par verdict puis par destination.

```
## Plan de routage : [X] items analysés (passe : [thème de la passe])

### Vue d'ensemble
- KEEP_NOTE       : [X]
- EXTRACT_CONTEXT : [Y]
- SUMMARIZE       : [Z]  (dans [N] groupes)
- ARCHIVE         : [W]

---

### KEEP_NOTE -> 1 Projets/[Projet 1] ([N])
| Source | -> Destination | Propriétaire | Confiance | Raison |
|---|---|---|---|---|

### KEEP_NOTE -> 2 Domaines/[domaine] ([N])
[pareil]

### KEEP_NOTE -> 3 Ressources/Références/ ([N])
[pareil]

### EXTRACT_CONTEXT ([N])
| Source | -> Note cible enrichie | Patch (extrait) |
|---|---|---|
| `xxx.md` | `2 Domaines/Vision & Contexte/Vision.md` | "+ On a lancé X en 2019..." |

### SUMMARIZE ([N] items dans [G] groupes)
- Groupe "chats-projet-X" : [N] items -> 1 note de synthèse dans `1 Projets/Projet X/`

### ARCHIVE ([N])
> Bruce Lee : ne sert plus.
| Source | Raison |

### -> 0 Inbox/ ([N]) : décisions humaines
| Source | Pourquoi je n'ai pas décidé |

### Alertes
- Doublons potentiels :
- Candidats nouveau Domaine :
- Gaps entre le corpus et l'intention initiale :

---

Veux-tu :
a) Exécuter tel quel (passer en MODE BUILD)
b) Ajuster certains verdicts ou routages
c) Voir le contenu d'une ou plusieurs notes avant de décider
```

### Step 7 : Ajustements

- **Option b** : l'utilisateur dit « change le verdict de X » ou « route Y vers Z ». Update la liste en mémoire.
- **Option c** : montre le contenu brut, re-propose ajusté.

Boucle jusqu'à validation (option a).

### Step 8 : Exécution (MODE BUILD)

Annonce : « Passage en MODE BUILD. J'exécute par batches de 15. »

Pour chaque batch :

1. **KEEP_NOTE** : déplace (renomme si `rename_suggestion`) vers la destination.
2. **EXTRACT_CONTEXT** : applique le `context_patch` à la note cible, appendé sous `## Import YYYY-MM-DD`. Déplace l'original vers `4 Archive/_extracted/`.
3. **SUMMARIZE** : pour chaque `summarize_group`, crée une note de synthèse (8-15 lignes denses) à la destination. Déplace les sources vers `4 Archive/_summarized-sources/`.
4. **ARCHIVE** : déplace vers `4 Archive/_import-YYYY-MM-DD/`.

Demande confirmation avant de créer un nouveau dossier de Projet ou de Domaine.

Après chaque batch :

```
Batch [N]/[Total] traité : [X] KEEP_NOTE, [Y] EXTRACT_CONTEXT, [Z] SUMMARIZE, [W] ARCHIVE.
On continue ? (oui / pause / stop)
```

Nettoie les dossiers vides dans `0 Inbox/_Import/` à la fin (garde `_originaux/` en place pour la traçabilité).

### Step 9 : Récap final + boucle de feedback

```
Import terminé pour cette passe.

Résumé :
- KEEP_NOTE       : [X]  -> Projets / Domaines / Références
- EXTRACT_CONTEXT : [Y]  -> Vision.md, projets, domaines enrichis
- SUMMARIZE       : [Z]  -> [G] notes de synthèse créées
- ARCHIVE         : [W]  -> 4 Archive/

Coût estimé : [X] tokens (~[Y]).

Avant de clôturer, deux questions :

1. Est-ce que ce qui s'est passé te convient ?
2. Qu'est-ce que j'aurais pu faire mieux ?
   (poser plus / moins de questions d'emblée, deviner les verdicts mieux,
    grouper différemment, briéfer les sub-agents mieux...)

Si tu vois un axe d'amélioration concret, je peux éditer mon propre
SKILL.md. Je te montre le diff d'abord.
```

Si le feedback est actionnable :

1. Reformule l'amélioration en 1 phrase.
2. Propose le diff précis (avant / après) du SKILL.md.
3. Applique seulement si validé.

Puis lance `/done` pour loguer la session.

Rappelle :

```
`_Import/` est vide (sauf `_originaux/`). Pour la prochaine passe,
dépose une nouvelle source et relance `/import`. Une passe = une source ou
un thème, ~100 items max. Sois intentionnel.
```

## Principes

1. **Importer le moins possible (la membrane).** L'objectif n'est pas de faire entrer des fichiers, c'est d'enrichir les notes de contexte existantes en lisant les fichiers importés, et de discard ou archive le reste. Seul ce qui est encore relevant pour les Projets et Domaines actifs passe. Dans le doute entre garder et archiver, archive. Un vault avec beaucoup de notes et peu de signal est un vault mort.
2. **Passes intentionnelles, pas un dump en vrac.** Une source ou un thème à la fois, ~100 items max. Énonce ça au début et à la fin.
3. **Alignement profond avant l'action.** Le Step 1 capture le contexte humain. Sans lui, le scan est aveugle.
4. **Quatre verdicts, pas un, et EXTRACT_CONTEXT est le défaut.** L'outcome principal est des notes de contexte enrichies. `KEEP_NOTE` est rare (vraie valeur autonome ET encore relevant). `SUMMARIZE` quand plusieurs items tiennent du contexte ensemble. `ARCHIVE` pour tout ce qui n'est plus relevant. Dans le doute, archive.
4. **Préparation automatique, pas de demandes manuelles.** MarkItDown installé par toi s'il manque. Dumps chat et Slack parsés en notes individuelles avec des règles spécifiques (Step 2.2).
5. **L'agent principal voit, puis délègue avec un brief.** Step 3 = LS et échantillonnage par toi. Step 4 = table de routage. Step 5 = sub-agents briefés avec contexte + intention + corpus + mots-clés des Projets et Domaines + propriétaires d'équipe.
6. **Mode plan puis mode build, clairement séparés.** Pas d'écritures avant validation.
7. **Parallélisation systématique.** Plus de 50 notes courtes = sub-agents en parallèle. 10/batch pour les longues conversations.
8. **La commande apprend.** Step 9 = boucle de feedback avec edit possible de ce fichier.
9. **Optimisation des coûts.** Pour les gros volumes, propose OpenRouter DeepSeek pour les sub-agents. Le routage n'a pas besoin d'un gros modèle.
10. **`0 Inbox/` est une exception.** Si un sub-agent route plus de 10% là, il lui manque du contexte : affine la table de routage et le brief.

## Destinations de routage (référence rapide)

- **1 Projets/** : initiatives transversales actives avec une deadline.
- **2 Domaines/[domaine]/** : responsabilités ongoing (un domaine que l'équipe possède en continu). Inclut `2 Domaines/Vision & Contexte/`, `2 Domaines/Pilotage/`, et les domaines spécifiques à l'entreprise ajoutés pendant l'init.
- **3 Ressources/Références/** : matériel de référence (articles, playbooks, méthodes publiques, modèles, lectures).
- **4 Archive/** : items obsolètes ou déjà traités.
- **0 Inbox/** : seulement quand vraiment impossible à router (< 5%).

## Règles

- **La membrane d'abord.** Importe le moins possible. Le boulot par défaut est d'enrichir les notes de contexte existantes (Vision, Projets, Domaines) en lisant les fichiers importés, pas de classer des fichiers. Seul ce qui est encore relevant pour les Projets et Domaines actifs passe. Dans le doute entre garder et archiver, archive.
- Ne fais pas entrer une source entière (tout le SharePoint, tout le wiki, tout le CRM). Lis-la, extrais le contexte qui sert les Projets et Domaines actifs, discard ou archive le reste.
- Lance une passe intentionnelle à la fois. ~100 items max. Relance par passe.
- Alignement profond (Step 1) avant qu'un seul fichier soit ouvert. Valide la reformulation.
- L'agent principal fait la discovery LS (Step 3) et build la table de routage (Step 4) lui-même.
- Briefe chaque sub-agent avec le contexte complet (vault, intention, corpus, mots-clés, propriétaires).
- MODE PLAN puis MODE BUILD. Pas d'écritures avant validation.
- Set toujours un `owner` pour les items routés dans le vault partagé (link via [[wikilink]] vers les personnes de l'Organigramme quand connues).
- `0 Inbox/` est une exception (< 5%). Si un sub-agent en abuse, affine le brief.
- Convertis les fichiers PDF et Office avec MarkItDown. Installe-le toi-même s'il manque (demande confirmation d'abord).
- Utilise des [[wikilinks]] vers les Projets, Domaines, et personnes de l'Organigramme dans les notes de destination.
- Si un Projet, un Domaine, ou un teammate référencé manque, signale-le et demande. N'invente jamais d'entités.
- Pas de tirets longs (utilise deux points, virgule, parenthèse, ou reformule).
- Pas de tic rhétorique « pas X mais Y ». Dis les choses directement.
- Pas d'emojis.

## Ce que tu ne fais pas

- Faire entrer des fichiers dans le vault pour le plaisir de les classer. Le boulot est d'enrichir les notes de contexte, pas de peupler des dossiers.
- Importer tout le SharePoint / tout le wiki / tout le CRM / tout le drive. Importe des fichiers spécifiques qui servent les Projets et Domaines actifs, et même alors extrais le contexte et archive l'original.
- Garder une note qui n'a ni Projet ni Domaine actif à enrichir ni valeur autonome. Archive-la à la place.
- Default vers KEEP_NOTE. Le défaut est EXTRACT_CONTEXT. KEEP_NOTE est l'exception, réservé aux notes avec une vraie valeur autonome ET encore relevant.
- Garder quelque chose « au cas où ». Dans le doute entre garder et archiver, archive. Le coût du bruit entrant est plus élevé que le coût d'une note manquante.
- Importer tout en une passe en vrac. Splitte toujours en passes thématiques intentionnelles.
- Ouvrir des fichiers avant la conversation d'alignement du Step 1.
- Laisser les sub-agents router plus de 10% vers `0 Inbox/`.
- Écrire quoi que ce soit avant la validation du MODE PLAN.
- Créer un dossier de Projet ou de Domaine silencieusement; propose et valide d'abord.
- Deviner un owner. Si le domaine ou le teammate est inconnu, demande.
- Router la note d'un teammate vers ton propre domaine par défaut; route vers le propriétaire et enregistre-le.
- Laisser les formats lourds (PDF, docx, pptx, xlsx) non convertis; lance MarkItDown d'abord.
- Classer un PDF converti depuis son nom de fichier; l'agent principal échantillonne le contenu au Step 3, les sub-agents lisent les items au Step 5.
- Traiter les dumps chat / Slack en `KEEP_NOTE` par défaut; préfère `EXTRACT_CONTEXT` ou `SUMMARIZE`.
- Skipper la boucle de feedback du Step 9 même quand la passe a semblé routine.
