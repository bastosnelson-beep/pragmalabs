---
name: new-strategic-cycle-manager
description: "Clôt le cycle stratégique en cours et ouvre le suivant, au nom du manager. Lit Vision, le cycle qui se termine, et chaque Bilan individuel du dossier du cycle. Fait le bilan du manager (point de vue global), synthétise les bilans d'équipe + le sien, puis définit le prochain cycle (nom, objectif n°1, mouvements clés, contraintes, definition of done, stratégie par état), décline une roadmap précise, déplace les intentions des membres vers le dossier du nouveau cycle, clôture l'ancien (status completed), crée le nouveau, met à jour l'index et Vision. Output : Synthèse + Bilan Manager dans le dossier du cycle qui se termine, plus le nouveau dossier de cycle avec lettre d'intention globale + roadmap. Lancé par le manager après que tous les membres ont soumis leur bilan. À utiliser quand « ouvrir le prochain cycle », « clôturer le cycle », « synthèse de cycle », « nouveau cycle stratégique »."
---

# /new-strategic-cycle-manager : Clôturer un cycle et ouvrir le suivant

Tu clôtures le cycle stratégique en cours et tu ouvres le suivant, au nom du manager (en général le team lead ou CEO). Tu lis tout le contexte pertinent, tu fais ton propre bilan de manager, tu synthétises les bilans d'équipe, puis tu définis le prochain cycle (lettre d'intention globale) et tu en déclines une roadmap. Le manager valide et ajuste avant que tu écrives les fichiers.

C'est le pendant de `/new-strategic-cycle-team-member` : chaque membre écrit son bilan individuel en fin de cycle; le manager lance `/new-strategic-cycle-manager` pour reprendre ces bilans, faire le sien, synthétiser, et ouvrir le prochain cycle.

## Structure du dossier du cycle

```
Cycles Stratégiques/
├── Cycles Stratégiques.md              <- index
├── [N] - [nom du cycle]/
│   ├── Cycle Stratégique - [N] [nom].md  <- intention globale (lettre d'intention)
│   ├── Roadmap - [N] [nom].md            <- roadmap déclinée
│   ├── Intention - [membre 1].md         <- intention individuelle pour ce cycle
│   ├── Bilan - [membre 1].md             <- bilan individuel en fin de cycle
│   ├── Bilan - [manager].md              <- bilan du manager
│   └── Synthèse - Cycle [N] [nom].md     <- synthèse du manager (fin de cycle)
```

## Ce que tu lis (les inputs)

1. **Vision** (`2 Domaines/Vision & Contexte/Vision.md`) : direction de l'entreprise, North Star, voix de marque. Le prochain cycle doit y mener.
2. **Cycle qui se termine** (détecte, ne hardcode jamais) : le dossier du cycle actif. Lis l'intention globale (`Cycle Stratégique - [N] [nom].md`), la roadmap (`Roadmap - [N] [nom].md`), et chaque `Intention - [membre].md`.
3. **Chaque Bilan individuel du cycle** : les fichiers `Bilan - [membre de l'équipe].md` dans le dossier du cycle. C'est la matière première.
4. **Le Moteur de Valeur** (`2 Domaines/Vision & Contexte/Moteur de Valeur.md`) : pour vérifier que le prochain cycle adresse les goulots et avance la boucle de valeur.
5. **L'Organigramme** (`2 Domaines/Vision & Contexte/Organigramme/`) : qui fait quoi, pour attribuer les mouvements clés aux bonnes personnes.
6. **Projets et Domaines actifs** : skimme les notes de contexte de `1 Projets/` et des `2 Domaines/[domaines]/` pour catcher ce qui bouge.
7. **Le log des décisions stratégiques** (`2 Domaines/Vision & Contexte/Logs/`) : les décisions prises pendant le cycle.

## Output

Dans le dossier du cycle qui se termine (`[N] - [nom]/`) :
- `Bilan - [manager].md` : le bilan du manager (point de vue global).
- `Synthèse - Cycle [N] [nom].md` : la synthèse (bilan manager + agrégation des bilans d'équipe + recommandations pour le prochain cycle).

Dans le dossier du nouveau cycle (`[N+1] - [nouveau nom]/`) :
- `Cycle Stratégique - [N+1] [nouveau nom].md` : la lettre d'intention globale.
- `Roadmap - [N+1] [nouveau nom].md` : la roadmap déclinée de la lettre d'intention.
- `Intention - [membre].md` : déplacées depuis les bilans du cycle précédent (la section intention de chaque membre).

Plus trois mises à jour : l'ancien cycle passe `status: completed`, l'index `Cycles Stratégiques.md` est mis à jour, et le frontmatter `cycle_strategique` de `Vision.md` pointe vers le nouveau cycle.

## Process

### Step 1 : Qui prépare, et quel cycle se termine

Demande :

> « Qui prépare cette clôture de cycle ? (prénom + rôle) »

Mappe le nom vers l'Organigramme. Cette personne est le `prepared_by` et est le manager pour ce passage.

Détecte le cycle qui se termine :

```bash
CYCLE_DIR=$(ls -d "2 Domaines/Vision & Contexte/Cycles Stratégiques/"*/ 2>/dev/null | sort -V | tail -1)
CYCLE_NAME=$(basename "$CYCLE_DIR")
CYCLE_NUM=$(echo "$CYCLE_NAME" | grep -oE '^[0-9]+')
NEXT_NUM=$((CYCLE_NUM + 1))
echo "Cycle qui se termine : $CYCLE_NAME | Prochain numéro : $NEXT_NUM"
ls "$CYCLE_DIR" 2>/dev/null
```

Si le dossier ne contient aucun `Bilan - *.md`, dis-le clairement :

> « Aucun bilan individuel trouvé pour le cycle "[nom]". La synthèse sera basée sur le cycle et Vision seulement. Je recommande à l'équipe de lancer /new-strategic-cycle-team-member avant la clôture. »

Procède quand même si le manager le veut, en mode bilan manager seul.

### Step 2 : Lire le contexte de l'entreprise

Lis, dans l'ordre :

- `2 Domaines/Vision & Contexte/Vision.md` : identité, North Star, vision, voix de marque.
- Le cycle qui se termine : lis `Cycle Stratégique - [N] [nom].md` (objectif n°1, mouvements clés, contraintes, definition of done) et `Roadmap - [N] [nom].md` (les jalons). C'est ce qu'on évalue.
- `2 Domaines/Vision & Contexte/Moteur de Valeur.md` : la boucle acquisition -> ventes -> delivery -> rétention, et les goulots. Le prochain cycle devrait avancer la boucle ou adresser un goulot.
- `2 Domaines/Vision & Contexte/Organigramme/` : liste l'équipe, note qui possède quelle Domaine/Projet.
- `2 Domaines/Vision & Contexte/Logs/` : les décisions stratégiques du cycle.

Si Vision ou le cycle manque, note-le et procède avec ce qui existe. N'invente jamais.

### Step 3 : Lire chaque bilan individuel du cycle

```bash
ls "$CYCLE_DIR/Bilan - "*.md 2>/dev/null
```

Lis **chaque** fichier `Bilan - [membre de l'équipe].md`. Pour chacun, extrais dans un résumé structuré par membre :

- **Conclusion globale** : le sentiment du membre sur le cycle, de son périmètre.
- **Leçons apprises** : ce qu'il en retire.
- **Ce qui a marché** : les réussites et les fiertés, de son périmètre.
- **Constat factuel sur les mouvements clés** : atteint / partiellement / non atteint, par mouvement (de son périmètre).
- **À améliorer** : les axes d'amélioration du membre.
- **Intention pour le prochain cycle** : objectif n°1 proposé, mouvements clés proposés, besoins (section à déplacer vers le nouveau cycle).

Si le bilan d'un membre manque, signale-le. N'invente pas son cycle. Demande au manager s'il faut ping le membre ou procéder sans.

### Step 4 : Le bilan du manager (point de vue global)

Maintenant, fais ton propre bilan de manager. Ce n'est pas la synthèse (qui agrège l'équipe), c'est ton point de vue à toi sur le cycle, vu d'en haut. Pose ces questions au manager, **une par une**, attends la réponse entre chacune, reformule ce que tu as compris avant de passer.

Le manager peut répondre en écrit ou à la voix (dictation). Travaille dans la langue de travail de l'équipe.

Annonce :

> « Ton bilan de manager sur le cycle qui se termine, une question à la fois. Point de vue global : ce que TU en retiens, du haut. »

**Question 1 : Conclusion globale du cycle**

> « En quelques phrases, comment résumes-tu ce cycle, du point de vue du manager ? »

**Question 2 : Leçons apprises**

> « Quelles leçons as-tu apprises pendant ce cycle, comme manager ? »

**Question 3 : Ce qui a marché**

> « Qu'est-ce qui a marché dans ce cycle ? De quoi es-tu fier, pour l'entreprise ? »

**Question 4 : Constat factuel sur l'objectif n°1 et les mouvements clés**

> « Constat factuel sur l'objectif n°1 et chaque mouvement clé du cycle. Pour chacun : atteint, partiellement, ou non atteint ? »

Pré-remplis depuis l'intention du cycle (Step 2) l'objectif n°1 et tous les mouvements clés, et valide. Contrairement au bilan employé (qui filtre à un périmètre), ici tu évalues le cycle entier. C'est des faits, pas du récit.

**Question 5 : Ce que tu aimerais améliorer pour le prochain cycle**

> « Qu'est-ce que tu aimerais améliorer pour le prochain cycle, comme manager ? »

### Step 5 : Synthétiser le cycle

Depuis les bilans individuels + ton bilan de manager + le cycle qui se termine + Vision, construis une synthèse :

**5.1 Par membre** : agrège le bilan de chaque membre (conclusion, leçons, constat sur les mouvements clés, intention pour le prochain cycle, besoins).

**5.2 Ce qui a marché** : collecte les réussites et fiertés de l'équipe + du manager. Croise avec les mouvements clés : lesquels ont avancé.

**5.3 Ce qui n'a pas marché / à améliorer** : collecte les axes d'amélioration de l'équipe + du manager. Croise avec les mouvements clés : lesquels n'ont pas avancé, et pourquoi.

**5.4 État de l'objectif n°1** : où en est-on sur l'objectif n°1 du cycle ? Atteint, partiellement, non atteint. Ce qui reste à faire.

**5.5 Intentions pour le prochain cycle** : collecte les objectifs n°1 proposés et les mouvements clés proposés par chaque membre + le manager. Croise avec Vision et le Moteur de Valeur : lesquels mènent au North Star et adressent les goulots.

**5.6 Trous et décalages** : tout ce où l'intention d'un membre ne se connecte pas à Vision, tout ce qui a besoin d'une décision mais que personne n'a demandée, tout décalage entre les bilans.

Présente la synthèse au manager sous une forme compacte et confirme qu'elle matche sa lecture du cycle avant que tu définisses le prochain.

### Step 6 : Définir le prochain cycle (lettre d'intention globale)

Depuis la synthèse + Vision + le Moteur de Valeur, propose le prochain cycle. Pose les questions **une par une**, reformule, valide.

**6.1 Nommer le cycle**

> « Un nom court et évocateur pour le prochain cycle ? »

Capture le nom. Il devient le nom du dossier et de l'index.

**6.2 Objectif n°1**

> « C'est quoi la chose la plus importante pour ce cycle ? Si on n'accomplit que ça, le cycle est une réussite. »

Construis depuis la synthèse (les intentions de l'équipe + du manager) et Vision. Capture l'objectif n°1. Une seule chose dominante.

**6.3 Mouvements clés**

> « Quels sont les 2-3 mouvements concrets qui nous y amènent ? »

Capture les mouvements clés. Attribue chaque mouvement à un propriétaire (recoupe l'Organigramme). Croise avec les intentions proposées par les membres.

**6.4 Contraintes**

> « Quelles sont les contraintes ? Temps disponible, budget, capacité de l'équipe, non-négociables. »

**6.5 Definition of done**

> « Qu'est-ce qui est vrai quand ce cycle se termine ? »

**6.6 Stratégie par état**

> « Que fait-on quand on est surchargé (firefighting) ? concentré ? en flow ? »

Présente le prochain cycle complet au manager :

```
Voici le prochain cycle proposé :

Cycle [N+1] : "[nom]"

Objectif n°1 : [objectif]
Mouvements clés :
- [Mouvement 1] -> [[propriétaire]]
- [Mouvement 2] -> [[propriétaire]]
- [Mouvement 3] -> [[propriétaire]]
Contraintes : [contraintes]
Definition of done : [DoD]
Stratégie par état : [surchargé / concentré / flow]

Veux-tu :
a) Générer la synthèse, la roadmap, et ouvrir le prochain cycle tels quels
b) Ajuster le nom, l'objectif, les mouvements, les contraintes, ou la DoD
c) Revoir un bilan spécifique, le cycle qui se termine, ou Vision avant de décider
```

### Step 7 : Décliner la roadmap

Une fois le cycle validé (option a), propose une roadmap déclinée de la lettre d'intention. Découpe l'objectif n°1 et les mouvements clés en jalons concrets sur la durée du cycle.

Demande au manager :

> « Combien de temps dure ce cycle (en semaines) ? »

Puis propose 3-5 jalons répartis sur la durée, chacun avec :
- Un nom
- Une semaine / date estimée
- Un critère de livraison concret
- Un propriétaire (recoupe l'Organigramme)
- Les mouvements clés qu'il avance
- Les dépendances

Présente la roadmap au manager et valide :

```
Roadmap proposée pour "[nom]" ([N] semaines) :

Jalon 1 : [nom] (semaine [X])
- Livré quand : [critère]
- Propriétaire : [[personne]]
- Avance : [mouvements clés]

Jalon 2 : ...

Valider la roadmap ? (oui / ajuster)
```

Ajuste jusqu'à validation.

### Step 8 : Ajustements du cycle

- **Option b** (Step 6) : le manager change le nom, l'objectif, l'attribution d'un mouvement, les contraintes, ou la DoD. Update en mémoire, re-présente, puis retour à la roadmap (Step 7).
- **Option c** (Step 6) : montre la source (le bilan, le cycle, Vision, le Moteur de Valeur) et re-propose.

Boucle jusqu'à validation complète (cycle + roadmap).

### Step 9 : Écrire (clôturer l'ancien, ouvrir le nouveau)

Une fois le cycle et la roadmap validés, écris tous les changements :

**9.1 Le bilan du manager**

Crée `Bilan - [manager].md` dans le dossier du cycle qui se termine, depuis le modèle `3 Ressources/Capacités IA/Templates/Bilan Cycle Stratégique`. Remplis avec les réponses du Step 4 (sans la section intention pour le prochain cycle, qui n'est pertinente que pour les membres). Set le frontmatter : `strategic_cycle`, `team_member: "[manager]"`, `role`, `status: active`.

**9.2 La synthèse**

Crée `Synthèse - Cycle [N] [nom].md` dans le dossier du cycle qui se termine, depuis le modèle `3 Ressources/Capacités IA/Templates/Synthèse Cycle Stratégique`. Remplis chaque section : bilan du manager (Step 4), synthèse par membre (Step 5.1), synthèse globale (5.2-5.4), recommandations pour le prochain cycle (le cycle validé au Step 6). Set le frontmatter : `strategic_cycle`, `prepared_by`, `based_on_reviews` (liste des bilans lus), `next_cycle` (wikilink vers le nouveau cycle), `status: active`.

**9.3 Clôturer l'ancien cycle**

Dans `Cycle Stratégique - [N] [nom].md` (l'intention globale du cycle qui se termine) :
- Change `status: active` en `status: completed`.
- Set `end: [date du jour]`.
- Ajoute en bas un lien vers la synthèse :

```markdown

## Synthèse de clôture

-> [[Synthèse - Cycle [N] [nom]]]
```

**9.4 Créer le nouveau dossier de cycle**

```bash
NEXT_DIR="2 Domaines/Vision & Contexte/Cycles Stratégiques/$NEXT_NUM - [nouveau nom]"
mkdir -p "$NEXT_DIR"
```

**9.5 La lettre d'intention globale**

Crée `Cycle Stratégique - [N+1] [nouveau nom].md` dans le nouveau dossier, depuis le modèle `3 Ressources/Capacités IA/Templates/Cycle Stratégique`. Remplis avec le cycle validé au Step 6 : objectif n°1, mouvements clés (avec propriétaires en wikilinks), contraintes, definition of done, stratégie par état. Set `status: active`, `start: [date du jour]`, `end_estimated: [à définir]`.

**9.6 La roadmap**

Crée `Roadmap - [N+1] [nouveau nom].md` dans le nouveau dossier, depuis le modèle `3 Ressources/Capacités IA/Templates/Roadmap Cycle Stratégique`. Remplis avec les jalons validés au Step 7. Set le frontmatter `strategic_cycle` (wikilink vers le nouveau cycle), `status: active`.

**9.7 Déplacer les intentions des membres**

Pour chaque bilan de membre lu au Step 3, extrais la section « Mon intention pour le prochain cycle » et crée `Intention - [membre].md` dans le nouveau dossier, depuis le modèle `3 Ressources/Capacités IA/Templates/Intention Cycle Stratégique`. Remplis avec l'objectif n°1, les mouvements clés proposés, et les besoins du membre. Set le frontmatter : `strategic_cycle` (wikilink vers le nouveau cycle), `team_member`, `role`, `status: active`.

Ces intentions sont les propositions des membres, capturées pendant leur bilan. Le manager peut les ajuster avec chaque membre au démarrage du cycle.

**9.8 Mettre à jour l'index**

Update `2 Domaines/Vision & Contexte/Cycles Stratégiques/Cycles Stratégiques.md` :
- Dans le tableau des cycles : marque l'ancien `completed` et ajoute la ligne du nouveau cycle.
- Dans la section « Cycle actuel » : remplace le lien par `-> [[Cycle Stratégique - [N+1] [nouveau nom]]]`.

**9.9 Mettre à jour Vision**

Dans `2 Domaines/Vision & Contexte/Vision.md`, update le frontmatter `cycle_strategique` avec le wikilink vers le nouveau cycle.

### Step 10 : Mettre à jour les contextes

Avant de clôturer, fais le lien entre ce qui s'est dit dans les bilans et les notes de contexte du vault. Pour chaque projet, domaine, ou le cycle stratégique lui-même que les bilans ont révélé comme nécessitant une mise à jour :

1. **Lis la note de contexte** concernée.
2. **Demande-toi : est-ce à jour ?** Ce que les bilans ont révélé contredit-il, complète-il, ou invalide-il une information ?
3. **Si oui, propose une mise à jour** au manager. Exemples :
   - « Le bilan de [membre] dit que le projet X est bloqué, mais la note de contexte ne le mentionne pas. Je l'ajoute ? »
   - « Plusieurs bilans mentionnent un changement de priorité sur le domaine Y. La note de contexte reflète encore l'ancienne priorité. Je la mets à jour ? »
4. **Sur validation du manager, applique la modification** (édition chirurgicale).

Si le manager a fait des modifications pendant la définition du prochain cycle qui doivent se refléter sur le cycle stratégique (par exemple, un mouvement clé qui a été reformulé, une contrainte qui a changé), vérifie que la lettre d'intention globale et la roadmap les reflètent bien. C'est déjà le cas si tu as écrit depuis le Step 6/7 validé, mais confirme-le au manager.

### Step 11 : Confirmation

```
=== Cycle clôturé, prochain cycle ouvert ===

Cycle clôturé : [[Cycle Stratégique - [N] [nom]]] (status: completed)
Prochain cycle : [[Cycle Stratégique - [N+1] [nouveau nom]]] (status: active)

Fichiers créés dans le dossier du cycle qui se termine ([N] - [nom]/) :
- Bilan - [manager].md
- Synthèse - Cycle [N] [nom].md

Fichiers créés dans le dossier du nouveau cycle ([N+1] - [nouveau nom]/) :
- Cycle Stratégique - [N+1] [nouveau nom].md (lettre d'intention globale)
- Roadmap - [N+1] [nouveau nom].md
- Intention - [membre 1].md (déplacée depuis le bilan)
- Intention - [membre 2].md

Fichiers modifiés :
- Cycle Stratégique - [N] [nom].md (status: completed, end, lien synthèse)
- Cycles Stratégiques.md (index)
- Vision.md (cycle_strategique)

Contextes mis à jour : [liste des notes modifiées, ou "aucun"]
Bilans individuels lus : [N] sur [M] membres
[Si des bilans manquaient] Rappel : [liste] n'a pas soumis de bilan.
Objectif n°1 du nouveau cycle : [résumé en une ligne]

Prochaines étapes :
- L'équipe s'aligne sur le nouveau cycle au prochain sync hebdo (/prepare-weekly le lira)
- Chaque membre peut ajuster son Intention - [membre].md au démarrage
- Les revues hebdo (/weekly-review-team-member) s'alignent au nouveau cycle
- Les décisions stratégiques du nouveau cycle vont dans 2 Domaines/Vision & Contexte/Logs/
```

---

## Règles

- **Lis tout avant de proposer.** Vision, le cycle qui se termine (intention + roadmap), le Moteur de Valeur, l'Organigramme, et chaque bilan individuel. La synthèse est un passage de lecture, pas un plan top-down.
- **Bilan d'abord, synthèse ensuite, cycle ensuite, roadmap ensuite.** Fais ton bilan (Step 4) et la synthèse (Step 5) avant de définir le prochain cycle (Step 6) et la roadmap (Step 7).
- **Suggestions, pas décisions.** La synthèse, le prochain cycle, et la roadmap sont des propositions. Le manager décide. Offre toujours l'option ajuster.
- **Le prochain cycle mène à Vision.** L'objectif n°1 doit connecter au North Star et à la vision 5 ans. Les mouvements clés devraient avancer le Moteur de Valeur ou adresser un goulot. Signale tout ce qui ne le fait pas.
- **Le bilan du manager est un point de vue global**, pas une agrégation. Les bilans employés sont scopés à un périmètre; le bilan manager regarde le cycle entier.
- **Un dossier par cycle.** Chaque cycle a son dossier `[N] - [nom]/` qui contient l'intention globale, la roadmap, les intentions individuelles, les bilans, et la synthèse.
- **Un seul cycle actif à la fois.** L'ancien passe `completed`, le nouveau devient `active`. L'index et Vision sont mis à jour.
- **La roadmap se décline de la lettre d'intention.** Pas de roadmap sans intention validée d'abord.
- **Les intentions des membres sont déplacées** depuis leur bilan (section intention) vers le dossier du nouveau cycle en fichiers `Intention - [membre].md` distincts.
- **Mets à jour les contextes.** Si les bilans révèlent qu'une note de projet, de domaine, ou le cycle lui-même n'est plus à jour, propose la modification et applique-la sur validation.
- **Mappe les noms vers l'Organigramme** avant d'écrire. N'invente jamais un teammate.
- **Signale les bilans manquants.** Si un membre n'a pas soumis, dis-le. N'invente pas son cycle.
- **Utilise des [[wikilinks]]** vers les Projets, Domaines, le Cycle Stratégique, et les personnes de l'Organigramme.
- **Pas de tirets longs** (utilise deux points, virgule, parenthèse, ou reformule).
- **Pas de tic rhétorique « pas X mais Y ».** Dis les choses directement.
- **Pas d'emojis.**

## Ce que tu ne fais pas

- Définir le prochain cycle avant d'avoir lu chaque bilan et fait le tien. Synthèse d'abord.
- Décliner la roadmap avant que le cycle (lettre d'intention) soit validé. Intention d'abord, roadmap ensuite.
- Inventer le cycle d'un membre si son bilan manque. Signale-le.
- Décider le prochain cycle ou la roadmap unilatéralement. Propose, laisse le manager ajuster.
- Mettre la synthèse ou les bilans ailleurs que dans le dossier du cycle `[N] - [nom]/`.
- Hardcoder le nom du Cycle Stratégique; détecte-le.
- Oublier de clôturer l'ancien cycle (`status: completed`, `end`, lien synthèse) ou de mettre à jour l'index et `Vision.md`.
- Oublier de déplacer les intentions des membres vers le dossier du nouveau cycle.
- Skipper la lecture de Vision et du Moteur de Valeur même quand le cycle semble évident.
- Skipper l'étape de mise à jour des contextes (Step 10). C'est ce qui garde le vault vivant.
- Confondre ce skill avec `/new-strategic-cycle-team-member`. Ce skill clôt le cycle et ouvre le suivant (lit + synthétise + définit + roadmap + écrit); l'autre est le bilan individuel que chaque membre écrit.
- Proposer un prochain cycle qui ne se connecte pas à Vision sans signaler l'écart.
