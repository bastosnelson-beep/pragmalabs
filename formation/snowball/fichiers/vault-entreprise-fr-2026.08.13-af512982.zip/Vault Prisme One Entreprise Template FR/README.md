# Vault Prisme One Entreprise Template

Le template de second cerveau d'entreprise pour les clients Prisme One. Un vault Obsidian partagé (le « Business Brain ») pour une équipe d'entreprise, avec les skills et la structure pour initialiser le contexte complet de l'entreprise et faire tourner le rythme opérationnel.

C'est le miroir entreprise du `Vault Prisme One Template` personnel. Là où le vault personnel initialise le contexte d'une personne (qui je suis, vision, phases de vie, projets perso), celui-ci initialise le contexte d'une entreprise (identité, North Star, organigramme, moteur de valeur, domaines, projets, outils, cycle stratégique).

Les dossiers PDRA sont à plat à la racine du vault (pas de sous-dossier wrapper). La racine du vault est la racine du workspace.

## Ce qu'il y a dans la boîte

```
Vault Prisme One Entreprise Template/        # racine du vault = racine du workspace
├── AGENTS.md                       # Identité + arbre du workspace + ontologie (PDRA) + règles d'interaction
├── CLAUDE.md                       # @AGENTS.md (rempli avec le triage outils/où-trouver-quoi pendant l'init)
├── opencode.json                   # Chemin des skills -> 3 Ressources/Capacités IA/skills
├── LICENSE
├── README.md
├── .obsidian/                      # Config (daily -> Pilotage, notes hebdo calendar -> Pilotage/Logs de Session, plugin calendar)
├── 0 Inbox/                       # Capture rapide; _Import/ pour les docs à classer
├── 1 Projets/                    # Initiatives transversales (deadline, archiver quand terminé)
├── 2 Domaines/                       # Responsabilités ongoing = le contexte central
│   ├── Vision & Contexte/          # Couche stratégique ALWAYS-ON (transversale, pré-créée)
│   │   ├── Vision.md
│   │   ├── Moteur de Valeur.md
│   │   ├── Cycles Stratégiques/      # Index + un fichier par cycle
│   │   │   ├── Cycles Stratégiques.md (index)
│   │   │   └── Cycle Stratégique - 1 Initial.md
│   │   ├── Organigramme/          # 1 fichier par membre de l'équipe
│   │   └── Logs/                  # Log des décisions stratégiques
│   ├── Pilotage/                       # Rythme opérationnel (transversal, pré-créé)
│   │   ├── Revues Hebdo/      # Dossiers par semaine (2026-W28/), un fichier par membre
│   │   └── Logs de Session/         # Logs de session /done + notes hebdo calendar
│   └── [domaines business]/        # Ajoutés par entreprise pendant l'init (Sales, Operations, Finance...)
├── 3 Ressources/
│   ├── Capacités IA/
│   │   ├── skills/                # 18 skills exécutables (un dossier chacun)
│   │   └── Templates/             # 12 modèles de notes
│   ├── Process/                  # Process Maps par employé + Fiches de Process (depuis /map-process)
│   ├── Infrastructure/            # Outils, credentials, où trouver quoi
│   │   └── Services API, CLI et MCP disponibles/  # Catalogue de services partagé (depuis /connect-tool)
│   └── Références/                # Matériel de référence (brut)
└── 4 Archive/
```

## Les deux domaines transversaux (pré-créés)

Chaque vault d'entreprise est livré avec ces deux domaines déjà en place. Les domaines business (Sales, Operations, etc.) sont ajoutés pendant `/initialisation-entreprise`, car chaque entreprise est différente.

- **Vision & Contexte** : la couche stratégique always-on. Qui nous sommes (Vision), comment nous créons de la valeur (Moteur de Valeur), qui fait quoi (Organigramme), sur quoi nous nous concentrons maintenant (Cycle Stratégique).
- **Pilotage** : le rythme opérationnel. Revues hebdo, standups, logs de session.

## Skills (18)

| Skill | Objectif |
|-------|----------|
| `/initialisation-entreprise` | Le gros. Initialisation guidée du contexte complet de l'entreprise (identité, vision, organigramme, moteur de valeur, domaines, projets, outils, cycle stratégique). Génère la structure, les notes, les canvas, et le triage CLAUDE.md. |
| `/map-process` | Cartographie chaque tâche d'un membre de l'équipe (quotidien/hebdo/mensuel/sur-déclencheur), avec le temps, la méthode par étape, et les outils. Produit une note de Process Map par employé + une fiche de Process par process, séquentiel, un à la fois. Objectif : l'IA prend le relais sur certaines tâches, ou le membre divise son temps d'exécution par 2 à 10x. |
| `/create-skill` | Capture un process d'équipe comme un skill exécutable (SOP -> skill). Inclut propriétaire, handoff, outils. |
| `/create-value-engine` | Construit le Master Value Board (représentation visuelle du moteur de valeur, côté client, de la découverte au referral). 3 niveaux : Domaine > Activité > Process. Output : canvas + note dans Vision & Contexte. |
| `/meeting-review` | Résume une réunion, extrait les décisions et les action items avec leurs propriétaires, les route vers le bon Projet/Domaine, met à jour la revue hebdo, signale les décisions stratégiques. |
| `/weekly-review-team-member` | Revue hebdo individuelle pour un membre de l'équipe (vendredi) : ce à quoi j'étais engagé, ce que j'ai fait, les blockers, le focus de la semaine prochaine, les points à remonter au sync. Output : 2 Domaines/Pilotage/Revues Hebdo/2026-W28/Revue Hebdo - [membre de l'équipe].md. |
| `/prepare-weekly` | Prépare le sync hebdo du lundi pour la semaine à venir (lead, dimanche soir ou lundi matin) : lit Vision, le Cycle Stratégique actif, les engagements passés, et chaque revue individuelle de la semaine écoulée. Synthétise, puis propose la structure du sync (agenda + sujets) plus des suggestions pour les rushes et les gros sujets de la semaine. Output : 2 Domaines/Pilotage/Revues Hebdo/2026-W28/Sync Hebdo - 2026-W28.md. |
| `/new-strategic-cycle-team-member` | Bilan individuel de fin de cycle pour un membre (scoped à son périmètre) : conclusion, leçons, ce qui a marché, assessment des key moves, à améliorer, intentions pour le prochain. Output : Bilan Cycle - [membre].md dans le dossier du cycle. |
| `/new-strategic-cycle-manager` | Clôture le cycle courant et ouvre le suivant (côté manager) : lit tous les bilans individuels + fait le sien, synthétise, définit le prochain cycle (objectif #1, key moves avec owners, contraintes). |
| `/done` | Clôt une session de travail chirurgicalement : diff d'état, micro-patches, log minimal, handoffs routés vers leurs propriétaires. |
| `/clean-context` | Nettoie le contexte d'un Domaine ou d'un Projet : analyse toutes les notes d'un dossier sur 5 axes (contradictions, répétitions, obsolètes, à ajouter, mal rangées), propose un plan concret. Lecture seule jusqu'à validation. À utiliser par le responsable du dossier pour maintenir son contexte à jour. |
| `/inbox-processor` | Trie les notes déposées dans 0 Inbox/ (et le passage _Import/) vers la bonne destination, avec propriétaire. |
| `/import` | Importe la connaissance de l'entreprise (dumps SharePoint/Drive, exports wiki, exports CRM, anciens dossiers) par petites passes intentionnelles. Le moteur derrière le passage _Import/. |
| `/thinking-partner` | Partenaire de pensée stratégique : stress-teste une décision business contre la Vision, le North Star, et le Cycle Stratégique actif. |
| `/research-assistant` | Recherche un sujet (marché, concurrent, fournisseur, outil) avec Firecrawl, produit une note de recherche citée, route les implications. |
| `/de-ai-ify` | Retire le jargon IA et restaure la voix de marque + la voix de l'auteur (référence Vision.md et les profils de voix de l'Organigramme). |
| `/new-automation` | Conçoit et documente une nouvelle automation (n8n / MCP / cron / script) avec propriétaire, mainteneur, et liens vers le process cartographié. |
| `/connect-tool` | Recherche la meilleure façon de connecter un outil (MCP / CLI / clé API + skill / endpoint HTTP), demande si c'est user-scoped ou company-scoped, installe dans les bons configs (OpenCode, Claude Code, Claude Desktop, pi), et le documente dans le catalogue de services partagé si company-scoped. |

## Modèles (12)

`Domaine`, `Projet`, `Revue Hebdo`, `Sync Hebdo`, `Note de Standup`, `Cycle Stratégique`, `Bilan Cycle Stratégique`, `Synthèse Cycle Stratégique`, `Réflexion`, `Notes de Réunion`, `Personne`, `Vision`.

## Process de delivery de bout en bout

Pour un engagement Prisme One (ex la delivery FiveKeys), le process est :

**1. Déployer (devs)**
- Copier ce template sur le serveur souverain du client.
- Renommer `Vault Prisme One Entreprise Template` avec le nom du client.
- Configurer Obsidian Sync + syncThing pour l'équipe. Distribuer les accès.

**2. Préparer (Eliott -> lead client)**
- Envoyer ce README + la référence du skill `/initialisation-entreprise` au lead client (le CEO ou team lead qui va initier).
- Lui demander de rassembler et déposer dans `0 Inbox/_Import/` : pitch deck, brochure, URL du site, organigramme, liste des employés avec rôles, offres/pricing, propositions récentes, SOPs/wiki existants, liste d'outils, roadmap, docs d'immatriculation.

**3. Initialiser (lead client, avec Eliott à côté)**
- Le lead ouvre le vault dans Obsidian + OpenCode Desktop sur la racine du vault.
- Lance `/initialisation-entreprise`. L'IA guide la décharge (2-4h) : identité, vision, organigramme, moteur de valeur, domaines, projets, outils, cycle stratégique.
- L'IA génère la structure, les notes, les deux canvas (Organigramme, Moteur de Valeur), et le triage CLAUDE.md.
- Le lead relit et corrige tout ce qui ne colle pas à la réalité.

**4. Enrichir (async, lead)**
- Le lead complète les trous restants directement dans le vault.
- Déposer les docs d'entreprise restantes dans `0 Inbox/_Import/` et lancer `/import` pour les classer.
- Eliott relit le AGENTS.md + Vision.md + CLAUDE.md pour la cohérence.

**5. Embarquer l'équipe (on-site, Jour 2)**
- Chaque membre de l'équipe reçoit l'accès, ouvre le vault, et cartographie ses propres process via `/map-process` puis `/create-skill` (au bon format, ensemble).
- Le Business Brain se connecte aux cerveaux personnels (si l'engagement inclut les vaults personnels).

**6. Faire tourner (ongoing)**
- `/weekly-review-team-member` à la fin de chaque semaine (chaque membre, individuellement).
- `/prepare-weekly` avant le sync du lundi (le lead : synthétise toutes les revues dans le plan hebdo).
- `/done` à la fin de chaque session de travail (n'importe quel membre).
- `/clean-context` quand le responsable d'un dossier veut le nettoyer (contradictions, doublons, obsolètes).
- `/meeting-review` après chaque réunion.
- `/inbox-processor` quand l'inbox déborde.
- Nouveau Cycle Stratégique quand le focus change.

## Comment initialiser (quick start)

1. Ouvre le dossier racine du vault (celui qui contient `AGENTS.md` et les dossiers PDRA) dans Obsidian.
2. Ouvre OpenCode Desktop sur le même dossier racine du vault.
3. Lance `/initialisation-entreprise`.
4. Suis la conversation guidée. Dépose des docs à n'importe quelle étape. Prévois 2-4 heures.

## Notes pour le lead de delivery

- Les domaines business NE sont PAS pré-créés. `/initialisation-entreprise` les crée à partir de la décharge (Step 7).
- Les deux canvas (Organigramme, Moteur de Valeur) sont générés par le skill d'init au format JSON Canvas (spec sur jsoncanvas.org).
- Le skill d'init écrase `CLAUDE.md` (l'alias `@AGENTS.md`) avec le triage complet : table des outils, où trouver quoi, règles de validation. Ça correspond à la vraie delivery client (le triage CLAUDE.md est le point d'entrée opérationnel).
- La langue de travail est choisie à l'init (Step 2). Français par défaut. Toutes les notes du vault et les outputs des skills tournent dans cette langue.
- Les secrets ne sont jamais stockés en clair dans le vault partagé : les credentials sont référencés (où ils vivent), jamais collés.
