---
name: cartographier-icp
description: "Part d'un produit et d'un verbatim client pour produire des fiches ICP précises, chacune positionnée sur l'échelle des 5 niveaux de conscience, avec ses douleurs en mots exacts, son rêve en image concrète et son shift moment. Le tout premier skill du socle."
---

# Cartographier l'ICP et son niveau de conscience

> **Objectif :** partir d'un produit et d'un verbatim client, produire une ou plusieurs fiches ICP precises, chacune positionnee sur l'echelle des 5 niveaux de conscience, avec ses douleurs en mots exacts, son reve en image concrete et son shift moment.

C'est le tout premier skill du socle marketing. Tant que cette fiche n'existe pas, tu ne peux ni cartographier les croyances, ni ecrire une pub, ni rediger une page de vente : une croyance, un contenu, une pub se mappent toujours sur UNE cible precise a UN niveau de conscience. Ce skill s'arrete a la fiche ICP validee. Si l'offre n'est pas claire, clarifie-la avant de continuer (voir le cours Offre). Une fois la fiche ICP validee, passe a l'etape suivante : cartographier les croyances de cette cible (voir le cours Bases marketing, etape 3).

Ce skill est **dialogique** : tu poses les questions une a une, tu creuses les reponses, tu ne remplis jamais les trous par des suppositions. Si une info manque, tu la marques `[A VALIDER]`.

---

## Principe directeur

La plupart des marketings echouent parce qu'ils parlent a "tout le monde", donc a personne. Un meme produit se vend avec des messages radicalement differents selon le niveau de conscience de la cible.

Deux regles non negociables :

1. **Cible par comportement, pas par metier.** "Les CEO" = un million de personnes, c'est un sac sans fond. Vise "le CEO noye par l'operationnel qui utilise deja l'IA mais ne sait pas creer des systemes". Le metier ne dit rien ; le comportement et le moment de vie disent tout.
2. **Pense probleme-first, jamais solution-first.** L'histoire du vendeur de bouteilles d'eau (Atomic Offers) le resume : la meme bouteille se vend 50 centimes a Montpellier en hiver (personne n'en veut), 2 euros en ete, et 10 euros au milieu du Sahara sur une route touristique. Ce n'est pas le produit qui change, c'est la foule assoiffee. Si tu ne sais pas ou et quand ta cible ressent la douleur, tu ne vendras jamais.

---

## Étape 1 : Inventorier les sources de verite

Avant de demander des opinions, liste ou vit le **verbatim client reel**. On ne suppose rien tant qu'on n'a pas lu ce qui existe deja.

| Source | Ce qu'on y trouve |
|---|---|
| Conversations support / chat (Intercom) | les frictions du quotidien, les mots exacts |
| Questions posees dans la communaute | ce que la cible ne comprend pas encore |
| Q&A des webinars | les objections recurrentes |
| Commentaires sous les ads et contenus organiques | les declics et les blocages |
| Success stories et temoignages | le reve formule par la cible elle-meme |
| Appels d'onboarding / de vente | le job-to-be-done derriere l'achat |
| Raisons de churn et de refus | les croyances qui bloquent |

**Instruction d'execution :** demande "Quelles sources peux-tu me donner a lire maintenant ? Lesquelles faudra-t-il extraire plus tard ?" Lis ce qui est accessible AVANT de continuer.

**Piege :** brancher l'IA sur ton intuition au lieu du verbatim. L'IA n'invente pas la qualite, elle copie la tienne et la duplique. Si tu pars de suppositions, tu obtiens une fiche generique.

---

## Étape 2 : Le portrait, en dialogue (7 questions)

Pose une question a la fois. Exige des exemples reels, de vrais clients, avec leurs mots, jamais des generalites.

1. **Qui est-il ?** Situation (age, metier, situation financiere, ou il vit) et surtout : a quel moment de sa vie est-il quand il te trouve ?
2. **Que cherche-t-il a accomplir, vraiment ?** Le job-to-be-done derriere l'achat (la rente, la retraite, quitter son job, la securite ?).
3. **Qu'est-ce qui lui fait mal aujourd'hui ?** Frustrations concretes du quotidien, en ses mots exacts.
4. **A quoi ressemble son reve ?** L'image concrete du succes pour lui, pas "etre epanoui" mais "mon premier deal signe, X par mois de cash-flow".
5. **Quel vocabulaire utilise-t-il ?** Les mots qu'il emploie, et ceux qu'il ne comprend pas encore : le jargon qui marque le shift moment.
6. **Qui ecoute-t-il ?** Influenceurs, podcasts, communautes ou il traine.
7. **Qu'achete-t-il d'autre ?** Les alternatives qu'il compare, du software a 19 par mois au mastermind a 20 000 par an.

**Methode pour creuser la douleur (Atomic Offers, 3.1) :** liste 10 personnes reelles de la niche, avec des prenoms, pas des categories. Prends une de ces personnes et deroule sa journee heure par heure pour extraire ses douleurs. Eliott le decrit ainsi : "je me mets dans la vie de Manon, elle se leve, quel probleme elle rencontre... elle ecrit un post en une matinee, pas du tout assez productif... elle voit sur Instagram d'autres gens qui font la meme chose, elle se sent mal d'avoir l'impression de copier... c'est quoi ma valeur ajoutee au monde". Fais ca jusqu'a avoir au moins 100 problemes, puis garde ceux que ton offre resout.

**Piege signal d'alerte :** si tu ne connais pas 10 personnes reelles dans ta niche, c'est peut-etre un marche fantasme. Soit tu vas chercher des inconnus (LinkedIn, groupes), soit tu reconsideres la niche.

---

## Étape 3 : Positionner sur l'echelle des 5 niveaux de conscience

L'echelle d'Eugene Schwartz. Pour chaque ICP, place-le sur l'echelle avec une justification **par le verbatim**, pas au feeling.

| Niveau | Etat du prospect | Ce qu'il faut lui dire |
|---|---|---|
| 1 - Unaware | Ne sait pas qu'il a un probleme | Parler de sa vie, pas du probleme |
| 2 - Problem aware | Conscient du probleme, pas des solutions | Nommer et amplifier le probleme |
| 3 - Solution aware | Sait que des solutions existent, cherche la bonne | Prouver que ton mecanisme est LA bonne approche |
| 4 - Product aware | Connait ton produit, hesite | Differencier, prouver, rassurer |
| 5 - Most aware | Convaincu, attend la bonne occasion | Offre, urgence, deal |

**Instructions d'execution :**

- Identifie le **shift moment** : la prise de conscience qui fait basculer la cible d'un niveau au suivant. Exemple PropertyFilter : "comprendre ce qu'est un Motivated Seller".
- Demande : "Quelle cible adjacente, un niveau en dessous, pourrait elargir le TAM ? Qu'est-ce qui l'empeche aujourd'hui de monter d'un niveau ?" Une boite a souvent plusieurs fiches ICP : son coeur de cible actuel + les cibles adjacentes pour elargir le marche.

**Piege :** oublier le niveau de conscience. Toute la suite (croyances, contenus, livrables) en depend. Une fiche ICP sans niveau de conscience est inutilisable.

---

## Étape 4 : Verifier que c'est un bon marche (4 criteres)

Avant de figer la fiche, passe la cible au filtre des 4 criteres d'un bon marche (Atomic Offers, 3.1).

| Critere | Question | Exemple "perte de poids" (Eliott) |
|---|---|---|
| **Douleur massive** | Ressenti fort au quotidien, pas "agreable a resoudre" ? | "ils le voient tous les jours dans le miroir, ils se degoutent" |
| **Pouvoir d'achat** | La cible peut payer ? | "les mecs de 30-40 ans qui commencent a avoir un peu de vente" |
| **Niche et ciblable** | On peut les trouver (LinkedIn, groupes, events, pages d'influenceurs) ? | ciblables par age, sexe, ville, centres d'interet |
| **En croissance** | Marche montant, momentum, pas descendant ? | "qu'il y ait un momentum du marche autour de ce que tu proposes" |

Le 5e critere, personnel : reprends ta verite non consensuelle et demande a qui elle serait le plus utile, dans quel groupe tu appartiens deja naturellement. Si la cible coche les 4 criteres mais que tu ne peux pas y appliquer ta vision du monde, prends une autre cible.

---

## Étape 5 : Produire la fiche ICP au format impose

```
FICHE ICP - [nom court, ex: "L'investisseur en construction de retraite"]
Statut : [coeur de cible actuel / cible d'elargissement]

QUI : [situation, moment de vie]
JOB-TO-BE-DONE : [ce qu'il cherche vraiment a accomplir]
DOULEURS (verbatim) : [3-5 citations exactes]
REVE (image concrete) : [ce que le succes veut dire pour lui]
NIVEAU DE CONSCIENCE : [1-5] - justification : [verbatim / signaux]
SHIFT MOMENT : [la prise de conscience qui le fait basculer]
VOCABULAIRE : [ses mots / le jargon qu'il ne maitrise pas encore]
OU LE TROUVER : [influenceurs, communautes, canaux]
ALTERNATIVES COMPAREES : [contre quoi il t'evalue]
[A VALIDER] : [les trous a combler par interviews / extraction de verbatim]
```

**Instruction d'execution :** demande ou enregistrer les fiches (recommande : avec les ressources marketing du produit), puis passe a l'etape suivante : cartographier les croyances de cette cible (voir le cours Bases marketing, etape 3), une fiche a la fois.

**Regle sur le reve :** une image concrete, jamais une abstraction. "Vous vous reveillez et pouvez travailler depuis votre cuisine ou depuis Lisbonne" plutot que "vous vous sentez libre". "Elle signe 2 nouveaux clients par mois sans faire de cold calling" plutot que "elle se sent epanouie dans son business".

---

## Exemples

### Bon

> ICP Formation IA : "independant / coach / createur / freelance non technique, utilise ChatGPT 1-2h par jour de facon lineaire. Douleur verbatim : je bidouille mais je ne controle vraiment rien."

Pourquoi c'est bon : on voit une scene (ChatGPT ouvert plusieurs fois par jour, tout reecrit a la main), une douleur en mots exacts, un comportement et non un metier. On peut ecrire une pub demain.

> ICP PropertyFilter : "L'investisseur en construction de retraite. Douleur verbatim : l'immobilier c'est risque. Niveau de conscience : 2, problem aware. Shift moment : comprendre ce qu'est un Motivated Seller."

Pourquoi c'est bon : douleur sourcee, niveau de conscience justifie, shift moment identifie. Toute la carte des croyances peut s'accrocher dessus.

### Mauvais

> "Les entrepreneurs qui veulent gagner du temps."

Pourquoi c'est rate : c'est une valise. Ca decrit tout le monde, donc personne. Pas de moment de vie, pas de douleur en mots exacts, pas de niveau de conscience. Aucun message ne peut s'y accrocher.

> "Les CEO."

Pourquoi c'est rate : un million de personnes, un sac sans fond. C'est un metier, pas un comportement. Compare a "le CEO noye par l'operationnel qui utilise deja l'IA mais ne sait pas creer des systemes" : la seconde version donne un angle, la premiere n'en donne aucun.

---

## Pieges

- **Remplir les trous par des suppositions.** Interdit. Tout ce qui n'est pas source par du verbatim se marque `[A VALIDER]`.
- **Cibler tout le monde.** "Tout le monde" = personne. Une fiche par cible precise, plusieurs fiches si besoin.
- **Confondre metier et comportement.** "Les coachs" ne dit rien ; "le coach qui ouvre ChatGPT 5 fois par jour mais reecrit tout a la main" dit tout.
- **Reve abstrait.** "Etre epanoui" ne se met pas dans une page de vente. "Mon premier deal signe" oui.
- **Oublier le niveau de conscience.** C'est le pivot de toute la suite. Une fiche sans niveau est a refaire.
- **Penser solution-first.** Tu tombes amoureux de ton produit et tu oublies la foule assoiffee.

---

## Références

- Formation **Atomic Offers** -> <a href="/plateforme/business-os/atomic-offers">/plateforme/business-os/atomic-offers</a> : la cible comportementale, les 4 criteres de bonne niche, l'histoire du vendeur de bouteilles d'eau et l'exercice des 100 douleurs viennent de la (videos 3.1 Trouver une niche, 2.2 et 2.3 les 5 questions).
- Formation **Challenge Offre Alignee** -> <a href="/plateforme/business-os/challenge-offre-aligne">/plateforme/business-os/challenge-offre-aligne</a> : les 5 questions d'introspection (cout a payer, sujet qui te fait reagir, probleme pour lequel on vient te voir, forces/faiblesses selon tes proches, verite non consensuelle) pour fonder ta perspective et valider l'offre alignee.
- Cours **bases marketing**, etape 1 -> <a href="/plateforme/business-os/bases-marketing/systeme-bases-marketing#etape-1">/plateforme/business-os/bases-marketing/systeme-bases-marketing#etape-1</a>.

---

## Checklist rapide

- [ ] Sources de verite inventoriees et lues (support, Q&A, commentaires, churn) avant toute supposition.
- [ ] Portrait en 7 questions rempli avec du verbatim reel, pas des generalites.
- [ ] 10 personnes reelles listees, au moins une journee deroulee heure par heure.
- [ ] Cible definie par comportement et moment de vie, pas par metier.
- [ ] Niveau de conscience (1-5) place et justifie par le verbatim, shift moment identifie.
- [ ] Cible adjacente un niveau en dessous reperee pour elargir le TAM.
- [ ] 4 criteres de bon marche valides (douleur massive, pouvoir d'achat, ciblable, en croissance).
- [ ] Reve formule en image concrete, douleurs en mots exacts.
- [ ] Fiche(s) ICP produite(s) au format impose, trous marques `[A VALIDER]`.

---

