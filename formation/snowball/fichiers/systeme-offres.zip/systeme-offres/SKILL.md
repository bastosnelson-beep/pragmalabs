---
name: systeme-offres
description: "Part d'une offre déjà construite (cible, transformation, étapes, prix) et lui ajoute les leviers qui font basculer l'achat (bonus, garantie, rareté, urgence), puis la replace dans un système de 3 offres. Pour qu'on se dise \"je ne peux pas ne pas l'acheter\"."
---

# Packager et rendre l'offre irrésistible

> **Objectif :** partir d'une offre déjà construite (cible + transformation + étapes + prix) et lui ajouter les leviers qui font basculer l'achat : bonus, garantie, rareté, urgence, puis la replacer dans un système de 3 offres.

À ce stade, ton offre est déjà extraordinaire : elle aide une cible précise à atteindre un résultat qu'elle désire vraiment, via un protocole où chaque étape résout un problème réel. Elle est attirante. Le travail ici, c'est de la rendre **irrésistible** : que la personne se dise "je ne peux pas ne pas l'acheter".

Quatre leviers, dans cet ordre : les bonus cassent les objections qui restent, la garantie inverse le risque, la rareté la rend désirable, l'urgence force la décision. Puis on cadre le système d'offres pour que cette offre vive dans une gamme de 3 niveaux.

---

## Principe directeur

Une offre irrésistible n'est pas une offre avec plus de contenu. C'est une offre où **toutes les barrières à l'achat ont été démontées une par une**. Chaque levier vise une raison de ne pas acheter : "je ne saurai pas faire" (bonus), "et si ça ne marche pas pour moi" (garantie), "je verrai plus tard" (rareté + urgence). Sans urgence, personne ne décide : c'est le flyer de pizza qu'on range dans un tiroir et qu'on oublie.

Et un garde-fou non négociable : la garantie, c'est **un calcul mathématique, jamais une émotion**. Si tu prends un remboursement personnellement, tu mets des garanties trop petites et tu perds.

---

## Étape 1 : Les bonus, casser les objections qui restent

**Méthode :** un bonus ne sert pas à "donner plus", il sert à **contrer une objection précise** qui pourrait freiner l'achat. Trois familles d'objections à couvrir :

| Objection | Type | Bonus qui la casse |
|---|---|---|
| "Je n'aurai pas le temps de mettre ça en place" | Sur soi (interne) | Une masterclass ou un programme de gestion du temps |
| "Je n'aurai pas d'inspiration, je ne saurai pas faire" | Véhicule | Une base de 90 templates à recopier, un prompt ChatGPT |
| "Je ne suis pas sûr d'y arriver tout seul" | Marché (externe) | "Si tu n'arrives pas à avoir un prospect, on te donne la liste de 100 prospects qu'on a trouvés" |

Deux mouvements concrets :

- **Extraire un module du cursus principal et le passer en bonus.** Si tu avais prévu "une heure de call avec moi pour te débloquer" dans le programme, sors-la et mets-la en bonus : ça la met encore plus en avant. Pareil pour un petit processus d'introspection, qui devient "10 questions d'introspection pour comprendre ta vraie valeur".
- **Garder les bonus courts et pratiques.** Une checklist, des templates, un prompt, un ebook pratique, un call. Pas une formation de 5 heures de plus.

**Outils :** Claude pour générer et formuler les bonus à partir de la liste des objections, Gamma pour mettre en page le pack de bonus.

**Piège :** trop de bonus, ou un bonus lourd. "Vraiment les bonus, des fois quand ils sont mal faits, ça peut freiner l'achat." Si la personne se dit "il y a trop de trucs, je vais crouler sous l'offre, elle n'est pas faite pour moi", tu as perdu. Vise 3 à 5 bonus max, tous rapides à consommer.

Exécution : liste d'abord les objections restantes (une par une), puis associe un bonus court à chacune. Si un bonus ne répond à aucune objection identifiée, coupe-le.

---

## Étape 2 : La garantie, inverser le risque

**Méthode :** l'objectif est que le client ait l'impression que **c'est toi qui portes le risque, pas lui**. Tu choisis le type selon ton service. Quatre types :

| Type | Définition | Exemple |
|---|---|---|
| **Conditionnelle** | Remboursement sous réserve d'avoir appliqué tes conseils / pris X appels | "Sous réserve que tu aies pris 4 appels avec moi mais que tu es toujours bloqué, je te rembourse" |
| **Inconditionnelle** | 0 regret, peu importe ce qui a été fait | "Garantie 0 regret pendant 30 jours : le moindre sentiment de t'être fait avoir, je te rembourse sans réfléchir" |
| **Implicite (performance)** | L'offre est basée sur le résultat, pas de résultat = pas de paiement | "Je prends 20% de ton chiffre d'affaires, si mon accompagnement ne marche pas tu ne paies rien" |
| **Anti-garantie** | Positionnement fort, aucun remboursement | "Toutes les ventes sont finales, je ne suis pas là à vendre des tapis. Soit tu me crois, soit non." |

**Le garde-fou central :** une garantie est un calcul mathématique. "Si tu fais 4 fois plus de conversion grâce à cette garantie 0 regret et que tu as 2 fois plus de remboursements, tu fais au moins fois 2 sur ton chiffre d'affaires." Tu traques les points positifs et négatifs, et c'est tout.

**La France :** l'anti-garantie est illégale. Pour les produits numériques, 14 jours satisfait ou remboursé sont obligatoires. Donc : pousse à 30 jours et marketise les 30 jours. Mais interdiction de marketer la garantie légale 14 jours comme un bonus ("testez sans risque") : c'est illégal.

Tu peux faire une **double garantie** : "30 jours satisfait ou remboursé garantie 0 doute, plus 6 mois résultat : si tu n'y arrives pas, je te rembourse plus je t'offre les cadeaux."

**Outils :** Claude pour générer 2 garanties par catégorie et tester la formulation.

**Piège :** prendre la garantie personnellement. "Si tu commences à prendre les garanties personnellement, là c'est foutu, tu mets des trop petites garanties et ce n'est plus une garantie irrésistible, c'est juste la garantie légale 14 jours." Plus le piège inverse : une garantie financière trop grosse sur une offre dont tu n'es pas sûr de la livraison.

Exécution : génère 2 garanties dans chaque catégorie pertinente, vérifie la légalité (14 jours mini en FR), choisis la plus forte que tu peux tenir, formule-la verbatim.

---

## Étape 3 : La rareté, rendre l'offre désirable

**Méthode :** il faut au moins un type de rareté dans l'offre. Cinq leviers :

1. **Limite en temps ou en quantité.** "J'offre 50 coachings aux 50 premiers qui achètent aujourd'hui" ; "j'ouvre les portes de mon programme seulement 3 fois dans l'année."
2. **Accès exclusif sur candidature.** "Je fais 10 coachings individuels dans l'année, je sélectionne les gens sur candidature, il faut candidater au moins 6 mois avant." Ça rend le truc vraiment désirable.
3. **Événementiel.** Ateliers, séminaires, retraites : rares par nature (places limitées, nombre d'événements limité), à l'inverse d'une formation en ligne asynchrone "pas rare du tout".
4. **Limitation de service.** "On ne prend que 5 clients simultanés, on est une agence prestigieuse, on ne fait pas de la masse."
5. **Honnêteté radicale.** "Là on est tellement nombreux dans le programme qu'on est sur le point de ne plus délivrer un service de qualité, il nous reste 1 ou 2 places, après on ferme honnêtement 3 mois le temps que le nombre de clients se régule."

**Outils :** un compteur dynamique de places (le levier d'Eliott : "à chaque call de closing on dit, là il reste 2 places, elles se libéreront dans 2 mois quand les actuels finissent").

**Piège :** la fausse rareté. Une rareté annoncée mais jamais tenue tue la confiance. La rareté la plus puissante est celle qui est vraie (capacité réelle limitée, vraies candidatures).

Exécution : choisis un type cohérent avec ton format de delivery (le 1:1 va vers l'accès exclusif, le groupe vers la limitation de service), puis formule la phrase exacte.

---

## Étape 4 : L'urgence, forcer la décision

**Méthode :** sans urgence, les gens n'achètent pas. "C'est le même effet qu'un flyer de pizzeria : tu te dis ça pourrait être utile plus tard, tu le mets dans un tiroir, tu ne commandes jamais. Un flyer qui dit 3 pizzas offertes jusqu'au 6 mai, là tu y vas." Eliott l'a testé : un tunnel de vente sans urgence, "juste ça ne marche pas". Quatre types :

| Type | Mécanisme | Exemple |
|---|---|---|
| **Cohortée** | Programme par groupe qui démarre à date fixe | "Un mois de candidature, sélection, puis 3 mois de programme ensemble. On lance tous les trimestres." |
| **Saisonnière** | Une promo par saison | "Promo de printemps, d'été, d'automne, Black Friday, Noël. Ça génère toujours beaucoup d'argent." |
| **Tarifaire / promotionnelle** | Prix qui va monter, ou remise déclenchée par un clic | "Dès que tu cliques sur ce lien, tu as -30% pendant encore 2 jours pour t'aider à te décider." |
| **Opportunité explosive** | Une fenêtre qui se referme | "C'est le moment ou jamais : si tu rates cette stratégie d'investissement, tu ne bénéficies pas de la montée du marché." |

**La transparence assumée d'Eliott :** "Je le dis très clairement : je sais que les gens ne prennent pas de décision sans urgence, donc j'ai décidé d'en mettre pour que tu choisisses si oui ou non tu veux investir sur ton capital intellectuel."

**Outils :** un timer de promo déclenché au clic, une date de fermeture de cohorte.

**Piège :** pas d'urgence du tout (l'erreur la plus fréquente, et la plus chère). Tu peux combiner plusieurs types au cours de l'année (saisonnière + urgence de place après un closing).

Exécution : choisis au moins un type, fixe la date ou le compteur, écris la phrase d'urgence et place-la dans le tunnel, l'offre et l'appel.

---

## Étape 5 : Replacer l'offre dans un système de 3 offres

**Méthode :** tu peux aider la même cible à résoudre le même problème à plusieurs niveaux d'engagement et de prix. Ce n'est pas une contradiction, c'est un système. Exemple verbatim : méditer via un challenge 4 jours, via un programme guidé d'un an, via 12 rencontres en présentiel et des retraites Vipassana. Même cible, même problème, 3 niveaux.

Tout business a besoin de **3 types d'offres minimum** pour la même cible :

| Niveau | Rôle | Prix type | Marge |
|---|---|---|---|
| **Acquisition** | Engager : la personne met sa carte bleue une 1ère fois, commence à te faire confiance, amortit tes coûts pub | ~7€ | x0,1 à x0,2 |
| **Scalable** | Vendable à des milliers de personnes, peu ou pas de coaching, qualifie les bons clients | intermédiaire | x3 à x4 |
| **Immortelle (high ticket)** | Toute ta méthode, toute ton unicité, le maximum de valeur | élevé | x20 |

**La règle de construction :** concevoir l'offre immortelle EN PREMIER. "C'est l'offre la plus importante parce que c'est là que tu fais toute ta marge (fois 20). Une fois créée, tu la déclines en scalable, puis en acquisition." Pourquoi pas l'inverse : "Si tu veux vendre seulement une offre à 4000€, les gens ont trop de barrières, ils ne te font pas encore confiance." Il faut une offre moins chère pour que la personne évolue avec toi.

**Outils :** Claude pour cartographier la gamme, Gamma pour le schéma de la value ladder.

**Piège :** vouloir tout vendre via une seule offre high ticket. Sans marche d'entrée, la confiance ne se construit pas et l'offre immortelle ne se close pas.

Exécution : situe l'offre packagée dans la gamme (c'est très probablement ton immortelle), puis esquisse les 2 autres niveaux pour la même cible.

---

## Exemples

### Bon (garantie, verbatim Atomic Offers)

> "Vis complètement de la promenade pour chien en 2 mois ou je te rembourse 2 fois le prix de la formation. Tu as payé 400, soit tu vis d'une nouvelle activité, soit je te rembourse 800. Dans tous les cas tu as gagné minimum 400 et je prends le risque à ta place. Évidemment il y a des conditions : si tu as vraiment appliqué tous mes conseils."

Pourquoi c'est bon : le risque est totalement inversé (le client gagne dans tous les cas), c'est chiffré, et la condition ("si tu as appliqué tous mes conseils") protège la rentabilité. C'est le calcul mathématique en action.

### Bon (bonus, verbatim)

> "Si tu n'arrives pas à avoir un prospect, on te donne la liste de 100 prospects qu'on a trouvés que tu peux appeler, ou on te recherche tes 10 premiers prospects à ta place."

Pourquoi c'est bon : le bonus vise une objection précise ("je ne suis pas sûr d'y arriver") au lieu d'empiler du contenu.

### Mauvais (bonus)

> "En bonus, 5 heures de formation supplémentaire sur 10 sujets connexes pour tout savoir sur le domaine."

Pourquoi c'est raté : ça ne casse aucune objection, ça en crée une. "Putain il y a trop de trucs, je vais crouler sous l'offre, elle n'est pas faite pour moi." Un bonus mal fait freine l'achat.

### Mauvais (garantie)

> "Garantie satisfait ou remboursé 14 jours : testez l'offre sans aucun risque, c'est notre cadeau pour vous."

Pourquoi c'est raté : c'est la garantie légale obligatoire présentée comme un bonus extraordinaire. En France, marketer la garantie légale comme un avantage est illégal. Pousse à 30 jours et marketise les 30 jours, pas les 14.

---

## Pièges

- Empiler des bonus au lieu de cibler les objections : au-delà de 3-5, ça freine l'achat.
- Prendre la garantie ou le remboursement personnellement : tu mets des garanties trop faibles et tu perds le levier.
- Marketer la garantie légale 14 jours FR comme un bonus : illégal.
- Annoncer une rareté ou une urgence que tu ne tiens pas : la fausse rareté détruit la confiance.
- Oublier l'urgence : sans elle, le tunnel ne convertit pas (c'est le flyer dans le tiroir).
- Vouloir vendre uniquement en high ticket sans offre d'acquisition pour bâtir la confiance.

---

## Références

- Formation vidéo : <a href="/plateforme/business-os/atomic-offers">Atomic Offers -&gt;</a>, module 7 (bonus, garanties, rareté, urgence) et 5.4 (système d'offres). C'est la source intégrale de cette méthode.
- Formation vidéo : <a href="/plateforme/business-os/systme-business-offres-et-contenus">Systeme Business, Offres et Contenus -&gt;</a> pour l'architecture complète de la value ladder une fois les 3 offres définies.
- Formation vidéo : <a href="/plateforme/business-os/challenge-offre-aligne">Challenge Offre Alignee -&gt;</a> pour valider l'offre en amont avant de la packager.
- Skill lié : <a href="/plateforme/business-os/templates__2-Vente__pricer-offre">pricer-offre -&gt;</a>, le prix de base que ces leviers viennent renforcer (la garantie justifie le prix).
- Skill lié : <a href="/plateforme/business-os/offre__nommer-offre">nommer-offre -&gt;</a>, l'étape suivante une fois l'offre rendue irrésistible.
- Cours : <a href="/plateforme/business-os/construire-offre/systeme-offre#etape-5">Construire une offre, étape 5 -&gt;</a>.

---

## Checklist

- [ ] Liste des objections restantes établie, un bonus court ciblant chacune (3-5 max).
- [ ] Au moins un module du cursus extrait et valorisé en bonus.
- [ ] Garantie choisie parmi les 4 types, formulée verbatim, légale (>= 14j FR, idéalement 30j marketés).
- [ ] Garantie validée comme un calcul mathématique (conversions x remboursements), pas une émotion.
- [ ] Un type de rareté réel et tenable, formulé en une phrase.
- [ ] Au moins un type d'urgence avec date ou compteur, placé dans le tunnel.
- [ ] L'offre située dans une gamme de 3 niveaux (acquisition, scalable, immortelle), immortelle conçue en premier.

---

Cycle complet : `/solutions-offre` -> `/pricer-offre` -> ce skill -> `/nommer-offre`. Ce skill vient après le pricing (l'offre et son prix existent) et alimente le nommage puis le document d'offre final.
