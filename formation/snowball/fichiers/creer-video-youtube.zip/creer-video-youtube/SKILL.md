---
name: creer-video-youtube
description: "La conception d'une vidéo étape par étape : clarifier le sujet, choisir l'angle, créer le hook, structurer, affiner la narration, puis poser le titre et la miniature. Skill dialogique de référence."
---

# Créer une vidéo YouTube : du sujet à la miniature

> **Objectif :** accompagner la création d'une vidéo YouTube de A à Z, étape par étape : clarifier le sujet, choisir l'angle, créer le hook, structurer, affiner la narration, puis poser le titre et la miniature.

Ce skill couvre la conception d'UNE vidéo. Pour trouver de nouveaux sujets, mobilise le skill `/ideation-video`. Pour le détail du titre et de la miniature, mobilise `/titres-youtube` et `/miniatures-youtube`.

**Règle d'or : tu es dialogique.** Pose des questions, attends les réponses, valide à chaque étape avant d'avancer. Ne saute jamais une étape sans accord explicite.

## Arguments

- `$ARGUMENTS` : sujet ou idée de vidéo (optionnel, si absent on explore ensemble).

## Contexte

### Statique
- Style : direct, affirmatif, personnel, basé sur l'expérience vécue.
- Équation qualité : Résonance x Nouveauté.
- Deux métriques décident d'une vidéo : le CTR (taux de clic, piloté par le titre et la miniature) et le watch time (rétention, piloté par le script). On garde les deux en tête tout du long.

### Dynamique
- Input : `$ARGUMENTS` (sujet optionnel).
- Notes pertinentes au sujet.
- Vidéos récentes de la chaîne (pour éviter les doublons et garder la cohérence).

---

## Étape 0 : Diagnostic initial

Au lancement, poser ces questions en une seule fois :

> "Avant de commencer, j'ai besoin de quelques infos :
> 1. Tu as déjà une idée de vidéo, ou tu veux qu'on en trouve une ensemble ?
> 2. Quel est l'objectif de cette vidéo ? (toucher des inconnus / éduquer ton audience / convertir)
> 3. Tu veux un plan en bullet points (pour parler naturellement à l'oral) ou un script complet (pour lire face caméra) ?"

- **Idée fournie** : aller à l'Étape 1 pour la cadrer, puis l'Étape 2.
- **Pas d'idée** : lancer d'abord le skill `/ideation-video`, puis revenir ici avec un sujet choisi.

---

## Étape 1 : Clarifier le sujet

Si `$ARGUMENTS` est vide ou vague, explore avec ces questions (une par une) :
- "C'est quoi le sujet qui te tient à coeur en ce moment ?"
- "Quel type de vidéo tu veux faire ?" Propose les 5 types :
  1. Remettre en question le statu quo.
  2. Proposer une solution à un problème complexe.
  3. Simplifier un sujet complexe.
  4. Raconter une histoire captivante avec une leçon.
  5. Exprimer une pensée commune mais rarement verbalisée.
- "Quelle transformation tu veux créer chez le spectateur ?"

Si `$ARGUMENTS` est précis, résume ta compréhension et demande validation.

**Précision :** un sujet n'est pas encore un angle. Le sujet, c'est le thème (la prise de notes). L'angle, c'est la prise de position dessus (à l'étape suivante).

**-> Attends validation avant de continuer**

---

## Étape 2 : Choisir l'angle

Propose 4 à 5 angles spécifiques pour le sujet. Pour chaque angle :
- L'angle en 1 phrase.
- Pourquoi il est intéressant (inattendu ? personnel ? contrarian ?).
- Score de curiosité estimé (1-5).

Rappelle la règle : l'angle le plus évident n'est pas le meilleur. Cherche l'inattendu.

```
Exemples de transformation :
- "Mon apprentissage de la biologie" (générique)
- "Comment j'ai appris ce livre de 3000 pages en 6 mois" (spécifique, intrigue)
```

**Précision :** un angle fort vient souvent d'un insight, une perspective neuve sur le sujet. Si l'angle te semble plat, le skill `/ideation-video` (croisement valeurs, croyances, sujets) aide à en sortir un plus original.

**-> Attends le choix de l'angle avant de continuer**

---

## Étape 3 : Créer le hook

Génère 4 hooks, un par type :
1. **Question intrigante** : question sans réponse immédiate.
2. **Narrative** : début d'histoire avec boucle ouverte.
3. **Données de recherche** : résultat surprenant.
4. **Argument inattendu** : affirmation contre-intuitive.

Pour chacun, indique :
- Le texte du hook (30 à 60 secondes parlées).
- Pourquoi il crée de la tension.
- Score d'accroche estimé (1-5).

**Précision :** le hook doit ouvrir une boucle que seule la fin de la vidéo referme. C'est lui qui sauve les premières secondes, là où se joue le plus gros décrochage.

**-> Attends le choix du hook avant de continuer**

---

## Étape 4 : Structurer le contenu

Construis la structure en pyramide de Freytag :

```
## Introduction (hook choisi)
[Hook] -> Contexte partagé -> Problème et enjeux -> Importance -> Solution suggérée

## Partie 1 : [Premier conflit]
- Point principal
- Exemple / histoire / analogie
- Transition forte vers partie 2

## Partie 2 : [Conflit plus profond]
- Point principal (intensité croissante)
- Exemple / histoire / analogie
- Transition : "mais ce n'est pas tout..."

## Partie 3 : [Climax / Révélation]
- La grande révélation
- Données / preuves
- Moment "wow"

## Conclusion / Résolution
- Résumé de la transformation
- Takeaway actionnable
- Ouverture / question finale
```

Max 4 parties. Chaque partie a : un point principal, un exemple ou une analogie, une transition forte.

**Précision (débutant) :** si la personne débute, oriente vers une LISTE (6 erreurs, 4 conseils) et une vidéo courte qui répond à une question. C'est le format le plus simple à scripter et à tenir.

**-> Affiche la structure et attends validation**

---

## Étape 5 : Affiner la narration

Pour chaque partie, développe en bullet points (PAS de script mot à mot, sauf demande explicite) :
- Les points clés à aborder.
- Les connecteurs logiques (mais, car, donc, c'est pourquoi).
- Les micro-conflits qui maintiennent la tension.
- Les histoires, exemples et analogies prévues.

Vérifie la checklist narration :
- [ ] Chaque partie augmente en intensité.
- [ ] Une histoire ou un exemple par concept important.
- [ ] Transitions fortes entre chaque partie.
- [ ] Le fil rouge (angle) est maintenu du début à la fin.
- [ ] La promesse du hook est tenue dans la résolution.

**Précision :** c'est cette étape qui pilote le watch time. Une narration plate fait décrocher, une narration en péripéties croissantes retient.

---

## Étape 6 : Créer le titre

Mobilise le skill `/titres-youtube` pour la version complète. En résumé, génère 10 variations en utilisant ces structures :
1. **Paradoxe** : "L'hack de productivité ultime : procrastiner 2h par jour".
2. **Révélation personnelle** : "Comment j'ai dit FUCK à la société".
3. **Correction de croyance** : "Vous n'êtes pas déconcentré : ma méthode...".
4. **Liste d'erreurs** : "4 erreurs qui ruinent vos notes".
5. **L'art de...** : "L'art subtil de ruiner sa vie (intentionnellement)".

Pour chaque titre : nombre de caractères (max 60), power words utilisés, score scroll-stop (1-5).

**Précision :** le titre porte la moitié du CTR. Un power word et une vraie curiosité sont non négociables.

**-> Attends le choix du titre**

---

## Étape 7 : Brief miniature

Mobilise le skill `/miniatures-youtube` pour le brief complet. En résumé, propose 2 à 3 concepts, pour chacun :
- **Type** : Émotionnel / Démonstratif / Narratif / Minimaliste.
- **Visage** : expression + direction du regard.
- **Texte** : 3 à 4 mots maximum, qui complètent le titre sans le répéter.
- **Composition** : placement des éléments (règle des tiers).
- **Couleur dominante** : + justification psychologique.

**Précision :** la miniature forme un combo avec le titre. Elle ne redit pas le titre, elle ajoute une couche de curiosité, et elle doit rester lisible en tout petit sur mobile.

---

## Étape 8 : Récapitulatif

Génère un récapitulatif complet :

```markdown
## Vidéo : [Titre choisi]

**Angle :** [L'angle en 1 phrase]
**Objectif :** [toucher / éduquer / convertir]
**Hook :** [Type de hook choisi]
**Durée estimée :** [X min]

### Structure
[La structure validée en bullet points]

### Titre
[Le titre choisi] ([X] caractères)

### Brief miniature
[Le concept choisi]

### Notes de tournage
- Expressions à capturer pour la miniature
- Décor / accessoires suggérés
- Points clés à ne pas oublier
```

---

## Vérification finale

- [ ] UN seul angle maintenu du début à la fin.
- [ ] Hook qui crée une boucle ouverte.
- [ ] Structure en péripéties croissantes (pas plate), max 4 parties.
- [ ] Une histoire ou un exemple par concept.
- [ ] Titre sous 60 caractères avec un power word.
- [ ] Brief miniature avec expression, texte et composition.
- [ ] Qualité = Résonance (histoires, pertinence) x Nouveauté (insights, perspective inédite).

## Ce que tu ne fais PAS

- Écrire un script mot à mot par défaut (bullet points, sauf demande).
- Proposer des angles génériques ("tout savoir sur X").
- Créer des structures plates (liste de points sans progression).
- Oublier les exemples et histoires (chaque concept en a un).
- Proposer des titres de plus de 60 caractères, ou ignorer le test mobile pour la miniature.

---

Skills liés : `/ideation-video` (trouver le sujet en amont), `/titres-youtube` et `/miniatures-youtube` (le packaging en détail).
