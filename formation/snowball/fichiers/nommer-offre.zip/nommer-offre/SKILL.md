---
name: nommer-offre
description: "Transforme une offre déjà construite (avant/après, étapes, prix, packaging) en une USP en une phrase plus un nom de produit qui encapsule cette USP et te sépare de la concurrence. On fait l'USP d'abord, le nom ensuite."
---

# Trouver le nom et l'USP qui mécanisent ton offre

> **Objectif :** transformer une offre déjà construite (avant/après, étapes, prix, packaging) en une USP en une phrase + un nom de produit qui encapsule cette USP, et qui te sépare de la concurrence.

C'est l'avant-dernière étape de la construction d'offre. Elle arrive APRÈS que tu aies clarifié ta cible, fait l'avant/après en mots clients, listé tes étapes et tes solutions, fixé ton prix et ton packaging. À ce stade tu sais exactement ce que tu vends et à qui. Il te reste à le nommer pour qu'on s'en souvienne et à le formuler pour qu'on l'achète.

Deux livrables, deux temps. D'abord l'USP (la phrase qui encapsule toute ton offre). Ensuite le nom (le mot qui te rend incomparable). Le nom encapsule l'USP, donc on fait l'USP d'abord.

---

## Principe directeur

Une USP, c'est la pierre angulaire d'un business. Comme je le dis dans le challenge : "c'est ce sur quoi tout ton avenir, disons pour les 10 prochaines années, va se baser." Si elle est floue, tout le reste est flou.

Trois règles non négociables :

1. **L'USP encapsule toute l'offre en une phrase.** Cible + résultat + temps + mécanisme. "Vous aidez une cible à avoir un résultat en une période donnée." Si tu ne peux pas la dire en une phrase, ton offre n'est pas claire.
2. **Le nom est un actif différenciant, pas une étiquette.** Si j'avais appelé mon produit "formation second cerveau pour les nuls", il serait banal aujourd'hui, copiable, noyé. Parce que j'ai pris le temps de créer "Atomic Thinking", les gens tapent ce nom-là sur Google, pas "second cerveau". Le nom te sépare de la concurrence.
3. **On encapsule l'USP DANS le nom.** Le nom final n'est pas juste un mot : c'est le mot + le mécanisme conteneur + l'objectif + le temps. "Atomic Perspectives, le programme intensif de 2 mois pour devenir expert de ton domaine, innover et créer ta propre méthode."

---

## Étape 1 : Écrire l'USP en une phrase

**Méthode :** une USP, c'est cette phrase que tout entrepreneur sait dire de lui : "j'aide telles personnes à obtenir tel résultat en tant de temps." La structure :

> J'aide [cible] à [résultat mesurable] en [temps] grâce à [mécanisme unique].

Tu pars de l'avant/après déjà fait. Le "résultat" de l'USP, c'est ton point B en mots clients. Le "mécanisme", ce sont tes étapes nommées. Le "temps", c'est ta promesse temporelle.

**Les 5 critères PMDMT.** Une bonne USP coche les cinq :

| Critère | Ce qu'il exige | Test rapide |
|---|---|---|
| **Précise** | Pas vague. "Sereine au quotidien" ne veut rien dire ; "une bonne organisation pour être plus sereine" oui. | Peux-tu visualiser le résultat ? |
| **Mesurable** | Le résultat se chiffre ou se constate. "Plus de paix" non ; "arrêter de ruminer en permanence" oui. | Y a-t-il un chiffre ou un état observable ? |
| **Désirable** | La personne veut vraiment ça (validé par l'avant/après et tes interviews, pas supposé). | De vraies personnes ont-elles dit vouloir ça ? |
| **Mécanisée** | Un mécanisme unique nommé, qui t'appartient, où tu mets tes valeurs. "Système d'investissement résilient minimaliste durable" : tes valeurs sont dedans. | Le "grâce à" est-il à toi et à personne d'autre ? |
| **Temporellement définie** | En combien de temps on obtient le résultat. Les gens veulent une transformation en un temps donné, plus de l'information. | Y a-t-il une durée ? |

**Outils :** l'avant/après (point A / point B en mots clients) comme matière première. Claude pour générer 20 formulations différentes d'un coup. La communauté / des pairs pour tester laquelle résonne.

**Piège :** rester vague pour ne vexer personne ("j'aide les entrepreneurs à réussir"). Une USP qui ne dérange personne n'attire personne. L'autre piège : inventer la désirabilité au lieu de la valider sur de vraies personnes.

**Exécution :**
1. Reprends l'avant/après. Le point B (en mots clients) devient ton "résultat".
2. Écris une première USP avec la structure "j'aide [cible] à [résultat] en [temps] grâce à [mécanisme]".
3. Fais de la divergence : écris-en 10 à 20, formulées différemment. "Plus tu as d'itérations, le plus évidemment le résultat sera bon."
4. Passe chacune au filtre PMDMT. Coupe celles qui ratent un critère.
5. Converge sur celle qui résonne le plus. Teste l'alignement : "voyez à l'intérieur de vous comment ça se passe." Si ce n'est pas la cible, le mécanisme ou le résultat, ajuste.
6. Si tu as un catalogue, écris une USP pour le business global ET une USP par produit (plus spécifique).

---

## Étape 2 : Trouver le nom du produit

**Méthode :** le nom se construit en trois temps : un mot conteneur, un brainstorm de divergence, une convergence sur tes valeurs.

### Le mot conteneur

Le levier le plus simple et le plus puissant. Tu ajoutes devant ou autour de ton nom un mot qui mécanise et qui donne de la valeur perçue : "la méthode", "le système", "le programme", "le challenge", "le programme intensif de 2 mois", "la méthode ultime", "le programme exclusif".

Comme je le dis : "le fait de rajouter un mot, le système, le programme, le challenge, ça va ajouter de la valeur perçue pour le client." Ça encapsule le mécanisme. "Atomic Perspectives" seul est moins fort que "Atomic Perspectives, le programme intensif de 2 mois".

### Le brainstorm 2h (divergence)

Comment j'ai créé "Atomic Thinking" : "j'ai balancé tous les mots qui me faisaient penser à mon produit." Atomicité des pensées, donc "atomic". Pensée, donc "thinking". J'avais aussi tenté neurone, neuronote, neuronautes, perspective, profondeur. Puis "au bout d'un moment j'ai commencé à assembler 2 mots qui allaient bien ensemble et je me suis dit : putain, Atomic Thinking, ça marche pas mal ensemble."

La méthode concrète :
- Passe 2 heures de brainstorm. Mets tous les mots qui font penser de près ou de loin à ta méthode.
- Va relire un texte que tu as écrit sur ton sujet et repère les mots qui reviennent le plus souvent.
- Demande à Claude de générer des noms similaires aux pistes que tu aimes.
- Assemble deux mots qui sonnent bien ensemble.

### La convergence

Une fois assez de divergence, tu converges. Trois questions :
- Qu'est-ce qui incorpore le mieux tes valeurs ?
- Qu'est-ce qui reflète le mieux l'énergie que tu veux transmettre sur le long terme ?
- Qu'est-ce qui est DÉCLINABLE ? "Atomic, ça marche pas mal parce que du coup tous mes produits maintenant c'est Atomic quelque chose, et donc c'est super facile à nommer, ça fait un branding vraiment stylé." Si tu as "neuro", ça donne les neuronautes, le neuromarketing, etc.

**Outils :** un texte que tu as déjà écrit (mine à mots-clés), Claude (génération de variantes), un cours de français (pour l'allitération, voir étape 3).

**Piège :** le nom générique. "Formation second cerveau pour les nuls" : banal, copiable, noyé dans la masse. Le nom propriétaire te rend incomparable.

---

## Étape 3 : Les autres leviers de nommage

En dehors du mot conteneur, cinq leviers à combiner :

| Levier | Comment | Exemple |
|---|---|---|
| **L'objectif dans le titre** | Mets le résultat visé dans le nom. | "Expertise Mastery, le programme pour..." ; "Muscle Builder Extrême" |
| **L'intervalle de temps** | Une durée encapsule la promesse. | "Atomic Perspectives, le programme intensif de 2 mois" |
| **Cibler l'avatar** | Dis directement à qui tu t'adresses. | "Maman Productive : comment mieux gérer son emploi du temps quand on a des enfants" |
| **La raison magnétique (promos)** | Un mot fort qui justifie l'offre. | "grande ouverture", "liquidation annuelle", "solde de printemps", "Black Friday" |
| **L'allitération** | Des sons ou syllabes qui se répètent, pour que ça sonne. | Reviens en cours de français : crée de la poésie pour faire sonner ta promesse. |

**Méthode :** pour chaque levier, fais l'exercice directement. Crée un nom avec un bon conteneur, puis un nom avec un objectif, puis un nom qui cible l'avatar. Tu auras une dizaine de candidats, tu choisiras le meilleur.

**Piège :** empiler tous les leviers dans un seul nom imprononçable. Choisis-en deux ou trois qui sonnent ensemble.

---

## Étape 4 : Encapsuler l'USP dans le nom final

**Méthode :** le nom final n'est pas le mot tout seul. C'est le mot + le conteneur + l'objectif + le temps, assemblés pour porter l'USP. Format cible :

> [Nom] - le [conteneur] en [temps] pour [résultat].

Exemple complet, le mien : l'USP était "le programme intensif de 2 mois pour devenir expert de ton domaine, innover et créer ta propre méthode". Le nom complet du programme devient donc :

> **Atomic Perspectives, le programme intensif de 2 mois pour devenir expert de ton domaine, innover et créer ta propre méthode.**

"Le nom complet du programme a été nommé en incorporant l'USP, le bénéfice, etc." Et il reste améliorable avec de l'allitération.

**Exécution :**
1. Prends le nom propriétaire retenu (étape 2).
2. Colle le mot conteneur + l'intervalle de temps + l'objectif/résultat issu de l'USP.
3. Vérifie qu'on retrouve la cible, le résultat et le temps en lisant le nom complet.
4. Partage-le, lis-le à voix haute, garde celui dont tu es satisfait.

---

## Exemples

### Bon

**USP (verbatim, Atomic Investing) :** "le système d'investissement résilient et minimaliste pour vous créer un patrimoine et prendre votre retraite dans 20 ans, même en gagnant moins de 4000 euros par mois." -> Précise (système d'investissement, patrimoine), mesurable (retraite, moins de 4000€/mois), désirable (validée par l'avant/après FOMO -> clarté), mécanisée ("résilient et minimaliste" = mes valeurs dedans), temporellement définie (20 ans). Les cinq critères PMDMT cochés.

**USP (verbatim) :** "j'aide les cafés à augmenter leur rétention client d'au moins 30% en 4 mois." -> Tout y est en une ligne : cible (cafés), résultat mesurable (+30% de rétention), temps (4 mois).

**Nom complet (verbatim) :** "Atomic Perspectives, le programme intensif de 2 mois pour devenir expert de ton domaine, innover et créer ta propre méthode." -> Mot conteneur ("le programme intensif"), intervalle de temps ("2 mois"), objectif ("devenir expert, créer ta propre méthode"), nom propriétaire déclinable ("Atomic" -> toute la gamme Atomic X). L'USP est encapsulée dans le nom.

### Mauvais

**USP :** "j'aide les entrepreneurs à réussir." -> Vague (réussir quoi ?), non mesurable, non mécanisée, sans temps. Rate 4 critères sur 5. N'attire personne parce qu'elle parle à tout le monde.

**USP :** "j'aide les mamans à être plus sereines au quotidien." -> Trop vague. Sereine comment ? Le fix : "j'aide les jeunes mamans à avoir une bonne organisation pour être plus sereines" (précis), ou "à mieux éduquer leurs enfants pour qu'ils s'autonomisent" (mesurable, désirable).

**Nom :** "formation second cerveau pour les nuls." -> Générique, copiable, déjà pris par d'autres sur le même sujet. Aucun actif de marque, aucune valeur perçue ajoutée, rien à taper sur Google qui te ramène à toi.

---

## Pièges

- **Faire le nom avant l'USP.** Le nom encapsule l'USP. Sans USP claire, le nom ne mécanise rien.
- **L'USP vague pour ne vexer personne.** Plus tu es précis et spécifique, plus tu attires. Le flou ne protège pas, il dilue.
- **Supposer la désirabilité.** Le "D" de PMDMT exige de vraies personnes qui veulent vraiment ce résultat (tes interviews, ton avant/après en mots clients), pas ta supposition.
- **Le nom générique.** Il te rend banal et copiable. Vise un nom propriétaire et déclinable si tu joues le long terme.
- **Bâcler le brainstorm.** 2 heures minimum. Le bon nom sort de la quantité de mots balancés, pas du premier jet.
- **Empiler tous les leviers.** Conteneur + objectif + temps suffisent. Trop de leviers = nom imprononçable.

---

## Références

- Formation vidéo : <a href="/plateforme/business-os/atomic-offers">Atomic Offers</a> - leçons 4 (Créer une USP) et 7.5 (Trouver le nom). La méthode complète dont ce skill est la synthèse activable.
- Formation vidéo : <a href="/plateforme/business-os/challenge-offre-aligne">Challenge Offre Alignée</a> - le jour 4 du challenge est consacré à l'USP, à faire en amont pour valider l'alignement de l'offre.
- Skill lié : <a href="/plateforme/business-os/offre__avant-apres">avant-apres</a> - fournit le point A / point B en mots clients qui alimentent le "résultat" de l'USP.
- Skill lié : <a href="/plateforme/business-os/offre__solutions-offre">solutions-offre</a> - fournit le mécanisme unique nommé qui devient le "grâce à" de l'USP.
- Skill lié : <a href="/plateforme/business-os/templates__2-Vente__category-of-one">category-of-one</a> - quand tu veux nommer une nouvelle catégorie de marché, pas seulement un produit.
- Skill lié : <a href="/plateforme/business-os/offre__systeme-offre">systeme-offre</a> - l'orchestrateur qui assemble le document d'offre final, nom inclus.

---

## Checklist

- [ ] Avant/après en mots clients disponible (point A / point B) avant de commencer.
- [ ] USP écrite en une phrase : j'aide [cible] à [résultat] en [temps] grâce à [mécanisme].
- [ ] USP passée au filtre PMDMT : Précise, Mesurable, Désirable (validée), Mécanisée, Temporellement définie.
- [ ] 10 à 20 USP générées en divergence, puis convergence sur celle qui résonne.
- [ ] Brainstorm de nom 2h : tous les mots balancés, deux assemblés qui sonnent.
- [ ] Nom propriétaire choisi : incorpore tes valeurs, reflète ton énergie long terme, est déclinable.
- [ ] Leviers combinés : mot conteneur + objectif + intervalle de temps (+ avatar / allitération si pertinent).
- [ ] Nom final assemblé : [Nom] - le [conteneur] en [temps] pour [résultat], avec l'USP encapsulée dedans.

---

Cycle complet : `/avant-apres` -&gt; `/problemes-par-etape` -&gt; `/solutions-offre` -&gt; `/pricer-offre` -&gt; `/systeme-offres` -&gt; ce skill `/nommer-offre` -&gt; assemblage du document d'offre par `/systeme-offre`. Vient après le packaging et le pricing (tu sais ce que tu vends et à qui) ; alimente le document d'offre final, qui devient la base de la page de vente (Théme C, Livrables marketing).
