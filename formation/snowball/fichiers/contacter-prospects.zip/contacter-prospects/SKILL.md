---
name: contacter-prospects
description: "Contacter chaque prospect avec un message naturel et personnalisé : d'où tu viens, ce que tu as ressenti en regardant ce qu'ils font, pourquoi tu veux parler, et 20 minutes. Pas de pitch, pas de framework mécanique."
---

# Contacter : le premier message qui convertit

> **Objectif :** contacter chaque prospect en statut "à contacter", avec un message personnalisé envoyé via Beeper sur le bon canal, puis mettre le statut à jour.

C'est l'étape où le travail amont paie. On traite les prospects un par un, en commençant par les scores les plus hauts (les plus chauds). Taux de réponse attendu : ~20% (10 à 40% selon la qualité de la cible et du nid).

---

## Principe directeur

On ne déballe JAMAIS la solution avant que la personne soit intéressée. On donne envie, on demande 20 min, c'est tout. Un premier message qui pitche l'offre se fait ignorer.

---

## Étape 1 : prendre les infos sur la personne

On lit la ligne du board et on récupère les champs. Chaque champ alimente un endroit précis du message.

| Champ | À quoi il sert |
|---|---|
| `Title` (nom) | Prénom dans l'accroche. |
| `Nid source` | L'endroit où tu es tombé sur eux. Ça rend le message naturel, pas froid. |
| `Poste / Activité` | Pour réagir à ce qu'ils font de façon humaine. |
| `Bio` | Détails concrets pour parler de leur quotidien dans leurs mots. |
| `Commentaire` | Note interne, contexte. Ne pas citer tel quel. |
| `Localisation` | Touche de proximité si pertinent. |
| `Abonnés / Avis` | Signal d'audience ou de crédibilité. |
| `Score ICP` | Priorité de traitement. Plus haut = contacté en premier. |
| `Awareness` | Calibre le ton (voir plus bas). |
| `Justification` | Pourquoi ce profil est cible. Aide à viser le bon problème. |
| `Profil` / `Téléphone` / `Email` / `Recherche Google` | Sert à choisir le canal Beeper. |

Calibrage selon `Awareness` :
- **unaware / problem aware** : on reste sur le problème, dans ses mots. Pas de jargon, pas de produit.
- **solution aware** : on peut évoquer qu'on a "une manière de faire" sans nommer l'offre.
- **product aware / most aware** : on peut être plus direct sur le rendez-vous, la personne connaît déjà le sujet.

---

## Étape 2 : construire le message

La structure d'un bon message est simple et naturelle. Pas de framework mécanique. On écrit comme on parlerait à quelqu'un qu'on vient de découvrir et qui nous intrigue.

1. **D'où tu viens** (depuis `Nid source`) : tu montres comment tu es tombé sur eux. Ça désamorce le "mais qui est celui-là".
2. **Ton ressenti sur ce qu'ils font** (depuis `Poste` + `Bio` + `Abonnés`) : une réaction humaine, pas du complimentage creux. Ce qui t'a vraiment marqué en lisant leur profil.
3. **Pourquoi tu veux leur parler** : ta conviction personnelle, pas un argument de vente. Ce que tu cherches à comprendre ou à explorer avec eux.
4. **La demande** : 20 min, ajd ou demain. Simple, direct.

L'ensemble doit tenir en 4-5 phrases. Quelqu'un qui lit ça sur son téléphone doit se dire "ah ok, c'est un humain", pas "c'est encore un message automatisé".

### Ce qui porte le message

- **L'authenticité du ressenti** : tu as lu leur profil, quelque chose t'a accroché. Tu le dis avec tes mots, pas avec une formule.
- **Le petit oui** : on ne demande rien d'énorme. Juste 20 min. Facile à accorder.
- **On montre, on ne vend pas** : on propose de montrer comment NOUS on fait. Zéro lien, zéro solution déballée avant que la personne soit intéressée.

---

## Le mauvais message vs le bon message

### À ne jamais envoyer

> "Bonjour, je propose des formations en IA pour aider les entrepreneurs à gagner du temps. Intéressé(e) ?"

Générique, vendeur, solution balancée direct. Ignoré.

### Le bon message (modèle DM long, type LinkedIn)

> "Salut Marie, j'ai découvert ton profil sous un post de Thibaut sur les agents IA, j'étais curieux donc je suis allé regarder ce que tu faisais. Ta façon de questionner le 'comment' plutôt que de sauter sur l'outil, ça me parle. En ce moment je cherche à parler à des gens qui réfléchissent avant d'adopter, car je suis convaincu que la bonne question n'est pas quel outil mais comment tu construis ton système. Tu as 20 minutes pour discuter aujourd'hui ou demain ?"

### Variante courte (DM Instagram / WhatsApp)

> "Salut Marie ! Vu ton like sur le Reel ChatGPT, j'ai été voir ton profil. Ton approche de l'IA me parle beaucoup, t'es pas dans le buzz mais dans le concret. Je cherche à parler à des gens comme toi qui utilisent l'IA tous les jours mais galèrent à en faire un vrai système. 20 min cette semaine ?"

### Ce qui différencie le bon du mauvais

- Pas de compliment creux ("pour un métier aussi qualifié que le tien...").
- Pas d'observation vendeuse ("ce que je remarque souvent chez les gens comme toi...").
- Pas de phrase scriptée ("je te montre juste comment moi je m'y prends").
- Le message respire. On sent quelqu'un qui a lu, qui a réagi, qui demande naturellement.

---

## Étape 3 : choisir le canal et envoyer via Beeper

Beeper agrège tous les canaux. On choisit selon les infos présentes dans la fiche, par ordre de priorité.

1. **LinkedIn DM** si le profil est renseigné. Canal par défaut quand le nid vient de LinkedIn.
2. **WhatsApp / iMessage / SMS** si `Téléphone` est renseigné et qu'on veut un canal plus direct.
3. **Instagram DM** si un compte Insta apparaît (nid Instagram ou `Recherche Google`).
4. **Email** en dernier recours (`Email` renseigné), objet court et même structure.

Procédure Beeper :
1. Ouvrir Beeper.
2. Rechercher la personne par son nom dans le réseau choisi, ou ouvrir la conversation existante.
3. Coller le message personnalisé construit à l'étape 2.
4. Adapter la longueur au canal : version complète pour LinkedIn / email, version courte pour Instagram / WhatsApp.
5. Envoyer.

Bonnes pratiques :
- Un message = une personne. Jamais de copier-coller brut : on adapte prénom, point commun, ressenti.
- Pas de lien dans le 1er message.
- Une seule demande : les 20 min.

---

## Étape 4 : mettre à jour le statut

Dès que le message est parti :
1. Ouvrir la ligne dans le board.
2. Passer `Statut` de **`à contacter`** à **`contacté`**.
3. (Optionnel) noter dans `Commentaire` le canal et la date (ex : "Contacté LinkedIn 17/06").

Le passage de statut horodate `UpdatedAt`. Ce timestamp sert de point de départ au calcul des relances.

---

## Exemples

### Conseillère immobilier indépendante

Fiche : **Elisabeth Pisigot** (Score ICP 83). Conseillère immobilier indépendante, +100 ventes actées, 5 446 abonnés, problem aware. Téléphone et profil renseignés. Nid : commentaire sous un post d'Ugo sur le skill LOOP.

> "Salut Elisabeth, j'ai découvert ton profil sous un post d'Ugo, j'étais curieux donc je suis allé voir ce que tu faisais. +100 ventes actées et une audience de plus de 5 000 personnes, franchement ça force le respect. En ce moment je cherche à parler à des indépendants qui gèrent tout de A à Z, car je suis convaincu que les meilleurs n'ont pas besoin de plus d'outils mais de mieux capitaliser ce qu'ils font déjà. Tu as 20 minutes pour discuter aujourd'hui ou demain ?"

Canal : LinkedIn DM par défaut, ou WhatsApp via le téléphone. Après envoi : `Statut` -> `contacté`, `Commentaire` -> "Contacté LinkedIn 17/06".

### Coach business

Fiche : **Karim Benali** (Score ICP 78). Coach business, 2 300 abonnés, solution aware. Nid : like sous un reel d'Alex Hormozi.

> "Salut Karim, j'ai vu ton like sous le reel d'Hormozi, du coup j'ai été voir ton profil. J'aime bien ton angle, tu parles de rentabilité mais sans faire le bro marketer, ça change. Je cherche à parler à des coachs qui ont déjà des résultats mais qui sentent qu'ils could être plus systématiques. Tu as 20 min cette semaine ?"

### Fondateur SaaS

Fiche : **Léa Martin** (Score ICP 71). Fondatrice d'un SaaS RH, 45 employés, problem aware. Nid : membre du même groupe LinkedIn "Tech Founders France".

> "Salut Léa, je suis tombé sur ton profil dans le groupe Tech Founders, j'ai cliqué parce que le SaaS RH m'intéresse. Gérer 45 personnes tout en construisant le produit, c'est pas un truc que tout le monde arrive à faire tenir. Je cherche à comprendre comment les fondateurs à cette taille organisent leurs process internes, parce que je pense que c'est là que ça casse ou ça scale. Tu aurais 20 min pour en discuter, ajd ou demain ?"

### Consultant indépendant

Fiche : **Thomas Duval** (Score ICP 65). Consultant en transformation digitale, problème récurrent avec la capitalisation de ses livrables. Unaware. Nid : abonné à la même newsletter (The Morning Brew FR).

> "Salut Thomas, on est abonnés à la même newsletter, j'ai cliqué sur ton profil par curiosité. Ta posture de consultant qui accompagne la transformation plutôt que de vendre des slides, ça me parle. En ce moment j'essaie de comprendre comment les consultants comme toi capitalisent sur leurs missions, parce que j'ai l'impression que c'est le truc que tout le monde refait à chaque fois. Tu as 20 minutes pour discuter cette semaine ?"

---

## Checklist rapide

- [ ] Filtrer `Statut = à contacter`, trier par `Score ICP` décroissant.
- [ ] Lire infos (nom, source, poste, bio, audience, awareness).
- [ ] Construire le message : d'où tu viens + ton ressenti + pourquoi tu veux parler + demande 20 min.
- [ ] Calibrer le ton selon l'awareness.
- [ ] Choisir le canal Beeper (LinkedIn par défaut).
- [ ] Coller le message personnalisé, adapter la longueur, envoyer.
- [ ] `Statut` -> `contacté` + note canal / date dans `Commentaire`.
