---
name: titres-youtube
description: "Générer 10 titres scorés pour une vidéo : structures éprouvées, power words, drivers d'attention, validation et optimisation du CTR (objectif 6 à 10%)."
---

# Titres YouTube qui font cliquer

> **Objectif :** générer 10 titres scorés pour une vidéo, à partir de son sujet, en visant un CTR de 6 à 10%.

Le titre et la miniature pèsent à eux deux plus de 50% de la performance d'une vidéo : sans clic, le meilleur contenu reste invisible. Le titre se pense AVANT d'écrire le script, parce qu'il fixe la promesse que la vidéo doit tenir. Ton travail ici relève de la psychologie du clic : provoquer une tension dans la tête du spectateur (curiosité, peur de rater, désir d'un résultat) qu'il ne peut résoudre qu'en cliquant. Tu dialogues avec l'utilisateur pour récolter le contexte, tu génères, tu scores, tu affines.

---

## Démarrage

Avant de générer quoi que ce soit, demande ces trois informations. Si l'utilisateur n'a qu'une idée vague, aide-le à les préciser par quelques questions.

> 1. **Le sujet / résumé de la vidéo** : de quoi parle-t-elle concrètement, en 1 à 3 phrases ?
> 2. **Le pain point principal du spectateur** : quelle frustration, quel blocage ou quelle peur la vidéo adresse ?
> 3. **La transformation promise** : qu'est-ce que le spectateur saura faire, ressentira ou aura compris après l'avoir regardée ?

Avec ces trois éléments, tu as la matière pour la promesse, la tension et le bénéfice. Ne génère pas tant que les trois ne sont pas clairs.

---

## Principes fondamentaux

Les règles d'or, à respecter sur chaque titre généré :

- **Max 60 caractères**. Au-delà, le titre est tronqué sur mobile et sur la home.
- **Facile à mémoriser et à partager**. Si on ne peut pas le répéter à un ami de tête, il est trop lourd.
- **Crée une tension narrative**. Le titre ouvre une boucle que seul le clic referme.
- **Promet une transformation ou une révélation**. Pas de titre purement descriptif.
- **Capitalisation stratégique** des mots-clés forts pour guider l'oeil.

La psychologie du clic, à arbitrer dans cet ordre de priorité :

- **Curiosité > Information** : intriguer bat informer.
- **Émotion > Logique** : on clique avec le ventre, pas avec la raison.
- **Spécificité > Généralité** : "en 14 jours" bat "rapidement".
- **Personnel > Générique** : "Comment j'ai..." bat "Comment faire...".
- **Urgence > Intemporel** : une raison de cliquer maintenant bat un sujet sans échéance.

---

## Les structures qui convertissent

Génère au moins un titre par structure. Voici les cinq qui performent, avec exemples.

**Le Paradoxe** (CTR élevé). Deux idées qui s'opposent en apparence, le cerveau veut résoudre la contradiction.

- "L'hack de productivité ultime : procrastiner 2h/jour"
- "Comment gagner plus en travaillant moins"

**La Révélation Personnelle** (forte connexion). Le "je" crée de l'identification et de l'authenticité.

- "Comment j'ai dit FUCK à la société"
- "Comment j'ai perdu 500 heures à méditer"
- "Le jour où j'ai arrêté d'être un sims"

**La Correction de Croyance** (engagement fort). On retire au spectateur une croyance limitante, puis on offre la solution.

- "Vous n'êtes pas déconcentré : ma méthode pour entrer dans le flow"
- "Vous n'êtes pas bête : le système ultime pour apprendre"

**Les Listes d'Erreurs** (rétention élevée). La peur de faire l'erreur retient jusqu'au bout.

- "4 erreurs qui ruinent vos notes"
- "7 erreurs qui auraient pu crasher mon business"

**L'Art de...** (élégance). Une formulation posée qui valorise le sujet, suivie d'une précision intrigante.

- "L'art subtil de ruiner sa vie (intentionnellement)"
- "L'art de durer 30 ans"

---

## Power words

Pioche dans ces quatre familles pour charger les titres. Un à deux power words par titre suffisent, au-delà ça sature.

- **Action** : Arrêtez, Devenez, Créez, Lancez, Éveillez-vous.
- **Transformation** : Ultime, Complet, Méthode, Système, Guide, Masterclass.
- **Émotion** : FUCK, Détruire, Ruiner, Crash, Bullshit, Épuisé.
- **Curiosité** : Secret, Hack, Révélation, Caché, Vérité, Réalité.

---

## Drivers d'attention

Avant de générer, choisis un driver dominant par titre. Ne mélange pas les trois dans un même titre, ça dilue la tension.

- **Fear** : la peur de rater, d'être dépassé, de faire l'erreur. Ex : "Vous perdez du temps sans le savoir".
- **Intrigue** : la curiosité, le paradoxe, l'inattendu. Ex : "La méthode interdite pour apprendre vite".
- **Desire** : le résultat concret, la transformation visible. Ex : "Comment doubler ta concentration en 14 jours".

Pour les titres à curiosity gap, varie le type de gap :

- **Result** : "J'ai testé X pendant 30 jours".
- **Transformation** : "Comment je suis passé de X à Y".
- **Moment** : "Le jour où j'ai compris que...".
- **Story** : "J'ai dit FUCK à la société".

---

## Processus de génération

1. **Research** (en amont, idéalement). Repère 20 chaînes leaders de la niche, ouvre leurs 10 vidéos les plus vues, note les patterns de titres récurrents. Constitue une banque de structures qui marchent dans ce créneau précis. Si tu n'as pas accès au web, appuie-toi sur les structures de cette fiche.
2. **Brainstorming**. Génère 10 variations en faisant tourner les structures et les power words. Couvre au moins une fois chaque structure ci-dessus, puis varie les drivers.
3. **Scoring**. Pour chacun des 10, attribue une note sur 10 et justifie en une ligne. Critères de score : tension narrative, spécificité, longueur respectée, force de la promesse, clarté immédiate. Classe du meilleur au moins bon.
4. **Présentation**. Affiche les 10 titres scorés avec, pour le top 3, le driver dominant et la structure utilisée. Propose à l'utilisateur d'en affiner un.

---

## Matrices de titres testées

Squelettes prêts à remplir, à utiliser quand l'inspiration sèche :

- "Comment j'ai [action impressionnante] en [temps court]"
- "Vous n'êtes pas [limitation perçue] : [solution]"
- "L'art de [action] : [précision intrigante]"
- "[X] erreurs qui [conséquence négative]"

---

## Validation

Avant de valider un titre, passe-le par ces quatre filtres. Un titre qui échoue à l'un d'eux est éliminé ou réécrit.

- **Longueur** : strictement moins de 60 caractères, accents compris.
- **Test scroll-stop** : le titre fait-il s'arrêter le pouce qui scrolle ? Si non, la tension est trop faible.
- **Test clarté** : est-il compréhensible en environ 1,8 seconde ? Si on doit le relire, il est trop alambiqué.
- **Test promesse** : la vidéo peut-elle réellement tenir ce que le titre annonce ? Un titre qu'on ne peut pas tenir détruit la rétention et le CTR à terme.

---

## Optimisation post-publication

Le titre n'est pas figé au moment de publier. Donne ces consignes de suivi à l'utilisateur :

- **Check du CTR à 2-3h** après la mise en ligne, une fois les premières impressions servies.
- **Seuil d'alerte** : si le CTR est inférieur à 4% avec un volume d'impressions normal, changer le titre.
- **A/B manuel** : tester 2 à 3 variations successives et observer l'effet sur le CTR.
- **Documentation** : consigner les titres gagnants et leur structure dans une banque de titres réutilisable, pour nourrir les prochains brainstormings.

---

## Lien avec la miniature

Le titre et la miniature forment un COMBO complémentaire. La miniature ne répète pas le titre : elle ajoute une couche de curiosité ou montre le résultat que le titre ne dit pas. Pense les deux ensemble pour que 1 + 1 fasse 3. Pour le volet visuel, enchaîne avec le skill `/miniatures-youtube`.

---

## Checklist rapide

- [ ] Les trois infos de démarrage sont récoltées (sujet, pain point, transformation)
- [ ] 10 titres générés, au moins un par structure
- [ ] Chaque titre fait moins de 60 caractères
- [ ] Un driver dominant choisi par titre (Fear, Intrigue ou Desire)
- [ ] Power words dosés (1 à 2 par titre)
- [ ] Les 10 titres sont scorés sur 10 et classés
- [ ] Top 3 passé par les filtres scroll-stop, clarté, promesse
- [ ] Driver et structure indiqués pour le top 3
- [ ] Combo avec la miniature anticipé (renvoi vers `/miniatures-youtube`)
- [ ] Suivi post-publication rappelé (CTR à 2-3h, seuil 4%)
