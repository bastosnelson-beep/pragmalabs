---
name: avant-apres
description: "Produit le tableau avant/après (point A vers point B) dans les mots exacts des clients, puis en tire une USP V1 qui passe les 5 critères. Input : ce que tes prospects t'ont dit en interview. Le coeur du copywriting."
---

# L'avant / après : la copy se trouve dans la bouche du client

> **Objectif :** produire le tableau avant/après (point A vers point B) en mots EXACTS des clients, puis en tirer une USP V1. Input : ce que tes prospects t'ont dit en interview. Output : un tableau 5 lignes x 2 colonnes + une USP qui passe les 5 critères.

C'est le coeur du copywriting. Ton offre, c'est d'amener les gens d'un point A bien défini, bien clair, à un point B bien défini, bien clair, grâce à des étapes. Avant de pricer, avant de packager, tu dois savoir où en sont tes prospects aujourd'hui et où ils veulent vraiment aller. En leurs mots, pas dans les tiens.

Cette étape se place juste après la clarification de l'ICP et juste avant la construction de l'architecture de l'offre (les étapes A vers B, puis les problèmes par étape).

---

## Principe directeur

Les mots du client = la meilleure copy que tu écriras jamais. Trois règles qui découlent de là.

1. **L'avant/après d'hier soir = tes suppositions. Celui d'après les appels = leurs mots exacts.** Le matin tu as des données réelles, des vraies personnes avec de vrais problèmes. Hier soir tu avais une idée, ce que TOI tu pensais. La différence entre les deux, c'est la qualité de toute ton offre.
2. **Le point B est une IMAGE CONCRÈTE, jamais une émotion abstraite.** "Elle signe 2 nouveaux clients par mois sans cold calling" est utilisable. "Elle se sent épanouie" ne l'est pas. Tu dois pouvoir la visualiser dans un moment précis de son quotidien.
3. **Descends sous le factuel.** Quand un prospect dit "je n'arrive pas à faire ça", le vrai avant n'est pas l'action ratée : c'est "il se sent incompétent, syndrome de l'imposteur, peur du jugement". Le plus tu comprends les mécanismes psychologiques cachés, le plus tu es pertinent et spécifique dans ton marketing.

---

## Étape 1 : récolter les mots exacts (ne pas reformuler)

**Méthode :** avant de remplir quoi que ce soit, va chercher le verbatim brut. Si tu as fait tes interviews, demande à la personne : "Raconte-moi ce que les gens t'ont dit pendant les interviews ou dans les DMs. Utilise leurs mots exacts, pas ta reformulation, leurs mots." Si elle n'a pas encore interviewé, marque chaque ligne `[SUPPOSITION A VALIDER]` et renvoie-la au protocole d'interview avant de figer quoi que ce soit.

**Outils :** support et Intercom, Q&A de webinaire, commentaires sous les ads et les posts organiques, objections en call de vente, raisons de churn. Ces sources contiennent déjà les mots du client. Tu lis avant de demander une opinion.

**Piège :** reformuler les mots du client pour "faire plus pro". Tu perds la copy au moment où tu la trouves. Copie-colle, ne paraphrase pas.

Une règle de récolte : ce que tu cherches à l'avant n'est pas l'action ("il n'écrit pas assez vite"), c'est la peur ou la croyance dessous ("il se sent superficiel, il a peur que son business s'effondre s'il arrête de publier").

---

## Étape 2 : remplir le tableau 5 lignes x 2 colonnes

**Méthode :** un tableau à 2 colonnes (AVANT = point A, APRÈS = point B) et 5 lignes. Tu reprends à l'avant tous les problèmes que tu as déjà ciblés à l'étape ICP, et tu construis l'après en miroir.

| Ligne | AVANT (point A) | APRÈS (point B) |
|---|---|---|
| Ce qu'ils font au quotidien | leurs gestes et galères concrètes | ce qu'ils pourront enfin faire |
| Ce qu'ils ressentent | stress, fatigue, honte, imposture | comment ils veulent se sentir |
| Ce qu'ils craignent | la peur qui les réveille la nuit | la peur levée |
| Ce dont ils ont honte ou qu'ils évitent | le tabou, le sujet qu'ils fuient | ce qu'ils assument enfin |
| Ce qu'ils veulent vraiment | le désir réel sous le factuel | le résultat rêvé en image |

**Outils :** la méthode pour creuser l'après, c'est l'empathie active. Ferme les yeux, mets-toi dans ses baskets, ressens ce que la personne ressent et où elle veut aller. Décris-le dans des moments spécifiques du quotidien. Le plus tu es spécifique, le plus ça marche.

**Piège :** un point B émotionnel et flou ("elle se sent fluide et alignée"). Une émotion ne se vend pas, une image se vend. Transforme chaque émotion en scène concrète : pas "elle est sereine" mais "elle ferme son ordi à 17h et ses 2 clients du mois sont signés".

Quand le tableau est rempli avec les mots récoltés, tu tiens déjà 80% de ta page de vente.

---

## Étape 3 : réécrire l'USP à partir du tableau

**Méthode :** une fois l'avant/après posé, l'USP se déduit. Format :

> "J'aide [cible] à [résultat APRÈS en leurs mots] en [temps] grâce à [mécanisme = les étapes nommées]"

Le résultat se prend directement dans la colonne APRÈS. Le mécanisme, ce sont les étapes A vers B que tu nommeras juste après. Le temps vient de ta promesse.

**Outils :** les 5 critères PMDMT. Une bonne USP est :

| Critère | Ce qu'il exige | Test rapide |
|---|---|---|
| **Précise** | pas vague, on sait exactement quoi | "être plus serein" non, "arrêter de ruminer au quotidien" oui |
| **Mesurable** | un résultat quantifiable ou observable | "+3000€", "+30% de rétention", "2 clients par mois" |
| **Désirable** | validée par de vraies personnes, pas inventée dans ta tête | tirée du verbatim, pas du fantasme |
| **Mécanisée** | un process nommé qui t'appartient | "le cold emailing authentique", pas "ma méthode" |
| **Temporellement définie** | en combien de temps exactement | "en 14 jours", "en 4 mois", "en 2 mois" |

**Outils :** fais de la divergence. Écris autant d'USP que tu peux, formulées différemment, puis tu convergeras. Le plus d'itérations, le meilleur le résultat. Teste laquelle résonne, et regarde aussi l'alignement intérieur : est-ce la cible que tu as vraiment envie d'aider, est-ce un mécanisme auquel tu crois.

**Piège :** une USP qui ne passe pas le test "mesurable" et "temporellement définie". Les gens cherchent une transformation datée, plus de l'information. Sans chiffre et sans délai, tu vends de l'encyclopédie.

---

## Exemples

### Bon (Atomic Perspectives, verbatim à copier intégralement)

> **AVANT :** "Syndrome de l'imposteur, pas de méthode, j'ai l'impression d'être superficiel, peur que mon business s'effondre si j'arrête de publier, je cours après les dernières tendances sans jamais aller en profondeur."
>
> **APRÈS :** "Expert reconnu dans mon domaine, j'ai créé ma propre méthode originale, j'apporte vraiment de la valeur, mon business tient sur mes idées pas sur mes heures."

Pourquoi c'est bon : l'avant nomme la peur cachée (imposteur, business qui s'effondre), pas seulement l'action ratée. L'après est une scène concrète et désirable ("tient sur mes idées pas sur mes heures"), pas une émotion floue.

### Bon (Atomic Investing, verbatim)

> **AVANT :** "Ils ont entendu parler de la bourse mais ça reste obscur, ils ne savent pas comment investir leur argent, pas de clarté financière, la FOMO, peur de passer à côté d'une bonne opportunité, peur de ne pas avoir de retraite, peur de rater leur vie à cause de ce manque de sécurité financière."
>
> **APRÈS :** "Ils ont regagné de la clarté, une stratégie d'investissement résiliente sur 50 ans, tous les outils pour créer et gérer leur portefeuille, et vivent de leurs revenus passifs à 100% d'ici 10 ans."

Pourquoi c'est bon : la peur est nommée avec son jargon ("FOMO"), l'après est chiffré et temporalisé ("résiliente sur 50 ans", "100% d'ici 10 ans"). On en tire directement la promesse : "en un week-end vous avez tout intégré, en un an des résultats significatifs, en 20 ans vous prenez votre retraite".

### Mauvais (point B émotionnel)

> "Elle se sent épanouie dans son business."

Pourquoi c'est raté : ce n'est pas une image, c'est une émotion. On ne peut pas la mettre en scène, on ne peut pas la vendre. À remplacer par : "Elle signe 2 nouveaux clients par mois sans faire de cold calling."

### Bon vs mauvais USP

> Bon : "J'aide les copywriters à signer leur premier client à +3000€ en 14 jours grâce au cold emailing authentique." Bon : "J'aide les cafés à augmenter leur rétention client d'au moins 30% en 4 mois grâce à un programme de fidélité automatisé."
>
> Mauvais : "J'aide les entrepreneurs à réussir." Trop vague, pas mesurable, pas temporalisé, pas de mécanisme. Mauvais : "J'aide les mamans à être plus sereines au quotidien." Tu les aides à QUOI ? Avoir une bonne organisation pour être plus sereines, ça oui c'est précis.

---

## Pièges

- **Travailler de mémoire.** Si tu n'as pas le verbatim brut sous les yeux, tu inventes. Marque `[A VALIDER]` et retourne interviewer.
- **Paraphraser.** Reformuler les mots du client te fait perdre la meilleure copy au moment où tu la tiens.
- **Point B abstrait.** "Aligné", "épanoui", "serein" ne se vendent pas. Une scène concrète dans un moment précis du quotidien, oui.
- **Rester en surface.** Si tu t'arrêtes au factuel ("il n'arrive pas à publier"), tu rates le levier émotionnel ("il se sent superficiel, il a peur du jugement").
- **USP sans chiffre ni délai.** Elle échoue aux critères Mesurable et Temporellement définie : tu vends de l'information, pas une transformation.

---

## Références

- Formation vidéo : <a href="/plateforme/business-os/atomic-offers">Atomic Offers</a> -&gt; la leçon "4 - Créer une USP" est la source directe de cette méthode (avant/après + 5 critères PMDMT, exemples Consult et Investing).
- Formation vidéo : <a href="/plateforme/business-os/challenge-offre-aligne">Challenge Offre Alignée</a> -&gt; le challenge 5 jours où l'avant/après se construit en amont sur une offre alignée.
- Skill amont : <a href="/plateforme/business-os/bases-marketing__cartographier-icp">cartographier-icp</a> -&gt; fournit la cible et le verbatim que ce skill transforme en avant/après.
- Skill aval : <a href="/plateforme/business-os/offre__problemes-par-etape">problemes-par-etape</a> -&gt; nomme les étapes A vers B qui deviennent le mécanisme de l'USP.
- Skill voisin (Theme A) : <a href="/plateforme/business-os/bases-marketing__cartographier-croyances">cartographier-croyances</a> -&gt; même matière psychologique, exploitée pour reframer les croyances bloquantes.

---

## Checklist

- [ ] Verbatim brut récolté (support, Q&A, commentaires, calls) avant toute opinion.
- [ ] Tableau 5 lignes (quotidien / ressentent / craignent / honte / veulent vraiment) x 2 colonnes rempli avec les MOTS exacts.
- [ ] Avant creusé sous le factuel jusqu'aux peurs et croyances cachées.
- [ ] Chaque point B est une image concrète et datable, pas une émotion.
- [ ] Lignes non sourcées marquées `[A VALIDER]` et renvoyées en interview.
- [ ] USP V1 écrite au format "J'aide [cible] à [résultat] en [temps] grâce à [mécanisme]".
- [ ] USP testée sur les 5 critères PMDMT (Précise, Mesurable, Désirable, Mécanisée, Temporellement définie).
- [ ] Plusieurs versions d'USP générées puis convergées sur celle qui résonne.

---

Chaînage : ce skill vient après `/cartographier-icp` (qui livre la cible et le verbatim) et alimente `/problemes-par-etape` (les étapes A vers B deviennent le mécanisme de l'USP), dans le workflow Construire une offre.
