---
slug: bases-marketing__creer-base-produit
command: /creer-base-produit
---

# Créer la base marketing d'un produit dédié

> Objectif : à partir d'une offre précise ET de la base psychographique (fiche ICP + carte des croyances + sujets chauds déjà produits par le workflow bases-marketing), construire le document "base marketing produit" qui sert de source unique à tous les livrables de vente (page de vente, VSL, mails).

La carte des croyances te dit ce que ta cible pense aujourd'hui et ce qu'elle doit penser pour acheter. Les sujets chauds te disent ce que le marché cherche activement. Ce skill prend ces deux matériaux et les met au service d'UNE offre précise : il produit la "base marketing produit", un seul document assemblé que tu relis avant d'écrire la moindre page de vente, le moindre script VSL, le moindre mail. Sans cette base, chaque livrable repart de zéro et perd la cohérence du big domino.

Ce skill vient après `cartographier-icp` et `cartographier-croyances`. Il relit le matériau existant sous l'angle produit et y ajoute les 5 briques qui manquent pour écrire des livrables.

## Principe directeur

Trois règles non négociables, reprises de la formation Atomic Funnels :

1. **Rien avant la base.** Ne rédige aucune page, aucun script, aucun mail tant que ce document n'est pas rempli. La base est le travail, le livrable n'est que de la mise en forme.
2. **Du concret, jamais d'abstraction.** Chaque ligne doit être une image dans la journée du prospect, pas un concept. "Il est stressé" ne dit rien. "Il reçoit 80 mails par jour et ne sait jamais par quoi commencer" se vend. Pour chaque mot abstrait, demande : "concrètement, ça ressemble à quoi dans sa journée ?"
3. **Tout sert le big domino.** Chaque section de chaque livrable doit faire tomber la croyance unique. Si une section ne sert pas le big domino, coupe-la.

## Étape 1 : La cartographie psychologique (5 croyances)

La carte des croyances déjà produite range le matériau en 4 dimensions (thématique, lui-même, créateur, produit) avec un départ, une chaîne, une arrivée. Les 5 croyances ci-dessous sont une RELECTURE produit de cette même carte, focalisée sur le big domino. Tu reprends le verbatim et les croyances déjà sourcées, et tu les reclasses dans les 5 cases qui structurent la VSL.

La base alimente la VSL : les 3 croyances véhicule, interne et externe correspondent directement aux 3 histoires du même nom ; la situation actuelle nourrit l'histoire d'origine et la douleur ; la situation désirée nourrit l'histoire de la solution et la transformation. Au passage au script, tu réordonnes le verbatim déjà sourcé, qui se retrouve tel quel dans la trame.

| Élément | Question | Lien avec la carte des croyances |
|---|---|---|
| **Situation actuelle** | Où est le prospect aujourd'hui ? Frustrations, habitudes, problèmes précis du quotidien. | Croyances de départ (verbatim sourcé). |
| **Situation désirée** | Où veut-il aller ? Concret et mesurable, jamais "être heureux". | Croyances d'arrivée, dimension thématique + rêve de l'ICP. |
| **Croyance véhicule** | Pourquoi pense-t-il que ta méthode ne marcherait pas ("ça ne marche plus", "j'ai déjà essayé") ? | Croyances de départ sur le produit et le mécanisme. |
| **Croyance interne** | Pourquoi pense-t-il qu'il n'y arrivera pas personnellement ("moi je suis nul en rédaction") ? | Croyances de départ sur lui-même. |
| **Croyance externe** | Qu'est-ce que son environnement l'empêche de faire ("pas le temps", "ma femme ne comprend pas") ? | Croyances de départ sur la thématique et l'environnement. |

**Outils :** un doc unique (Obsidian, Google Docs), une case par croyance, le verbatim de la carte des croyances sous les yeux.

**Piège :** rester abstrait. Mauvais : "il est stressé". Bon : "il reçoit 80 mails par jour et ne sait jamais par quoi commencer". Remplis les 5 cases avant de passer à la suite.

## Étape 2 : Avant / Après en images concrètes

Deux colonnes, 5 lignes minimum chacune. Le quotidien précis avec le problème à gauche, le quotidien idéal après la solution à droite. Chaque ligne est une image, jamais un concept.

| AVANT | APRÈS |
|---|---|
| Le quotidien précis avec le problème | Le quotidien idéal après la solution |
| Émotions, situations, sentiment d'impasse | Sensations concrètes, nouveau rapport à la vie |

**Outils :** le test du "concrètement". Pour chaque mot abstrait (liberté, sérénité, épanouissement), demande "à quoi ça ressemble dans une journée ordinaire ?".

> Bon : "vous vous réveillez et pouvez travailler depuis votre cuisine ou depuis Lisbonne"
> Mauvais : "vous vous sentez libre"

> Bon : "vous ne ressentez plus ce nœud dans le ventre le lundi matin"
> Mauvais : "vous retrouvez la sérénité"

On voit la cuisine, on voit Lisbonne, on sent le nœud dans le ventre. "Libre" et "sérénité" ne déclenchent aucune image, donc aucune envie d'acheter.

## Étape 3 : Les 19 questions (la base marketing complète)

19 questions réparties en 4 catégories. Tu réponds une fois, tu réutilises partout. Si une réponse est déjà dans l'avant/après, tu laisses la case vierge. La catégorie "problème" reprend l'avant et y ajoute ce qui manque dans une page de vente : la source réelle du problème, pourquoi il est dur à résoudre, pourquoi les solutions précédentes ont échoué.

### Catégorie 1 : Le problème

1. Quel est le problème dur à résoudre ? (le plus précis possible)
2. En quoi affecte-t-il le quotidien concrètement ?
3. Dans quelle situation est-il le plus douloureux ?
4. **Quelle est la source réelle du problème ?** (ce que les autres méthodes ignorent = le mécanisme différenciateur)
5. Pourquoi est-il difficile à résoudre ? (structurel, systémique, complexe)
6. Pourquoi les solutions précédentes n'ont pas marché ?

La question 4 porte le mécanisme différenciateur. Verbatim de la formation : "là où ça va être intéressant c'est la source, la réelle source du problème. Ça on l'a pas identifié, c'est super important dans une page de vente."

### Catégorie 2 : La solution

7. Quelle est la solution au problème ?
8. Comment répond-elle mieux que les alternatives ?
9. Quelle est la preuve que ça marche ? (étude, témoignages, chiffres)

### Catégorie 3 : Le résultat

10. Comment la solution transforme-t-elle le quotidien ?
11. Quels résultats concrets va accomplir le prospect ?
12. Quelles émotions va-t-il ressentir ?
13. Comment va-t-il être perçu différemment par les autres ?
14. Que se passe-t-il s'il ne passe PAS à l'action ? (le pire scénario)

### Catégorie 4 : L'appel à l'action

15. À quoi ressemble le produit concrètement ?
16. Contenu orienté bénéfices (toujours avec un "pour")
17. Quel est le prix ?
18. Quelle est la garantie ? (ce qui casse les dernières objections : confiance, prix, faisabilité)
19. **Pourquoi agir maintenant ?** (urgence non négociable)

Sur la question 19, verbatim : "il faut toujours de l'urgence. Je n'ai jamais réussi à faire fonctionner un tunnel de vente sans urgence. J'en ai créé des dizaines et des dizaines." Si le problème n'est pas urgent par nature, l'urgence vient d'une promotion à durée limitée ou de la fermeture des portes. Sans urgence, aucune décision.

## Étape 4 : Les bénéfices ([caractéristique] POUR [bénéfice])

Chaque élément du produit se formule [caractéristique] **pour** [bénéfice concret]. Verbatim : "à chaque fois, je parle d'une caractéristique du produit ou d'un élément abordé et je montre directement le bénéfice." On force le "pour" sur chaque ligne, même quand la caractéristique semble se suffire.

**Outils :** la liste des modules et éléments du produit, transformés un par un.

**Piège :** lister des caractéristiques nues. "Un playbook sur le canal en question" est factuel et froid. Force le "pour" : "pour ne plus être dans le flou et savoir spécifiquement quel message envoyer et à qui."

Transforme aussi chaque objection fréquente en bénéfice : "accès à vie" devient "vous pouvez y revenir à n'importe quel moment de votre vie, même dans 3 ans".

> Bon : "2 playbooks détaillés sur le canal POUR savoir exactement quel message envoyer, à qui, et quel suivi enchaîner, aucune approximation"
> Mauvais : "2 playbooks sur le canal"

Le prospect projette le résultat dans sa vie. La version nue décrit le produit sans rien promettre, donc rien ne donne envie.

## Étape 5 : Le big domino

Le big domino est la croyance ultime que le prospect doit avoir pour n'avoir d'autre choix que d'acheter. Verbatim : "tu n'as pas besoin de convaincre ton client de plein de choses. Tu as juste besoin de le convaincre d'une grande croyance." Tout le reste du marketing ne fait que la marteler sous tous les angles.

**Formule exacte :**

> "Si j'arrive à faire croire que [mon véhicule unique] est la clé pour [le résultat le plus désiré] ET que la seule façon de l'appliquer est par [ma solution], alors toutes les autres objections deviennent impertinentes."

**Outils :** trois briques à articuler ensemble : ton véhicule unique, la situation désirée, ton produit.

**Piège n.1 :** un véhicule trop large. Verbatim : "le copywriting, il y avait déjà des gros acteurs sur le marché. Ce n'était pas assez spécifique. Et donc j'ai dit, si j'arrive à faire croire que la psycho-structure est la meilleure façon de persuader sur internet." Quand tu débutes, il te faut un véhicule presque unique, dont tu es seul à connaître la recette.

**Piège n.2 :** mentir avec "n'est atteignable que par". Russell Brunson dit "les tunnels de vente ne sont atteignables qu'avec ClickFunnels", et c'est faux (d'autres éditeurs existent). La version authentique : "ClickFunnels est la meilleure solution pour les tunnels de vente." Pour la méditation Vipassana, la méditation seule est atteignable par plein d'autres façons, mais "la méditation Vipassana ACCOMPAGNÉE n'est atteignable que par mon programme" est vrai parce que l'accompagnement est le véhicule unique. Ajoute un qualificatif ("accompagné", "pour ta cible") quand le "n'est atteignable que par" serait faux sans lui.

## Exemples

### Bon (big dominos verbatim de la formation)

> Russell Brunson : "Si j'arrive à faire croire que les tunnels de vente sont la clé pour le succès en ligne et ne sont atteignables qu'avec ClickFunnels, alors toutes les objections deviennent impertinentes."

> Un éditeur de livres spécialisé sur le book funnel : il délaisse le "funnel" (déjà pris, trop large) et s'empare du "book funnel". Tous ses contenus disent la même chose : "la clé pour ton business de formateur ou de conférencier, c'est d'écrire un livre et de faire un tunnel du livre."

> Un coach qui positionne sur les cycles sportifs pour entrepreneurs : "Si j'arrive à faire croire que fonctionner par cycle sportif est la meilleure façon de se sentir bien et d'avoir des relations à succès, et que la seule façon de l'avoir est par mon accompagnement cycle sportif, alors toutes les objections deviennent impertinentes." Cible unique (les entrepreneurs), véhicule unique (les cycles sportifs), besoin particulier (haute énergie, bonnes relations).

Chaque véhicule est spécifique. Chaque big domino fait le lien entre UN véhicule et la situation désirée d'UNE cible. Personne ne concurrence le coach sur "cycles sportifs pour entrepreneurs", alors que l'accompagnement sportif est hyper concurrentiel.

### Mauvais

> "Le sport est la clé pour se sentir bien."

Le véhicule ("le sport") est trop large, des milliers de formateurs en parlent, aucune recette secrète, aucune cible précise. Le prospect n'a aucune raison d'acheter chez toi. Le coach a ingénieurisé une sous-méthode du sport (les cycles) pour une cible précise (les entrepreneurs), et là plus aucune concurrence.

> Avant/après : "vous vous sentez libre et plus serein."

Deux concepts, zéro image. La version qui vend : "vous travaillez depuis votre cuisine ou depuis Lisbonne, vous ne ressentez plus ce nœud dans le ventre le lundi matin."

## Pièges

- **Écrire un livrable avant d'avoir la base.** Tu refais le même travail 4 fois et tu perds la cohérence entre tes assets.
- **Refaire la carte des croyances ici.** Les 5 croyances sont une relecture produit du matériau existant. Reprends le verbatim déjà sourcé, ne repars pas en extraction.
- **Rester abstrait.** Liberté, sérénité, épanouissement : aucune image, aucun désir. Redescends dans la journée du prospect.
- **Un véhicule trop large.** Si un gros acteur occupe déjà le terrain, ton big domino ne fait tomber personne. Spécifie le véhicule jusqu'à l'unicité.
- **Promettre "n'est atteignable que par moi" quand c'est faux.** Préfère "la meilleure façon de", ou ajoute l'angle qui rend ta version vraiment unique (accompagné, pour TA cible).
- **Oublier l'urgence (question 19).** Sans urgence, aucune décision, même avec une base parfaite.
- **Garder une section qui ne sert pas le big domino.** Si elle ne fait pas tomber la croyance unique, coupe-la.

## Références

- Cours Bases marketing, étape 5 : `/plateforme/business-os/bases-marketing/systeme-bases-marketing#etape-5`.
- Amont : `/plateforme/business-os/bases-marketing__cartographier-icp`, `/plateforme/business-os/bases-marketing__cartographier-croyances`, formation Atomic Offers `/plateforme/business-os/atomic-offers`, cours Construire l'offre `/plateforme/business-os/construire-offre/systeme-offre`.
- Aval : `/plateforme/business-os/livrables-marketing__page-de-vente`, `/plateforme/business-os/livrables-marketing__script-webinaire-vsl`, `/plateforme/business-os/livrables-marketing__sequence-email-lancement`.
- Dé-ai-ify : `/plateforme/business-os/livrables-marketing__de-ai-ify-copy`.

## Checklist

- [ ] Cartographie psychologique remplie : situation actuelle, désirée, croyance véhicule, interne, externe (relecture de la carte des croyances, pas une nouvelle extraction).
- [ ] Avant/après, 5 lignes minimum par colonne, chaque ligne est une image concrète.
- [ ] Les 19 questions répondues, dont la question 4 (source réelle = mécanisme différenciateur) et la 14 (pire scénario si pas d'action).
- [ ] Bénéfices au format [caractéristique] POUR [bénéfice], objections fréquentes transformées en bénéfices.
- [ ] Big domino formulé : véhicule unique + résultat désiré + ma solution.
- [ ] Véhicule assez spécifique pour être presque unique (test : un gros acteur l'occupe-t-il déjà ?).
- [ ] Urgence définie (question 19), promo à durée limitée ou fermeture des portes.
- [ ] Test final : chaque section sert le big domino, sinon coupée.

## Cycle complet

Amont : `cartographier-icp` -> `cartographier-croyances` -> **`creer-base-produit`** (ce skill) -> aval : `livrables-marketing__page-de-vente`, `livrables-marketing__script-webinaire-vsl`, `livrables-marketing__sequence-email-lancement`, puis `livrables-marketing__de-ai-ify-copy`. La base produit se construit une fois et alimente tous les livrables de vente.
