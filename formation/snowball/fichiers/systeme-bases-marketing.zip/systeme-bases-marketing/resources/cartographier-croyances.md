---
slug: cartographier-croyances
command: /cartographier-croyances
---

# Cartographier les croyances : le document fondateur de tout ton marketing

> **Objectif :** à partir d'une fiche ICP, produire la carte des croyances d'une cible précise (ce qu'elle croit aujourd'hui : la chaîne intermédiaire : ce qu'elle doit croire pour acheter) plus un backlog de contenus prêt à découper en vidéos, emails, angles de pub et sections de page de vente.

C'est l'étape la moins enseignée du marketing et la plus puissante. Une fois la carte faite, tout le reste découle d'elle : ads, vidéos YouTube, emails, webinars, pages de vente, bonus. Une liste de croyances à reframer, c'est une liste de 250 vidéos YouTube, de séquences email, d'angles de pub. Tu la construis UNE fois, sur UNE fiche ICP à la fois, et toute l'équipe (et l'IA) la lit avant de produire le moindre livrable.

Ce skill nécessite une fiche ICP avec son niveau de conscience comme point de départ. Si tu n'en as pas, cartographie d'abord ton ICP (voir le cours Bases marketing, étape 1).

---

## Principe directeur

Le marketing fonctionne en trois temps, dans cet ordre :

1. **Convaincre** : reframer les croyances une à une jusqu'à ce que le prospect partage ta vision du monde. Tant que les croyances ne sont pas ouvertes, rien d'autre ne marche. C'est de là que viennent toutes les objections.
2. **Persuader** : une fois les croyances ouvertes, jouer l'émotionnel. Le changement de vie, l'avant/après, les leviers psychologiques.
3. **Casser les dernières barrières à l'achat** : confiance, crédibilité, urgence, bonus, formulation d'offre.

Ce skill travaille le temps 1. La règle non négociable : **chaque contenu, chaque pub, chaque email reframe UNE croyance précise.** Une croyance = une Big Idea = un contenu.

Ce skill est dialogique. Tu pars du **verbatim** et de la tête du fondateur, jamais de ton intuition. Si une croyance est supposée et non observée, marque-la `[HYPOTHESE]`.

---

## Input requis

- La fiche ICP avec son niveau de conscience, ses douleurs et son rêve en verbatim.
- Accès au verbatim disponible : support, communauté, commentaires sous les ads, objections en call, raisons de churn et de refus.

Si l'ICP n'existe pas, tu t'arrêtes et tu cartographies d'abord ton ICP (voir le cours Bases marketing, étape 1). Jamais de croyances avant l'ICP.

---

## Étape 1 : Les croyances de départ du prospect

**Méthode :** lister ce que la cible croit AVANT tout contact avec le marketing, y compris (surtout) les croyances qui bloquent l'achat. Tu pars du verbatim, pas de l'intuition. Chaque croyance se classe dans une des 4 dimensions et porte sa source.

Les 4 questions pour extraire :

| Dimension | Question pour la faire sortir | Exemple verbatim PropertyFilter |
|---|---|---|
| **La thématique** | Qu'est-ce qu'elle croit sur le domaine, qui est faux ou incomplet ? | "l'immobilier c'est risqué", "il faut être qualifié en travaux", "pas dans ma région" |
| **Elle-même** | Qu'est-ce qu'elle croit sur elle qui l'auto-sabote ? | "je n'aurai pas le temps", "je ne suis pas capable" |
| **Le créateur** | Qu'est-ce qu'elle croit sur toi, ta catégorie de produit ? | (à creuser : "encore un outil de plus") |
| **Le produit** | Quelles phrases reviennent dans les objections et les refus ? | "vous n'êtes qu'un software, il y a des concurrents à 19 livres par mois" |

**Outils :** les sources de vérité de la fiche ICP (les vraies citations), plus les croyances véhicule / interne / externe si tu les as déjà travaillées (croyance véhicule = "pourquoi ta méthode ne marcherait pas pour lui", croyance interne = "pourquoi il pense ne pas pouvoir y arriver", croyance externe = "ce qui dans son environnement l'empêche d'agir").

**Piège :** inventer des croyances depuis ton fauteuil. Une croyance non sourcée se marque `[HYPOTHESE]` et part en liste de questions à valider, elle ne devient pas une base de contenu tant qu'elle n'est pas confirmée.

Exécution : pour la cible choisie, fais sortir 8 à 15 croyances de départ, classe-les dans les 4 dimensions, note pour chacune sa source (citation exacte ou `[HYPOTHESE]`).

---

## Étape 2 : Les croyances d'arrivée

**Méthode :** remplir le framework des croyances que le prospect doit avoir en tête au moment de sortir sa carte. Une croyance par ligne, formulée **comme LUI se la dirait**, dans les 4 mêmes dimensions.

Le cadre à remplir, "les croyances que mon prospect doit avoir en tête pour acheter mon produit" :

- **Sur la thématique** : exemples PropertyFilter, "c'est un buyer market, c'est LE moment", "le vrai jeu c'est les motivated sellers, pas Rightmove".
- **Sur lui-même** : "je suis capable de le faire sans être un expert en travaux", "j'ai le temps si la recherche est divisée par 10".
- **Sur moi, sur le créateur** : "ils sont investisseurs eux-mêmes, ils ont construit l'outil pour eux", "ils veulent mon succès, pas juste mon abonnement".
- **Sur mon produit** : "ce n'est pas un software, c'est un écosystème : leads plus méthode plus communauté", "comparé à un mastermind à 20 000 livres, c'est un no-brainer".

**Outils :** la fiche ICP (le rêve et le vocabulaire donnent le ton exact). Le Big Domino aide à trouver LA croyance centrale dont tout dépend : "si j'arrive à faire croire que [mon véhicule unique] est la clé pour [résultat le plus désiré] ET que la seule façon de l'appliquer est par [ma solution], alors toutes les autres objections deviennent impertinentes". Exemple de Big Domino : "Les tunnels de vente sont la clé du succès en ligne et ne sont maîtrisables qu'avec cet outil".

**Piège :** écrire les croyances d'arrivée en langage marketing au lieu du langage du prospect. "Notre solution est un écosystème complet" est mort. "Ce n'est pas un software, c'est un écosystème" est vivant, parce que c'est lui qui le pense.

Exécution : remplis les 4 dimensions, une croyance par ligne. Puis applique le **test de complétude** : "si le prospect avait TOUTES ces croyances au vert, qu'est-ce qui pourrait encore l'empêcher d'acheter ?" S'il reste quelque chose, c'est une croyance manquante, ajoute-la.

---

## Étape 3 : Construire la chaîne de croyances

**Méthode :** mettre départ et arrivée en regard, puis construire le chemin marche par marche. Chaque marche est une croyance intermédiaire, donc une Big Idea, donc un contenu potentiel.

Le format de chaîne, une par paire départ vers arrivée :

```text
Croyance de départ : "[ce qu'il croit aujourd'hui]"
  -> marche 1 : "[première prise de conscience]"
  -> marche 2 : "[deuxième prise de conscience]"
  -> ...
Croyance d'arrivée : "[ce qu'il doit croire pour acheter]"
```

Les 3 règles de construction :

- **Une marche = une idée prouvable dans UN contenu** : une étude de cas, une donnée, une actu, une démonstration suffit pour la faire croire.
- **Si le saut entre deux marches demande plus d'un contenu pour être cru, il manque une marche.** Découpe encore.
- **La chaîne commence là où la cible EST, pas où tu voudrais qu'elle soit** : croise avec le niveau de conscience de la fiche ICP. Une cible problem aware démarre plus bas qu'une cible solution aware.

**Outils :** le niveau de conscience de l'ICP (échelle d'Eugene Schwartz) qui fixe le point de départ de la chaîne.

**Piège :** une chaîne avec des sauts trop grands. Si tu passes de "l'immobilier c'est risqué" à "c'est LE moment d'acheter via les motivated sellers" en une marche, personne ne te suit. Il faut les marches intermédiaires (le risque vient d'acheter au mauvais prix, le mauvais prix vient des canaux saturés type Rightmove, le bon prix vient des motivated sellers, etc.).

Exécution : pour chaque croyance d'arrivée prioritaire, écris la chaîne complète depuis sa croyance de départ correspondante.

---

## Étape 4 : Exploiter la carte

**Méthode :** transformer la carte en plan d'action marketing en trois gestes.

1. **Prioriser** : quelles 3 à 5 croyances bloquent le plus d'achats aujourd'hui ? Croise avec les objections les plus fréquentes en call et en commentaire.
2. **Mapper chaque croyance à reframer vers des formats** : une croyance peut devenir une vidéo YouTube, un email de séquence, un angle de pub, une section de page de vente, un contenu de webinar, un bonus d'offre qui adresse directement la croyance.
3. **Brancher l'actu** : pour chaque croyance prioritaire, quel fait d'actualité (prévisions Savills, stats du marché) sert de hook pour la reframer maintenant.

**Outils :** une recherche de sujets chauds (Ahrefs ou autre outil) peut confirmer quelles croyances beaucoup de monde reconnaît (un mot-clé à fort volume = une douleur partagée = une croyance prioritaire à attaquer). Voir le cours Bases marketing, étape 4.

**Piège :** s'arrêter à la carte sans backlog. Une carte sans liste de contenus reste un joli document mort. La sortie utile, c'est la liste où 1 croyance donne N idées de contenus par canal.

Exécution : produis l'output ci-dessous, du verbatim de départ jusqu'au backlog.

```text
CARTE DES CROYANCES - [ICP] (niveau de conscience [X])
Genere le [date]

CROYANCES DE DEPART (verbatim source) :
[par dimension : thematique / lui-meme / createur / produit]

CROYANCES D'ARRIVEE (les 4 dimensions remplies) :
[le framework complet, formule comme le prospect se le dirait]

CHAINES DE CROYANCES :
[chaque chaine depart -> marches -> arrivee]

TOP 5 CROYANCES A REFRAMER EN PRIORITE :
[croyance -> preuve/angle -> formats ou l'attaquer]

BACKLOG DE CONTENUS GENERE :
[liste : 1 croyance = N idees de contenus, par canal]
```

Demande où enregistrer (recommandé : le dossier ressources marketing). C'est le document que toute l'équipe et l'IA doivent lire avant de produire le moindre contenu.

---

## Exemples

### Bon

Croyance d'arrivée sur le produit, PropertyFilter : **"ce n'est pas un software, c'est un écosystème : leads plus méthode plus communauté"** et **"comparé à un mastermind à 20 000 livres, c'est un no-brainer"**.

Pourquoi c'est bon : c'est formulé exactement comme le prospect se le dirait, ça répond à une objection de départ réelle ("vous n'êtes qu'un software, il y a des concurrents à 19 livres par mois") et ça donne directement un angle de pub, un objet d'email et une section de page de vente. La croyance est une Big Idea exploitable.

Une chaîne propre, dimension thématique :

```text
Croyance de depart : "l'immobilier c'est risque"
  -> marche 1 : "le risque vient du prix d'achat, pas de l'immobilier"
  -> marche 2 : "sur Rightmove tout le monde se bat sur les memes biens au mauvais prix"
  -> marche 3 : "les motivated sellers vendent vite et sous le marche"
Croyance d'arrivee : "le vrai jeu c'est les motivated sellers, pas Rightmove"
```

Pourquoi c'est bon : chaque marche est prouvable dans UN contenu, le saut entre deux marches est franchissable, et la chaîne démarre là où la cible EST (elle croit que l'immobilier est risqué).

### Mauvais

> Croyance d'arrivée : "le prospect doit comprendre que notre solution apporte une vraie valeur ajoutée et se différencie de la concurrence."

Pourquoi c'est raté : ce n'est pas sourcé, ce n'est pas classé dans une dimension, et surtout ce n'est pas formulé comme le prospect se le dirait. Personne ne pense "cette solution apporte une vraie valeur ajoutée" en sortant sa carte. C'est du langage marketing, donc inexploitable en contenu. Une croyance vague ne génère ni vidéo, ni email, ni angle de pub.

Chaîne avec un saut trop grand :

```text
Croyance de depart : "je ne suis pas capable"
  -> marche 1 : "achete maintenant"
Croyance d'arrivee : "je suis capable de le faire sans etre expert en travaux"
```

Pourquoi c'est raté : il manque toutes les marches intermédiaires (la recherche est divisée par 10, l'outil gère le tri, des gens comme lui l'ont fait). Le saut demande plus d'un contenu pour être cru, donc la croyance ne se reframe pas.

---

## Pièges

- **Sauter l'ICP.** Sans fiche ICP avec son niveau de conscience, tu ne sais pas où la chaîne commence ni en quel vocabulaire écrire les croyances. Cartographie d'abord ton ICP (voir le cours Bases marketing, étape 1).
- **Inventer les croyances.** Toute croyance non observée se marque `[HYPOTHESE]` et part en liste à valider par interview ou extraction de verbatim.
- **Écrire en langage marketing.** Les croyances se formulent comme le prospect se les dit, pas comme une brochure.
- **Des sauts trop grands dans la chaîne.** Si une marche demande plus d'un contenu pour être crue, découpe encore.
- **Une carte sans backlog.** La carte n'a de valeur que si elle se termine en liste de contenus exploitables par canal.
- **Oublier le test de complétude.** Si tout est au vert et qu'il reste un frein, c'est une croyance manquante.

---

## Références

- Formation **Atomic Offers** (`/plateforme/business-os/atomic-offers`) : la perspective et la vérité non consensuelle qui fondent les croyances sur le créateur. Eliott y montre que ce qui fait acheter chez toi plutôt qu'ailleurs, c'est ta perspective, pas l'information. Sa croyance fondatrice : "on peut designer sa vie de A à Z". Trouve la tienne, elle devient la croyance d'arrivée la plus forte sur le créateur.
- Formation **Idées et Perspective** (`/plateforme/business-os/ides-et-perspective`) : trouver son angle, sa niche et sa perspective différenciante, matière première des croyances d'arrivée.

---

## Checklist

- [ ] Fiche ICP en input, avec son niveau de conscience.
- [ ] 8 à 15 croyances de départ extraites du verbatim, classées dans les 4 dimensions, source notée (`[HYPOTHESE]` si supposée).
- [ ] Croyances d'arrivée remplies dans les 4 dimensions, formulées comme le prospect se les dirait.
- [ ] Test de complétude passé (si tout est au vert, plus aucun frein).
- [ ] Chaînes de croyances construites marche par marche (une marche = un contenu), démarrant au niveau de conscience réel.
- [ ] Top 3 à 5 croyances prioritaires identifiées (croisées aux objections fréquentes).
- [ ] Chaque croyance prioritaire mappée vers des formats (vidéo, email, pub, page de vente, bonus).
- [ ] Output CARTE DES CROYANCES produit, backlog de contenus inclus, lieu d'enregistrement validé.
