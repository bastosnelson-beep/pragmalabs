---
name: systeme-bases-marketing
description: "Transforme \"je veux poser mes bases marketing\" en un dossier source unique (fiches ICP, carte des croyances, sujets chauds, base produit) : il diagnostique l'existant, impose la bonne séquence et route vers le sous-skill qui fait le travail à chaque étape (cartographier-icp, cartographier-croyances, recherche-ahrefs, creer-base-produit). Tu l'invoques toujours, lui pioche la sous-capacité pertinente. Utiliser quand \"je pose mes bases marketing\", \"fais ma carte des croyances\", \"par quoi je commence mon marketing\"."
---

# Bases marketing : l'orchestrateur du socle

> **Ressources de ce pack** (dossier `resources/`) - l'orchestrateur route vers ces sous-capacites :
> - `/cartographier-icp` -> `resources/cartographier-icp.md`
> - `/cartographier-croyances` -> `resources/cartographier-croyances.md`
> - `/recherche-ahrefs` -> `resources/recherche-ahrefs.md`
> - `/creer-base-produit` -> `resources/creer-base-produit.md`


> **Objectif :** transformer "je veux poser mes bases marketing" en un dossier source unique (fiches ICP + carte des croyances + sujets chauds + base produit) en faisant l'état des lieux de l'existant, en imposant la bonne séquence, et en routant vers le sous-skill qui fait le travail à chaque étape. Tu l'invoques toujours, lui pioche la sous-capacité pertinente.

Ce méta-skill est le chef d'orchestre du socle marketing. Il ne refait pas le travail des sous-skills : il diagnostique ce que tu as déjà, il t'oblige à construire dans le bon ordre, et il route vers le sous-skill de l'étape (`/cartographier-icp`, `/cartographier-croyances`, `/recherche-ahrefs`, `/creer-base-produit`). La base marketing se construit **une seule fois** et devient la source que tu lis avant d'écrire la moindre pub, page de vente, email ou VSL. Tant qu'elle n'existe pas, tout livrable produit derrière est générique.

C'est le même principe que partout : l'IA n'invente pas la qualité, elle copie la tienne et la duplique. Une carte des croyances solide, c'est une liste de 250 vidéos YouTube, de séquences email et d'angles de pub déjà cadrés. C'est ce que cet orchestrateur sert à fabriquer, dans l'ordre.

---

## Principe directeur

Une croyance, un contenu, une pub se mappent toujours sur UNE offre précise, pour UNE cible précise, à UN niveau de conscience donné. Donc l'ordre n'est pas négociable :

1. **Offre claire d'abord.** Sans offre, tu n'as rien sur quoi mapper une croyance. Si l'offre n'est pas posée, arrête-toi ici et clarifie ton offre avant de toucher au reste (format USP : j'aide [cible] à [résultat mesurable] en [temps] grâce à [mécanisme unique]). Voir la formation Atomic Offers pour les critères d'un bon marché et d'une offre solide : `/plateforme/business-os/atomic-offers`.
2. **ICP avant croyances.** Une carte des croyances se construit pour une fiche ICP précise et son niveau de conscience. Pas d'ICP, pas de croyances.
3. **Croyances avant sujets chauds.** Les sujets chauds confirment et enrichissent la carte ; ils ne la remplacent pas.

**Mode dialogique, non négociable :** tu poses les questions une à une, tu attends la réponse, tu exiges du verbatim réel. Tu ne remplis jamais un trou par une supposition. Si une info manque, tu la marques `[À VALIDER]` (ICP) ou `[HYPOTHÈSE]` (croyances) et tu continues. Un dossier rempli au feeling se retourne contre toi à l'étape des livrables.

---

## Étape 1 : Faire l'état des lieux

**Méthode :** avant de lancer quoi que ce soit, tu poses quatre questions de diagnostic, une à une, et tu lis ce qui existe déjà. Le but est de savoir où démarrer la séquence, pas de tout refaire.

| Question de diagnostic | Si NON | Si OUI |
|---|---|---|
| As-tu une offre claire ? (USP : "j'aide [cible] à [résultat mesurable] en [temps] grâce à [mécanisme unique]") | Arrête-toi ici. Clarifie ton offre avant tout le reste (format USP ci-dessus). Voir `/plateforme/business-os/atomic-offers` pour la méthode complète. | Continue |
| As-tu une ou des fiches ICP avec leur niveau de conscience ? | Commence par cartographier l'ICP (voir Étape 3a ci-dessous) | Relis-les, vérifie qu'elles ont un niveau de conscience et du verbatim |
| As-tu une carte des croyances pour cette cible ? | Si l'ICP est fait, construis la carte des croyances pour UNE fiche ICP à la fois (voir Étape 3b ci-dessous) | Vérifie qu'elle a départ + arrivée + chaîne |
| As-tu exploité les sujets chauds du domaine ? | Optionnel : lance une recherche de mots-clés pour confirmer/enrichir (voir Étape 3c ci-dessous) | Croise-les avec les croyances prioritaires |

**Outils :** la conversation (les quatre questions ci-dessus) + lecture de l'existant (un dossier "Base marketing", des fiches déjà écrites, du verbatim accessible). Demande explicitement : "Quelles sources de verbatim peux-tu me donner à lire maintenant ? Support, commentaires sous les ads, Q&A, objections en call ?"

**Piège :** sauter le diagnostic et foncer sur la demande littérale de l'utilisateur. S'il dit "fais ma carte des croyances" mais n'a pas d'ICP, le diagnostic est ce qui t'évite de produire une carte orpheline.

Instructions d'exécution : pose les quatre questions dans l'ordre. À la première réponse NON, tu connais ton point d'entrée dans la séquence. Ne pose pas les quatre d'un coup en bloc, déroule-les.

---

## Étape 2 : Imposer la séquence

**Méthode :** une fois l'état des lieux fait, tu énonces la séquence à voix haute et tu la fais respecter. Elle est toujours la même, et chaque étape a son sous-skill :

```text
Offre claire (USP posée, voir /plateforme/business-os/atomic-offers)
  -> /cartographier-icp          (une ou plusieurs fiches, avec niveau de conscience)
  -> /cartographier-croyances    (une fiche ICP à la fois)
  -> /recherche-ahrefs           (confirme et enrichit la carte)
  -> /creer-base-produit         (assemble la base marketing d'UNE offre précise)
  -> Dossier "Base marketing" prêt -> alimente les livrables (page de vente, séquence email, VSL)
```

| État du diagnostic | Route | Ce que le sous-skill produit |
|---|---|---|
| Pas de fiche ICP (ou fiche sans niveau de conscience) | `/cartographier-icp` | fiche(s) ICP + niveau de conscience + shift moment + verbatim |
| ICP posé, pas de carte des croyances | `/cartographier-croyances` | départ verbatim -> chaîne -> arrivée (4 dimensions) + top 5 + backlog |
| Carte posée, sujets chauds non exploités | `/recherche-ahrefs` | 20-50 mots-clés (volume + difficulté) croisés aux croyances |
| Socle posé, une offre précise part en livrables | `/creer-base-produit` | la base marketing produit (5 croyances, avant/après, 19 questions, bénéfices, big domino) |

Tu ne lances jamais l'étape N+1 tant que l'étape N n'a pas produit son livrable validé. Dans le pack .zip, les sous-skills sont dans le dossier `resources/`, un fichier par sous-capacité.

**Piège :** lancer les croyances avant l'ICP, ou l'ICP sans offre. Les deux produisent un travail qui semble avancer mais qui ne se branche sur rien. La règle inverse aussi est un piège : ne re-déroule pas une étape déjà faite proprement, vérifie-la et avance.

Instructions d'exécution : si une étape amont manque, tu reviens dessus avant de continuer, même si l'utilisateur voulait sauter directement à l'aval.

---

## Étape 3 : Router vers le sous-skill de chaque étape

**Méthode :** chaque étape de la séquence a son sous-skill, qui porte la méthode complète. L'orchestrateur ne déroule pas la méthode : il route, passe le contexte (l'offre, la fiche ICP, les sources de verbatim, ce que l'étape amont a produit), et vérifie le livrable avant de passer à la suivante.

### 3a. Clarifier l'offre (si pas encore fait)

**Ce que ça produit :** l'offre + l'USP, point A vers point B.

**Route :** pas de sous-skill ici, c'est le seul cas. Tu rappelles les deux éléments minimaux dont la base marketing a besoin (l'USP au format "j'aide [cible] à [résultat mesurable] en [temps] grâce à [mécanisme unique]" et le mécanisme avant/après), et tu diriges vers la formation Atomic Offers (`/plateforme/business-os/atomic-offers`) et le Challenge Offre Alignée (`/plateforme/business-os/challenge-offre-aligne`) si l'offre n'est pas posée. Tu ne refais pas la méthode de création d'offre.

### 3b. Cartographier l'ICP

**Ce que ça produit :** fiche(s) ICP + niveau de conscience + shift moment + verbatim.

**Route :** `/cartographier-icp` (dans le pack : `resources/cartographier-icp.md`). Le sous-skill porte le portrait en 7 questions, l'échelle des 5 niveaux de conscience, le shift moment et le filtre des 4 critères de marché. Tu lui passes l'offre clarifiée et les sources de verbatim identifiées à l'état des lieux. Tu vérifies au retour : chaque fiche a un niveau de conscience, du verbatim réel, et les trous sont marqués `[À VALIDER]`.

### 3c. Cartographier les croyances

**Ce que ça produit :** départ verbatim -> chaîne -> arrivée (4 dimensions) + top 5 croyances d'arrivée + backlog de contenus.

**Route :** `/cartographier-croyances` (dans le pack : `resources/cartographier-croyances.md`). Une fiche ICP à la fois, jamais deux. Tu lui passes la fiche ICP validée. Tu vérifies au retour : la carte a un départ en verbatim, une chaîne, une arrivée en 4 dimensions, un top 5 et un backlog. La formation Idées et Perspective (`/plateforme/business-os/ides-et-perspective`) aide à fonder les croyances créateur sur un angle et une vérité non consensuelle.

### 3d. Rechercher les sujets chauds

**Ce que ça produit :** liste de 20-50 mots-clés (volume + difficulté) croisée aux croyances.

**Route :** `/recherche-ahrefs` (dans le pack : `resources/recherche-ahrefs.md`). Étape optionnelle mais recommandée. Tu lui passes la thématique et la carte des croyances. Tu vérifies au retour : les mots-clés sont croisés avec les croyances prioritaires, pas juste listés.

---

## Étape 4 : Assembler le dossier et chaîner vers les livrables

**Méthode :** quand le socle est posé (ICP + croyances + sujets chauds), tu assembles un seul dossier "Base marketing" qui devient la source unique lue avant tout livrable.

```text
DOSSIER BASE MARKETING - [produit]

1. FICHE(S) ICP            : qui, douleurs verbatim, rêve, niveau de conscience, shift moment, vocabulaire
2. CARTE DES CROYANCES     : départ verbatim -> chaîne -> arrivée (4 dimensions), top 5, backlog
3. SUJETS CHAUDS           : mots-clés priorisés croisés aux croyances
4. BASE PRODUIT            : 5 croyances, avant/après, 19 questions, bénéfices, big domino (une par offre)
```

**Route :** dès qu'une offre précise part en production de livrables, `/creer-base-produit` (dans le pack : `resources/creer-base-produit.md`). Le sous-skill relit l'ICP, la carte des croyances et les sujets chauds sous l'angle de CETTE offre, et produit le document "base marketing produit" que tu relis avant d'écrire la moindre page de vente, le moindre script VSL, le moindre mail.

**Outils :** un emplacement de stockage stable (recommandé : avec les ressources marketing du produit, là où l'équipe ET l'IA peuvent le lire avant de produire). Demande où l'enregistrer.

**Piège :** laisser les livrables éparpillés. S'ils ne sont pas réunis dans une source unique, personne ne les lit avant d'écrire, et les livrables redeviennent génériques.

Instructions d'exécution : une fois le dossier assemblé, énonce le chaînage aval : la base produit est l'input direct de la page de vente, de la séquence email et de la VSL. Correspondance 1:1 à rappeler : les 5 croyances d'arrivée alimentent les 5 histoires de la VSL.

---

## Exemples

### Bon

> "As-tu une offre claire au format USP ? - Pas vraiment, je vends un software à 19£/mois et je galère à le différencier." Réponse de l'orchestrateur : "Stop, on ne touche pas aux croyances. Ton problème est une offre comparée à un software à 19£/mois, c'est un sujet d'offre. On clarifie l'USP d'abord (voir /plateforme/business-os/atomic-offers pour la méthode), puis on revient poser l'ICP et les croyances."

Pourquoi c'est bon : le diagnostic a détecté l'étape amont manquante (offre floue, verbatim réel "concurrents à 19£/mois") et a refusé d'avancer sur l'aval. C'est exactement le rôle de l'orchestrateur : imposer la bonne séquence, pas exécuter dans le désordre.

### Mauvais

> "Tu veux ta carte des croyances ? Ok, je liste : 'l'immobilier c'est risqué', 'je n'aurai pas le temps', 'je ne suis pas capable'... voilà, c'est parti pour la page de vente."

Pourquoi c'est raté : aucun état des lieux, aucune fiche ICP, des croyances inventées sans verbatim et sans niveau de conscience, et un saut direct vers le livrable. La carte est orpheline, elle ne se branche sur aucune cible précise. L'orchestrateur aurait dû cartographier l'ICP d'abord et exiger du verbatim sourcé, pas des croyances de tête.

---

## Pièges

- **Faire le travail des sous-skills au lieu de router.** L'orchestrateur diagnostique, séquence, route, vérifie. Dès qu'il commence à dérouler lui-même la méthode des 5 niveaux de conscience ou la chaîne de croyances, il sort du cadre : chaque étape a son sous-skill.
- **Exécuter les étapes dans le désordre.** Croyances avant ICP, ICP sans offre : l'inversion de l'ordre est l'erreur la plus fréquente et la plus coûteuse.
- **Sauter le diagnostic.** Foncer sur la demande littérale ("fais X") sans vérifier les prérequis produit une chaîne qui semble avancer mais ne tient pas.
- **Refaire l'offre ici.** "Clarifier l'offre" a sa propre méthode (voir Atomic Offers). On rappelle l'USP et l'avant/après, on ne refait pas la méthode.
- **Remplir les trous par des suppositions.** Marquer `[À VALIDER]` / `[HYPOTHÈSE]` et continuer, jamais inventer pour faire avancer.
- **Laisser les livrables éparpillés.** Sans dossier source unique, la base marketing ne sert à rien à l'étape des livrables.

---

## Références

- Formation : [Les bases marketing](/plateforme/business-os/bases-marketing/systeme-bases-marketing) - le cours que ce méta-skill orchestre.
- Sous-skills routés : [cartographier-icp](/plateforme/business-os/cartographier-icp), [cartographier-croyances](/plateforme/business-os/cartographier-croyances), [recherche-ahrefs](/plateforme/business-os/recherche-ahrefs), [creer-base-produit](/plateforme/business-os/creer-base-produit).
- En aval : [Livrables marketing](/plateforme/business-os/livrables-marketing/systeme-livrables) - la page de vente, la VSL et la séquence email qui se nourrissent de la base.
- En amont : [Atomic Offers](/plateforme/business-os/atomic-offers) et [Challenge Offre Alignée](/plateforme/business-os/challenge-offre-aligne) - poser et valider l'offre avant le socle.

---

## Checklist

- [ ] État des lieux fait : 4 questions de diagnostic posées une à une, existant lu.
- [ ] Offre claire confirmée (USP posée) ou clarification de l'offre engagée avant de continuer.
- [ ] Séquence énoncée et respectée : offre -> ICP -> croyances -> sujets chauds -> base produit.
- [ ] Chaque étape routée vers son sous-skill (`/cartographier-icp`, `/cartographier-croyances`, `/recherche-ahrefs`, `/creer-base-produit`), jamais déroulée par l'orchestrateur.
- [ ] Output de l'étape N passé en contexte au sous-skill de l'étape N+1, et livrable vérifié au retour.
- [ ] Mode dialogique tenu : questions une à une, verbatim réel exigé, trous marqués `[À VALIDER]` / `[HYPOTHÈSE]`.
- [ ] Dossier "Base marketing" assemblé (ICP + carte des croyances + sujets chauds + base produit) dans un emplacement stable.
- [ ] Chaînage aval énoncé : base produit -> page de vente, séquence email, VSL (5 croyances = 5 histoires).
