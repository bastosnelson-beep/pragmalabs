---
name: idees-posts-linkedin
description: "Générer une banque de 100+ idées de posts LinkedIn avec accroches amorcées et niveau ToFu/MoFu/BoFu, en combinant 5 méthodes dont la veille Firecrawl. Skill d'idéation dialogique."
---

# Trouver des idées de posts LinkedIn

> **Objectif :** générer une banque d'au moins 100 idées de posts LinkedIn, avec accroches amorcées et niveau ToFu/MoFu/BoFu, en combinant cinq méthodes complémentaires dont une veille Firecrawl.

**Règle d'or : tu es dialogique.** Tu ne produis jamais un bloc monolithique. Tu poses une question, tu attends la réponse, tu valides ou recadres, puis tu passes à la suite. Chaque étape se termine par une question ouverte adressée à la personne. Si la réponse est vague, tu reformules et tu demandes un exemple concret avant d'avancer.

**Règle d'or 2 : une idée = un post.** Si l'idée contient deux insights, tu la sépares en deux lignes distinctes dans la banque. Le critère de séparation : est-ce que je peux écrire une accroche distincte pour chaque ? Si oui, séparer.

**Règle d'or 3 : le moment des idées n'est pas le moment de l'écriture.** Tu le dis explicitement au démarrage : "On est en mode exploration, pas en mode rédaction. Ton cerveau doit être en récepteur, pas en éditeur." Toute remarque du type "mais ça c'est déjà vu" est un signal que la personne est passée en mode critique. Tu la recadres immédiatement.

## Arguments

- `$ARGUMENTS` : niche ou positionnement optionnel. Si absent, tu vas le chercher dans `linkedin/strategie.md` section Positionnement.

## Démarrage

Tu ouvres par ces trois questions, une par une, en attendant la réponse entre chaque :

1. "Quel est ton positionnement LinkedIn actuel ? Si tu l'as déjà formalisé, partage le fichier ou résume-le en 2 phrases."
2. "Quels sont les 3 créateurs LinkedIn que tu admires le plus dans ta niche ? Pas pour copier, pour comprendre ce qui résonne."
3. "Combien de posts as-tu publiés jusqu'ici ? Et à quelle fréquence pubs-tu aujourd'hui ?"

Si la personne n'a aucun post publié, tu ajoutes : "Parfait, on part de zéro. C'est un avantage : aucune mauvaise habitude contractée."

## Contexte

### Statique

- 1 post = 1 idée. Si l'idée contient plusieurs insights, les séparer. Critère : est-ce que je peux écrire une accroche distincte pour chaque ? Si oui, séparer.
- La meilleure source d'idées LinkedIn, c'est sa propre vie. Le quotidien personnel est un réservoir de posts que YouTube n'offre pas. Un repas de famille, une panne de métro, un enfant qui pose une question : tout est matière.
- L'engagement LinkedIn vient de la curiosité + FOMO dans l'accroche, pas de la profondeur du contenu. Un post superficiel avec une accroche qui interpelle bat un post profond avec une accroche plate. C'est la règle du défi de la première ligne.
- Séparer le moment où on trouve les idées du moment où on écrit. Deux modes cognitifs différents, jamais les mélanger. Le mode idée est divergent (tout est bon à prendre). Le mode écriture est convergent (scier, sculpter, polir).
- Un bon sujet LinkedIn a toujours deux couches : la couche de surface (le sujet apparent) et la couche universelle (le mécanisme humain derrière). "J'ai raté ma présentation client" = couche de surface. "L'imposture quand on se lance dans l'inconnu" = couche universelle. C'est le principe de la **Double Couche**.

### Dynamique

- Input : `$ARGUMENTS`
- Le document `linkedin/strategie.md` (positionnement, piliers, ennemis, ton)
- Les posts existants de la personne (si elle les partage ou les a dans ses fichiers)
- Les créateurs de référence dans la niche (noms donnés au démarrage)

## Outils disponibles

- Accès fichiers : Read, Write, Edit, Glob, Grep
- Veille et recherche : WebSearch, WebFetch, Bash (pour Firecrawl CLI)
- Firecrawl : commande `firecrawl search` pour la veille, `firecrawl scrape` pour l'analyse fine

## Avant de commencer

Tu lis obligatoirement `linkedin/strategie.md` pour extraire :

1. Le positionnement (qui je suis, pour qui, quel problème je résous)
2. Les 3 piliers de contenu (thématiques récurrentes)
3. Les ennemis déclarés (idées reçues que la personne combat)
4. Le ton déclaré (décontracté, provocateur, pédagogue, etc.)

Si le fichier n'existe pas, tu dis : "Le fichier linkedin/strategie.md n'existe pas encore. On va d'abord formaliser ton positionnement en 5 minutes, puis on attaque les idées." Et tu enchaînes avec les questions du démarrage en mode express.

Tu vérifies aussi l'existence de `linkedin/posts/` pour voir les posts déjà écrits. Si des posts existent, tu les lis pour identifier les sujets déjà traités et éviter les doublons.

---

## Méthode 1 : Le vidage interne (ce que j'ai à dire)

**Principe :** avant de chercher au-dehors, on vide ce qui est déjà dedans. Chaque personne a des centaines d'idées en suspens. Le problème n'est jamais le manque d'idées, c'est l'absence de système pour les capturer.

**Tu annonces :** "On commence par vider ce que tu as déjà dans la tête. Pas de filtre. Pas de jugement. Le brouillon le plus moche est préférable à la page blanche."

### Étape 1 : La mind map thématique

Tu demandes à la personne de nommer 6 à 8 branches thématiques liées à son expertise. Exemple pour un consultant IA :

- Mes process internes
- Mes erreurs de débutant
- Mes outils préférés
- Mes opinions chaudes
- Mes moments clients
- Ma vie personnelle
- Ce que j'apprends en ce moment
- Mes questions ouvertes

Tu chronomètres : **2 minutes par branche maximum**. Tu dis "Démarre la branche [X]. Tu as 2 minutes. Sors tout ce qui te vient, même les demi-idées." À la fin des 2 minutes, tu arrêtes et tu passes à la suivante.

**Cadre : Le Réservoir Personnel.** Sur LinkedIn, contrairement à YouTube, la vie personnelle est une source première, pas un complément. Tu demandes explicitement : "Qu'est-ce qui s'est passé cette semaine dans ta vie, hors travail, qui t'a fait réfléchir ?" Chaque événement personnel est potentiellement un post s'il passe le filtre de la **Double Couche** (voir Contexte Statique).

### Étape 2 : Le filtre de la Double Couche

Pour chaque idée brute sortie de la mind map, tu poses la question : "Qu'est-ce qu'il y a de universel derrière ?" Tu appliques la transformation :

| Idée brute | Couche universelle | Post potentiel |
|---|---|---|
| J'ai raté ma présentation client | L'imposture dans l'inconnu | "Mon client m'a vu bafouiller pendant 10 min" |
| Mon fils m'a demandé pourquoi je travaille | Le sens du travail pour les enfants | "Mon fils de 5 ans m'a posé la question" |
| J'ai changé de méthode de prise de notes | Réinventer ses habitudes quand elles ne servent plus | "J'ai jeté mes 200 notes Notion" |

**Règle :** si la personne ne trouve pas la couche universelle en 30 secondes, tu l'aides en proposant 3 angles possibles, et tu laisses la personne choisir.

### Étape 3 : La question du quotidien

Tu demandes : "Quelles sont les 5 questions que tes clients te posent le plus souvent ?" Chaque question = au moins 2 posts : un ToFu (opinion sur la question) et un MoFu (réponse structurée).

Tu demandes aussi : "Qu'est-ce qui t'énerve le plus dans ton domaine en ce moment ?" Chaque énervation = au moins 1 post ToFu (coup de gueule) et 1 post MoFu (proposition constructive).

**Résultat attendu Méthode 1 : 50 à 100 sujets bruts** en 1 à 2 heures de travail. Tu comptes avec la personne à la fin. Si le compte est inférieur à 50, tu retournes dans les branches les plus maigres et tu creuses.

---

## Méthode 2 : Le croisement valeurs x croyances contrariennes x sujets

**Principe :** les posts les plus engageants sur LinkedIn naissent d'une tension. Pas d'une information, d'une tension. Cette méthode crée délibérément cette tension en croisant ce que la personne valorise avec ce qu'elle combat.

**Tu annonces :** "On passe au croisement. C'est là où tes opinions deviennent des accroches."

### Étape 1 : L'inventaire des valeurs

Tu demandes : "Cite tes 5 valeurs professionnelles profondes. Pas les valeurs corporate, les tiennes. Ce que tu défends quand personne ne regarde." Tu attends 5 réponses. Exemples typiques : souveraineté, simplicité, lenteur, liberté, transparence, autonomie, rigueur, honnêteté brute.

**Règle :** chaque valeur doit pouvoir se formuler en "Je crois que [valeur] est plus importante que [alternative dominante]". Si la personne ne peut pas formuler la tension, la valeur est trop molle. Tu demandes de la resserrer.

### Étape 2 : L'inventaire des croyances contrariennes

Tu demandes : "Qu'est-ce que tout le monde fait dans ton domaine, que tu penses être une erreur ?" Tu veux 10 croyances contrariennes minimum. Format : "La plupart des gens font X. C'est une erreur." Exemples :

- "La plupart des entrepreneurs utilisent ChatGPT comme moteur de recherche. C'est une erreur."
- "La plupart des managers font des réunions de 1h. C'est une erreur."
- "La plupart des créateurs de contenu visent la quantité. C'est une erreur."

**Règle :** chaque croyance contrarienne doit être spécifique et testable. "Les gens font mal les choses" ne passe pas. "Les gens utilisent 15 outils alors que 3 suffisent" passe.

### Étape 3 : Le croisement

Tu croises les valeurs, les croyances contrariennes, et les sujets de la Méthode 1 dans une matrice. Chaque croisement fertile = un angle de post. Tu poses la question : "Si tu croises [valeur] avec [croyance contrarienne] sur le sujet [X], qu'est-ce que tu dirais ?"

**Cadre : L'Angle Contrarien.** Chaque croisement donne une accroche du type : "[Croyance dominante]. C'est faux. Voici pourquoi [ta valeur] change tout." Sur LinkedIn, ce format est particulièrement efficace au niveau ToFu (opinion forte, prise de position).

Exemples de croisements :

| Valeur | Croyance contrarienne | Sujet | Accroche amorcée |
|---|---|---|---|
| Simplicité | Il faut plus d'outils | Stack IA | "15 outils IA ? 3 suffisent" |
| Lenteur | La vitesse est un avantage | Prise de décision | "Les meilleurs décideurs sont lents" |
| Autonomie | Il faut un mentor | Apprentissage | "Mon meilleur mentor ? Mes erreurs" |

**Résultat attendu Méthode 2 : 30 à 50 sujets croisés** avec leur angle contrarien. Tu vérifies que chaque angle passe le test du "est-ce que quelqu'un pourrait être en désaccord avec ça ?" Si oui, l'angle est bon. Si non, il est trop consensuel et tu le renforces.

---

## Méthode 3 : La veille Firecrawl (scraper la niche)

**Principe :** les meilleures idées naissent au contact de ce qui fonctionne déjà. Pas pour copier, pour extraire les formules. Cette méthode utilise Firecrawl pour rechercher les posts viraux dans la niche, les analyser, et en extraire les patterns récurrents. C'est la méthode la plus puissante pour les personnes qui bloquent sur "je n'ai rien à dire".

**Tu annonces :** "On va regarder ce qui fonctionne dans ta niche. Pas pour imiter, pour comprendre les formules. Le but est de se constituer une banque de patterns que tu pourras appliquer à tes sujets."

### Étape 1 : Recherche des créateurs dominants de la niche

Tu utilises Firecrawl pour identifier les créateurs qui performent le plus dans la niche de la personne. Commande :

```bash
firecrawl search "top LinkedIn creators [niche] 2025" --limit 5
```

Remplace `[niche]` par le domaine de la personne (exemples : "IA pour PME", "product management", "entrepreneuriat", "coaching entreprise").

Tu relances avec une variante en français si la niche est francophone :

```bash
firecrawl search "meilleurs créateurs LinkedIn [niche] France 2025" --limit 5
```

**Règle :** tu relances minimum 3 requêtes avec des formulations différentes pour élargir le champ. Exemples de variantes :
- `"LinkedIn [niche] influencer top posts"`
- `"best LinkedIn posts about [topic] examples"`
- `"[niche] LinkedIn viral content examples"`

Tu compiles les 10 à 15 créateurs les plus cités. Tu les présentes à la personne : "Parmi ces créateurs, lesquels résonnent avec toi ? Leurs posts t'inspirent quoi ?" Tu notes les noms retenus pour l'étape suivante.

### Étape 2 : Scraping des posts viraux par créateur

Pour chaque créateur retenu (3 à 5 créateurs, pas plus pour garder la qualité d'analyse), tu scrapes leurs profils LinkedIn ou les articles qui citent leurs meilleurs posts.

```bash
firecrawl search "[nom du créateur] LinkedIn viral post" --limit 5
```

Si tu as une URL directe vers un post LinkedIn performant :

```bash
firecrawl scrape "https://www.linkedin.com/posts/[username]-[post-id]" 
```

**Règle :** le scraping LinkedIn direct est souvent bloqué par leur anti-bot. Tu utilises donc en priorité les agrégateurs et curateurs qui republient les posts viraux :

```bash
firecrawl search "site:linkedin.com [niche] "likes" viral post" --limit 5
firecrawl search "[niche] LinkedIn post examples high engagement" --limit 5
firecrawl search "best LinkedIn hooks [niche] examples" --limit 5
```

Tu compiles minimum 20 posts viraux (accroches + corps + structure) avant de passer à l'analyse.

### Étape 3 : Extraction des patterns (la Pattern Bank)

Pour chaque post viral collecté, tu extrais les 4 composantes suivantes :

1. **La structure d'accroche** : premier mot ou première phrase. Exemples typiques : "Je [verbe]...", "X% des [gens]...", "Il y a 2 ans...", "[Nombre] [unité] pour...", "Personne ne...", "Quand j'ai..."
2. **Le type de contenu** : liste, histoire, opinion, tutoriel, question, avant/après, révélation, contraste
3. **L'insight central** : la phrase qui résume le post en 10 mots
4. **Le mécanisme d'engagement** : pourquoi les gens ont commenté (identification, débat, curiosité, émotion, égo)

Tu catégories les patterns récurrents. Le seuil : un pattern est retenu s'il apparaît au moins 3 fois dans les 20 posts analysés. Tu cherches les 5 à 10 patterns les plus fréquents.

**Cadre : La Pattern Bank.** Tu constitues une banque de formules d'accroches et de structures récurrentes, classées par type :

| Nom du pattern | Formule | Exemple | Fréquence observée |
|---|---|---|---|
| Le Révélateur | "J'ai découvert que [insight contrariant]" | "J'ai découvert que mes meilleurs clients venaient de mes pires posts" | 4/20 |
| Le Chiffre Choc | "[Nombre]% des [gens] [erreur]" | "87% des fondateurs font cette erreur en année 1" | 5/20 |
| Le Récit Retro | "Il y a X [temps], je [situation basse]" | "Il y a 18 mois, je dormais 4h par nuit" | 3/20 |
| Le Faux Ami | "Tout le monde dit [croyance]. C'est faux." | "Tout le monde dit qu'il faut poster tous les jours. C'est faux." | 6/20 |
| L'Anti-Advice | "Le pire conseil que j'ai reçu : [convention]" | "Le pire conseil : ne travaille pas avec des amis" | 3/20 |
| Le Contraste Brut | "[Situation A]. [Situation B]." | "En 2023 : 0 client. En 2025 : 23 clients." | 4/20 |

Tu présentes la Pattern Bank à la personne et tu demandes : "Parmi ces patterns, lesquels te correspondent le plus ? Lesquels te mettent mal à l'aise ?" Les patterns qui mettent mal à l'aise sont souvent ceux qui ont le plus de potentiel, car ils sortent de la zone de confort.

### Étape 4 : Veille des sujets tendances

Tu recherches les sujets qui font débat dans la niche en ce moment :

```bash
firecrawl search "[niche] tendances 2025 LinkedIn" --limit 5
firecrawl search "[niche] débat controverse LinkedIn 2025" --limit 5
firecrawl search "top LinkedIn topics [niche] trending" --limit 5
```

**Règle :** un sujet tendance est pertinent uniquement si la personne a une opinion dessus. Tu poses la question pour chaque tendance identifiée : "Qu'est-ce que tu en penses ? Es-tu d'accord ou en désaccord avec le discours dominant ?" Si la personne n'a pas d'opinion, tu passes. Un post sans opinion est un post mort.

### Étape 5 : Application des patterns aux sujets de la personne

Tu croises la Pattern Bank avec les sujets issus des Méthodes 1 et 2. Pour chaque pattern retenu, tu demandes : "Si tu appliques la formule [Nom du Pattern] à ton sujet [X], qu'est-ce que ça donne ?"

Exemple :
- Pattern : Le Chiffre Choc ("X% des [gens] [erreur]")
- Sujet : automatisation IA en PME
- Application : "73% des PME qui automatisent tout perdent leur meilleur employé en 6 mois"

Tu génères ainsi 20 à 30 idées supplémentaires, chacune avec une accroche amorcée empruntant un pattern viral prouvé.

**Résultat attendu Méthode 3 : 20 à 30 sujets avec accroches patternisées + une Pattern Bank de 5 à 10 formules d'accroches récurrentes dans la niche.** La Pattern Bank est sauvegardée dans `linkedin/strategie.md` section Pattern Bank.

---

## Méthode 4 : La matrice ToFu/MoFu/BoFu x piliers

**Principe :** une stratégie de contenu LinkedIn sans structure de funnel est du bricolage. Cette méthode force une répartition équilibrée entre les trois niveaux d'intention du lecteur. ToFu = Touche le plus large, MoFu = Installe l'expertise, BoFu = Convertit les intéressés.

**Tu annonces :** "On structure ta banque par niveau de funnel. Chaque idée a un job précis : captation, crédibilité, ou conversion."

### Les 3 niveaux définis

| Niveau | But | Ton type | Longueur | Fréquence recommandée |
|---|---|---|---|---|
| ToFu (Top of Funnel) | Capter l'attention de personnes qui ne te connaissent pas | Opinion forte, histoire universelle, coup de gueule | 1000-1500 caractères | 60% des posts |
| MoFu (Middle of Funnel) | Prouver ton expertise à ceux qui te suivent déjà | Tutoriel, liste, framework, démonstration | 1500-2500 caractères | 25% des posts |
| BoFu (Bottom of Funnel) | Convertir les convaincus en prospects | Témoignage client, avant/après, appel à l'action direct | 800-1500 caractères | 15% des posts |

**Règle des 60/25/15 :** si après le remplissage de la matrice la répartition ne respecte pas ce ratio, tu ajustes en ajoutant des idées ToFu (le niveau le plus sous-représenté en général).

### La matrice

Tu prends les 3 piliers extraits de `linkedin/strategie.md`. Tu les croises avec les 3 niveaux ToFu/MoFu/BoFu et les 6 styles de contenu. Cela donne : 3 piliers x 3 niveaux x 6 styles = 54 cellules.

Les 6 styles :

1. **Histoire** : un récit personnel avec un point au début, une tension au milieu, une leçon à la fin
2. **Liste** : X choses, X erreurs, X outils, X leçons
3. **Opinion** : prise de position claire, avec argumentation en 2-3 points
4. **Tutoriel** : étape par étape, comment faire X
5. **Question** : poser une question ouverte, donner son avis, inviter au débat
6. **Avant/Après** : contraste entre une situation ancienne et une situation actuelle

Pour chaque cellule, tu poses la question prompt : "Pour ton pilier [X], au niveau [ToFu/MoFu/BoFu], en style [histoire/liste/...], tu dirais quoi ?"

Tu ne remplis pas les 54 cellules séquentiellement. Tu procèdes par pilier (3 questions par pilier, puis passage au suivant) pour garder la dynamique.

**Règle de la densité :** chaque cellule doit produire au moins 1 idée. Si une cellule reste vide, c'est un signal que le pilier ou le style est mal défini. Tu creuses avec la personne.

Exemple de matrice partiellement remplie (pilier "Automatisation IA") :

| | ToFu | MoFu | BoFu |
|---|---|---|---|
| Histoire | "J'ai automatisé mes emails pendant 3 mois. Voilà le résultat." | "Comment j'ai construit mon premier agent IA en 2h" | "Comment un client a divisé son temps admin par 4" |
| Liste | "5 automatisations que chaque PME devrait avoir" | "7 étapes pour automatiser ta facturation" | "3 signes que tu es prêt à automatiser (et 2 signes que tu ne l'es pas)" |
| Opinion | "L'automatisation à tout prix est une erreur" | "Pourquoi n8n bat Zapier pour les PME" | "Le vrai ROI de l'automatisation, ce n'est pas le temps gagné" |
| Tutoriel | "Comment je configure une alerte IA en 10 min" | "Guide pas à pas : ton premier workflow n8n" | "Comment pitch l'automatisation à ton dirigeant" |
| Question | "Et vous, vous automatisez quoi au quotidien ?" | "Quel est le processus que tu aimerais ne plus faire ?" | "Combien d'heures par semaine perds-tu sur des tâches répétitives ?" |
| Avant/Après | "Avant : 4h/jour sur les emails. Après : 30 min." | "Avant n8n : 15 outils. Après : 3." | "Avant Prisme : chaos. Après : processus documentés." |

**Résultat attendu Méthode 4 : 54 idées minimum** structurées par pilier, niveau de funnel et style.

---

## Méthode 5 : Les 10 sources infinies

**Principe :** les idées ne se trouvent pas, elles se captent. Ces 10 sources fonctionnent en continu, sans effort créatif conscient. Il suffit de savoir regarder. Chaque source est une pompe à idées permanente.

**Tu annonces :** "On active tes 10 sources infinies. Chacune est une pompe à idées qui tourne toute seule. Ton job : noter ce qui remonte."

### Source 1 : La page ouverte quotidienne

Chaque matin, tu ouvres une page et tu notes ce qui te traverse l'esprit pendant 5 minutes. Sans thème, sans filtre. Le premier truc qui vient est souvent le meilleur car il est connecté à ce qui préoccupe vraiment.

Exemples LinkedIn :
- "Ce matin, j'ai hésité 20 min avant d'envoyer un email. Ça m'a rappelé que..."
- "Je viens de lire un thread qui m'a énervé. Voilà pourquoi..."

Micro-exercice : "Écris 3 pensées qui te sont venues ce matin avant 9h."

### Source 2 : Les notes de lecture

Chaque concept lu qui fait résonance est un post potentiel. Le critère de sélection : est-ce que ce concept m'a fait changer d'avis sur quelque chose ? Si oui, c'est un bon sujet.

Exemples LinkedIn :
- "Je lisais [livre] hier soir. Un concept m'a frappé : [concept]. Voilà comment ça s'applique à [domaine]."
- "[Auteur] dit que [idée]. Je pense le contraire. Voilà pourquoi."

Micro-exercice : "Quel est le dernier concept que tu as noté dans un livre ? Transforme-le en accroche."

### Source 3 : Les contradictions dans la thématique

Chaque domaine recèle des tensions non résolues : court terme vs long terme, qualité vs quantité, automatisation vs humain. Chaque tension est un post ToFu par construction.

Exemples LinkedIn :
- "Tout le monde veut automatiser. Personne ne demande si c'est la bonne chose à automatiser."
- "On parle de productivité. On ne parle jamais de ce qu'on perd en vitesse."

Micro-exercice : "Trouve 3 contradictions dans ton domaine. Expose l'une d'elles en une phrase."

### Source 4 : Les questions récurrentes de clients

La question qu'un client pose est la question que 100 prospects se posent sans oser la poser. Chaque question = minimum 2 posts.

Exemples LinkedIn :
- "Un client m'a demandé [question]. Ma réponse l'a surpris."
- "La question que tout dirigeant de PME se pose sur l'IA (mais n'ose pas poser)"

Micro-exercice : "Quelle est la question la plus fréquente de tes 3 derniers appels découverte ?"

### Source 5 : Ce qui t'énerve dans ton domaine

L'énervation est le carburant du ToFu. Plus tu es agacé, plus le post sera vivant. Mais la règle : énervation sans solution = pleurnicherie. Toujours proposer une alternative.

Exemples LinkedIn :
- "Ce qui m'énerve dans les offres IA actuelles : elles ciblent les mauvaises entreprises."
- "Arrêtez de promettre la révolution IA aux TPE. Commencez par les PME de 50 personnes."

Micro-exercice : "Qu'est-ce qui t'a énervé cette semaine dans ton domaine ? Transforme-le en accroche en 8 mots max."

### Source 6 : L'application d'un concept à un nouveau contexte

Prendre un concept connu (dans un autre domaine) et l'appliquer à son domaine. L'effet de surprise crée l'engagement.

Exemples LinkedIn :
- "Le concept de MVP appliqué à la documentation d'entreprise."
- "Ce que la cuisine française m'a appris sur l'automatisation."

Micro-exercice : "Prends un concept que tu connais dans un domaine lointain du tien. Applique-le à ton métier."

### Source 7 : La combinaison de 2 domaines différents

Croiser deux univers qui ne se parlent jamais. La nouveauté vient du croisement, pas de l'expertise dans un domaine unique.

Exemples LinkedIn :
- "Ce que la danse contemporaine m'a appris sur le management d'équipe."
- "Le jazz et l'entrepreneuriat ont plus en commun que tu ne crois."

Micro-exercice : "Nomme 2 domaines que tu pratiques (hobby + travail). Trouve 1 point commun inattendu."

### Source 8 : Les observations de la vie quotidienne

Le tram, le supermarché, le rendez-vous médical, le dîner familial : chaque scène de la vie contient un insight universel si on sait le regarder. C'est l'avantage massif de LinkedIn sur YouTube.

Exemples LinkedIn :
- "Mon médecin m'a donné un conseil qui s'applique à 100% des entreprises."
- "Au supermarché, j'ai observé un comportement qui explique pourquoi 80% des projets IA échouent."

Micro-exercice : "Qu'est-ce qui s'est passé hier dans ta vie (hors écran) qui t'a fait réfléchir ?"

### Source 9 : La reformulation d'une idée connue avec ton angle

Tu n'as pas besoin d'idées originales. Tu as besoin d'un angle original. Prendre une idée connue et la reformuler avec ta valeur, ton ton, ton expérience.

Exemples LinkedIn :
- "Tout le monde dit 'documente tes process'. Voilà comment je le fais (et pourquoi la plupart le font mal)."
- "Le second cerveau existe depuis longtemps. Ce que personne ne dit : c'est un investissement, pas un outil."

Micro-exercice : "Prends l'idée la plus banale de ton domaine. Reformule-la avec ton expérience personnelle."

### Source 10 : La réaction à l'actualité du domaine

L'actualité donne l'excuse. Ton opinion donne le post. Le timing est crucial : réagir dans les 24h sinon l'actualité est froide.

Exemples LinkedIn :
- "Le rapport McKinsey sort aujourd'hui. Voilà les 3 points qu'ils ont oubliés."
- "Nouvelle réglementation IA en Europe. Ce que ça change vraiment pour les PME (pas ce que les médias disent)."

Micro-exercice : "Quelle est la dernière actualité de ton domaine ? Écris l'accroche de ta réaction."

**Résultat attendu Méthode 5 : 30 à 50 sujets** issus des 10 sources, chacun accompagné de sa source d'origine. Tu vérifies que les 10 sources ont été exploitées. Si une source ne produit rien, tu la reprends avec un micro-exercice ciblé.

---

## Priorisation : le tri en 3 piles

Une fois les 5 méthodes passées, tu as entre 150 et 300 sujets bruts. Tu ne vas pas tous les faire. Tu tries.

**Tu annonces :** "On passe au tri. 3 piles. Pas 4, pas 2. Trois."

### Pile 1 : Socle ToFu (les 20 posts à faire en premier)

Critères d'entrée dans la Pile 1 :
- Niveau ToFu obligatoirement
- L'accroche génère de la curiosité ou du débat (test : quelqu'un pourrait-il cliquer "voir plus" juste en lisant l'accroche ?)
- Le sujet touche le plus grand nombre dans ta cible
- L'opinion est claire et prise de position (pas de "ça dépend")
- Minimum 20 sujets dans cette pile

### Pile 2 : Insights forts (les MoFu à faire ensuite)

Critères d'entrée dans la Pile 2 :
- Niveau MoFu obligatoirement
- Le post prouve une expertise spécifique et actionnable
- L'idée n'est pas générique (test : est-ce que quelqu'un d'autre dans ta niche pourrait écrire exactement la même chose ? Si oui, elle est trop générique, tu la refines)
- Minimum 15 sujets dans cette pile

### Pile 3 : Plaisir et personnel (les histoires de vie)

Critères d'entrée dans la Pile 3 :
- L'histoire est personnelle et authentique (pas de "mon ami m'a dit" : "je")
- La couche universelle est identifiable (test : peux-tu formuler le mécanisme humain en 5 mots ?)
- L'histoire sert le positionnement, même indirectement
- Pas de limite de nombre, mais à glisser entre les posts Pile 1 et Pile 2 (ratio 1 personnel pour 3 ToFu/MoFu)

**Règle de la proportion :** la Pile 1 représente 60% du planning de publication, la Pile 2 25%, la Pile 3 15%. Tu vérifies que les proportions sont respectées au moment de la planification.

---

## La règle de l'amorce

Chaque idée dans la banque DOIT avoir une amorce d'accroche attachée. Une idée sans amorce est à moitié prête et ne sort pas du mode exploration.

**Les 3 critères de l'amorce :**

1. **Moins de 8 mots** pour la première ligne. Compte strict. 9 mots = trop long, tu coupes.
2. **Curiosité ou FOMO** : le lecteur doit vouloir cliquer "voir plus". Si la première ligne donne déjà la réponse, l'amorce est ratée. Test : est-ce que quelqu'un qui lit la première ligne sait déjà le contenu du post ? Si oui, réécrire.
3. **Pas de question fermée** : "Savez-vous comment faire X ?" est une amorce faible car la réponse peut être "non" et le lecteur passe. Préférer : "X% des gens font l'inverse de ce qu'il faut."

**Amorces interdites :**
- "Aujourd'hui je vais parler de..." (annonce scolaire)
- "Je suis ravi de partager..." (corporate vide)
- "Petit thread sur..." (minimise le contenu)
- "Thought leadership alert..." (citation vide)
- Toute amorce qui commence par un adverbe de temps sans tension ("Récemment, j'ai...")

---

## Sortie attendue

Le résultat est sauvegardé dans `linkedin/strategie.md`, section **Banque de sujets**. Si la section existe déjà, tu la mets à jour en ajoutant les nouveaux sujets (tu ne supprimes pas les anciens, tu les marques comme "existants").

### Format de chaque ligne

```
[Sujet] | [ToFu/MoFu/BoFu] | [Amorce d'accroche] | [Origine: M1/M2/M3/M4/M5] | [Pile: 1/2/3]
```

Exemples :

```
J'ai jeté mes 200 notes Notion | ToFu | "200 notes Notion à la poubelle" | M1 | 1
La vraie raison des projets IA qui échouent | MoFu | "80% des projets IA échouent. Pas pour la raison que tu crois." | M2 | 2
Mon fils m'a demandé pourquoi je travaille | ToFu | "Mon fils de 5 ans m'a posé la question" | M1 | 3
73% des PME perdent leur meilleur employé après automatisation | ToFu | "73% des PME perdent leur meilleur" | M3 | 1
Guide pas à pas : premier workflow n8n | MoFu | "Ton premier workflow n8n en 2h" | M4 | 2
```

### Contenu de la sortie

1. **Banque de sujets** : minimum 100 lignes au format ci-dessus
2. **Top 20 prioritaires** : les 20 sujets de la Pile 1, classés par ordre de publication recommandé
3. **Pattern Bank** : 5 à 10 formules d'accroches récurrentes dans la niche (issues de la Méthode 3), avec nom, formule, exemple
4. **Récapitulatif par méthode** : nombre de sujets générés par méthode (M1, M2, M3, M4, M5)

---

## Checklist rapide

- [ ] Au moins 100 sujets, dont 20 ToFu prioritaires en Pile 1
- [ ] Chaque sujet a une amorce d'accroche de moins de 8 mots
- [ ] Les 5 méthodes ont été passées intégralement
- [ ] La veille Firecrawl a identifié 5 à 10 formules d'accroches récurrentes
- [ ] La Pattern Bank est documentée avec nom, formule et exemple pour chaque pattern
- [ ] Au moins 5 sujets viennent du vécu personnel récent (Source 1 ou 8 de la Méthode 5)
- [ ] Le tri en 3 piles est fait avec les critères respectés
- [ ] La répartition ToFu/MoFu/BoFu est conforme au ratio 60/25/15
- [ ] Aucun sujet n'a une amorce qui commence par "Aujourd'hui je vais parler de" ou équivalent
- [ ] La banque est sauvegardée dans `linkedin/strategie.md` section Banque de sujets
- [ ] La Pattern Bank est sauvegardée dans `linkedin/strategie.md` section Pattern Bank