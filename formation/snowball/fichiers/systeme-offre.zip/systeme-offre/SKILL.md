---
name: systeme-offre
description: "Part de ce que tu vends (rien, une idée, ou une offre en place) et te route vers la bonne brique, dans le bon ordre, jusqu'à un document d'offre activable qui se transforme en page de vente. Porte l'assemblage final et le chaînage avec les bases marketing."
---

# Système d'offre : l'orchestrateur

> **Ressources de ce pack** (dossier `resources/`) - l'orchestrateur route vers ces sous-capacites :
> - `/cartographier-icp` -> `resources/cartographier-icp.md`
> - `/avant-apres` -> `resources/avant-apres.md`
> - `/problemes-par-etape` -> `resources/problemes-par-etape.md`
> - `/solutions-offre` -> `resources/solutions-offre.md`
> - `/creer-offre` -> `resources/creer-offre.md`
> - `/pricer-offre` -> `resources/pricer-offre.md`
> - `/systeme-offres` -> `resources/systeme-offres.md`
> - `/nommer-offre` -> `resources/nommer-offre.md`


> **Objectif :** partir de ce que tu vends (rien, une idée, ou une offre déjà en place) et te router vers la bonne brique, dans le bon ordre, jusqu'à un document d'offre activable qui se transforme en page de vente derrière.

Ce skill est le chef d'orchestre du workflow Construire une offre. Il ne refait pas le travail des sous-skills : il fait l'état des lieux, impose une séquence, et aiguille vers le sous-skill qui débloque vraiment ta prochaine heure de travail. Il porte aussi l'assemblage final (le document d'offre) et le chaînage avec les bases marketing.

Le piège que ce skill évite : ouvrir un canvas vide et "réfléchir à une offre" pendant trois jours. Une idée n'est pas une offre. Une offre c'est une transformation précise, pour une personne précise, à un prix précis. Ce matin tu as des données, hier soir tu avais une idée. On construit à partir des mots réels des clients, pas de tes suppositions.

---

## Principe directeur

Le marketing c'est de l'empathie : comprendre QUI est prêt à payer QUELLE valeur pour QUELLE transformation, puis designer le programme exactement comme la personne le voudrait.

Trois règles que l'orchestrateur fait respecter à chaque étape, quoi qu'il arrive :

1. **Jamais sur des suppositions.** Tant que l'avant/après n'est pas écrit avec les mots exacts des clients, l'offre est une hypothèse, pas une offre. Si la personne dit "je sais ce dont mes clients ont besoin", c'est le signal qu'il faut des interviews.
2. **Le prix se fixe à la valeur de la transformation, pas au contenu.** "15 vidéos + un PDF = X€" est interdit. On price la valeur perçue du point B.
3. **On filtre tout par la journée idéale.** Une solution géniale mais qui te scotche en 1:1 alors que tu veux du scalable, c'est une mauvaise solution. La meilleure offre est celle qui sert le client ET ta vie.

---

## Étape 1 : État des lieux en 3 questions (avant tout)

**Méthode :** ne rien construire avant d'avoir posé ces trois questions et écouté les réponses. Elles déterminent le mode et le point d'entrée.

**Q1 - "Tu pars de zéro ou tu as déjà une offre qui se vend ?"**

| Réponse | Mode | Parcours |
|---|---|---|
| Zéro, ou une idée jamais vendue | **Construction** | Étapes 1 à 7 dans l'ordre, du `/cartographier-icp` jusqu'au document final. |
| Une offre qui se vend déjà mais plafonne / ressemble à tout le monde | **Repositionnement** | Ne pas tout refaire. Cartographier l'offre actuelle, scorer l'équation de valeur, repérer le terme le plus faible, sortir de la comparaison via Category of One, monter en gamme. |

**Q2 - "Qu'est-ce qui existe déjà ?"** Demander ou lire, et marquer chaque brique manquante : fiche ICP ? avant/après ? appels clients faits (mots exacts) ou seulement des suppositions ? étapes A vers B listées ? prix actuel et comment il a été fixé ?

**Q3 - "C'est quoi ta demande précise aujourd'hui ?"** Si la demande est ciblée, router direct vers UN sous-skill et ne pas dérouler tout le parcours :

| La personne dit | Tu routes vers |
|---|---|
| "Je sais pas combien facturer" | `/pricer-offre` |
| "Mon offre ressemble à tout le monde" | Category of One puis `/solutions-offre` |
| "Je trouve pas de nom" | `/nommer-offre` |
| "Mon avant/après c'est mes suppositions" | `/avant-apres` + protocole d'interview |
| "Je veux lancer vite, en 30 jours" | la variante `/offre-minimum-viable` |
| "C'est ma toute première offre, je débute" | la variante douce `/7-2-premiere-offre` |

**Piège :** dérouler les 7 étapes alors que la personne a une demande précise. L'orchestrateur sert d'abord à ne PAS faire le travail inutile.

---

## Étape 2 : Router par brique manquante

**Méthode :** quand le mode est Construction et qu'il n'y a pas de demande ultra-ciblée, on aiguille selon la première brique qui manque dans la chaîne. Chaque brique débloque la suivante, on ne saute pas.

| Brique manquante | Route | Ce que le sous-skill produit |
|---|---|---|
| Pas d'ICP clair | `/cartographier-icp` (PARTAGÉ Theme A) | une ou plusieurs fiches ICP + niveau de conscience |
| ICP ok, avant/après = suppositions | `/avant-apres` | tableau 5 lignes en mots exacts + USP V1 |
| Avant/après ok, pas d'architecture | `/problemes-par-etape` | 3 à 7 étapes (modules) + 100+ problèmes |
| Étapes ok, pas de solutions | `/solutions-offre` | solutions retenues par étape + format de delivery |
| Solutions ok, "fade / comparable" | `/pricer-offre` puis `/systeme-offres` | prix à la valeur + bonus/garanties/rareté/urgence |
| Tout est prêt sauf le nom | `/nommer-offre` | nom + USP encapsulée |
| Tout prêt | assemblage du DOCUMENT D'OFFRE (étape 7) | le doc activable + chaînage croyances |

**Outils :** Claude pour le dialogue étape par étape ; Gamma pour mettre en forme le document d'offre final.

**Piège :** router vers `/solutions-offre` alors que l'avant/après n'existe qu'en supposition. On ne génère pas de solutions à des problèmes qu'on a inventés. Remonter d'abord la chaîne.

---

## Étape 3 : Garde-fous embarqués (à appliquer à chaque route)

**Méthode :** l'orchestrateur ne laisse jamais passer ces erreurs, même si la personne pousse pour avancer.

- **Pricer au temps passé.** "4 sessions x 400€ = 1600€" est refusé. On price la valeur du point B. Renvoie vers `/pricer-offre`.
- **Valider sur des suppositions.** Pas de mots clients = retour interviews. La personne a souvent un avant/après "d'hier soir" : c'est ce que ELLE pensait, pas ce que le marché confirme.
- **Moins de 10 problèmes par étape.** Signal que le marché n'est pas assez connu. Renvoyer en interview avant de continuer (`/problemes-par-etape`).
- **Solution qui dépend de ta présence permanente.** À couper ou à rendre scalable. Toujours filtrer par la journée idéale.
- **Trop de bonus.** Au-delà de 3 à 5, la peur de crouler freine l'achat. Renvoie vers `/systeme-offres`.

**Piège :** céder à "on verra le prix plus tard, avance". Le prix conditionne l'architecture (protocole inversé). Si la personne veut closer en 1:1 à 5000€, l'offre ne se construit pas comme une formation async à 200€.

---

## Étape 4 : Assemblage final et chaînage (le rôle propre de l'orchestrateur)

**Méthode :** quand toutes les briques sont là, l'orchestrateur produit les DEUX documents (et seulement lui le fait) :

**Document 1 - l'offre V1 sur papier :** NOM, CIBLE, USP révisée, AVANT/APRÈS en mots exacts, ÉTAPES (les modules), FORMAT de delivery, PRIX, GARANTIE (formulation exacte), BONUS (chacun ciblant une objection), RARETÉ/URGENCE.

**Document 2 - la roadmap de construction :** par étape, les problèmes résolus, les livrables à créer, le temps estimé, et le total.

Puis le **chaînage obligatoire** vers les bases marketing : enchaîner avec `systeme-bases-marketing` pour intégrer le reframing des croyances. Le marketing fonctionne en 3 temps : convaincre (reframer les croyances), persuader (avant/après émotionnel), casser les dernières barrières (garantie/urgence/bonus). Une fois que tu as le document d'offre + la carte des croyances, la page de vente s'écrit toute seule derrière.

**Piège :** s'arrêter au document d'offre sans le chaîner. L'offre seule ne vend pas. C'est la carte des croyances (1 croyance bloquante = 1 bonus, 1 angle, 1 contenu) qui transforme l'offre en livrables marketing (Theme C : page de vente, séquence email, VSL).

---

## Exemples

### Bon

> Personne : "J'ai déjà une offre de software à 19£/mois qui tourne, mais on me compare à 3 concurrents et je galère à monter mes prix."
>
> Orchestrateur : mode REPOSITIONNEMENT, pas Construction. On ne refait pas l'offre de zéro. On cartographie l'offre actuelle, on score l'équation de valeur, on identifie le terme faible (ici la comparabilité : "vous n'êtes qu'un software"), on passe par Category of One pour sortir de la comparaison, puis on monte en gamme.

Pourquoi c'est bon : la Q1 a évité de gaspiller le parcours complet sur une offre qui se vend déjà. Le diagnostic route vers la vraie douleur (sortir de la commodité) au lieu de tout reconstruire.

### Mauvais

> Personne : "Je veux créer mon offre, je pense à un programme avec 49 conseils pour bien manger."
>
> Orchestrateur qui démarre direct sur le nom et le prix.

Pourquoi c'est raté : "49 conseils" c'est de l'information, les gens veulent une transformation. On a sauté l'état des lieux (pas d'ICP, pas d'avant/après en mots clients) et on a laissé une offre encyclopédie partir vers la mise en forme. L'orchestrateur aurait dû remonter à l'étape 1 : QUI, quelle transformation, quels mots réels.

---

## Pièges

- Faire le travail des sous-skills au lieu d'aiguiller. L'orchestrateur diagnostique et route, point.
- Dérouler les 7 étapes sur une demande ciblée (Q3 ignorée).
- Confondre mode Construction et mode Repositionnement : une offre qui se vend déjà ne se reconstruit pas de zéro.
- Oublier le chaînage final vers les bases marketing : le document d'offre sans la carte des croyances ne se transforme pas en page de vente.
- Laisser pricer au contenu ou valider sur des suppositions (garde-fous étape 3).

---

## Références

- Formation vidéo : <a href="/plateforme/business-os/atomic-offers">Atomic Offers</a> - la méthode complète dont ce workflow est la synthèse activable (niche, USP, prix, valeur, solutions, bonus/garanties/rareté/urgence, nom).
- Formation vidéo : <a href="/plateforme/business-os/challenge-offre-aligne">Challenge Offre Alignée</a> - pour valider en amont une offre alignée avec ta vision avant de la construire.
- Formation vidéo : <a href="/plateforme/business-os/atomic-funnels">Atomic Funnels</a> - le tunnel de vente complet qui se branche derrière l'offre.
- Sous-skills routés : <a href="/plateforme/business-os/bases-marketing__cartographier-icp">cartographier-icp</a> (partagé Theme A), <a href="/plateforme/business-os/offre__avant-apres">avant-apres</a>, <a href="/plateforme/business-os/offre__problemes-par-etape">problemes-par-etape</a>, <a href="/plateforme/business-os/offre__solutions-offre">solutions-offre</a>, <a href="/plateforme/business-os/templates__2-Vente__creer-offre">creer-offre</a> (offre V1 de bout en bout, mode zéro), <a href="/plateforme/business-os/templates__2-Vente__pricer-offre">pricer-offre</a>, <a href="/plateforme/business-os/templates__2-Vente__systeme-offres">systeme-offres</a>, <a href="/plateforme/business-os/offre__nommer-offre">nommer-offre</a>.
- Variantes citées : <a href="/plateforme/business-os/templates__2-Vente__offre-minimum-viable">offre-minimum-viable</a> (lancer en 30 jours), <a href="/plateforme/business-os/templates__2-Vente__category-of-one">category-of-one</a> (repositionnement), <a href="/plateforme/business-os/parcours-de-base__7-2-premiere-offre">7-2-premiere-offre</a> (première offre douce).
- Chaînage aval : <a href="/plateforme/business-os/bases-marketing__systeme-bases-marketing">systeme-bases-marketing</a> (reframing des croyances).

---

## Checklist

- [ ] Mode déterminé (Construction vs Repositionnement) via la Q1.
- [ ] Briques existantes inventoriées, briques manquantes marquées (Q2).
- [ ] Demande précise du jour identifiée et routée si ciblée (Q3).
- [ ] Aucune brique validée sur des suppositions (mots clients exigés).
- [ ] Prix fixé à la valeur, pas au contenu ni au temps.
- [ ] Solutions filtrées par la journée idéale.
- [ ] Document d'offre (offre V1 + roadmap) produit.
- [ ] Chaînage vers `systeme-bases-marketing` (croyances) déclenché pour préparer la page de vente.

---

## Chaînage

Cet orchestrateur ouvre le workflow Construire une offre : il route vers `/cartographier-icp` -&gt; `/avant-apres` -&gt; `/problemes-par-etape` -&gt; `/solutions-offre` -&gt; `/pricer-offre` -&gt; `/systeme-offres` -&gt; `/nommer-offre`, puis alimente `systeme-bases-marketing` (croyances) et le Theme C (livrables marketing : page de vente, séquence email, VSL).
