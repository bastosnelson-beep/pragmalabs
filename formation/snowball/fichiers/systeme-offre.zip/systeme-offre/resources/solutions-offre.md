---
slug: solutions-offre
command: /solutions-offre
---

# Trouver les solutions de ton offre

> **Objectif :** pour chaque problème listé par étape, générer la solution (insights propriétaires + divergence WTF puis sélection scalable/alignée) et choisir le format de delivery. En sortie : la liste des solutions retenues par étape + le format.

C'est l'étape la plus importante de la construction d'offre. Eliott le dit franc : "c'est en fait la vidéo principale de la formation, celle sur laquelle vous devriez mettre le plus d'efforts". Plus tu travailles cette étape, plus ton offre est originale, complète, facile à vendre. Prends une semaine s'il le faut, "allez dans la montagne, allez dans un chalet pour réellement apporter de la valeur".

Elle se place après la liste des problèmes par étape (`/problemes-par-etape`) et avant le pricing. Tu arrives avec ta colonne de problèmes A -&gt; B. Tu repars avec, pour chaque problème, une solution conçue et un format de delivery choisi.

---

## Principe directeur

On ne part pas du scalable, on diverge d'abord. Le piège des concurrents : ils réfléchissent uniquement en "je veux un truc scalable, je veux pas passer de temps, je veux pas travailler". Résultat : tout le monde propose la même formation vidéo tiède. Toi tu fais l'inverse. D'abord toutes les solutions possibles, même les plus folles, ensuite seulement tu sélectionnes.

Trois règles non négociables :

1. **Insight d'abord, solution ensuite.** Une bonne solution s'appuie sur un concept propriétaire. Un concept propriétaire = une idée NOUVELLE pour la personne (vs la culture de base du domaine) ET qui RÉSONNE. C'est ça qui te différencie et qui te donne crédibilité et confiance auprès du prospect.
2. **Diverger avant de converger.** Quatre solutions WTF par problème, zéro censure. "Les solutions les plus what the fuck, les plus folles sont possibles." Les plus folles sont les meilleurs points de départ.
3. **Aligné prime sur scalable à tout prix.** On transforme le WTF en livrable réutilisable, mais si ta journée idéale c'est le 1:1, choisis l'aligné. "Si c'est ce qui vous fait kiffer, faites le choix aligné avec votre journée idéale, ce que vous avez envie de vivre."

---

## Étape 1 : Générer tes insights propriétaires (le protocole)

**Méthode :** avant de chercher des solutions, génère le matériau qui les rendra différenciantes. Un insight, c'est un "waouh moment", une grande idée qui te démarque. L'exemple verbatim d'Eliott : "attention il y a le coût d'opportunité d'envoyer un email. Ce que ça te rapporte d'envoyer un email 1000 euros, mais le coût d'opportunité si tu souls trop souvent ton audience, tu perds la confiance de tes lecteurs, donc le coût d'opportunité c'est peut-être un manque 10000 euros, VS un gain de 1000 euros." Nouveau pour lui (jamais appliqué à l'envoi d'emails) + ça résonnait : voilà une bonne idée.

L'équation à tester sur chaque idée :

| Critère | Question |
|---|---|
| **Nouveauté** | Est-ce nouveau pour la personne ET par rapport à la culture de base de la thématique ? |
| **Résonance** | Est-ce que ça résonne profondément avec ton prospect et avec toi ? |

Le protocole pour faire émerger ces insights, dans l'ordre :

1. **Liste tes valeurs et avis non conventionnels.** Exemple Eliott : "un système ne devrait pas contraindre un humain mais accompagner dans ses énergies", "la vie n'est pas figée, c'est un flux, donc on ne doit pas figer un système d'organisation, on doit en avoir plusieurs en fonction de notre phase de vie".
2. **Découpe ta thématique en sous-branches.** Productivité -&gt; gestion du temps, gestion des tâches, gestion des emails, planification moyen terme. Et chaque branche a ses sous-branches. Liste tout de A à Z.
3. **Injecte tes valeurs dans chaque branche** pour faire émerger des concepts propriétaires. "Comment je fais de la gestion du temps en gardant en tête que la vie change et qu'on doit partir de notre énergie interne ?" -&gt; le **tableau émotion action**.
4. **Décline en stratégies puis en méthodes.** La pyramide d'un business : valeurs -&gt; grandes idées -&gt; stratégies -&gt; méthodes (= les produits, tes offres).

**Outils :** un doc avec 4 colonnes (valeurs / grandes idées / stratégies / méthodes). Une IA pour interroger chaque sous-branche avec tes valeurs en contexte.

**Piège :** créer "une formation vidéo classique" sans concept propre. Eliott : "je ne me suis pas contenté de créer une formation, créer un second cerveau. Non, j'ai créé Atomic Thinking, une marque basée sur des méthodes concrètes que j'ai développées." C'est ça qui lui garde 60 à 80% du marché trois ans après le lancement.

---

## Étape 2 : Diverger en solutions WTF (4 par problème)

**Méthode :** reprends ta liste de problèmes par étape. Pour chaque problème, pose-toi la question magique : "si tu pouvais être là en permanence avec ce client, budget infini, disponible 24h/24, que ferais-tu exactement pour résoudre ce problème ?" Zéro censure. Vise 4 solutions par problème.

L'exemple verbatim d'Eliott : "une personne veut buzzer sur LinkedIn. Comment être sûr que je vais buzzer, que je vais pas faire des flops ? Solution what the fuck : je viens à côté de toi chez toi pendant une journée et j'écris tous tes posts pendant une journée." Autre exemple : "s'ils veulent apprendre à méditer, savoir comment bien respirer, je les emmène en voyage, on va faire un stage d'apnée. Ce qui pourrait être contre-intuitif mais aussi une méthode différenciée."

Pourquoi cette phase : "pour avoir des idées qui émergent, out of the box, auxquelles vos concurrents ne pensent pas". C'est là que naît la divergence créative, "s'autoriser à avoir des associations mentales qui émergent toutes seules".

**Outils :** une colonne "WTF" à côté de chaque problème. Brainstorme vite. Eliott : "j'ai passé peut-être 30 minutes à balancer tout mon brainstorming."

**Piège :** brider la divergence en pensant déjà scalable. "Eux ils réfléchissent : je veux un truc scalable où je n'ai pas de temps à passer. Vous, vous pensez : non, tous les possibles sont là." Si tu te censures ici, ton offre ressemblera à toutes les autres.

---

## Étape 3 : Rendre scalable (transformer le WTF en livrable)

**Méthode :** chaque solution WTF se transforme en livrable réutilisable qui produit le même résultat sans ta présence permanente. L'exemple verbatim : "au lieu d'aller chez chaque client derrière son épaule pour lui écrire son post LinkedIn, on va faire une vidéo de nous une fois où on écrit un post LinkedIn, et hop, ce sera de quoi les gens vont s'inspirer pour écrire les leurs. Ça c'est scalable, je n'ai pas de temps à passer."

Quelques transformations modèles :

| Solution WTF | Version scalable |
|---|---|
| "Je viens écrire tous tes posts une journée" | Je me filme en train d'écrire un post de A à Z = étude de cas vidéo réutilisable |
| "Je fais ta bibliographie chez toi" | Template de cartographie thématique + session collective de 2h |
| "Je brainstorme 2h/semaine avec toi" | Protocole de génération d'insights + prompts ChatGPT + séance live mensuelle |
| "Je corrige tous tes écrits" | Critères d'évaluation clairs + atelier de correction collectif hebdo |

**Outils :** pour chaque WTF, écris la version "produit" en face. Si la solution existe déjà chez toi, note-la. Sinon, conçois-la maintenant : "si je ne savais pas, il faut que je l'écrive juste ici, protocole GPT, je le rédige".

**Piège :** sortir de cette étape sans avoir CONÇU les solutions. Eliott : "il faut qu'à la fin vous ayez créé et designé toutes les solutions que vous avez écrites. Non seulement les idées de solutions mais aussi toutes les solutions en elles-mêmes." Une idée de solution non conçue n'est pas une solution.

---

## Étape 4 : Sélectionner et choisir le format de delivery

**Méthode :** maintenant on converge. Pour chaque solution scalable, applique la grille de sélection.

**Garde la solution si :**
- forte valeur ajoutée pour le client
- rentable pour toi, ne demande pas trop de temps
- alignée avec ta journée idéale
- scalable sans exploser ton temps

**Coupe la solution si :**
- coûteuse à livrer pour peu de valeur perçue
- dépend de ta présence permanente pour fonctionner
- pas différenciante vs les concurrents
- incompatible avec ta journée idéale

Eliott coupe en direct sur Atomic Perspectives : "le micro-conf interne, peut-être que ça va être trop lourd, on va devoir enlever. Les micro-essais, ça va peut-être être trop contraignant, on va se rendre compte que ce n'est pas un product market fit." On itère, on garde "seulement les solutions qui sont alignées, utiles pour le client, utiles pour moi, scalables".

**Choisis ICI le format de delivery** (un par grande solution, ou un format dominant pour l'offre) :

| Format | Valeur perçue | Scalabilité |
|---|---|---|
| **1:1** (coaching individuel) | maximale | faible |
| **Groupe** (programme collectif) | forte | équilibrée |
| **Async** (formation vidéo) | moyenne | maximale |
| **Hybride** | forte | bonne |

**Outils :** une 3e colonne "retenu / coupé / format" à côté des solutions scalables.

**Piège :** choisir le scalable par réflexe. Nuance d'Eliott : "on n'est pas obligé de toujours faire un truc ultra scalable. Si ce qui vous fait kiffer dans votre journée idéale c'est d'accompagner les gens en one to one, alors la solution alignée ce sera du coaching, par exemple." Aligné &gt; scalable quand ta journée idéale le dit.

---

## Exemple travaillé : Atomic Perspectives (verbatim)

Niveaux d'orientation d'Eliott : "le premier niveau ce sont les étapes, le second ce sont les problèmes, le troisième c'est les solutions que je propose."

Quelques solutions retenues par problème, mot pour mot :

- Problème "comment lire beaucoup" -&gt; "un système d'engagement où on s'engage tous à lire un livre, on le poste dans le groupe chaque semaine, on doit poster un résumé chaque semaine, un nombre d'heures de lecture quotidienne pour valider", plus un **tracking dans un tableau de suivi collectif** avec rappel à l'ordre par une assistante.
- Problème "comment bien prendre des notes" -&gt; la formation **Atomic Knowledge**.
- Problème "comment lire des études compliquées" -&gt; **protocole Zotero + protocole ChatGPT pour résumer les études**.
- Problème "comment apprendre des livres" -&gt; **protocole de déconstruction + formation mémorisation**.
- Problème "comment mettre des idées en réseau" -&gt; **protocole émergence + atelier workshop**.
- Problème "comment créer un essai par jour" -&gt; **Atomic Timing**.
- Problème "comment savoir quoi dire tous les jours" -&gt; **protocole de génération de sujets à l'infini + protocole de co-écriture**.
- Problèmes généraux (pas liés à une étape) "comment je suis sûr d'y arriver" -&gt; **la puissance du groupe, du coaching toutes les semaines avec Eliott et Jean-Charles une semaine sur 2, des conférences internes hebdo, des micro-essais quotidiens publiés**.

Et l'insight propriétaire derrière le delivery : le **tableau émotion action**, né de la valeur "un système accompagne l'énergie, ne contraint pas" croisée avec la gestion du temps. Résultat concret : "c'est la pub qui marche le mieux, les posts LinkedIn qui ont fait 500 voire 1000 j'aime, et c'est aussi ce qui fait que les gens achètent : tu as des outils propres qu'on a vu nulle part ailleurs."

### Bon vs mauvais

> **Bon :** problème "buzzer sur LinkedIn" -&gt; WTF "je viens écrire tous tes posts une journée" -&gt; scalable "étude de cas vidéo où je m'écris un post de A à Z" -&gt; retenu, format async. Pourquoi c'est bon : on a divergé jusqu'au WTF avant de scaler, donc la solution finale est différenciante ET reproductible.

> **Mauvais :** problème "buzzer sur LinkedIn" -&gt; "une vidéo de 10 min qui explique comment écrire un bon post". Pourquoi c'est raté : on est parti direct du scalable, sans divergence. C'est exactement ce que font les concurrents, zéro waouh, aucune raison d'acheter chez toi.

---

## Pièges

- **Bâcler l'étape.** C'est la plus importante. Si elle te prend une semaine, c'est normal. Une offre faible ici = une offre faible partout.
- **Sauter le protocole d'insights.** Sans concept propriétaire, tes solutions sont génériques et copiables. Le concept propre est ce qui te garde leader.
- **Penser scalable en premier.** Tu te coupes des idées out of the box. Diverge, PUIS converge.
- **Confondre idée de solution et solution conçue.** Sortir de l'étape avec "protocole GPT" écrit mais pas rédigé = travail non fait.
- **Forcer le scalable contre ta journée idéale.** Si le 1:1 te fait kiffer, l'aligné gagne.

---

## Références

- Formation vidéo : <a href="/plateforme/business-os/atomic-offers">Atomic Offers -&gt;</a> (modules 6.5 "Protocole pour générer des insights" et 6.6 "Créer les solutions") pour la méthode source complète, divergence WTF et exemples Atomic Perspectives.
- Formation vidéo : <a href="/plateforme/business-os/ides-et-perspective">Idées et Perspective -&gt;</a> pour creuser la génération de concepts propriétaires et d'angle.
- Skill amont : <a href="/plateforme/business-os/offre__problemes-par-etape">problemes-par-etape -&gt;</a> fournit la liste de problèmes que ce skill transforme en solutions.
- Skill aval : <a href="/plateforme/business-os/templates__2-Vente__pricer-offre">pricer-offre -&gt;</a> price les solutions retenues.
- Orchestrateur : <a href="/plateforme/business-os/offre__systeme-offre">systeme-offre -&gt;</a>.

---

## Checklist

- [ ] Insights propriétaires générés (valeurs -&gt; grandes idées -&gt; stratégies -&gt; méthodes), testés sur nouveauté + résonance.
- [ ] Pour chaque problème, 4 solutions WTF écrites sans censure (divergence).
- [ ] Chaque WTF transformé en version scalable (livrable réutilisable).
- [ ] Grille de sélection appliquée (garde si valeur + rentable + aligné + scalable ; coupe sinon).
- [ ] Format de delivery choisi (1:1 / groupe / async / hybride), aligné avec ta journée idéale.
- [ ] Liste finale des solutions retenues par étape, chaque solution CONÇUE (pas seulement idéée).

---

Chaînage : vient après `/problemes-par-etape` (la liste des problèmes par étape) et alimente `/pricer-offre` (qui price les solutions retenues), dans le cycle `/avant-apres` -&gt; `/problemes-par-etape` -&gt; ce skill -&gt; `/pricer-offre`.
