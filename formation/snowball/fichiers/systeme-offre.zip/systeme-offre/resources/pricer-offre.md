---
slug: pricer-offre
command: /pricer-offre
---

# Pricer l'offre : fixer le prix à la valeur, pas au contenu

> **Objectif :** partir d'une offre déjà construite (cible, transformation, étapes A vers B) et sortir un prix recommandé + une structure de paiement, calés sur la valeur perçue de la transformation et sur ta journée idéale.

Le prix n'est pas une question de coût de production. C'est le dernier verrou de l'offre : trop bas, tu tues l'engagement émotionnel, la complétion et tes marges ; bien placé, tu déclenches un cercle vertueux. Eliott le pose net dans la masterclass : "le prix, ce n'est pas le contenu. Les personnes n'achètent pas un contenu. Le prix, ça doit être la valeur perçue. C'est la transformation concrète que vous allez apporter aux clients."

Ce skill vient APRÈS la construction de l'offre (étapes, solutions, format de delivery choisi) et AVANT le packaging irrésistible (bonus, garanties, rareté, urgence). Il ne fait pas le packaging et ne décide pas le système d'offres complet : il sort un prix et sa structure.

---

## Principe directeur

Le marketing, c'est de l'empathie : comprendre QUI est prêt à payer QUELLE valeur pour QUELLE transformation, puis fixer le prix là-dessus. Trois règles non négociables :

1. **Le prix reflète la transformation, jamais le contenu.** "Si vous lui apportez cette transformation là, cette valeur là, vous pouvez vendre votre produit au moins 3 4000 euros peu importe ce qu'il y a dedans." Quinze vidéos plus un PDF ne valent rien en soi : ce qui se paie, c'est le résultat sur la bottom line du client.

2. **Tu pars du prix, pas du produit.** Protocole inverse : définis d'abord le prix visé selon ta journée idéale, puis conçois l'offre pour que la valeur perçue le justifie largement. "D'abord vous allez vous demander à quel prix est-ce que je veux vendre mon produit."

3. **Un prix haut est bon pour tout le monde.** Engagement émotionnel, complétion, résultats, témoignages, marges réinvesties dans l'expérience client. "Mes programmes qui coûtent 3000 euros, il y a 99 pour 100 de taux de complétion alors qu'un programme à 100 200 euros, les gens ne vont jamais avoir de résultats."

---

## Étape 1 : Poser les 2 erreurs de débutant et reframer

**Méthode :** avant tout calcul, neutralise les deux réflexes qui plombent le prix. Eliott : "Il y a 2 erreurs que la plupart des débutants font par rapport au prix."

| Erreur | Ce que fait le débutant | Pourquoi c'est faux |
|---|---|---|
| **Copier les concurrents** | Regarde le marché et se met "à peu près en dessous pour faire plus de ventes" | Le prix des autres ne dit rien de la valeur de TA transformation. Te mettre sous le marché n'a que des inconvénients. |
| **Pricer le contenu** | "Il fait 15 vidéos asynchrones, un PDF, un template" puis se demande "combien est-ce que ce contenu coûte" | Les gens n'achètent pas un contenu. Le prix doit refléter la valeur perçue, la transformation. |

**Outils :** Claude (dialogue de cadrage), la fiche offre déjà produite (cible + transformation + format de delivery).

**Piège :** commencer à chiffrer avant d'avoir tué ces deux réflexes. Si la personne raisonne encore en "heures de vidéo", tout le reste sera faux.

Énonce les deux erreurs à voix haute dès l'ouverture, puis demande : "Quelle est la transformation concrète que ton client obtient après ton offre, en résultat mesurable ?" Refuse les réponses processus ("il apprend à créer du contenu") et relance : "Et grâce à ça, qu'est-ce qu'il obtient concrètement ?"

---

## Étape 2 : Fixer le prix à partir de la journée idéale (protocole inverse)

**Méthode :** le prix d'entrée que tu peux pratiquer dépend de la structure de delivery que tu acceptes de vivre. Eliott : "Si vous faites un prix premier à plus de 3000 euros, vous devrez avoir les gens au téléphone, les closer au téléphone, avoir une relation personnelle avec chacun de vos clients. Si ce n'est pas dans votre journée idéale, vous ne pourrez pas avoir un prix à 3000 euros." On part donc de la journée idéale, on en déduit le format, on en déduit la fourchette.

Arbre de décision delivery vers fourchette de prix (verbatim de la masterclass) :

| Format de delivery | Fourchette de prix | Condition |
|---|---|---|
| Full asynchrone (vidéos + ressources, éventuellement réponses async) | jusqu'à 1000€, plafond 1500€ | "S'il n'y a vraiment pas d'interaction, pas d'aide directe personnalisée, pas plus de 1000 euros." |
| Asynchrone + coaching de groupe | 600€ à 5000€ | "Vous ne pouvez pas le vendre en dessous de 600 par contre." |
| Coaching de groupe intensif | 1500€ à 5000€ | base de connaissances à vie + coaching async illimité plusieurs mois |
| Accompagnement individuel (1:1) | 3000€ à 20000€+ | "Est-ce que vous aimez le coaching ? Si oui, vous pouvez mettre des prix jusqu'à 10, 15, 20000 euros." |
| Basé sur la performance | illimité | conditionné au résultat réellement obtenu |

**Outils :** Claude pour dérouler l'arbre de décision question par question (closer au téléphone ? gérer une équipe de coachs ? coaching de groupe ? tout async ?).

**Piège :** choisir un prix qui ne tient pas avec ta journée idéale. Viser 6000€ tout en refusant d'appeler qui que ce soit ne marche pas : "si vous ne voulez pas appeler des gens, vous aurez du mal à vendre un produit à plus de 1500 euros."

Déroule l'arbre dans cet ordre : closes-tu au téléphone ? veux-tu gérer une équipe de closers ? aides-tu les gens en 1:1, aimes-tu le coaching ? veux-tu du coaching de groupe ou du tout-async ? À chaque réponse, resserre la fourchette. Sors une fourchette, pas encore un prix sec.

---

## Étape 3 : Appliquer la règle +50 à 100%

**Méthode :** une fois la fourchette posée, demande à la personne le prix avec lequel elle est "à l'aise", puis pousse-le. Eliott : "Quand vous avez votre prix, faites une augmentation de 50%, 100%. Si vous vous dites que je suis à l'aise de facturer 1000 euros, testez 1500. Si vous êtes à l'aise de facturer 20000, testez 30000."

**Outils :** Claude pour annoncer le prix recommandé après application de la règle.

**Piège :** prendre le premier instinct comme prix final. Le premier instinct est presque toujours sous-évalué (peur de demander). La règle +50 à 100% corrige ce biais de prudence.

Demande : "Quel prix te semble raisonnable pour ton offre aujourd'hui, premier instinct, sans filtrer ?" Puis annonce le prix recommandé (instinct x 1,5 à x 2) et la fourchette basse/haute. Précise que ce prix conditionne ensuite la sélection des solutions : "gardez en tête ce prix pour savoir exactement quoi délivrer et comment le délivrer."

---

## Étape 4 : Travailler l'équation de valeur, surtout le dénominateur

**Méthode :** la valeur perçue se calcule. Eliott reprend l'équation de Hormozi et insiste sur le bas de la fraction, là où la plupart des entrepreneurs ne regardent jamais.

```text
Valeur perçue = (Résultat rêvé x Probabilité de succès anticipée) / (Délai x Efforts et sacrifices)
```

- **Numérateur (le résultat rêvé x la proba de succès) :** "le résultat rêvé, logiquement vous êtes quasiment sûr de l'avoir bien ciblé si vous avez bien fait vos appels clients." La proba de succès se construit par le marketing : "c'est normal que tu n'aies pas perdu de poids parce que les méthodes que tu as déjà essayées sont inefficaces pour des raisons x, y et z. Moi mes méthodes sont efficaces pour des raisons XYZ, et regarde, j'ai 500 témoignages à te proposer."
- **Dénominateur (le délai x les efforts et sacrifices) :** c'est là que se jouent les grosses boîtes. "Amazon vend la même chose que les autres, une plateforme de e-commerce, mais aucun effort et sacrifice : retour gratuit, service client extraordinaire, le produit en 2 heures quand tu habites à Paris. Le coût au dénominateur est réduit quasiment à 0."

**Outils :** Claude pour scorer chaque terme de l'équation sur 10 (résultat rêvé bien ciblé, proba de succès rendue crédible, délai court, efforts faibles).

**Piège :** vendre des features. Eliott : "vendre un futur et pas des fonctionnalités. Les gens s'en foutent des fonctionnalités. Le moins il y a de fonctionnalités dans votre produit, le plus il va lui permettre d'aller rapidement vers son objectif, le plus ça aura de la valeur." Empiler des heures de vidéo gonfle le dénominateur et détruit la valeur perçue.

Score les 4 termes pour la cible précise. Si la valeur perçue est faible, ne baisse pas le prix : retravaille l'offre pour réduire le délai et les efforts (le concombre dans le désert : "le contexte et l'état psychologique de votre prospect définissent la valeur qu'il perçoit"). Règle morale qui borne le tout : "vous avez une obligation morale de toujours délivrer plus de valeur que ce que la personne a l'impression que ça vaut. Si vous délivrez 5000 euros de valeur, il faut que la personne paye 3500 et qu'elle ait l'impression d'avoir fait une affaire."

---

## Étape 5 : Choisir la bonne cible pour le bon prix

**Méthode :** même compétence, même service : change la cible et tu changes le prix, parce que tu changes la valeur perçue. C'est le levier le plus puissant et le plus négligé.

Exemple verbatim de la méditation, déroulé sur 3 cibles :
- **Débutant qui veut apprendre à méditer :** "peut-être qu'elle va vouloir payer 200 euros max ou 300 euros max."
- **Pratiquant qui n'arrive pas à tenir sa routine :** programme de groupe sur un an, workshops, garantie. "Là ça peut être un groupe 5 600 euros parce que la personne sait déjà le bénéfice, elle l'a déjà vécu, mais elle n'arrive pas à tenir sa routine et vous lui apportez la solution."
- **Personne en quête d'éveil spirituel :** programme d'un an, retraites présentielles obligatoires. "Au final les gens auront payé sur un an 15000 euros pour de la méditation."

Eliott applique exactement le même levier à son propre savoir : "Je pourrais vendre des produits sur la prise de notes à 15000 euros. Il faut juste changer la cible. Au lieu de vendre une formation à 200 balles pour apprendre le meilleur système de prise de notes, je pourrais vendre un programme unique pour devenir un grand penseur. Le programme grand penseur, il coûte 10000 euros."

**Outils :** Claude pour explorer les variantes de cible avant de figer le prix.

**Piège :** rester bloqué sur "dans ma niche, les gens ne paient pas cher". Faux : "ça dépend à qui vous vous adressez et pourquoi vous leur proposez ce programme." Si tu veux un prix élevé sur une cible particuliers à faible ROI, envisage de pivoter vers une cible qui tire un vrai retour sur investissement (formation professionnalisante, reconversion).

---

## Étape 6 : Structurer le paiement quand le prix fait barrière

**Méthode :** le prix n'est pas obligé d'être un montant up-front. "Le pricing, c'est toujours à mettre en valeur avec le reste de l'offre." Quand le montant total bloque, étale-le et conditionne-le au résultat pour garder un prix total élevé tout en abaissant la barrière d'entrée.

Trois structures :
- **Conditionnel au résultat :** petit montant à la signature, puis paliers déclenchés par les résultats atteints.
- **Performance-based :** pourcentage du chiffre d'affaires généré.
- **Garantie financière inversée :** si pas de résultat, remboursement + bonus cash.

Exemple verbatim complet (freelance qui doit atteindre 25000€/mois) : "Je vais vous facturer 25000 euros, le mois type que vous allez obtenir. Je vous facture 500 euros à la signature aujourd'hui. Quand vous avez facturé 10000 euros, je vous facture 5000 euros. Quand vous avez refacturé 10000 euros, je vous re-facture 5000 euros, et ainsi de suite jusqu'aux 25000 euros. Si au bout de 3 mois vous n'avez même pas fait de chiffre d'affaires marginal, je vous rembourse non seulement les 500 euros mais je vous envoie en plus 1500 euros de ma poche. Donc vous aurez gagné 1500 euros dans tous les cas, ou vous serez à 25000 euros par mois."

**Outils :** Claude pour formuler la structure de paiement avec les paliers exacts.

**Piège :** voir la structure conditionnelle comme un risque personnel au lieu d'un calcul. La personne "s'engage quand même en mettant 500 euros et en signant un contrat", et tu n'es payé que si ça marche. L'offre "passe beaucoup mieux".

---

## Exemples

### Bon

> "Je vous facture 25000 euros, le mois type que vous allez obtenir. 500 euros à la signature, puis 5000 euros à chaque palier de 10000 euros atteint. Si à 3 mois vous n'avez rien fait, je vous rembourse les 500 euros et je vous envoie 1500 euros de ma poche."

Pourquoi c'est bon : le prix total est élevé (25000€) mais la barrière d'entrée est minuscule (500€), il est calé sur la valeur réelle (un mois de revenus du client) et le risque est inversé. L'offre passe sans friction.

> "Le programme grand penseur, il coûte 10000 euros. Il faut juste changer la cible : au lieu de vendre une formation à 200 balles pour apprendre la prise de notes, je vends un programme pour devenir un grand penseur."

Pourquoi c'est bon : même compétence de base, prix multiplié par 50 en changeant la cible et la transformation perçue. C'est le levier cible appliqué proprement.

### Mauvais

> "J'ai 4 sessions de coaching à 400 euros chacune, plus 15 vidéos, donc ça fait 1600 euros."

Pourquoi c'est raté : c'est pricer le contenu, pas la transformation. Le client n'achète pas des sessions, il achète un résultat. Cette logique plafonne mécaniquement le prix au coût perçu de production.

> "Mon concurrent vend à 1000 euros, je me mets à 800 pour gagner des ventes."

Pourquoi c'est raté : se caler sous le marché tue l'engagement émotionnel, la complétion, attire les mauvais clients ("les gens prêts à mettre très peu d'argent sont des clients trop chiants") et détruit les marges. Le prix du concurrent ne dit rien de la valeur de ta transformation.

---

## Pièges

- **Pricer au temps passé ou au contenu** au lieu de la transformation. "Le prix, ce n'est pas le contenu."
- **Se mettre légèrement sous le marché** pour vendre plus : que des inconvénients (engagement, complétion, mauvais clients, marges).
- **Prendre la garantie ou le prix personnellement.** C'est un calcul mathématique, pas un risque émotionnel.
- **Gonfler le numérateur en empilant des features** : ça alourdit le dénominateur (délai, efforts) et baisse la valeur perçue.
- **Croire que "ma niche ne paie pas cher"** : c'est une question de cible, pas de thématique.
- **Fixer un prix qui ne tient pas avec ta journée idéale** : un prix 1:1 sans envie de coaching ne se vend pas.

---

## Références

- Formation vidéo : <a href="/plateforme/business-os/atomic-offers">Atomic Offers -&gt;</a> modules 5.2 (masterclass prix) et 5.3 (masterclass valeur), d'où vient toute la méthode et le verbatim de ce skill.
- Formation vidéo : <a href="/plateforme/business-os/challenge-offre-aligne">Challenge Offre Alignée -&gt;</a> pour valider en amont que l'offre (donc le prix visé) est alignée avec ta journée idéale.
- Cours : <a href="/plateforme/business-os/construire-offre/systeme-offre#etape-5">Construire une offre, étape 5 -&gt;</a> où le pricing s'intègre au packaging complet.
- Skills liés : <a href="/plateforme/business-os/offre__solutions-offre">solutions-offre -&gt;</a> (choisit le format de delivery qui borne la fourchette de prix), <a href="/plateforme/business-os/templates__2-Vente__systeme-offres">systeme-offres -&gt;</a> (bonus, garanties, rareté, urgence qui justifient et défendent le prix), <a href="/plateforme/business-os/templates__2-Vente__creer-offre">creer-offre -&gt;</a> (l'offre complète dont le prix est un maillon).

---

## Checklist

- [ ] Les 2 erreurs (copier les concurrents, pricer le contenu) posées et neutralisées.
- [ ] Transformation reformulée en résultat mesurable, pas en processus.
- [ ] Format de delivery dérivé de la journée idéale, fourchette de prix déduite de l'arbre.
- [ ] Règle +50 à 100% appliquée au prix instinctif.
- [ ] Équation de valeur scorée, dénominateur (délai + efforts) travaillé.
- [ ] Cible choisie pour maximiser la valeur perçue (levier cible testé).
- [ ] Structure de paiement définie si le montant fait barrière (conditionnel / performance / garantie inversée).
- [ ] Prix recommandé + fourchette basse/haute + structure sortis noir sur blanc.

---

Cycle complet : `/solutions-offre` (format de delivery) -&gt; ce skill (prix + structure) -&gt; `/systeme-offres` (bonus, garanties, rareté, urgence) -&gt; `/nommer-offre`.
