---
slug: creer-offre
command: /creer-offre
---

# Créer une offre V1 de bout en bout

> **Objectif :** partir de zéro (juste une idée et un savoir-faire) et sortir en un seul passage rapide un document d'offre activable : cible -&gt; avant/après -&gt; problèmes -&gt; solutions -&gt; prix -&gt; packaging -&gt; nom. À la fin, tu as une offre V1 sur papier prête à devenir page de vente.

C'est le skill **colonne vertébrale** du thème Construire une offre. Il fait le tour complet en mode condensé : un passage rapide sur chaque brique pour avoir une V1 tenable, puis il te renvoie vers le sous-skill granulaire de chaque étape pour creuser.

Distinction à garder en tête : ce skill est le **mode zéro** (tu pars d'une idée, tu enchaines les 7 briques en un coup). Si tu veux orchestrer plus finement (état des lieux, repositionnement d'une offre qui se vend déjà, routage vers une seule brique), passe par `/systeme-offre`. Si tu veux lancer en 30 jours sans infra, passe par `/offre-minimum-viable`.

---

## Principe directeur

Une idée n'est pas une offre. **Une offre = transformation précise + personne précise + prix précis.**

Et une offre se construit à partir des **mots réels des clients**, pas de tes suppositions. La règle que je répète : hier soir tu avais une idée (ce que TOI tu pensais), ce matin tu as des données (ce que de vraies personnes t'ont dit). L'avant/après esquissé de tête, c'est tes suppositions. L'avant/après après les appels, ce sont leurs mots exacts. Les mots du client sont une meilleure copy que tout ce que tu écriras toi-même.

Trois reframings non négociables, à poser avant de commencer :

- **Information vs transformation.** Une offre encyclopédie ("49 conseils pour méditer") vend de l'information. Les gens veulent une transformation. Tatoue-toi ça.
- **Commodité vs différenciée.** "Agence à 1000€/mois, peut-être des résultats" = comparable, les gens prennent le moins cher. "100 leads qualifiés ou tu ne paies rien" = incomparable, achat à la valeur.
- **Sell futures, not features.** "Je gère vos publicités Meta" devient "je libère votre temps, protège votre tranquillité d'esprit, garantis le résultat". Même service, valeur perçue radicalement différente.

Le fil rouge de tout le marketing, c'est l'empathie : comprendre QUI est prêt à payer QUELLE valeur pour QUELLE transformation, puis designer le programme exactement comme la personne le voudrait.

---

## Étape 1 : Clarifier l'ICP et son niveau de conscience

**Méthode :** avant de demander des opinions, inventorie les sources de vérité où le client parle déjà (support/Intercom, Q&A de webinaire, commentaires sous les ads, objections en call de vente, raisons de churn). Puis dresse le portrait en image concrète : qui il est et à quel moment de sa vie il te trouve, le job-to-be-done réel derrière l'achat, ses douleurs en mots exacts, son rêve en image, son vocabulaire, qui il écoute, quelles alternatives il compare (du software à 19£/mois au mastermind à 20000£/an). Positionne-le sur l'échelle de Schwartz (unaware -&gt; problem aware -&gt; solution aware -&gt; product aware -&gt; most aware) pour savoir quoi lui dire.

**Outils :** Claude (dialogue, une question à la fois, exiger de vrais exemples).

**Piège :** parler à "tout le monde", et remplir les trous avec des suppositions. Marque chaque hypothèse non vérifiée par [À VALIDER].

Exercice obligatoire pour ancrer la niche : liste 10 personnes réelles (avec des prénoms) dans la cible visée. Si tu ne connais pas 10 personnes dans ta niche, c'est un signal d'alerte : marché peut-être fantasmé, va chercher des inconnus (LinkedIn, groupes) ou reconsidère la niche.

Les 4 critères d'un bon marché (Hormozi), à valider sur ta cible :

| Critère | Question |
|---|---|
| Douleur massive | Le problème est-il ressenti fort au quotidien, pas juste "agréable à résoudre" ? |
| Pouvoir d'achat | La cible peut-elle payer ? |
| Niché et ciblable | Peux-tu la trouver (LinkedIn, groupes, events, pages d'influenceurs) ? |
| En croissance | Le marché monte-t-il, plutôt que décliner ? |

> Encadré : c'est le **même skill** que le Thème A (Bases marketing). Ne duplique pas la fiche ICP, partage-la.

Sortie de l'étape : une fiche ICP avec verbatim source. Pour la méthode complète (5 niveaux de Schwartz détaillés, gabarit de fiche), va voir le skill dédié.

---

## Étape 2 : L'avant / après avec les mots exacts des clients

**Méthode :** remplis le tableau 5 lignes (ce qu'ils font au quotidien / ressentent / craignent / ont honte ou évitent / veulent vraiment) en deux colonnes, AVANT (point A) et APRÈS (point B). Pour creuser sous le factuel : ferme les yeux, mets-toi dans leurs baskets, descends jusqu'aux peurs et croyances cachées ("il n'arrive pas à faire ça" devient "il se sent incompétent, syndrome de l'imposteur").

**Outils :** Claude + tes notes d'interviews (les vrais mots).

**Piège :** un point B émotionnel et abstrait. Le point B est une IMAGE CONCRÈTE visualisable, toujours. Et ne reformule pas les mots du client : tu perdrais la meilleure copy.

| | AVANT (Point A) | APRÈS (Point B) |
|---|---|---|
| Ce qu'ils font au quotidien | ... | ... |
| Ce qu'ils ressentent | ... | ... |
| Ce qu'ils craignent | ... | ... |
| Ce dont ils ont honte | ... | ... |
| Ce qu'ils veulent vraiment | ... | ... |

Une fois rempli, réécris l'USP avec ces mots récoltés : "J'aide [cible] à [résultat APRÈS en leurs mots] en [temps] grâce à [mécanisme = les étapes nommées]".

Sortie de l'étape : le tableau avant/après + une USP V1. Détails et exemples supplémentaires dans le skill dédié.

---

## Étape 3 : Trouver les problèmes à résoudre

**Méthode :** d'abord liste les **étapes A-&gt;B** (3 à 7 max), chacune une transformation partielle dont l'ordre est logique (chaque étape débloque la suivante). Ces étapes SONT les modules de l'offre. Puis pour chaque étape, liste tous les problèmes, questions, blocages, peurs, confusions : vise 10 à 15 par étape, 100+ au total.

**Outils :** Claude + verbatim d'interviews. Si le verbatim manque, lance le protocole d'interview (DM Mom Test + trame d'appel) sans jamais pitcher.

**Piège :** inventer les problèmes au lieu de les récolter. Si tu as moins de 10 problèmes par étape, tu ne connais pas assez ton marché : retourne en interview.

Exemple d'étapes verbatim (Atomic Perspectives) : 1. carte de la thématique, 2. identifier les livres et concepts de référence, 3. tout lire et déconstruire (système de prise de notes), 4. incubation (un essai par jour), 5. exercices d'émergence, 6. assembler en une méthode propre.

Le DM de validation qui prend ~50% de RDV : un détail spécifique qui montre que ce n'est pas copié-collé, pas de pitch, format court avec date précise, une carte cadeau Amazon en échange. Règle absolue en appel : ne jamais parler de son idée. Dès qu'on pitche, les gens sont polis et disent "c'est génial".

Sortie de l'étape : liste des 3-7 étapes + 10-15 problèmes par étape. Protocole d'interview complet dans le skill dédié.

---

## Étape 4 : Trouver les solutions à inclure

**Méthode :** pour le mécanisme unique, applique le protocole d'insights (un bon insight = nouveau pour la personne vs la culture de base du domaine + qui résonne ; pyramide valeurs -&gt; grandes idées -&gt; stratégies -&gt; méthodes). Puis pour chaque problème, génère la solution en 3 phases : divergence WTF (si tu pouvais être là 24h/24, budget infini, que ferais-tu ?), scalable (transformer chaque WTF en livrable réutilisable), sélection (garder ce qui a forte valeur + rentable + aligné journée idéale + scalable). C'est ici que tu choisis le format de delivery : 1:1, groupe, async ou hybride.

**Outils :** Claude pour diverger sans censure, puis converger.

**Piège :** penser scalable d'abord (comme les concurrents) au lieu de diverger. Et bâcler cette étape : c'est la plus importante, prends une semaine s'il le faut.

Exemple de WTF -&gt; scalable verbatim : "je viens chez toi une journée et j'écris tous tes posts à ta place" devient "je me filme en train d'écrire un post de A à Z = étude de cas vidéo réutilisable". Exemple de concept propriétaire né d'une valeur : valeur "un système accompagne l'énergie, ne contraint pas" croisée avec gestion du temps a donné le "tableau émotion action", un outil qui fait 500-1000 likes LinkedIn et fait acheter les gens.

Sortie de l'étape : solutions retenues par étape + format de delivery. Méthode complète (insights, WTF, sélection) dans le skill dédié.

---

## Étape 5 : Pricer et packager (valeur, prix, bonus, garantie, rareté, urgence)

C'est l'étape la plus dense. En mode condensé, vise une V1 défendable sur chaque levier, puis approfondis avec les skills dédiés.

### Prix

**Méthode :** le prix = valeur perçue de la transformation, pas le contenu. Protocole inversé : définis d'abord le prix visé selon ta JOURNÉE IDÉALE, puis conçois l'offre pour le justifier largement. Arbre delivery -&gt; fourchette : full async &lt;=1000€ ; async + coaching groupe 600-5000€ ; 1:1 jusqu'à 10-20000€. Règle pratique : prends le prix où tu es à l'aise, +50 à 100%.

**Piège :** les 2 erreurs classiques, copier les concurrents et pricer le contenu ("15 vidéos + PDF = X€"). Et prendre le prix personnellement : c'est un calcul mathématique. Le cercle vertueux du prix haut : engagement émotionnel -&gt; 99% de complétion à 3000€ vs 10% à 100€ -&gt; résultats -&gt; témoignages.

### Valeur

**Méthode :** équation de Hormozi = (Résultat rêvé x Probabilité de succès) / (Délai x Efforts). Maximise le haut (le bon résultat en mots clients + preuves) et minimise surtout le **dénominateur** (délai et efforts perçus). Le panneau "prochain train dans 3 min" a plus augmenté la satisfaction que des trains plus rapides : la perception EST la valeur.

### Packaging

**Bonus :** contrer les objections restantes (véhicule "je ne sais pas comment" -&gt; checklist/template/prompt ; interne "je ne suis pas capable" -&gt; étude de cas/communauté ; externe "pas le temps" -&gt; méthode pour gens occupés/async). Formats courts uniquement, MAX 3-5 sinon peur de crouler.

**Garantie :** inverser le risque est un calcul mathématique (x4 conversions même avec x2 remboursements = gagnant). 4 types (conditionnelle, inconditionnelle 30j, implicite/performance, anti-garantie illégale &lt;14j en France).

**Rareté :** 5 types (limite temps/quantité, accès sur candidature, événementiel, limitation de service "5 clients max", honnêteté radicale "il reste 2 places").

**Urgence :** sans urgence personne ne décide (le flyer de pizza qui finit dans le tiroir). 4 types (cohortée, saisonnière, promo tarifaire, opportunité explosive).

> Système d'offres : tout business a besoin de 3 offres pour la même cible et le même problème - acquisition ~7€ (carte bleue une 1ère fois), scalable, immortelle high-ticket (toute la méthode, la marge se fait là, x20). Conçois l'immortelle en premier.

Sortie de l'étape : prix recommandé + structure de paiement + bonus/garantie/rareté/urgence formulés. Pour creuser, va voir `/pricer-offre` et `/systeme-offres`.

---

## Étape 6 : Trouver le nom (et l'USP)

**Méthode :** valide d'abord l'USP sur les 5 critères PMDMT (Précise, Mesurable, Désirable = validée par de vraies personnes, Mécanisée = process nommé qui t'appartient, Temporellement définie). Puis trouve le nom en 3 temps : un mot conteneur (le programme / le système / le challenge / la méthode) qui mécanise et ajoute de la valeur perçue ; un brainstorm 2h (balancer tous les mots, en assembler 2 qui sonnent, comme "atomic thinking" né de atomicité des pensées + thinking) ; converger sur ce qui incorpore tes valeurs et reste déclinable (toute la gamme "atomic X").

**Outils :** Claude pour le brainstorm et le tri.

**Piège :** un nom générique ("formation second cerveau pour les nuls") qui rend banal et copiable. Et une USP fourre-tout ("j'aide les entrepreneurs à réussir").

Format final : "[Nom] - le [conteneur] en [temps] pour [résultat]", l'USP encapsulée dans le nom. Exemple : "Atomic Perspectives - le programme intensif de 2 mois pour devenir expert de ton domaine et créer ta propre méthode".

Sortie de l'étape : un nom valide + l'USP finale. Méthode complète dans `/nommer-offre`.

---

## Étape 7 : Livrer le document d'offre V1

**Méthode :** assemble tout dans un document unique activable. C'est le livrable de fin du mode zéro.

```
NOM DE L'OFFRE : [Nom - le conteneur en temps pour résultat]
CIBLE : [Description précise + niveau de conscience]
USP : J'aide [X] à [Y en leurs mots] en [Z] grâce à [mécanisme = étapes nommées]
AVANT (mots exacts) : [Situation actuelle]
APRÈS (mots exacts) : [Résultat rêvé, image concrète]
ÉTAPES (modules de l'offre) : ① ... ② ... ③ ...
FORMAT DE DELIVERY : [1:1 / groupe / async / hybride]
PRIX : [Fourchette + justification par la valeur]
GARANTIE : [Type + formulation exacte]
BONUS : [Bonus 1 -> objection ciblée] / [Bonus 2 -> objection ciblée]
RARETÉ / URGENCE : [Ce qui est en place]
```

**Chaînage clé :** une fois l'offre V1 posée, enchaine avec les bases marketing pour intégrer le reframing des croyances. Le marketing fonctionne en 3 temps : convaincre (reframer les croyances), persuader (avant/après émotionnel), casser les dernières barrières (garantie/urgence/bonus). Le document d'offre + la carte des croyances = la page de vente s'écrit toute seule derrière.

**Outils :** Gamma pour mettre en forme le document final.

---

## Exemples

### Bon

**Avant/après (Atomic Perspectives, verbatim).**
AVANT : "Syndrome de l'imposteur, pas de méthode, j'ai l'impression d'être superficiel, peur que mon business s'effondre si j'arrête de publier, je cours après les dernières tendances sans jamais aller en profondeur."
APRÈS : "Expert reconnu dans mon domaine, j'ai créé ma propre méthode originale, j'apporte vraiment de la valeur, mon business tient sur mes idées pas sur mes heures."

Pourquoi c'est bon : ce sont les mots exacts des clients, descendus sous le factuel jusqu'aux peurs cachées (imposteur, effondrement). Cette copy se réutilise telle quelle dans la page de vente.

**Point B concret.** "Elle signe 2 nouveaux clients par mois sans faire de cold calling." Pourquoi c'est bon : c'est une image visualisable, pas une émotion.

**USP (verbatim).** "J'aide les copywriters à signer leur premier client à +3000€ en 14 jours grâce au cold emailing authentique." Pourquoi c'est bon : précise, mesurable, temporalisée, mécanisée par un process nommé.

### Mauvais

**Point B émotionnel.** "Elle se sent épanouie dans son business." Pourquoi c'est raté : abstrait, non visualisable, vrai pour tout le monde, donc ne vend rien.

**USP fourre-tout.** "J'aide les entrepreneurs à réussir." Pourquoi c'est raté : vague, pas mesurable, pas temporalisée, aucun mécanisme. Comparable à 1000 autres.

**Prix au temps passé.** "4 sessions x 400€ = 1600€." Pourquoi c'est raté : tu prices le contenu, pas la transformation. Le client compare et négocie.

---

## Pièges

- Valider l'offre sur tes suppositions au lieu des mots clients. Exige toujours le verbatim.
- Moins de 10 problèmes par étape : tu ne connais pas assez ton marché, retourne en interview.
- Pricer au temps passé ou se mettre sous le marché. Le prix se fixe à la valeur de transformation.
- Trop de bonus (peur de crouler) ou une fausse rareté. Max 3-5 bonus ciblés, rareté honnête.
- Filtrer les solutions sur la seule scalabilité. Filtre d'abord sur ta journée idéale.
- Pas d'urgence : l'offre finit dans le tiroir comme le flyer de pizza.

---

## Références

- Formation vidéo : <a href="/plateforme/business-os/atomic-offers">Atomic Offers</a> - la méthode complète dont ce skill est la synthèse activable (prix, valeur, problèmes, solutions, bonus, garanties, nom).
- Formation vidéo : <a href="/plateforme/business-os/challenge-offre-aligne">Challenge Offre Alignée</a> - le challenge 5 jours pour valider une offre alignée en amont.
- Formation vidéo : <a href="/plateforme/business-os/atomic-funnels">Atomic Funnels</a> - le tunnel de vente qui se construit derrière l'offre.
- Skill orchestrateur : <a href="/plateforme/business-os/offre__systeme-offre">systeme-offre</a> - état des lieux et routage fin (mode repositionnement inclus).
- Sous-skills pour approfondir : <a href="/plateforme/business-os/bases-marketing__cartographier-icp">cartographier-icp</a>, <a href="/plateforme/business-os/offre__avant-apres">avant-apres</a>, <a href="/plateforme/business-os/offre__problemes-par-etape">problemes-par-etape</a>, <a href="/plateforme/business-os/offre__solutions-offre">solutions-offre</a>, <a href="/plateforme/business-os/templates__2-Vente__pricer-offre">pricer-offre</a>, <a href="/plateforme/business-os/templates__2-Vente__systeme-offres">systeme-offres</a>, <a href="/plateforme/business-os/offre__nommer-offre">nommer-offre</a>.
- Variante : <a href="/plateforme/business-os/templates__2-Vente__offre-minimum-viable">offre-minimum-viable</a> - si tu veux lancer en 30 jours sans infra.

---

## Checklist

- [ ] Fiche ICP avec verbatim source + niveau de conscience positionné.
- [ ] Tableau avant/après en mots exacts des clients, point B en image concrète.
- [ ] 3-7 étapes A-&gt;B (les modules) + 10-15 problèmes par étape.
- [ ] Solutions retenues par étape (WTF -&gt; scalable -&gt; sélection) + format de delivery choisi.
- [ ] Prix fixé à la valeur (pas au contenu) + bonus, garantie, rareté, urgence formulés.
- [ ] Nom valide ("[Nom] - le [conteneur] en [temps] pour [résultat]") + USP PMDMT.
- [ ] Document d'offre V1 assemblé, prêt à enchainer vers le reframing des croyances.

---

Cycle complet : `/systeme-offre` (orchestrateur) -&gt; **`/creer-offre`** (cette fiche, mode zéro de bout en bout) -&gt; approfondir avec `/cartographier-icp`, `/avant-apres`, `/problemes-par-etape`, `/solutions-offre`, `/pricer-offre`, `/systeme-offres`, `/nommer-offre` -&gt; enchaine vers les bases marketing (reframing des croyances) puis les livrables marketing (page de vente, VSL, séquence email).
