---
name: problemes-par-etape
description: "Transforme la transformation A vers B en une liste d'étapes (3 à 7 modules) puis en 100+ problèmes répartis par étape, via brainstorm et interviews clients. Les étapes deviennent les modules, les problèmes deviennent le plan de formation."
---

# Trouver les problèmes à résoudre : la colonne vertébrale de l'offre

> **Objectif :** transformer la transformation A vers B en une liste d'étapes (3 à 7 modules) puis en 100+ problèmes répartis par étape, via brainstorm + interviews clients, pour ne plus jamais inventer le contenu de ton offre.

C'est l'étape qui décide de tout ce qui vient après. Elle se place entre l'avant/après (`/avant-apres`) et la création des solutions (`/solutions-offre`). On ne crée rien de neuf ici : on récolte. Les étapes deviennent les modules de l'offre, et les problèmes par étape deviennent le plan de formation. Une offre n'est rien d'autre qu'un véhicule qui amène le prospect de sa situation actuelle à sa situation désirée. Cette fiche dessine ce véhicule.

Reframing de base : "je vais créer du contenu et voir ce qui intéresse" ne marche pas. Les problèmes de tes clients SONT ton plan de formation. Tu ne crées rien, tu réponds à ce qu'ils t'ont dit.

---

## Principe directeur

Trois règles non négociables :

1. **Les étapes sont les modules, les problèmes sont les leçons.** Tu ne pars pas d'un programme imaginé. Tu pars du chemin réel de transformation, tu le découpes, et chaque blocage rencontré sur ce chemin devient une leçon à produire. L'offre se conçoit du chemin du client, pas de ton envie de filmer telle ou telle vidéo.

2. **La quantité est un signal de connaissance marché.** Vise 10 à 15 problèmes par étape, 100+ au total. Si tu trouves moins de 10 problèmes par étape, ce n'est pas un détail de format : ça veut dire que tu ne connais pas encore assez ton marché. Retourne en interview.

3. **On récolte, on n'invente pas.** Le brainstorm seul produit tes suppositions. Les vrais problèmes, dans les vrais mots, viennent des appels clients. Et règle absolue pendant ces appels : ne jamais pitcher ton idée. Dès que tu pitches, les gens deviennent polis et te disent "génial", et tu repars avec zéro information utile.

---

## Étape 1 : Lister les étapes A vers B (les modules)

**Méthode :** rappelle d'abord le point A et le point B en mots clients (issus de `/avant-apres`), puis demande : quelles grandes étapes le client doit-il franchir pour passer de A à B ? Chaque étape est une transformation partielle, pas une action isolée. L'ordre est logique : chaque étape débloque la suivante. Ces étapes SONT les modules de l'offre, le client paie pour être guidé à travers chacune.

**Outils :** Claude (dialogue, une étape à la fois). Un document unique "étapes + problèmes" que tu remplis au fur et à mesure.

**Piège :** confondre une étape (transformation) avec une tâche (action ponctuelle). "Ouvrir un compte LinkedIn" est une tâche. "Devenir expert reconnu de son domaine" est une étape, qui contient des dizaines de problèmes.

Instructions d'exécution :

- Contrainte de nombre : entre 3 et 7 étapes. En dessous, l'offre est trop fine pour valoir un prix ; au-dessus, tu mélanges étapes et sous-étapes (descends les sous-étapes d'un cran).
- Critère de validation d'une étape : elle débloque-t-elle la suivante ? Si l'ordre peut être permuté sans conséquence, ce ne sont pas de vraies étapes de transformation.
- Le marché peut être un service, une agence, un produit physique : la logique étapes vers problèmes vaut "à tout niveau".

Cette logique d'étapes A vers B est détaillée dans le skill <a href="/plateforme/business-os/offre__problemes-par-etape">problemes-par-etape -&gt;</a> et approfondie dans la formation vidéo Atomic Offers (6.3).

---

## Étape 2 : Brainstormer les problèmes par étape (toi d'abord)

**Méthode :** prends chaque étape, une par une, et demande "quels sont TOUS les problèmes, questions, blocages, peurs, confusions que mon client va rencontrer à cette étape ?". Tu fais d'abord ce travail seul, en session de brainstorm, avant de parler à qui que ce soit. C'est l'étape "tes suppositions". Elle est utile pour amorcer, jamais pour conclure.

**Outils :** Claude pour ouvrir le flux ("donne-moi 15 problèmes plausibles à cette étape, j'élague"). Le document étapes + problèmes.

**Piège :** s'arrêter à 4 ou 5 problèmes par étape parce qu'on les trouve évidents. Le manque de problèmes n'est pas un signe que l'étape est simple, c'est le signe que tu ne connais pas assez ton marché ("c'est probablement que vous n'avez pas été assez loin ou que vous n'avez pas assez de connaissances marché").

Instructions d'exécution :

- Cible : 10 à 15 problèmes par étape minimum. 100+ au total sur l'offre.
- Formule à poser pour chaque problème : préfère la forme "Comment + verbe" du point de vue du client ("Comment trouver des prospects ?", "Comment relancer sans être lourd ?"). C'est la forme exacte dans laquelle le client se pose la question.
- Mets en pause après chaque étape. Une étape à fond avant de passer à la suivante.

---

## Étape 3 : Récolter les vrais problèmes (interviews clients)

**Méthode :** quand le brainstorm te laisse l'impression de ne pas assez connaître tes prospects, va leur parler. C'est la meilleure chose à faire à ce stade. Tu décroches les rendez-vous par DM, tu mènes l'appel avec une trame, et tu reverses tout dans ta liste de problèmes par étape, dans leurs mots exacts.

**Outils :** DM (LinkedIn / Facebook), un agenda, une carte cadeau Amazon pour remercier, une trame d'appel imprimée.

**Piège :** pitcher son offre pendant l'appel. Le but n'est pas de vendre, c'est de creuser. Si tu pitches, tu casses la sincérité et tu n'apprends rien.

### Le DM (taux de prise de RDV visé : environ 50%)

La structure verbatim :

1. **Flatter + connexion émotionnelle.** Un compliment précis sur un contenu réel. "Salut Victor, je te suis depuis un petit temps sur LinkedIn et j'aime bien ce que tu écris, surtout le post où tu parlais de comment tu as automatisé ta prospection avec l'IA."
2. **Une question simple.** "Est-ce que tu as de bons résultats par rapport à ça ?"
3. **L'enjeu du message.** "Je suis en train de construire un nouveau produit dont le but serait d'aider [...]. Vu ton contenu, je me suis dit que tu pourrais être intéressé par une discussion à ce sujet."
4. **La clarification anti-vente.** "Le but n'est pas de te vendre quoi que ce soit, je veux simplement apprendre comment tu fonctionnes, tes problématiques, et ensuite créer une offre qui pourrait aider les gens comme toi."
5. **La proposition + le remerciement.** "Est-ce que ça te dirait qu'on s'appelle 20 minutes mardi ou mercredi en fin de journée ? Et pour te remercier de ton temps, je peux t'envoyer une carte cadeau Amazon."

Ce message, présenté "de manière authentique" et qui "met la personne sur un piédestal" (tu peux m'aider, tu peux solutionner), sort environ une personne sur deux en rendez-vous.

### La trame d'appel (créer, pas vendre)

| Bloc | Ce que tu cherches | Questions verbatim |
|---|---|---|
| Introduction | Connexion émotionnelle, cadre | "Je n'ai rien à te vendre, je veux simplement creuser ta problématique de gestion du temps et explorer ce qui bloque chez toi." |
| Déclencheurs | Ce qui a poussé à chercher une solution | "Pourquoi tu cherches des solutions alternatives ? En quoi ce que tu as aujourd'hui ne marche pas ?" |
| Résultat rêvé | Le point B en ses mots + le ressenti visé | "Quel résultat tu voudrais atteindre ? Comment tu voudrais te sentir avec ta gestion du temps ?" |
| Alternatives | Ce qu'il a déjà essayé | "Est-ce que tu as déjà essayé des solutions alternatives ?" |
| Exploration | Ce qui a marché / pas marché + le prix payé | "Qu'est-ce qui s'est bien passé ? Qu'est-ce qui ne s'est pas bien passé et pourquoi ? Combien as-tu payé ?" |
| Conséquences | Le coût du problème non résolu | "Aujourd'hui, quelles sont les conséquences de ce problème non résolu ?" |
| Conclusion | Garder le contact | "Est-ce que je peux te recontacter quand j'ai une proposition de solution ?" (ces gens deviennent tes premiers clients) |

À la fin de chaque appel, reverse tout dans la liste de problèmes par étape, dans les mots exacts du prospect. Pour creuser sans biaiser, applique le Mom Test (parler de la vie réelle et passée, jamais d'opinions sur ton idée).

Le DM complet et la trame d'appel sont dans la formation vidéo Atomic Offers (6.4).

---

## Exemples

### Bon : les étapes A vers B (Atomic Perspectives, verbatim)

Point A : "il manque de profondeur, syndrome de l'imposteur, pas de méthode". Point B : "être expert de leur domaine, avoir créé leur propre méthode, apporter vraiment de la valeur".

1. Faire la carte de la thématique (mapper concurrents, concepts, ramifications, méthodes existantes)
2. Identifier les livres et concepts de référence (le 80/20 de la thématique)
3. Tout lire et déconstruire (système de prise de notes orienté concept dans Obsidian)
4. Incubation (un essai par jour pour consolider sa pensée propre)
5. Exercices d'émergence (créer de nouveaux concepts)
6. Assembler en une méthode propre

Pourquoi c'est bon : six étapes, chacune débloque la suivante (tu ne peux pas incuber avant d'avoir lu et déconstruit), et chacune est une transformation, pas une tâche. Ces six étapes sont les six modules de l'offre.

### Bon : les problèmes d'une étape (étape "pré-vendre son offre", verbatim)

- Où trouver des prospects pour pré-vendre mon offre ?
- Comment les contacter ? Comment les avoir en call ?
- Comment leur vendre mon offre alors qu'elle n'existe pas encore ?
- Comment être convaincant en appel de vente ?
- Quoi leur dire quand ils me demandent si d'autres ont déjà acheté ?
- À combien vendre mon offre ?
- Comment gérer des prospects qui hésitent et demandent un délai ?
- Comment bien relancer un prospect ?
- À partir de combien de ventes l'offre est-elle validée ?

Pourquoi c'est bon : neuf problèmes formulés dans les mots du client ("Comment + verbe"), tous réels, tous adressables par une leçon. Chacun devient une vidéo ou un livrable.

### Bon : les problèmes de l'étape "écrire un essai par jour" (verbatim)

"Comment avoir le temps de créer un essai par jour ? Comment savoir de quoi parler tous les jours ? Comment trouver une audience qui les lit ? C'est quoi la structure d'un essai ? Comment faire émerger de nouvelles idées ? Comment être sûr que ces idées sont réellement nouvelles et que ce n'est pas du réchauffé ? Comment trouver un angle intéressant ? Comment rédiger rapidement tous les jours ?"

Pourquoi c'est bon : densité forte sur une seule étape, et la liste reste ouverte ("il y a probablement plein de problèmes auxquels je n'ai pas encore pensé"). C'est l'état d'esprit visé.

### Mauvais : la liste vague et courte

> Étape "devenir expert" : 1. se former, 2. travailler dur, 3. rester motivé.

Pourquoi c'est raté : trois problèmes génériques, aucun dans les mots du client, rien d'actionnable. "Se former" n'est pas un problème, c'est une réponse molle. Cette pauvreté est le diagnostic : marché pas assez connu, retour en interview obligatoire.

### Mauvais : pitcher pendant l'appel

> "Du coup j'ai créé une méthode en 6 étapes, est-ce que ça t'intéresserait ?"

Pourquoi c'est raté : tu as basculé en vente. Le prospect devient poli, répond "ah ouais carrément intéressant", et tu repars sans un seul problème réel. L'appel d'interview ne sert qu'à creuser, jamais à présenter ton idée.

---

## Pièges

- **Inventer les problèmes au lieu de les récolter.** Le brainstorm amorce, les interviews valident. Une offre construite sur tes seules suppositions vendra mal.
- **Moins de 10 problèmes par étape et passer outre.** C'est le signal d'alarme principal. Ne le contourne pas : retourne parler à des clients.
- **Confondre étape et tâche.** Une étape est une transformation qui débloque la suivante. Si l'ordre est interchangeable, ce sont des tâches.
- **Reformuler les mots du client.** Garde leurs formulations exactes : ce sera ta meilleure copy plus tard, sur la page de vente.
- **Pitcher en interview.** Dès qu'on vend, on n'apprend plus rien. Le but affiché est explicite : "le but n'est pas de te vendre quoi que ce soit".

---

## Références

- Formation vidéo : <a href="/plateforme/business-os/atomic-offers">Atomic Offers -&gt;</a> (leçons 6.3 "Lister les étapes" et 6.4 "Lister les problèmes par étape") : la méthode complète en vidéo, dont cette fiche est la version activable.
- Formation vidéo : <a href="/plateforme/business-os/challenge-offre-aligne">Challenge Offre Alignée -&gt;</a> : valider en amont que la transformation visée tient la route avant de la découper.
- Formation vidéo : <a href="/plateforme/business-os/atomic-funnels">Atomic Funnels -&gt;</a> : le tunnel qui va derrière l'offre une fois construite.
- Skill lié amont : <a href="/plateforme/business-os/offre__avant-apres">avant-apres -&gt;</a> : produit le point A et le point B en mots clients qui ouvrent cette fiche.
- Skill lié aval : <a href="/plateforme/business-os/offre__solutions-offre">solutions-offre -&gt;</a> : transforme chaque problème listé en solution (WTF vers scalable).
- Skill lié : <a href="/plateforme/business-os/offre__systeme-offre">systeme-offre -&gt;</a> : l'orchestrateur qui enchaîne toutes les étapes de l'offre.
- Pour trouver et contacter les prospects à interviewer, voir la formation <a href="/plateforme/business-os/atomic-funnels">Atomic Funnels -&gt;</a> et les skills de prospection.

---

## Checklist

- [ ] Point A et point B rappelés en mots clients (issus de `/avant-apres`).
- [ ] 3 à 7 étapes A vers B listées, chacune une transformation qui débloque la suivante.
- [ ] Chaque étape brainstormée seul : 10 à 15 problèmes minimum, formulés "Comment + verbe" côté client.
- [ ] Total 100+ problèmes sur l'ensemble de l'offre.
- [ ] Si une étape a moins de 10 problèmes : retour en interview, pas de passe-droit.
- [ ] DM envoyé à des prospects réels (flatter, enjeu, clarification anti-vente, RDV + carte cadeau).
- [ ] Appels menés avec la trame (déclencheurs, résultat rêvé, alternatives, exploration, conséquences), zéro pitch.
- [ ] Problèmes réels reversés dans la liste, dans les mots exacts des prospects.

---

Chaînage : vient après `/avant-apres` (point A vers B en mots clients) et alimente `/solutions-offre` (une solution par problème listé).
