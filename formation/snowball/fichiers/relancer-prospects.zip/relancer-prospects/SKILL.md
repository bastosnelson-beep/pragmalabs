---
name: relancer-prospects
description: "Relancer les prospects qui n'ont pas répondu, au bon rythme (J+1, J+4, J+10, mensuel), avec un message naturel à chaque fois. Jamais \"tu as vu mon message ?\". Chaque relance apporte un truc concret."
---

# Relancer : la séquence qui fait 60% des ventes

> **Objectif :** relancer les prospects déjà contactés qui n'ont pas répondu, au bon rythme, avec de la valeur à chaque fois, en pilotant tout via le statut et le timestamp du board.

C'est l'étape **la plus rentable** du cycle, et la plus négligée. 60 à 70% des ventes se font sur le suivi. On relance 5 à 7 fois, pas 1.

---

## Principe directeur

Chaque relance apporte un truc. Jamais "tu as vu mon message ?". Une relance qui n'apporte rien tue la conversation. Une relance qui donne quelque chose entretient une relation qui peut convertir des semaines plus tard.

---

## Étape 1 : repérer qui relancer

On regarde toutes les lignes dont le `Statut` est `contacté`, `relance 1` ou `relance 2`, et dont la dernière action remonte à plus d'un jour.

Le timestamp de référence est `UpdatedAt` (dernière modif = dernier changement de statut = dernier message envoyé).

Filtre de base :
- `Statut` dans (`contacté`, `relance 1`, `relance 2`)
- ET `UpdatedAt` antérieur à hier (plus d'un jour).

On exclut : `à contacter` (pas encore contacté), `relance 3` (au bout de la séquence active), `fail`, `R1`, `R2`, `win`.

---

## Étape 2 : déterminer le niveau de relance

Rythme de référence, en jours depuis le **premier contact** : **J+1, J+4, J+10**, puis tous les mois en soft.

Traduit en délais entre statuts (chaque relance ré-horodate `UpdatedAt`) :

| Statut actuel | Délai depuis `UpdatedAt` | Action | Nouveau statut |
|---|---|---|---|
| `contacté` | au moins 1 jour | Relance 1 | `relance 1` |
| `relance 1` | au moins 3 jours (J+4 global) | Relance 2 | `relance 2` |
| `relance 2` | au moins 6 jours (J+10 global) | Relance 3 | `relance 3` |
| `relance 3` | au moins 1 mois | Soft mensuel, ou bascule en `fail` si silence total | `relance 3` maintenu ou `fail` |

Si la personne a répondu entre temps : on sort de la séquence et on bascule sur le statut de conversation (`R1`, `R2`, `win`, ou `fail` selon l'issue).

---

## Étape 3 : rédiger la relance

Même canal que le message initial (voir `Commentaire` pour retrouver le canal). On reprend le fil de conversation existant dans Beeper.

### Relance 1 (J+1)

On apporte une ressource concrète, sans rien demander en retour.

> "Au fait Marie, je t'ai retrouvé le template dont je parlais : [ressource]. Même si on n'échange pas, ça peut déjà te faire gagner du temps."

> "Thomas, je suis tombé sur cet article en bossant sur le même sujet : [lien]. Rien de pressé, mais ça pourrait t'intéresser."

> "Hey Sophie, petite idée en passant : j'ai un buddy qui a le même cas que toi côté [sujet], je lui ai filé ce tuto et il m'a dit que ça l'avait débloqué en 20 min. [lien]"

### Relance 2 (J+4)

On pose une question sur SA réalité, on glisse un exemple concret de quelqu'un dans la même situation.

> "Tite question Marie - ce qui te prend le plus de temps dans ta semaine avec l'IA, c'est quoi ? J'ai aidé une coach exactement là-dessus hier, ça m'a rappelé notre échange."

> "Thomas, au fait : vous gérez comment les relances prospects actuellement ? J'ai vu un directeur commercial faire un truc malin avec n8n la semaine dernière, si ça t'intéresse je te montre en 2 min."

> "Dis Sophie, tu testes quoi comme outils en ce moment ? J'ai croisé une agence qui a exactement le même profil que vous, ils ont reduit leur temps de prod de 40% avec deux automatisations. Curieux de savoir si t'es sur la même piste."

### Relance 3 (J+10)

On lève la pression. On laisse la porte ouverte. On rend le "non" facile à dire, ce qui paradoxalement maintient la relation.

> "Je relance pas, je sais que t'es à fond. Je te laisse ça ici au cas où : [lien]. Et si c'est pas le moment, dis-le moi, zéro souci."

> "Thomas, j'imagine que t'es sous l'eau en ce moment. Pas de pression de mon côté. Je note dans mon agenda de te recontacter dans 2 mois. Et si tu veux en parler avant, tu sais où me trouver."

> "Sophie, je te laisse tranquille, promis. Juste au cas où : [ressource]. Si c'est pas la priorité maintenant, c'est totally cool, je retenterai ma chance dans quelques mois."

### La mauvaise relance (à bannir)

> "Bonjour, avez-vous vu mon message ? Toujours intéressé(e) ?"

Pression, zéro valeur, ça tue la conversation. Pareil pour "Juste un petit rappel" ou "Je me permets de revenir vers vous". Si t'as rien à dire, dis rien.

### Après J+10 : soft mensuel

Une fois par mois, un truc ultra light. Genre un partage de ressource, un "j'ai pensé à toi" honnête, ou une actu qui concerne leur secteur.

> "Marie, j'ai vu passer [article/event] et j'ai pensé à ta situation. [lien] Si jamais."

> "Thomas, gros changements dans [leur secteur] en ce moment. Si tu veux prendre 15 min pour discuter de l'impact pour vous, je suis dispo."

Au bout de 3 mois de silence total sans réponse à aucune relance, basculer en `fail`. C'est pas grave, le timing était mauvais, pas l'opportunité.

---

## Étape 4 : mettre à jour le statut

Dès que la relance est partie :
1. Ouvrir la ligne dans le board.
2. Faire avancer le `Statut` : `contacté` -> `relance 1` -> `relance 2` -> `relance 3`.
3. (Optionnel) noter dans `Commentaire` l'angle et la date (ex : "R1 valeur 18/06").

Le nouveau `UpdatedAt` sert de point de départ pour la relance suivante (étape 2).

---

## Automatisation pilotée par le statut

La commande `/relance` balaie tout le monde à relancer en une passe, sans intervention manuelle, parce que tout l'état vit dans le board :

1. Requête le board : `Statut` dans (`contacté`, `relance 1`, `relance 2`) ET `UpdatedAt` > 1 jour.
2. Pour chaque ligne, déterminer le niveau (R1 / R2 / R3) via le tableau des délais (statut actuel + écart `UpdatedAt`).
3. Rédiger la relance, personnalisée sur le métier du prospect.
4. Envoyer sur le même canal Beeper (reprendre le fil).
5. Faire avancer le `Statut` + horodater (`UpdatedAt` se met à jour seul).

Le couple `Statut` + `UpdatedAt` est la seule source de vérité : pas de cron rigide, pas de tableau à part. On peut relancer la commande chaque jour, elle ne traite que ce qui est mûr.

---

## Principes de la séquence

- Chaque relance apporte un truc. Jamais "tu as vu mon message ?".
- Espacement : J+1, J+4, J+10, puis tous les mois en soft.
- On relance 5 à 7 fois, pas 1. 60 à 70% des ventes se font sur le suivi.
- À la relance 3, on rend le "non" facile : c'est ça qui garde la relation ouverte.
- Dès qu'il y a réponse, on quitte la séquence automatique et on passe en conversation réelle.

---

## Checklist rapide

- [ ] Filtrer `Statut` dans (contacté, relance 1, relance 2) ET `UpdatedAt` > 1 jour.
- [ ] Pour chaque fiche : déterminer le niveau (R1 / R2 / R3) via le tableau des délais.
- [ ] Rédiger la relance personnalisée (valeur concrète / question + exemple / porte de sortie décontractée).
- [ ] Envoyer sur le même canal Beeper (reprendre le fil existant).
- [ ] Faire avancer le `Statut` + noter angle / date dans `Commentaire`.
