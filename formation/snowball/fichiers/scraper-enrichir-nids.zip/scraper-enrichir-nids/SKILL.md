---
name: scraper-enrichir-nids
description: "Scraper un nid à prospects (LinkedIn, Instagram, Facebook, Google Maps), scorer chaque profil vs l'ICP sur 100 (4 dimensions + awareness), puis enrichir en cascade (email, téléphone, site). Produit un board NocoDB prêt à contacter."
---

# Scraper, scorer et enrichir un nid à prospects

> **Objectif :** à partir d'un "nid" (un endroit précis où ta cible se rassemble : un post, un groupe, une recherche locale), remplir automatiquement un board de prospection avec des prospects scrapés, scorés, enrichis et prêts à être contactés.

C'est la fiche **amont** du cycle. Elle produit la matière première, la trie, et n'enrichit en contact que le haut du panier. Une fois le board rempli, on enchaîne sur `/contacter-prospects` (premier message), puis `/relancer-prospects` (suivi).

---

## Principe directeur

Un nid = un endroit précis à fort engagement où ta cible a déjà manifesté un signal. Ce n'est pas un compte entier, c'est UN post, UN groupe, UNE recherche.

Trois règles transverses, valables sur toutes les plateformes :

1. **On privilégie les signaux d'intention.** Plus une action coûte à la personne, plus elle est qualifiée. L'ordre de force : commenter > réagir / liker > s'abonner. Un commentaire avec une question vaut dix likes.
2. **On scrape large, on score, on enrichit étroit.** Le scraping de profil est quasi gratuit. L'email et le téléphone sont chers. On scrape 50 à 1000 profils, on les score, et on n'enrichit en contact (email / tel) que le haut du panier. Le scoring se fait AVANT l'enrichissement cher.
3. **L'enrichissement est en cascade.** Profil de base (scrape) -> scoring -> email Apify -> recherche Google Firecrawl pour email + téléphone + site. Chaque étage ne s'active que si l'étage précédent n'a pas suffi et que le prospect le mérite (score >= seuil).

---

## Ce que tu fournis quand tu lances `/scraper-enrichir-nids`

| Input | Exemple | Défaut |
|---|---|---|
| Plateforme | `linkedin` / `instagram` / `facebook` / `googlemaps` | obligatoire |
| Type de nid | `commentateurs` / `reacteurs` / `abonnes` / `membres-groupe` / `recherche-locale` | obligatoire |
| Cible (URL ou requête) | URL du post, du groupe, ou requête Maps "plombier Île-de-France" | obligatoire |
| Nombre à scraper | `50`, `200`, `1000` | 50 |
| Stratégie d'enrichissement | `score d'abord, enrich top` / `tout le monde` / `profil seul` | score d'abord, enrich top |
| Seuil "top" pour enrichir email/tel | `80` | 80 |
| Board cible | base + table NocoDB | board de prospection courant |

---

## Prérequis (credentials et pièges)

- **Clé API Apify** : dans `4 TOOLS/Infrastructure.md` (section Apify). Sert pour tous les scrapers, passée en `Authorization: Bearer <clé>` ou en `?token=<clé>`.
- **NocoDB** : token API + IDs dans `4 TOOLS/Infrastructure.md` (section NocoDB).
- **Firecrawl** : pour la recherche Google (CLI Firecrawl, jamais WebFetch). Clé dans Infrastructure.md.

Piège NocoDB : l'API REST est derrière Cloudflare. Sans header `User-Agent` navigateur, elle renvoie **403 / error code 1010**. Toujours ajouter un User-Agent type `Mozilla/5.0 ... Chrome/124 ...` sur chaque requête NocoDB.

Coûts indicatifs : ~0,002 $/profil en scraping, ~0,005 $/profil pour l'email Apify. Un batch de 50 + enrichissement du top revient à ~0,17 $.

---

## Apify, le marché des scrapers

Apify est un marketplace de scrapers communautaires (les "acteurs"). On ne code pas le scraper, on choisit celui qui correspond à la plateforme et au type de nid, on lui passe des paramètres, on récupère un dataset JSON.

Le cycle d'un run, identique pour tous les acteurs :

```bash
# 1. Lancer le run
curl -s -X POST "https://api.apify.com/v2/acts/<acteur>/runs?token=<APIFY_KEY>" \
  -H "Content-Type: application/json" \
  -d '{ ... paramètres ... }'

# 2. Attendre que le statut passe à SUCCEEDED (poll sur l'endpoint du run)
curl -s "https://api.apify.com/v2/actor-runs/<RUN_ID>?token=<APIFY_KEY>"

# 3. Récupérer le dataset
curl -s "https://api.apify.com/v2/datasets/<DATASET_ID>/items?clean=true&format=json" \
  -H "Authorization: Bearer <APIFY_KEY>"
```

Variante pratique pour les petits runs : `run-sync-get-dataset-items` lance et renvoie le dataset en une seule requête synchrone (utile pour l'enrichissement unitaire).

---

## Choisir le bon acteur Apify selon le nid

| Plateforme | Type de nid | Acteur type | Signal | Exemple de cible |
|---|---|---|---|---|
| LinkedIn | Commentateurs d'un post | `harvestapi/linkedin-post-comments` | fort (intention) | post viral d'un créateur IA |
| LinkedIn | Réacteurs d'un post | acteur "post reactions" | moyen | même post |
| LinkedIn | Abonnés d'une page / créateur | acteur "followers" | faible mais volume | page d'un influenceur de la niche |
| LinkedIn | Détail d'un profil (enrichissement) | `apimaestro/linkedin-profile-detail` | enrichit | n'importe quel profil scrapé |
| Instagram | Commentateurs d'un post | comment scraper Instagram | fort | post d'un compte qui parle du sujet |
| Instagram | Likers d'un Reel | acteur "likers" | moyen | Reel sur le thème |
| Instagram | Abonnés d'un compte | profile / followers scraper Instagram | faible mais volume | abonnés d'un influenceur de la niche |
| Facebook | Membres d'un groupe public | acteur "group members" | moyen (affinité thème) | groupe "méditation vipassana", "IA francophone" |
| Facebook | Commentateurs d'un post de page | acteur "page post comments" | fort | post d'une page |
| Google Maps | Entreprises locales par recherche | `compass/crawler-google-places` ou équivalent | intention locale | "écoles de danse Paris", "plombiers Île-de-France" |

Règle de choix : on part du signal le plus fort accessible. Sur un même créateur, on préfère scraper les commentateurs d'un post engageant que ses abonnés en masse. Sur un nid faible (abonnés, membres de groupe), on compense par le volume et un scoring plus sévère.

---

## Recettes par plateforme

### LinkedIn : commentateurs d'un post

Un seul acteur liste les commentateurs ET récupère le détail de chaque profil.

```bash
curl -s -X POST "https://api.apify.com/v2/acts/harvestapi~linkedin-post-comments/runs?token=<APIFY_KEY>" \
  -H "Content-Type: application/json" \
  -d '{
    "posts": ["<URL_DU_POST>"],
    "maxItems": 50,
    "scrapeReplies": false,
    "profileScraperMode": "main"
  }'
```

Paramètres clés :
- `maxItems` : nombre de commentateurs.
- `scrapeReplies: false` : on prend les commentaires de premier niveau (intention plus forte que les réponses).
- `profileScraperMode` : `short` est gratuit mais sans détail ; `main` coûte ~0,002 $/profil et donne headline, bio, abonnés, localisation. On prend toujours `main`, c'est ce qu'il faut pour scorer.

Champs utiles par item : `commentary` (le commentaire, signal d'intention), `actor.name`, `actor.headline` / `actor.position`, `actor.about` (bio), `actor.followerCount`, `actor.location.parsed.text`, `actor.publicIdentifier` (sert à l'enrichissement email), `actor.linkedinUrl`.

### LinkedIn : enrichissement profil + email

```bash
curl -s -X POST "https://api.apify.com/v2/acts/apimaestro~linkedin-profile-detail/run-sync-get-dataset-items?token=<APIFY_KEY>" \
  -H "Content-Type: application/json" \
  -d '{"username":"<publicIdentifier>","includeEmail":true}'
```

Renvoie `basic_info.email` (présent ~1 fois sur 3), plus `current_company`, `current_company_url`, `creator_website` : autant de pistes de domaine pour la recherche Google.

### Instagram : commentateurs, likers, abonnés

Comment scraper Instagram pour les commentateurs d'un post, "likers" pour un Reel, profile / followers scraper pour les abonnés d'un compte. On vise les commentateurs d'un compte qui parle du sujet, ou les abonnés d'un influenceur de la niche.

```bash
curl -s -X POST "https://api.apify.com/v2/acts/<acteur-instagram>/runs?token=<APIFY_KEY>" \
  -H "Content-Type: application/json" \
  -d '{
    "directUrls": ["<URL_DU_POST_OU_DU_COMPTE>"],
    "resultsType": "comments",
    "resultsLimit": 200
  }'
```

Champs utiles : username, full name, bio, nombre d'abonnés, site dans la bio. L'email est rare sur Instagram, on bascule vite sur la recherche Google pour le contact.

### Facebook : membres d'un groupe public, commentateurs d'une page

On cible les membres d'un groupe public thématique (ex : groupe "méditation vipassana", "Intelligence Artificielle francophone") ou les commentateurs d'un post de page.

```bash
curl -s -X POST "https://api.apify.com/v2/acts/<acteur-facebook-group>/runs?token=<APIFY_KEY>" \
  -H "Content-Type: application/json" \
  -d '{
    "groupUrls": ["<URL_DU_GROUPE>"],
    "maxItems": 300
  }'
```

Note terrain : sur un groupe public, on récupère souvent ~30% des membres visibles publiquement. C'est suffisant pour un nid de volume. L'affinité au thème du groupe fait office de pré-qualification.

### Google Maps : entreprises locales

On scrape des entreprises par recherche géographique (tous les plombiers d'Île-de-France, toutes les écoles de danse ou arts martiaux dans un périmètre).

```bash
curl -s -X POST "https://api.apify.com/v2/acts/compass~crawler-google-places/runs?token=<APIFY_KEY>" \
  -H "Content-Type: application/json" \
  -d '{
    "searchStringsArray": ["école de danse"],
    "locationQuery": "Paris, France",
    "maxCrawledPlacesPerSearch": 200,
    "language": "fr"
  }'
```

Champs utiles : nom, site web, téléphone, adresse, nombre d'avis, note.

Filtre malin : cibler les entreprises avec **moins de 10 avis**. Mauvais SEO local = faible présence en ligne = besoin marketing fort, donc bon prospect pour une offre de visibilité. À l'inverse, une boîte avec 500 avis et 4,9 est déjà bien outillée.

---

## Scoring des prospects vs l'ICP

Le scoring est l'étape charnière : on score AVANT d'enrichir en contact. Le profil de base (poste, bio, audience, commentaire) suffit pour noter. On ne paie l'email et le téléphone que pour les prospects qui passent le seuil.

### Principe du scoring

On ne contacte pas tout le monde, on contacte les bons. Le scoring transforme une liste brute en file de priorité. Trois règles :

1. **Scorer avant d'enrichir.** Le profil de base (poste, bio, audience, commentaire) suffit pour noter. On ne paie l'email et le téléphone que pour les prospects qui passent le seuil.
2. **Calibrer pour discriminer.** Une grille qui met tout le monde à 70 ne sert à rien. Les vrais ICP doivent atterrir **75-90**, les hors-cible **25-55**. Si tout se ressemble, la grille est mal pondérée.
3. **Viser un niveau d'awareness précis.** On cherche les gens qui ressentent déjà la douleur et commencent à chercher une méthode (problem aware -> début solution aware). On déclasse les deux extrêmes : les unaware (pas de douleur consciente) et les most aware (déjà équipés, pairs ou concurrents).

### Grille 4 dimensions (structure universelle)

Une grille de scoring = 4 dimensions pondérées à 100, plus un niveau d'awareness. Adapte le contenu de chaque dimension à ton offre, garde la structure.

| Dimension | Poids type | Question à laquelle elle répond |
|---|---|---|
| **A. Profil cible** | 0-30 | Est-ce le bon type de personne / d'entreprise ? |
| **B. Aptitude / usage** | 0-30 | A-t-elle le contexte d'usage qui rend l'offre pertinente, sans être déjà experte ? |
| **C. Douleur** | 0-25 | Ressent-elle fort le problème que l'offre résout ? |
| **D. Awareness & engagement** | 0-15 | A-t-elle manifesté un signal d'intention concret ? |

**Score = A + B + C + D.** Pondère selon ce qui compte le plus pour ton offre (une offre B2B chère monte le poids du pouvoir d'achat dans A ; une offre de formation monte la douleur en C).

### Niveaux d'awareness (échelle de Schwartz)

- **unaware** : ne sait pas qu'il a le problème. À déclasser.
- **problem aware** : ressent la douleur, ne connaît pas les solutions. Coeur de cible.
- **solution aware** : sait que des solutions existent, compare les approches. Coeur de cible.
- **product aware** : connaît des offres comme la tienne, hésite. Bon, plus direct.
- **most aware** : déjà décidé / déjà équipé / déjà expert. Souvent à déclasser (pair, concurrent).

### Calibrer la grille

Avant de scorer en masse, on calibre sur 5-10 profils connus :

- Prends 3 profils clairement dans la cible : ils doivent sortir **75-90**.
- Prends 3 profils clairement hors-cible : ils doivent sortir **25-55**.
- Si un hors-cible monte à 70, une dimension est trop généreuse. Si un parfait ICP plafonne à 65, une dimension est trop sévère. Ajuste les bornes, recommence.

### Déclasser systématiquement

Profils à **déclasser systématiquement** (à adapter, mais la logique vaut partout) :

- Les **pairs et concurrents** (déjà experts du sujet, ils vendent ce que tu vends).
- Les profils **sans pouvoir d'achat ni autonomie** (étudiants, juniors, postes sans budget).
- Les profils **trop équipés** (already most aware, n'ont plus la douleur).
- Les profils **hors usage** (le contexte qui rend l'offre utile est absent).

### Déléguer le scoring à un sous-agent

Le scoring de N profils se délègue à un sous-agent IA qui lit les profils et renvoie un JSON par prospect. Le sous-agent ne voit pas la conversation : on lui passe dans le prompt la grille complète, l'ICP de référence, et les profils.

Format de sortie attendu, un objet par prospect :

```json
{
  "name": "...",
  "url": "...",
  "score": 85,
  "awareness": "problem aware",
  "A": 28, "B": 25, "C": 22, "D": 10,
  "justification": "Coach indépendante, audience 5k, commentaire avec question précise sur le comment. Pile dans la cible, douleur d'organisation forte."
}
```

La `justification` est obligatoire : elle sert ensuite à viser le bon problème dans le message de prospection. Un score sans justification est inutilisable.

### Exemple concret : grille de la formation IA

À prendre comme **gabarit**, pas comme vérité figée. L'ICP : indépendant / coach / créateur / freelance / fondateur de TPE, qui utilise l'IA tous les jours mais NE CODE PAS, et a l'impression de bidouiller sans rien construire de pérenne.

**A. Profil cible (0-30)** : indépendant / coach / créateur / freelance / fondateur de TPE.
- 28-30 : indépendant solo, coach, créateur, freelance orienté clients / audience.
- 22-27 : fondateur ou dirigeant de TPE-PME, consultant indépendant établi.
- 15-21 : poste à autonomie entrepreneuriale dans une orga.
- 8-14 : salarié de grand groupe, poste corporate.
- 3-7 : étudiant, alternant, profil non identifiable.

**B. Usage IA actif + non-codeur (0-30)** : baseline 22 (a commenté un post IA = usage actif).
- +5 à +8 si créateur / marketeur / coach / dirigeant NON technique utilisant l'IA au quotidien (coeur de cible).
- Plafond 10-15 si développeur / ingénieur / très technique (ils codent déjà).
- Plafond 10-15 si déjà expert / formateur IA ou vend de l'IA (pair ou concurrent).

**C. Douleur orga / capitalisation (0-25)** :
- 21-25 : gère beaucoup de flux / clients / contenu / audience.
- 15-20 : activité avec projets / process à piloter.
- 8-14 : poste cadré, douleur modérée.
- < 8 : peu de douleur d'organisation visible.

**D. Awareness & engagement (0-15)** :
- 13-15 : commentaire avec question précise ou technique (début solution-aware engagé).
- 9-12 : intention claire (commentaire + remerciement, ou profil orienté solution).
- 6-8 : simple mot-clé type "LOOP" (problem-aware curieux).

Niveau visé : **problem aware -> début solution aware**. On déclasse les most aware (experts IA déjà équipés) et les unaware.

### Transposer le gabarit à un autre business

- **Coach bien-être** : A = particuliers en souffrance / stress chronique ; B = a déjà essayé des solutions sans tenir ; C = intensité de la douleur ; D = a commenté / posé une question sur le sujet.
- **Agence SEO local pour artisans** : A = artisan / TPE locale avec activité commerciale ; B = a un site mais peu d'avis (signal de besoin) ; C = dépendance au bouche-à-oreille, peu de leads en ligne ; D = a cherché ou demandé de la visibilité.
- **École de danse** : A = adulte de la zone géographique cherchant une activité ; B = niveau débutant / intermédiaire (pas déjà pro) ; C = envie de pratique régulière exprimée ; D = a liké / commenté un contenu danse local.

---

## Enrichissement en cascade (contact)

L'enrichissement en contact ne s'applique qu'aux prospects **au-dessus du seuil de score**. Trois étages, dans cet ordre, on s'arrête dès qu'on a ce qu'il faut.

1. **Email via Apify** (LinkedIn) : `apimaestro/linkedin-profile-detail` avec `includeEmail:true`. Donne aussi l'entreprise et le site, donc le domaine pour l'étape suivante.
2. **Email + téléphone via recherche Google (Firecrawl)** : pour ceux sans email, et pour les téléphones (LinkedIn et Instagram n'exposent jamais le tel).
   - `firecrawl_search` : "Prénom Nom + Entreprise + contact", puis "Entreprise + site officiel".
   - `firecrawl_scrape` de la home, `/contact`, `/mentions-legales` (les mentions légales FR contiennent souvent tel + email).
   - Ne jamais deviner un email ou un tel. `null` si introuvable. Un email générique (`contact@`, `hello@`) est acceptable, le noter comme tel.
3. **Estimation de qualité (optionnel)** : présence sur des outils ou annuaires IA, ancienneté du site, taille de l'audience. Sert à départager deux prospects à score égal.

Pour Google Maps, le site et le téléphone sont déjà dans le dataset : pas besoin d'Apify pour l'email, on passe direct au Firecrawl sur le site de l'entreprise.

On stocke le site, les sources et les contacts secondaires dans la colonne `Recherche Google`. L'email et le tel principaux vont dans `Email` et `Téléphone`.

> Note terrain : certains acteurs "email/phone finder" par domaine sont instables (parfois 0 résultat sans erreur). La recherche Google Firecrawl est le filet de sécurité fiable. Re-tester les acteurs ponctuellement.

---

## Écrire dans le board NocoDB

Schéma de colonnes minimal (adaptable selon la plateforme) :

| Colonne | Type (`uidt`) |
|---|---|
| Title (nom) | SingleLineText |
| Profil / URL source | URL |
| Commentaire | LongText |
| Poste / Activité | SingleLineText |
| Entreprise | SingleLineText |
| Localisation | SingleLineText |
| Abonnés / Avis | Number |
| Bio | LongText |
| Email | Email |
| Téléphone | PhoneNumber |
| Recherche Google | LongText |
| Score ICP | Number |
| Justification | LongText |
| Awareness | SingleSelect |
| Statut | SingleSelect |
| Nid source | SingleLineText |

Options `SingleSelect` :
- **Statut** : `à contacter`, `contacté`, `relance 1`, `relance 2`, `relance 3`, `fail`, `R1`, `R2`, `win`.
- **Awareness** : `unaware`, `problem aware`, `solution aware`, `product aware`, `most aware`.

Créer une colonne (une fois par table) :

```bash
curl -s -X POST "https://sheets.perspectives.ac/api/v2/meta/tables/<TABLE_ID>/columns" \
  -H "xc-token: <NOCODB_TOKEN>" \
  -H "Content-Type: application/json" \
  -H "User-Agent: Mozilla/5.0 ... Chrome/124 ..." \
  -d '{"title":"Score ICP","uidt":"Number"}'
```

Insérer les prospects (batch, un objet par prospect, statut `à contacter`, `Nid source` = description courte du nid) :

```bash
curl -s -X POST "https://sheets.perspectives.ac/api/v2/tables/<TABLE_ID>/records" \
  -H "xc-token: <NOCODB_TOKEN>" \
  -H "Content-Type: application/json" \
  -H "User-Agent: Mozilla/5.0 ... Chrome/124 ..." \
  -d '[{"Title":"...","Poste":"...","Abonnés":943,"Score ICP":85,"Awareness":"problem aware","Statut":"à contacter","Nid source":"..."}]'
```

Ne pas envoyer les clés vides : NocoDB préfère l'absence à `null`.

Mettre à jour le contact du top (PATCH avec l'`Id` retourné à l'insertion) :

```bash
curl -s -X PATCH "https://sheets.perspectives.ac/api/v2/tables/<TABLE_ID>/records" \
  -H "xc-token: <NOCODB_TOKEN>" -H "Content-Type: application/json" \
  -H "User-Agent: Mozilla/5.0 ... Chrome/124 ..." \
  -d '[{"Id":40,"Email":"...","Téléphone":"...","Recherche Google":"Site: ... | ..."}]'
```

---

## Ce que `/scraper-enrichir-nids` fait, bout en bout

1. Choisit l'acteur Apify selon plateforme + type de nid, lance le run, attend `SUCCEEDED`, récupère le dataset.
2. Score les N profils vs l'ICP (grille 4 dimensions, calibrage sur profils témoins, délégation au sous-agent).
3. Vérifie / crée les colonnes NocoDB (User-Agent navigateur obligatoire).
4. Insère les N prospects scorés, statut `à contacter`, `Nid source` renseigné, `Score ICP` + `Awareness` + `Justification` remplis.
5. Pour les prospects >= seuil : enrichissement en cascade (email Apify, puis Firecrawl pour email/tel/site), PATCH des lignes.
6. Sort un rapport : total scrapé, total scoré, nombre >= seuil, couverture contact (combien avec email, combien avec tel), patterns hors-cible repérés, coût Apify total.

---

## Checklist rapide

- [ ] Plateforme + type de nid + cible + nombre + seuil définis.
- [ ] Acteur Apify choisi selon le tableau, run lancé, dataset récupéré.
- [ ] Grille 4 dimensions pondérée à 100, adaptée à l'ICP du business.
- [ ] Niveaux d'awareness définis, cible = problem aware -> début solution aware.
- [ ] Calibrage validé sur 5-10 profils témoins (ICP à 75-90, hors-cible à 25-55).
- [ ] Profils à déclasser identifiés (pairs, sans budget, trop équipés, hors usage).
- [ ] Scoring délégué au sous-agent, JSON {name, url, score, awareness, A/B/C/D, justification} récupéré et intégré aux lignes NocoDB.
- [ ] Colonnes NocoDB présentes (sinon les créer, User-Agent navigateur).
- [ ] N lignes insérées, statut `à contacter`, `Nid source` renseigné, `Score ICP` + `Awareness` + `Justification` remplis.
- [ ] Top (>= seuil) enrichi en contact (Apify puis Firecrawl), lignes PATCHées.
- [ ] Rapport sorti (nombre scoré, nombre >= seuil, couverture contact, coût).

Cycle complet : **scraper + scorer** (cette fiche) -> `/contacter-prospects` -> `/relancer-prospects`.
