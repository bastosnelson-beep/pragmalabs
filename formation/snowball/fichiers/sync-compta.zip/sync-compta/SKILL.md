---
name: sync-compta
description: "Template à adapter : importer les transactions de ta banque (Revolut, Société Générale, Airwallex...), les catégoriser, enrichir (marchand, catégorie, et selon ton cas carte/projet/split), valider, et pousser vers Google Sheets sans doublon via un compte de service."
---

# Sync compta

Ce skill transforme un releve bancaire brut en compta exploitable : il classe chaque mouvement, enrichit les depenses, garde les revenus tracables, te fait valider, puis pousse vers Google Sheets de facon idempotente. Le but n'est pas de saisir des lignes, c'est d'obtenir une base propre que la revue financiere peut lire derriere.

C'est un TEMPLATE a customiser. Il marche avec n'importe quelle banque : tu adaptes les types de mouvement, les categories et l'enrichissement a TON cas. L'exemple ci-dessous est une config reelle (une societe a deux associes qui repartit ses depenses par carte), a remplacer par la tienne.

## Input

- Le chemin d'un CSV de transactions exporte depuis ta banque (le rapport qui liste tout ce qui est entre et sorti du compte, souvent nomme "Balance Activity Report" ou equivalent). Si rien n'est fourni, guider l'export.
- L'ID de la Google Sheet de destination.
- Ta config compta : les types de mouvement de ta banque et leur sens (revenu / depense / exclu), tes categories, et tes regles d'enrichissement. Au premier passage, on la construit avec toi.

Si le CSV est absent ou introuvable, ne rien inventer. Demander l'export et attendre le chemin.

## Output

- Un JSON enrichi avec deux listes : `revenus[]` et `depenses[]`. Chaque depense porte l'id de transaction, la date, le montant, le marchand, la categorie, et les champs d'enrichissement de ta config (ex carte, split, projet). Chaque revenu porte l'id, la date, la description complete, le montant.
- Un resume tabulaire a l'ecran : depenses par categorie avec totaux, detail des lignes, revenus avec descriptions, et la marge estimee.
- Une demande de validation explicite avant tout ecrit.
- Apres validation : le nombre de lignes inserees dans Google Sheets (dedupliquees par id de transaction), le lien vers la sheet, et un rappel de verifier les depots perso.

## Processus

### Etape 0 : Exporter le rapport de transactions

La source de verite, c'est ce qui a reellement touche le compte, frais deduits (le cash flow), pas la facturation. Faire exporter le rapport qui liste toutes les transactions entrees et sorties (souvent "Balance Activity Report"). Adapter au menu de la banque de l'utilisateur (Revolut, Societe Generale, Airwallex, Qonto...). Ne pas lancer le parsing tant que le chemin ne pointe pas vers un `.csv` qui existe.

Piege : sur certaines banques, il existe deux exports qui se ressemblent (ex un rapport de transactions "brutes" avant settlement vs le rapport de solde reel). Prendre celui qui reflete ce qui a reellement bouge sur le compte, frais inclus, sinon les frais sont comptes deux fois.

### Etape 1 : Definir les categories (au premier passage)

Avec l'utilisateur, mapper chaque type de mouvement de sa banque vers un sens de cash flow. Exemple de config (a remplacer) :

- Deposit -> revenu (virement entrant, client ou perso).
- Paying settlement -> revenu (encaissements par carte, net de frais).
- Payout refund -> revenu (annulation d'un virement sortant).
- Card purchase -> depense (achat par carte).
- Payout -> depense (virement sortant).
- Fee -> depense (frais bancaires).
- Conversion (change) -> exclu (mouvement FX interne, non comptable).

Cette table devient la regle de classification. La sauvegarder dans la config de l'utilisateur pour les passages suivants.

### Etape 2 : Parser et separer

Lire le CSV ligne par ligne, ignorer l'en-tete, classer chaque mouvement selon la table de l'etape 1 : revenus, depenses, ou exclus. Pour chaque ligne retenue, extraire : l'id de transaction (l'identifiant unique fourni par la banque), la date, le montant, la description brute, le type. Construire `revenus[]` et `depenses[]`.

Deterministe : un script fait ce parsing sans halluciner. Deux pieges : reporter deux fois les frais (souvent deja deduits des encaissements par carte), et traiter les mouvements de change comme du reel. Apres parsing, annoncer le compte (`X revenus, Y depenses, Z exclus`) ; si le total ne correspond pas au nombre de lignes du CSV, signaler l'ecart.

### Etape 3 : Enrichir les depenses

Transformer une description brute obfusquee en enregistrement structure. Enrichir avec ce qui compte pour l'utilisateur. Champs courants :

- **Marchand** : le nom propre lisible. Le matcher d'abord contre une table de marchands connus (la config). Si absent, deduire un nom propre evident. Si inconnu, ecrire `[Unknown]` et le signaler, jamais inventer.
- **Categorie** : une seule parmi une liste fermee (la config). En cas de doute reel, une categorie `Divers` justifiee est acceptable.
- **Champs specifiques a l'utilisateur** (selon sa config) : carte, projet, client, poste de cout, split de propriete. Exemple : chez une societe a deux associes, le split suit STRICTEMENT le last4 de la carte (regles de carte en config). Ne jamais deviner un split : il suit une regle.

Regle d'or : aucune invention. La config decide, le modele complete intelligemment les cas ambigus, jamais a l'aveugle.

### Etape 4 : Enrichir les revenus

Garder la description complete du CSV (elle identifie l'expediteur ou le batch de paiement, c'est ce qui permet de rapprocher plus tard). Ne pas tronquer. Laisser le controle a l'humain pour les rares depots perso (il ajustera la part sur la sheet). Ne pas deviner le proprietaire d'un revenu.

### Etape 5 : Presenter le resume et faire valider

Afficher : depenses agregees par categorie (`categorie | total | lignes | exemple`), detail des depenses (si peu de lignes), revenus avec description, puis les KPI : total revenus, total depenses, marge estimee = `(revenus - depenses) / revenus`. Poser la question franche ("cette depense est-elle bien categorisee ? le split est-il juste ? une depense perso a exclure ?") et attendre un go clair avant tout ecrit.

### Etape 6 : Pousser vers Google Sheets (compte de service)

Pour ecrire dans Google Sheets avec la pleine puissance (creer des onglets, des formules, importer), l'IA a besoin d'un **compte de service Google**, pas d'un simple MCP (trop limite). Mise en place une fois :

1. Sur console.cloud.google.com : nouveau projet, activer la facturation.
2. Activer les APIs Google Sheets, Docs et Drive.
3. API et services -> Identifiants -> creer un compte de service. Recuperer l'adresse email de service et la cle.
4. Dans la Google Sheet cible : Partager -> ajouter l'email de service en editeur.

Ideal : un script (`push-to-sheet.mjs`) qui lit le JSON enrichi et l'ecrit dans les onglets (Revenus, Depenses), en concatenant avec les mois precedents. La **dedup** se fait sur l'id de transaction : une ligne deja presente n'est pas re-inseree (idempotence). Documenter le compte de service dans un skill transverse "pousser vers Google" que tous tes skills reutilisent.

Piege : re-inserer des lignes deja importees faute de dedupliquer par l'id de transaction. Afficher a la fin le nombre exact de lignes inserees et le lien vers la sheet.

### Etape 7 (palier) : Automatiser et brancher le reporting

Une fois la boucle manuelle maitrisee : la rendre recurrente dans n8n (declencheur calendrier ou webhook banque, meme logique d'enrichissement, meme dedup), la validation humaine restant sur les cas ambigus. Puis brancher Metabase sur la sheet pour suivre marge, charges par categorie et evolution mensuelle. Ne pas automatiser avant d'avoir fiabilise l'enrichissement manuel sur un mois ou deux.

### Complement : associer les factures

Systeme distinct, en parallele : a partir du CSV des depenses, pour chaque depense, chercher la facture dans le dossier existant, sinon dans la boite mail (par expediteur), sinon via le navigateur (Playwright) sur la plateforme du marchand. Une fois rassemblees, les attribuer dans le logiciel de compta ou reporter le nom du fichier dans la sheet. Relancer automatiquement les team members dont la carte a servi pour les factures manquantes. Un gestionnaire de mots de passe (Bitwarden) permet a l'IA de se connecter aux plateformes.

## Exemples

### Bon : depense enrichie proprement

Description brute : `BUNNYCDN, MEDVODE, SVN, (Subscriptions, **5627): USD 25.00`.
Enrichissement : `marchand = "BunnyCDN"`, `categorie = "Hebergement"`, `carte = "5627"` (Prisme), `split = 50/50`. Rien n'est devine, tout vient de la config.

### Mauvais : marchand devine

Description brute illisible enrichie en `marchand = "Hebergement expert"`. C'est un faux positif comptable : le marchand reel est inconnu, le modele a invente. Bonne reponse : `marchand = "[Unknown]"`, `categorie = "Divers"`, signal "marchand a verifier".

### Bon : revenu trace

`Deposit from student@formation.com for Formation May 2026` : description conservee telle quelle, part par defaut a 100, type revenu. La description complete identifie le client, donc la ligne est rapprochable.

### Mauvais : revenu tronque

`Deposit from stu...` : l'info de rapprochement est perdue. Un revenu se garde entier.

## References

- Compte de service Google : Formation IA semaine 1, lecon Google Workspace (mise en place du projet Cloud, des APIs, du compte de service).
- [[revue-financiere]] : skill aval, a lancer APRES la synchro pour lire les chiffres consolides.
- Formation IA semaine 3 : contexte dynamique et creation d'automatisations (pour le palier n8n).
- Scripts de reference : un script de parsing du CSV, un `push-to-sheet.mjs` (push idempotent), un fichier de config (types de mouvement, marchands, categories, regles d'enrichissement).

## Regles

- C'est un template : adapter les types de mouvement, les categories et l'enrichissement a la banque et au cas de l'utilisateur.
- Jamais d'analyse sans CSV reel : pas de fichier, pas de chiffres inventes.
- La source de verite est le rapport qui reflete ce qui a reellement touche le compte, frais deduits.
- Ne jamais compter deux fois les frais deja deduits des encaissements par carte.
- Exclure les mouvements de change interne.
- Chaque depense a une categorie precise, ou `Divers` justifie. Aucun marchand invente.
- Un split ne se devine jamais : il suit une regle de la config.
- Les revenus gardent leur description complete ; l'humain ajuste les depots perso.
- Toujours faire valider le resume avant de pousser.
- La dedup par id de transaction est obligatoire a l'ecrit pour rester idempotent.

## Ce que tu ne fais PAS

- Inventer un marchand : un marchand inconnu reste `[Unknown]` + signal.
- Deviner le proprietaire d'un revenu : part par defaut, l'humain ajuste.
- Reporter deux fois les frais deja deduits.
- Tronquer une description de revenu.
- Pousser sans validation humaine.
- Ecrire dans Google Sheets sans compte de service (le MCP seul est trop limite).
- Automatiser via n8n tant que l'enrichissement manuel n'est pas fiabilise.
