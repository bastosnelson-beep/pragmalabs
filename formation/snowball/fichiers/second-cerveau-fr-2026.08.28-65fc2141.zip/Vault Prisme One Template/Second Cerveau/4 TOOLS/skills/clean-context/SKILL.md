---
name: clean-context
description: "Nettoie le contexte d'une Casquette ou d'un Projet perso : analyse toutes les notes d'un dossier, détecte les contradictions, les répétitions, les notes obsolètes, les infos à ajouter et les infos mal rangées, puis propose un plan de nettoyage concret (corriger, fusionner, archiver, déplacer). Lecture seule jusqu'à validation : tu proposes, l'utilisateur décide. À utiliser pour maintenir le contexte d'une Casquette ou d'un Projet à jour. Usage : /clean-context [chemin du dossier]."
---

# Clean Context : nettoyer le contexte d'un dossier

Le responsable d'une Casquette ou d'un Projet (toi, l'utilisateur) est chargé de garder son contexte à jour. Un contexte figé devient faux, et une IA qui lit du faux produit du faux avec assurance. `/clean-context` analyse un dossier et propose un plan de nettoyage concret. Lecture seule : rien n'est touché sans validation.

## Usage

```
/clean-context [chemin du dossier]
```

Le dossier est une Casquette (`Second Cerveau/2 CASQUETTES/[casquette]`) ou un Projet (`Second Cerveau/1 PROJETS/[projet]`). Si aucun chemin n'est donné, demande-le et n'invente rien.

## Process

### Step 1 : Lister et lire les notes du dossier

```bash
find "[dossier]" -name "*.md" -type f | sort
```

Lis chaque note en entier. Un dossier de Casquette contient sa note de contexte principale (même nom que le dossier) plus les notes liées (process, running notes, sous-dossiers). Un dossier de Projet contient sa note de contexte, sa roadmap, ses livrables et ses logs.

Si le dossier est vide ou n'existe pas, dis-le et stoppe.

### Step 2 : Recomposer l'état actuel

Pour chaque note, extrais ce qu'elle dit vraiment aujourd'hui. Dégage la direction réelle de la Casquette/Projet, au-delà des notes qui traînent depuis longtemps. C'est la référence contre laquelle on juge le reste.

### Step 3 : Analyser sur 5 axes

1. **Contradictions** : notes qui se contredisent (deux statuts, deux deadlines, deux prix, deux versions d'un même process). Pour chacune, propose laquelle garder (la plus récente, la plus fiable) et laquelle corriger ou archiver. En cas de doute sur la vérité, signale-le plutôt que de trancher au hasard.

2. **Répétitions** : information dupliquée entre notes. Indique les notes concernées et propose une version synthétique. Chaque info vit une seule fois au bon endroit (principe IPCRA : « à quoi ça sert ? »).

3. **Notes obsolètes** : notes qui ne sont plus alignées avec la direction actuelle (ancienne version, projet fini, process remplacé, référence périmée). Propose l'archive vers `5 ARCHIVE/`. Le doute tranche vers l'archive.

4. **À ajouter / améliorer** : notes incomplètes ou infos manquantes manifestes (un Projet sans roadmap, une Casquette sans intention à jour, un process sans étape clé). Propose des ajouts concrets.

5. **Mal rangées** : infos qui serviraient mieux ailleurs. Pour chacune, propose la destination :
   - Une autre Casquette (la responsabilité vit là)
   - Un autre Projet (l'info est sur une initiative temporaire)
   - `3 RESSOURCES/` (matériel de référence brut, inactif)
   - `0 INBOX/` (si tu ne sais pas, l'humain retriera)

### Step 4 : Proposer le plan

Affiche un rapport structuré sur les 5 axes, puis un plan d'action concret :

```
=== Plan de nettoyage : [dossier] ===

Contradictions :
- [note A] dit X, [note B] dit Y -> garder Y (plus récent), corriger A ligne [n]

Répétitions :
- [note A] + [note B] -> fusionner, version synthétique proposée

À archiver (5 ARCHIVE/) :
- [note X] : [raison]
- [note Y] : [raison]

À ajouter / améliorer :
- [note Z] : ajouter section [section] (deadline, statut)

À déplacer :
- [info dans note W] -> [destination] (raison)

Valider pour exécuter ? (oui / non / ajuster)
```

Attends la validation. N'applique rien tant que l'utilisateur n'a pas dit oui.

### Step 5 : Exécuter (après validation)

Une fois validé, applique le plan chirurgicalement :

- Corrige les contradictions dans les notes (édition d'une ligne, pas de réécriture complète).
- Fusionne les répétitions dans la note la mieux placée, retire les doublons.
- Déplace les notes obsolètes vers `5 ARCHIVE/` (crée le sous-dossier `5 ARCHIVE/[casquette ou projet]/` si besoin).
- Ajoute les sections manquantes dans les notes concernées.
- Déplace les infos mal rangées vers leur destination. Si la destination n'existe pas, signale-le au lieu de l'inventer.

### Step 6 : Loguer (léger)

Conserve un log minimal dans la daily note de la phase de vie active : `Second Cerveau/2 CASQUETTES/Sur ma vie/Life Phases/[phase active]/YYYY-MM-DD.md`. Appends-y un bloc de session au format du skill /done :

```markdown
## Logs IA / Session [HH:MM]

**Scope :** clean-context sur [dossier]

**Accompli :**
- [n] contradictions résolues
- [n] notes archivées
- [n] infos déplacées
- [n] sections ajoutées
```

Si la session est très courte, contente-toi d'une ligne dans la daily note. Garde-le léger.

## Règles

- Lecture seule jusqu'à validation. Tu proposes, l'utilisateur décide.
- Sois direct. Propose des actions concrètes.
- Si tu hésites entre deux options, dis-le clairement. Ne tranche pas au hasard.
- Préfère archiver plutôt que garder « au cas où ». Le doute tranche vers l'archive.
- Chaque info vit une seule fois au bon endroit (ontologie d'intention IPCRA).
- Édition chirurgicale : corrige une ligne, fusionne, déplace. Pas de réécritures complètes sans raison.
- Lis toujours une note avant de la modifier.
- Pas de tirets longs (U+2014). Pas de tic rhétorique « pas X mais Y ». Dis directement ce que tu veux.
- Pas d'emojis. Utilise des [[wikilinks]] vers les Casquettes, Projets et notes du vault.

## Ce que tu ne fais pas

- Toucher à quoi que ce soit avant validation.
- Inventer une destination. Si c'est inconnu, signale et demande.
- Supprimer une note sans l'archiver d'abord (déplacement vers `5 ARCHIVE/`; jamais de suppression directe).
- Réécrire une note entière quand une ligne suffit.
- Mentionner une contradiction sans proposer de résolution.
