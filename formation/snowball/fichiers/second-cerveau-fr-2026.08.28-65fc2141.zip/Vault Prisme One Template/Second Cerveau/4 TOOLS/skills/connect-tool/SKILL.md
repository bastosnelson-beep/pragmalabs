---
name: connect-tool
description: Connecte un outil, service ou API externe au système IA de l'utilisateur. Recherche la meilleure méthode de connexion (serveur MCP, install CLI, clé API + skill, ou endpoint HTTP), recommande, puis installe dans les bons configs (OpenCode, Claude Code, Claude Desktop) et vérifie. À utiliser quand « connecte X », « ajoute X à mon IA », « installe le X MCP », « donne accès à X à mon IA », « comment connecter X ».
---

# /connect-tool : Connecter un outil à ton IA

Tu recherches la meilleure façon de connecter un outil donné, tu l'installes dans les bons configs, et tu vérifies que ça marche.

## Argument

`$ARGUMENTS` = nom ou description de l'outil à connecter (ex « firecrawl », « playwright », « le GitHub MCP », « Notion », « web scraping », « ma base Supabase »).

Si vide, demande quel outil l'utilisateur veut connecter avant de continuer.

## L'idée centrale

Tous les outils ne devraient pas être un MCP. Parfois une CLI est plus simple, plus puissante et plus économe en contexte. Parfois une clé API plus un petit skill est plus flexible. Parfois tu documentes juste un endpoint HTTP.

Ce skill trouve la meilleure méthode, la recommande à l'utilisateur, l'installe au bon endroit, et vérifie.

## Convention de stockage

- **Config utilisateur** (sur la machine, gitignorée) : `~/.config/opencode/opencode.json`, `~/.claude.json`, `~/Library/Application Support/Claude/claude_desktop_config.json`. Les secrets vivent ici, jamais dans le coffre.
- **Inventaire personnel** : `Second Cerveau/4 TOOLS/Infrastructure.md` référence les outils connectés et OÙ vivent leurs secrets (nom de l'env var, gestionnaire de mots de passe), jamais les secrets eux-mêmes.

---

## Phase 0 : Recherche de la meilleure méthode de connexion

Découvre ce que l'outil offre. Ne suppose rien, cherche.

### 0.1 Recherche

Utilise Firecrawl ou webfetch si pas disponible :

1. Cherche `"<tool> MCP server"` et `"<tool> MCP npm"` pour vérifier un MCP officiel ou communautaire.
2. Cherche `"<tool> CLI"` pour vérifier un outil en ligne de commande.
3. Cherche `"<tool> API documentation"` pour vérifier une API REST/HTTP.
4. Cherche `"<tool> npm package"` ou `"<tool> python sdk"` pour vérifier un SDK.
5. Si un MCP est trouvé, fetch son README pour avoir la config exacte (package, transport, env vars).

### 0.2 Évaluer et recommander

Juge l'outil contre les 4 méthodes. Choisis le meilleur fit.

| Méthode | Quand l'utiliser | Ce que tu produis |
|--------|----------|------------------|
| **Serveur MCP** | Il existe un MCP bien maintenu (officiel ou communautaire populaire), et l'utilisateur a besoin d'un accès riche et structuré à l'outil (opérations multiples, inputs typés) | Entrée de config dans le(s) client(s) IA. Le meilleur pour : bases de données, CRM, outils de design, gestion de projet, tout ce qui a beaucoup d'opérations. |
| **Install CLI** | Il existe une bonne CLI, et l'usage consiste surtout à lancer des commandes | Installe la CLI (brew/npm/pip), crée optionnellement un skill qui wrap les commandes courantes. Le meilleur pour : mails, outils de build, de deploy, scrapers, utilitaires système. Souvent plus puissant et plus économe en tokens qu'un MCP. |
| **Clé API + skill** | Il existe une API REST mais pas de MCP/CLI, et l'utilisateur a besoin d'opérations reproductibles | Un petit skill dans `Second Cerveau/4 TOOLS/skills/[nom]/` qui appelle l'API, avec la clé référencée depuis l'env. Le meilleur pour : services one-off, APIs simples. |
| **Endpoint HTTP (documenter seulement)** | Usage simple one-off, l'utilisateur a juste besoin de connaître l'endpoint et l'auth | Une ligne dans `4 TOOLS/Infrastructure.md` documentant l'endpoint, l'auth, et l'usage. Le meilleur pour : dashboards, webhooks, APIs en lecture seule. |

Important : le réflexe « il y a forcément un MCP » est souvent le mauvais réflexe. Un MCP charge ses descriptions d'outils dans le contexte à chaque session (souvent 20 à 30k tokens) et ses opérations sont parfois restreintes par rapport à la CLI du même service. À capacités égales, préfère la CLI.

### 0.3 Présenter la recommandation

```
J'ai recherché [outil]. Voilà ce qu'il offre :

- MCP : [oui/non, quel package, comment maintenu]
- CLI : [oui/non, laquelle]
- API : [oui/non, REST/GraphQL]
- SDK : [oui/non, lequel]

Ma recommandation : [méthode]. [1 ligne pourquoi.]

Tu es d'accord, ou tu veux une autre méthode ?
```

Attends la confirmation. Seulement alors passe à la suite.

---

## Phase 1 : Rassembler les credentials

Si la connexion nécessite des credentials (clé API, token, etc.) :

- Dis à l'utilisateur exactement quelle(s) variable(s) sont nécessaires
- Explique où les obtenir (depuis le README que tu as scrapé, ou la page de settings de l'outil)
- Demande à l'utilisateur de les fournir
- Ne continue pas sans eux s'ils sont obligatoires

```
Cette connexion nécessite :
- VARIABLE_NAME : [courte explication, ex « ta clé API Firecrawl, disponible sur app.firecrawl.dev »]

Fournis ces valeurs pour que je puisse configurer la connexion.
```

**Règles de gestion des credentials :**
- Les vraies valeurs vont dans les fichiers de config utilisateur (sur la machine). C'est OK; ces fichiers sont gitignorés.
- `4 TOOLS/Infrastructure.md` référence OÙ vit le secret (nom de l'env var, gestionnaire de mots de passe), jamais le secret lui-même.

---

## Phase 2 : Installer

### 2.1 Détecter les systèmes IA installés

Lance ça pour voir quels systèmes sont présents :

```bash
echo "=== Détection des systèmes IA ==="

# OpenCode
if [ -f "$HOME/.config/opencode/opencode.json" ]; then
  echo "OpenCode: DÉTECTÉ ($HOME/.config/opencode/opencode.json)"
else
  echo "OpenCode: absent"
fi

# Claude Code CLI
if [ -f "$HOME/.claude.json" ]; then
  echo "Claude Code CLI: DÉTECTÉ ($HOME/.claude.json)"
else
  echo "Claude Code CLI: absent"
fi

# Claude Desktop (macOS)
if [ -f "$HOME/Library/Application Support/Claude/claude_desktop_config.json" ]; then
  echo "Claude Desktop (macOS): DÉTECTÉ"
elif [ -f "$APPDATA/Claude/claude_desktop_config.json" ] 2>/dev/null; then
  echo "Claude Desktop (Windows): DÉTECTÉ"
elif [ -f "$HOME/.config/Claude/claude_desktop_config.json" ]; then
  echo "Claude Desktop (Linux): DÉTECTÉ"
else
  echo "Claude Desktop: absent"
fi

# jq
if command -v jq &>/dev/null; then
  echo "jq: disponible"
else
  echo "jq: ABSENT (fallback Python sera utilisé)"
fi
```

Demande à l'utilisateur quels systèmes il utilise (il peut en avoir plusieurs; ne suppose pas que tous les détectés sont utilisés).

### 2.2 Patcher le config pour chaque système choisi

Le format diffère par système. N'écrase jamais un config existant : lis toujours, ajoute la clé, réécris.

#### OpenCode (`~/.config/opencode/opencode.json`)

Clé wrapper : `mcp`. `command` est un **tableau**. Clé env : `environment`. Type : `local` / `remote`. Besoin de `enabled: true`.

**stdio (local) :**
```json
{
  "mcp": {
    "<name>": {
      "type": "local",
      "command": ["npx", "-y", "<package>"],
      "environment": { "KEY": "VALUE" },
      "enabled": true
    }
  }
}
```

**http (remote) :**

```json
{
  "mcp": {
    "<name>": {
      "type": "remote",
      "url": "https://mcp.example.com/sse",
      "headers": { "Authorization": "Bearer TOKEN" },
      "enabled": true
    }
  }
}
```

Patch :
```bash
mkdir -p "$HOME/.config/opencode"
[ ! -f "$HOME/.config/opencode/opencode.json" ] && echo '{"$schema":"https://opencode.ai/config.json","mcp":{}}' > "$HOME/.config/opencode/opencode.json"

jq '.mcp["NAME"] = {
  "type": "local",
  "command": ["npx", "-y", "PACKAGE"],
  "environment": {"KEY": "VALUE"},
  "enabled": true
}' "$HOME/.config/opencode/opencode.json" > /tmp/oc.json && mv /tmp/oc.json "$HOME/.config/opencode/opencode.json"
```

#### Claude Code CLI (`~/.claude.json`) et Claude Desktop

Clé wrapper : `mcpServers`. `command` est une **chaîne**, `args` est un tableau séparé. Clé env : `env`. Pas de champ `type` pour stdio.

**stdio (local) :**
```json
{
  "mcpServers": {
    "<name>": {
      "command": "npx",
      "args": ["-y", "<package>"],
      "env": { "KEY": "VALUE" }
    }
  }
}
```

**http (remote) :** Claude Code/Desktop ne supporte pas le MCP HTTP remote nativement. Utilise le bridge `mcp-remote` :
```json
{
  "mcpServers": {
    "<name>": {
      "command": "npx",
      "args": ["-y", "mcp-remote", "https://mcp.example.com/sse", "--header", "Authorization:Bearer TOKEN"]
    }
  }
}
```

Patch Claude Code CLI (chemin : `~/.claude.json`). Patch Claude Desktop (chemin varie selon l'OS, voir détection ci-dessus).

```bash
[ ! -f "$HOME/.claude.json" ] && echo '{"mcpServers":{}}' > "$HOME/.claude.json"

jq '.mcpServers["NAME"] = {
  "command": "npx",
  "args": ["-y", "PACKAGE"],
  "env": {"KEY": "VALUE"}
}' "$HOME/.claude.json" > /tmp/cc.json && mv /tmp/cc.json "$HOME/.claude.json"
```

Claude Desktop : même format, chemin différent. Claude Desktop ne recharge pas le config automatiquement : relance l'app après le patch.

#### Fallback Python (si jq absent)

Même pattern que ci-dessus mais en utilisant `python3 -c` pour lire, modifier, et écrire le JSON. Exemple pour OpenCode :

```bash
python3 - <<'EOF'
import json, os
path = os.path.expanduser("~/.config/opencode/opencode.json")
os.makedirs(os.path.dirname(path), exist_ok=True)
config = json.load(open(path)) if os.path.exists(path) else {"$schema":"https://opencode.ai/config.json","mcp":{}}
config.setdefault("mcp", {})["NAME"] = {
    "type": "local",
    "command": ["npx", "-y", "PACKAGE"],
    "environment": {"KEY": "VALUE"},
    "enabled": True
}
json.dump(config, open(path, "w"), indent=2)
print("OpenCode patched.")
EOF
```

Adapte la clé wrapper (`mcp` vs `mcpServers`), la forme de command, et la clé env par système.

### 2.3 Aide-mémoire de compatibilité des formats

| Champ | OpenCode | Claude Code / Desktop |
|-------|----------|----------------------|
| Clé wrapper | `mcp` | `mcpServers` |
| Command | `command: ["npx", "-y", "pkg"]` (tableau) | `command: "npx"` + `args: ["-y", "pkg"]` (split) |
| Env vars | `environment: {}` | `env: {}` |
| Type (stdio) | `type: "local"` | (aucun) |
| Type (http) | `type: "remote"` + `url` + `headers` | bridge `mcp-remote` dans args |
| Activation | `enabled: true` | toujours actif |

L'erreur la plus courante est de confondre la command tableau d'OpenCode avec la command split de Claude. Vérifie deux fois avant d'écrire.

---

## Phase 3 : Documenter (optionnel mais recommandé)

Ajoute une ligne dans `Second Cerveau/4 TOOLS/Infrastructure.md` (crée le tableau s'il n'existe pas) :

```markdown
| Outil | Méthode | Secret dans | Ajouté le |
| --- | --- | --- | --- |
| [Nom de l'outil] | MCP / CLI / clé API + skill / endpoint | [env var / gestionnaire de mots de passe] | [date] |
```

Jamais la valeur du secret, seulement où il vit.

---

## Phase 4 : Vérifier et résumer

### 4.1 Vérifier

**OpenCode :** ouvre OpenCode, tape `/mcp` dans le chat. Le nouveau MCP doit apparaître.

**Claude Code CLI :** `claude mcp list`. Le MCP doit apparaître.

**Claude Desktop :** relance l'app. Dans une nouvelle conversation, le MCP doit apparaître dans la liste des tools.

**CLI :** `which <cli>` ou `<cli> --version`, puis une commande simple.

**Test :** si possible, lance une opération simple via l'outil pour confirmer qu'il répond. Ex : pour un outil de scraping, scrape une URL simple.

### 4.2 Résumer

```
Outil connecté : [outil] via [méthode].

Installé dans :
- OpenCode : [oui / non détecté]
- Claude Code CLI : [oui / non détecté]
- Claude Desktop : [oui (relance requise) / non détecté]

Credentials :
- VARIABLE_NAME : setté dans [fichiers de config]

Documenté dans 4 TOOLS/Infrastructure.md : [oui/non]

Vérification : [testé / non testé, résultat]
```

Si une étape a échoué, dis-le clairement et propose le fix.

---

## Cas particuliers

### Install CLI (pas un MCP)

Si la meilleure méthode est une CLI :
1. Installe la CLI (`brew install`, `npm install -g`, `pip install`, etc.)
2. Vérifie : `which <cli>` ou `<cli> --version`
3. Si l'utilisateur a besoin de commandes reproductibles, crée un skill dans `Second Cerveau/4 TOOLS/skills/[nom]/SKILL.md` qui wrap les commandes courantes
4. Documente dans `4 TOOLS/Infrastructure.md`

### Clé API + skill (pas de MCP, pas de CLI)

Si la meilleure méthode est une clé API + un skill :
1. Demande la clé API, stocke-la comme env var
2. Crée un skill dans `Second Cerveau/4 TOOLS/skills/[nom]/SKILL.md` qui documente comment appeler l'API (endpoint, header d'auth, opérations courantes)
3. Documente dans `4 TOOLS/Infrastructure.md`

### Endpoint HTTP (documenter seulement)

Si la meilleure méthode est juste de documenter un endpoint HTTP :
1. Ajoute la ligne dans `4 TOOLS/Infrastructure.md` (URL, méthode d'auth, usage), skippe le patching de config

---

## Règles

- **Recherche avant d'installer.** Ne suppose pas qu'un outil a un MCP, ni qu'un MCP est la meilleure méthode. Évalue les 4 méthodes et recommande le meilleur fit. Confirme avec l'utilisateur avant d'installer.
- **À capacités égales, préfère la CLI.** Plus puissante, plus économe en contexte, pas de descriptions d'outils chargées à chaque session.
- **Ne colle jamais de secrets dans le coffre.** Les secrets vivent dans les fichiers de config utilisateur (gitignorés) ou un gestionnaire de mots de passe. `Infrastructure.md` référence où ils vivent, jamais leur valeur.
- **N'écrase jamais un config existant.** Lis toujours, ajoute la clé, réécris. Utilise `jq` ou Python, jamais d'écriture aveugle.
- **Respecte le format par système.** OpenCode utilise des commandes tableau + `environment` + `enabled`. Claude utilise command split + `env` et le bridge `mcp-remote` pour le HTTP.
- **Vérifie après l'install.** Ne clame pas le succès sans vérifier que l'outil apparaît et répond.

## Ce que tu ne fais pas

- Installer un MCP sans rechercher si un MCP est vraiment la meilleure méthode.
- Coller des secrets dans le coffre ou dans Infrastructure.md.
- Écraser un fichier de config existant au lieu de le patcher.
- Confondre la command tableau d'OpenCode avec la command split de Claude.
- Oublier de relancer Claude Desktop après le patch (il ne recharge pas automatiquement).
- Skipper l'étape de vérification.
