---
name: creer-lead-magnet
description: Crée un lead magnet complet du concept à la structure finale. Utiliser quand "je veux créer un lead magnet", "j'ai besoin d'un freebie pour capturer des emails", "aide-moi à créer une ressource gratuite", "je veux préparer un webinaire d'acquisition", "comment attirer des prospects qualifiés".
domaine: Acquisition
---

# Lead Magnet — Du concept à la structure finale

Flux complet : objectif → format → proposition de valeur → 5 histoires → contenu + bonus.

---

## Démarrage

Poser cette question en premier et attendre la réponse :

> "Combien de lead magnets veux-tu concevoir aujourd'hui ?"

Traiter chaque lead magnet l'un après l'autre. Ne pas enchaîner sans validation du précédent.

---

## Pour chaque lead magnet — 5 étapes

### Étape 1 — Clarifier l'objectif et le produit payant

Un lead magnet a **2 fonctions simultanées** :
1. Générer le clic (taux de conversion sur la page de capture)
2. Pré-vendre le produit payant (créer l'envie d'aller plus loin)

Demander :

> "Dis-moi :
> 1. Quel est le produit payant que ce lead magnet doit pré-vendre ? (formation, accompagnement, service, logiciel...)
> 2. Quel est son prix ?
> 3. Qui est ton prospect idéal ? (niveau, situation, problème principal)"

**Règle critique** : le lead magnet doit attirer les bons prospects — ceux qui peuvent acheter le produit payant, pas n'importe qui.

✅ **Bon alignement** : lead magnet "comment doubler ton taux de closing en 30 jours" → produit payant = coaching en vente pour entrepreneurs à 2000€/mois

❌ **Mauvais alignement** : lead magnet "introduction au copywriting pour débutants" → produit payant = accompagnement pour trouver des clients (public déjà formé)

Valider l'objectif et l'alignement avant de continuer.

---

### Étape 2 — Choisir le format

Demander :

> "Tu as une préférence de format, ou tu veux que je te recommande en fonction de ton produit ?"

**Guide de choix par prix du produit payant :**

| Format | Idéal pour | Avantages |
|--------|-----------|-----------|
| Freebie (PDF, checklist, scripts) | Produits < 100€ | Rapide à produire, très partageable |
| Séquence email (4-7 mails) | Produits 100-500€ | Relation progressive, automatisable |
| VSL / Vidéo de vente | Produits 97-297€ | Fort taux de conversion, persuasion immédiate |
| Challenge (5-7 jours) | Produits 200-1000€ | Engagement fort, transformation visible |
| Formation gratuite / mini-cours | Produits 500€+ | Crédibilité haute, preuve de valeur |
| Webinaire | Produits 500€+ | Relation + persuasion, questions en direct |
| Appel gratuit | High-ticket uniquement | Qualification maximale |
| Quiz | Tous prix | Personnalisation + qualification |

**Principe snack** : le meilleur lead magnet = le truc le plus tangible et immédiatement utile que tu as. Court, direct, action immédiate.

✅ **Exemple** : "les 9 meilleurs emails de prospection avec scripts" → bien mieux que "10h de formation copywriting gratuite"

Valider le format avant de continuer.

---

### Étape 3 — Définir la proposition de valeur

La proposition de valeur doit réunir 2 critères obligatoires :

**Critère 1 — Mesurable** : inclure un résultat observable, de préférence chiffré.
**Critère 2 — Désirable** : validé par ce que tes prospects disent vraiment vouloir (appels, commentaires, messages reçus).

Demander :

> "Complète cette phrase : 'Grâce à ce lead magnet, mon prospect va obtenir [résultat précis] en [délai] sans [obstacle principal].'"

**Exemples :**

✅ **Bonne proposition** : "Obtenir 3 premiers clients B2B en 30 jours sans audience ni publicité"
✅ **Bonne proposition** : "Réduire le temps de traitement des candidatures de 5h à 1h par semaine grâce à l'IA"

❌ **Mauvaise proposition** : "Améliorer ta productivité" (trop vague, pas mesurable)
❌ **Mauvaise proposition** : "Découvrir les bases du marketing de contenu" (pas désirable pour quelqu'un qui cherche des clients)

Si le résultat n'est pas chiffrable (sujet subjectif) → le rendre concret et comportemental. Ex : "ne plus jamais te sentir bloqué face à une page blanche" → "produire 5 posts LinkedIn par semaine en moins de 2h".

Valider la proposition de valeur avant de continuer.

---

### Étape 4 — Construire les 5 histoires (structure PSM)

Le lead magnet doit contenir 5 histoires pour convaincre et pré-vendre :

**Présenter chaque histoire une par une. Attendre les réponses avant de passer à la suivante.**

---

**Histoire 1 — L'origine** (crédibilité)

> "Raconte comment tu as découvert / mérité cette méthode. Structure : situation avant → désir → mur → épiphanie → résultat obtenu."

But : transmettre l'émotion de l'épiphanie pour que le prospect veuille l'opportunité.

✅ Parler des émotions et de la transformation, pas des techniques.

---

**Histoire 2 — Le véhicule** (lever l'objection "ça ne marche plus")

> "Pourquoi TA méthode est-elle la meilleure aujourd'hui pour CE prospect dans CETTE situation ?"

But : définir clairement le véhicule unique et prouver qu'il est adapté maintenant.

✅ Plus la niche est spécifique, plus le véhicule correspond parfaitement.

---

**Histoire 3 — L'interne** (lever l'objection "moi je ne peux pas")

> "Quelle est la croyance limitante principale de ton prospect ? Quel framework prouve qu'il peut réussir malgré elle ?"

Exemples de formulation : "même si tu n'as jamais écrit une ligne de code", "même si tu es introverti", "même si tu n'as aucune audience".

---

**Histoire 4 — L'externe** (lever l'objection "mon contexte ne me permet pas")

> "Quel obstacle environnemental bloque ton prospect ? (famille, temps, argent, marché) Comment ton framework le neutralise ?"

Question clé : "Quelle est la chose à laquelle ils pensent qui les empêche de démarrer maintenant ?"

---

**Histoire 5 — La solution** (pré-vendre le produit payant)

> "Décris ta méthode / offre avec sa stack de valeur. Ce que tu donnes dans le lead magnet = les frameworks (le QUOI). Ce que tu vends = les tactiques (le COMMENT)."

⚠️ Règle absolue : dans le lead magnet, présenter les frameworks (quoi faire), jamais les tactiques détaillées (comment exactement). Les tactiques = ce que le prospect achètera.

Valider les 5 histoires avant de continuer.

---

### Étape 5 — Structurer le contenu + les bonus anti-objections

**Structure de l'offre complète :**

- **Corps principal** : la valeur centrale (les frameworks des 5 histoires)
- **Bonus 1** : contre l'objection du véhicule ("est-ce que cette méthode fonctionne encore aujourd'hui ?")
- **Bonus 2** : contre l'objection interne ("est-ce que MOI je peux y arriver ?")
- **Bonus 3** : contre l'objection externe ("est-ce que MON ENVIRONNEMENT me permet de le faire ?")
- **Bonus 4** (optionnel) : contre l'objection de mise en pratique ("je ne sais pas par où commencer")

Demander :

> "Pour chaque bonus, dis-moi : quelle objection il contre, et quelle ressource concrète tu peux donner pour l'éliminer ?"

**Exemple de structure complète :**

Corps principal : 9 scripts emails de prospection B2B
- Bonus 1 : étude de cas vidéo "3 CEO qui ont signé leurs premiers clients avec ces scripts" (véhicule)
- Bonus 2 : checklist "qualifier un prospect en 5 questions" (interne — même sans expérience)
- Bonus 3 : liste de 100 prospects qualifiés par secteur (externe — manque de contacts)

Rédiger l'architecture complète avant de clore.

Valider la structure avant de terminer.

---

## Rappels permanents

- **2 objectifs simultanés** : générer le clic ET pré-vendre le produit payant
- **Principe snack** : court, direct, action immédiate — jamais les grandes philosophies
- **Les frameworks dans le gratuit, les tactiques dans le payant**
- **Proposition de valeur = mesurable + désirable** (validé par des vrais retours clients)
- **Les bonus sont des contreurs d'objections**, pas des "cadeaux"
- **Un lead magnet qui attire tout le monde n'attire personne** — cibler précisément
