---
name: base-marketing
description: Crée la base marketing commune réutilisable dans tous les assets (pub, page de vente, emails). Utiliser quand "je veux créer mes arguments marketing", "aide-moi à construire mon message de vente", "je commence ma campagne marketing", "je veux comprendre mon client".
domaine: Vente
---

# Skill : Base Marketing Commune

Ce document se construit **une seule fois** et sert de source pour toutes les publicités, pages de capture, pages de vente et emails. Ne rien écrire avant d'avoir rempli cette base.

**Mode dialogique** : à chaque étape, poser les questions, attendre les réponses, puis passer à la suivante. Ne pas avancer sans validation.

---

## Étape 1 — Cartographie psychologique du client (Forces Client)

Remplir ces 5 éléments avant d'écrire quoi que ce soit. Poser chaque question une par une.

**Question 1 — Situation actuelle**
> Où est le client aujourd'hui ? Ses frustrations concrètes, ses habitudes, ses problèmes précis du quotidien.
> (Pas "il est stressé" → "il reçoit 80 emails par jour et ne sait jamais par quoi commencer")

**Question 2 — Situation désirée**
> Où veut-il aller ? Quelque chose de concret et mesurable — pas "être heureux".
> (Pas "avoir plus de liberté" → "pouvoir choisir ses horaires sans demander l'autorisation à personne")

**Question 3 — Croyance véhicule**
> Pourquoi pense-t-il que votre méthode ne marcherait pas pour lui ?
> (Exemples : "ça ne marche plus en 2024", "c'est trop technique pour moi", "j'ai déjà essayé et ça n'a rien donné")

**Question 4 — Croyance interne**
> Pourquoi pense-t-il ne pas pouvoir y arriver personnellement ?
> (Exemples : "moi je suis nul en rédaction", "je n'ai pas le profil", "je n'ai jamais réussi à tenir un régime")

**Question 5 — Croyance externe**
> Qu'est-ce qui dans son environnement l'empêche d'agir ?
> (Exemples : "je n'ai pas le temps", "ma femme ne comprend pas", "le marché est saturé")

→ Valider avec l'utilisateur avant de continuer.

---

## Étape 2 — Solutions alternatives déjà essayées

> Qu'est-ce que le prospect utilise déjà pour résoudre ce problème ?
> Quels sont les problèmes concrets de ces solutions ?

C'est ici que se trouvent les meilleures pépites de copywriting. Explorer :
- Ce qu'il a essayé (outils, méthodes, autres formations, thérapeutes, lectures…)
- Pourquoi ça n'a pas marché dans son cas précis
- Ce qu'il a ressenti après chaque tentative échouée

**Astuce** : Si tu as eu des conversations avec ta cible, dis-moi ce qu'ils t'ont dit. Sinon, décris ce que tu penses de leur situation — on validera avec des vrais retours ensuite.

→ Valider avant de continuer.

---

## Étape 3 — Exercice Avant / Après

Tracer deux colonnes. Remplir avec des **images concrètes uniquement** — jamais d'abstractions.

| AVANT | APRÈS |
|-------|-------|
| Décrire le quotidien précis avec le problème | Décrire le quotidien idéal après la solution |
| Émotions, situations, sentiment d'impasse | Sensations concrètes, nouveau rapport à la vie |

**Règle absolue** : chaque ligne doit être une image, pas un concept.
- Mauvais : "vous vous sentez libre"
- Bon : "vous vous réveillez et pouvez travailler depuis votre cuisine ou depuis Lisbonne"

- Mauvais : "vous retrouvez la sérénité"
- Bon : "vous ne ressentez plus ce nœud dans le ventre le lundi matin"

**Méthode** : pour chaque mot abstrait, se demander "concrètement, ça ressemble à quoi dans sa journée ?"

→ Viser au moins 5 lignes par colonne. Valider avant de continuer.

---

## Étape 4 — Les 19 questions (base marketing complète)

Répondre une fois, réutiliser dans tous les assets. Guider une question à la fois.

> Je vais te poser ces questions **une par une**. Réponds à chaque question avant que je passe à la suivante. Prêt ? On commence.
>
> **Question 1 :** Quel est le problème dur à résoudre ? (le plus précis possible)

Attendre la réponse. Puis poser la question suivante, et ainsi de suite jusqu'à la question 19.

### Catégorie 1 — Le problème
1. Quel est le problème dur à résoudre ? (le plus précis possible)
2. En quoi affecte-t-il le quotidien concrètement ? (situations précises)
3. Dans quelle situation est-il le plus douloureux ?
4. Quelle est la source réelle du problème ? (ce que les autres méthodes ignorent)
5. Pourquoi est-il difficile à résoudre ?
6. Pourquoi les solutions précédentes n'ont pas marché ?

### Catégorie 2 — La solution
7. Quelle est la solution au problème ?
8. Comment répond-elle mieux que les alternatives ?
9. Quelle est la preuve que ça marche ?

### Catégorie 3 — Le résultat
10. Comment la solution transforme-t-elle le quotidien ?
11. Quels résultats concrets va accomplir le prospect ?
12. Quelles émotions va-t-il ressentir ?
13. Comment va-t-il être perçu différemment ?
14. Que se passera-t-il s'il ne passe PAS à l'action ?

### Catégorie 4 — L'appel à l'action
15. À quoi ressemble le produit concrètement ?
16. Contenu orienté bénéfices (toujours avec un "pour")
17. Quel est le prix ?
18. Quelle est la garantie ?
19. Pourquoi agir maintenant ? (urgence — sans urgence, aucune décision)

→ Valider les réponses à toutes les 19 questions avant de continuer.

---

## Étape 5 — Bénéfices produit (bullet points)

**Formule obligatoire** : [Caractéristique] **pour** [bénéfice concret]

Pour chaque module ou élément du produit, formuler un bullet complet :

- Mauvais : "Un module sur la gestion du temps"
- Bon : "Un module sur la gestion du temps **pour savoir exactement quoi faire en premier** chaque matin — sans devoir décider sous stress"

- Mauvais : "2 vidéos de traitement"
- Bon : "2 vidéos détaillées sur le traitement **pour savoir exactement où placer les doigts, quelle force appliquer, et ce que vous devez ressentir** — aucune approximation"

**Règles supplémentaires :**
- Finir chaque bullet par une image de la situation transformée quand c'est pertinent
- Transformer les questions fréquentes en bénéfices ("accès à vie" → "vous pouvez y revenir à n'importe quel moment de votre vie, même dans 3 ans")

→ Valider la liste de bénéfices avant de continuer.

---

## Étape 6 — Le Big Domino

La croyance unique que le prospect doit avoir pour n'avoir d'autre choix que d'acheter.

**Formule** :
> "Si j'arrive à faire croire que [mon véhicule unique] est la clé pour [résultat le plus désiré] ET que la seule façon de l'appliquer est par [ma solution], alors toutes les autres objections deviennent impertinentes."

**Exemples de big dominos efficaces :**
- "Les tunnels de vente sont la clé du succès en ligne, et ne sont maîtrisables qu'avec [cet outil]"
- "Le book funnel est le meilleur tunnel pour les formateurs et conférenciers"
- "Fonctionner par cycles sportifs est la clé pour se sentir bien durablement (cible : entrepreneurs)"

**Règles :**
- Tout le contenu (chaque phrase, chaque histoire, chaque section) doit faire tomber ce big domino
- Si une section ne sert pas directement à faire tomber le big domino → la couper
- Choisir un véhicule spécifique, pas générique ("sport" est trop large — "cycles sportifs adaptés aux entrepreneurs nomades" est différenciant)

→ Formuler le big domino de ce projet précis. Valider avant de continuer.

---

## Étape 7 — Enrichissement avec des images concrètes

Revoir toutes les réponses précédentes et remplacer chaque mot abstrait par une image concrète.

**Méthode :** Pour chaque mot abstrait dans tes messages, demande-toi : "Concrètement, ça ressemble à quoi dans la journée de mon prospect ?" Remplacer les abstractions par des situations concrètes.

**Test systématique** : pour chaque mot abstrait (liberté, sérénité, épanouissement, clarté…), se demander "concrètement, ça ressemble à quoi dans une journée ordinaire du prospect ?"

---

## Output final

Le document produit contient :

```
BASE MARKETING — [Nom du projet]

1. Cartographie psychologique (5 éléments)
2. Solutions alternatives + problèmes identifiés
3. Tableau Avant / Après (5+ lignes par colonne)
4. Réponses aux 19 questions
5. Liste de bénéfices produit (formule [Caractéristique] pour [bénéfice])
6. Big Domino formulé
7. Banque de métaphores / images concrètes
```

Ce document est la source unique pour tous les assets suivants : publicités, page de capture, page de vente, emails de relance.
