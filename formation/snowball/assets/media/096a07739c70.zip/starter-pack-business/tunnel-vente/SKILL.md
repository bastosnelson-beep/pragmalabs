---
name: tunnel-de-vente
description: Choisit, mappe et construit un tunnel de vente complet. Utiliser quand "je veux créer un tunnel de vente", "comment automatiser mes ventes", "aide-moi à construire mon funnel", "je veux un système de vente qui tourne sans moi".
domaine: Vente
---

# SKILL — Tunnel de Vente

## Ce que ce skill fait

Ce skill guide la conception complète d'un tunnel de vente : choix de la structure selon le prix, définition du lead magnet, base marketing commune, mapping détaillé, séquences email, upsells/downsells et optimisation.

---

## Démarrage

Avant tout, poser ces 4 questions :

> "Pour créer ton tunnel, j'ai besoin de comprendre ta situation :
> 1. Quel est ton produit ou service ? (nom + brève description + prix)
> 2. Tu pars de zéro ou tu as déjà un tunnel à optimiser ?
> 3. Tu as déjà une liste email ? (si oui, combien de contacts approximativement)
> 4. Quel est ton objectif principal — générer des leads, vendre directement, ou nurture ?"

Attendre les 4 réponses. Ne pas continuer sans.

---

## ÉTAPE 0 — Rappel fondamental

**L'offre est la variable la plus importante.** Un tunnel médiocre avec une super offre bat un tunnel parfait avec une offre nulle. Ne pas passer à la structure avant que l'offre soit solide.

Un tunnel scalable commence par de la publicité payante (YouTube, Facebook, Google) : revenu non corrélé au temps. Commencer avec 100€ de budget pub suffit pour tester.

---

## ÉTAPE 1 — Choisir la structure selon le prix

Poser d'abord : **"Quel est le prix de votre produit ?"**

### Produit < 37€ (low-ticket)
- **Option 1** : Pub → Page de vente directe (moins de leads, conversions directes)
- **Option 2** : Pub → Page de capture → Page de vente (plus de leads, moins de conversions directes)
- Recommandation : commencer par le tunnel le plus simple possible

### Produit 97-297€ (mid-ticket)
- Pub → Page de capture → VSL/Vidéo de vente (20-30 min) → Page de vente
- Nécessite de construire la confiance avant l'achat

### Produit 500-2000€ (high-ticket)
- Pub → Page de capture → Série de 4 vidéos ou webinaire (50-60 min) → Page de vente longue
- Structure webinaire : Promesse → Histoire/crédibilité → Mécanisme → Avant/Après → Offre → FAQ

### Produit 1000€+ (premium)
- Même structure que high-ticket + séquence email d'urgence (4-5 mails sur 72h)
- Insister sur la précommande / disponibilité limitée si applicable

**Règle de départ :** Commencer avec un produit max 100€ pour tester la demande. Itérer jusqu'à la rentabilité avant de monter en gamme.

---

## ÉTAPE 2 — Choisir le format du lead magnet

| Prix du produit | Format recommandé |
|---|---|
| < 100-200€ | Freebie, VSL courte (10-20 min), séquence email 5 jours, quiz |
| 200-800€ | Webinaire, challenge 4-7 jours, série de 4-5 vidéos |
| 800-3000€ | Webinaire + appel, formation gratuite de 4-5h, produit d'entrée à 7-8€ |
| 3000€+ | Formation à bas prix + appel de closing obligatoire |

**Formulation :** Éviter "100% gratuit" → préférer "en accès libre" ou "offert" (meilleure conversion mesurée).

---

## ÉTAPE 3 — Définir le problème et faire l'exercice Avant/Après

> Si tu as déjà fait l'exercice de base marketing pour ce produit, colle le document ici — je saute ces étapes. Sinon, on les fait maintenant.

**C'est la base de TOUS les assets marketing** (pub, page de capture, page de vente, emails).

### Exercice Avant/Après

Tracer une feuille en 2 colonnes :

**AVANT** : décrire le quotidien précis du prospect avec son problème
- Émotions, situations concrètes, sentiment d'impasse
- Chercher des images concrètes, pas des abstractions ("vous ne dormez plus" > "vous êtes fatigué")
- Aller chercher les désirs cachés : qu'est-ce qu'il aimerait avoir dans sa vie ?

**APRÈS** : décrire le quotidien idéal après la solution
- Sensations concrètes, nouveau rapport à la vie
- Toujours demander : "concrètement, ça ressemble à quoi ?"

---

## ÉTAPE 4 — Répondre aux 19 questions de base marketing

> Si tu as déjà fait l'exercice de base marketing pour ce produit, colle le document ici — je saute ces étapes. Sinon, on les fait maintenant.

À faire une seule fois. Ces réponses alimentent tous les assets (pub, emails, pages).

**Le problème :**
1. Quel est le problème dur à résoudre ?
2. En quoi affecte-t-il le quotidien ?
3. Dans quelle situation est-il le plus douloureux ?
4. Quelle est la source réelle du problème ?
5. Pourquoi est-il difficile à résoudre ?
6. Pourquoi les solutions précédentes n'ont pas marché ?

**La solution :**
7. Quelle est la solution ?
8. Comment répond-elle mieux que les alternatives ?
9. Quelle est la preuve que ça marche ?

**Le résultat :**
10. Comment la solution transforme-t-elle le quotidien ?
11. Quels résultats va accomplir le prospect ?
12. Quelles émotions va-t-il ressentir ?
13. Comment va-t-il être perçu différemment ?
14. Que se passera-t-il s'il ne passe PAS à l'action ?

**L'appel à l'action :**
15. À quoi ressemble le produit concrètement ?
16. Contenu orienté bénéfices (toujours avec un "pour")
17. Quel est le prix ?
18. Quelle est la garantie ?
19. Pourquoi agir maintenant ? (urgence)

---

## ÉTAPE 5 — Mapper le tunnel avant de construire

**Règle absolue : mapper AVANT d'exécuter.**

Utiliser un outil visuel (Whimsical, MIRO, papier) et détailler :
- Chaque page (titre, contenu, objectif)
- Chaque email (objet, corps, CTA)
- Chaque script de pub (accroche, corps, CTA)
- Chaque upsell / downsell (timing, prix, contenu)

Cela évite les oublis et accélère l'exécution.

---

## ÉTAPE 6 — Séquence email post-inscription

Structure minimale éprouvée :

| Email | Timing | Contenu | Objectif |
|---|---|---|---|
| **Email J+0** | Immédiat | Bienvenue + lien vers la vidéo/contenu. Qui est l'auteur. Rappel du problème ciblé. | Clic sur le lien |
| **Email J+1** | +24h | Rappel simple : 3 bénéfices clés + lien page de vente. Pas de promo. | Re-engagement |
| **Email J+2** | +48h | Offre agressive : réduction exclusive 24h + timer visible. | Conversion urgente |
| **Email J+4** | +96h (optionnel) | Dernière chance avec coupon encore plus agressif (jusqu'à -70%). | Conversion finale |

**Règles :**
- Désinscrire automatiquement de la séquence dès l'achat
- Signer les emails de relance avec un "assistant" ou un nom secondaire → l'auteur reste perçu comme généreux, pas pushy (Note : vérifier la conformité avec la réglementation locale — en France, l'identité de l'expéditeur doit être claire)
- Pour webinaire haute valeur (500€+) : voir séquence spécifique dans le skill webinaire

---

## ÉTAPE 7 — Upsells et downsells

**Timing critique :** proposer l'upsell APRÈS le paiement initial. Le prospect a déjà autorisé le 3DS — pas besoin de re-saisir sa carte. C'est le moment d'achat maximum.

**Schéma concret (exemple produit à 37€) :**
1. Achat produit principal → pop-up upsell : version complète à tarif réduit
2. Si refus → downsell : produit complémentaire à 10€
3. Si refus → arrivée sur l'espace client

**Exit intent popup :** détecter la tentative de sortie de page → proposer -40% instantanément.

**Résultat :** le panier moyen réel peut atteindre 120€ sur un tunnel positionné à 37€.

**Règles de promotion :**
- Réduction de 30-50% (60% = trop, perd en crédibilité)
- Durée : < 200€ → 2-3 jours / 200-800€ → 3-5 jours / 800€+ → 5-10 jours
- Plus la promo est courte, plus elle est efficace

---

## ÉTAPE 8 — Automatisations avancées

- **Visite page de vente sans achat** → email personnalisé le lendemain ("On a vu que vous étiez sur la page, voici ce que vous ratez")
- **Inactivité 7 jours** → coupon à usage unique avec réduction supplémentaire
- **Achat produit d'entrée** → déclencher séquence upsell vers le produit supérieur
- **Exit intent popup** → -40% instantané si tentative de quitter la page

**Principe :** épuiser toutes les opportunités de conversion avant de "perdre" un prospect. Un prospect qui a laissé son email a montré de l'intérêt.

---

## ÉTAPE 9 — Métriques de rentabilité (benchmark)

**Ces chiffres varient fortement selon la niche, la plateforme et le marché. À calibrer avec tes données réelles après 500€+ de pub.**

Ordres de grandeur à titre indicatif (pub froide) :
- Coût par lead : entre 0,50€ et 5€ selon la niche
- Taux de conversion page de capture : 10-40%
- Taux d'achat sur les leads : 1-10%

**Si métriques pub OK (coût/lead dans ta fourchette cible) mais pas de ventes → problème dans le tunnel, pas dans la pub.**

---

## ÉTAPE 10 — Optimiser le tunnel

**Règle fondamentale :** Ne jamais tout changer en même temps. Isoler une variable à la fois pour comprendre ce qui fonctionne.

**Process d'optimisation :**
1. Identifier quelle étape convertit mal (pub → capture → vidéo → vente)
2. Changer une seule variable (titre, CTA, prix, garantie)
3. Mesurer pendant 7-14 jours
4. Garder si amélioration, rétablir sinon

**Action sous-estimée :** Appeler les prospects qui n'ont pas acheté pour comprendre pourquoi. C'est la source d'insights la plus puissante.



---

## Vision long terme : système d'offres

- 2 leviers de croissance : plus de clients **ET** faire payer plus cher
- 20% des clients font 80% du CA → concevoir une gamme pour maximiser la LTV
- Gamme progressive : produit d'entrée (7-37€) → mid (97-297€) → high (500-2000€)
- Un prospect qui a déjà payé est beaucoup plus facile à reconvertir
- Définir la gamme complète dès le départ pour éviter les plafonds de verre

---

## Checklist de lancement

- [ ] Prix du produit défini → structure du tunnel choisie
- [ ] Lead magnet format choisi selon le prix
- [ ] Exercice Avant/Après complété
- [ ] 19 questions marketing répondues
- [ ] Tunnel mappé visuellement (chaque page, chaque email)
- [ ] Séquence email J+0 à J+4 rédigée
- [ ] Upsells + downsells définis avec timing et prix
- [ ] Exit intent popup configurée (-40%)
- [ ] Automatisations avancées configurées
- [ ] Métriques de suivi définies (coût/lead, coût/achat, ROI)
