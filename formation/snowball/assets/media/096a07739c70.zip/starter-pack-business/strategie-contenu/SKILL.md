---
name: strategie-contenu
description: Construit une stratégie de contenu complète et un système de production. Utiliser quand "je veux créer une stratégie de contenu", "aide-moi à organiser ma création de contenu", "je veux publier régulièrement mais je ne sais pas par où commencer", "comment trouver des idées de contenu", "je veux un calendrier éditorial".
domaine: Acquisition
---

# Stratégie de contenu — De la ligne éditoriale au système de production

Flux complet : positionnement → backlog d'idées → calendrier → système de production → pratique délibérée.

---

## Démarrage

Poser cette question en premier et attendre la réponse :

> "Pour combien de canaux veux-tu construire ta stratégie de contenu ? (LinkedIn seul, LinkedIn + newsletter, multi-canal...)"

Traiter chaque canal séparément si besoin. Sinon, construire une stratégie unifiée. Attendre la réponse avant de continuer.

---

## 5 étapes

### Étape 1 — Définir le positionnement et la ligne éditoriale

Un bon positionnement = l'intersection entre **monopole personnel** (centres d'intérêt, vision du monde, façon de voir les choses) et **expertise métier** (le sujet pour lequel tu veux être reconnu).

Demander un par un, attendre la réponse à chacun :

> "1. Sur quoi veux-tu être reconnu dans 2 ans ? (domaine principal)"

> "2. Quels sont tes centres d'intérêt qui nourrissent ta réflexion ? (2-3 domaines connexes)"

> "3. Quel angle ou conviction te rend différent sur ce sujet ?"

**Structure de ligne éditoriale — 3 thématiques max :**

| Thématique | Description | Exemple |
|-----------|-------------|---------|
| **Expertise** | Ton domaine principal — ce pour quoi tu veux être connu | "Automatisation IA pour les PME" |
| **Centre d'intérêt** | Ce qui nourrit ta réflexion et enrichit ta marque | "Neurosciences et performance cognitive" |
| **Développement** | Philosophie, psychologie, growth — pour toucher plus large | "Entrepreneuriat intentionnel" |

✅ **Règle** : 3 thématiques maximum. L'audience doit pouvoir "te ranger" dans quelques sujets identifiables.

✅ **Bon positionnement** : "consultant IA pour DRH + intérêt pour les sciences cognitives + mindset entrepreneurial"
❌ **Mauvais positionnement** : "business, finance, sport, développement personnel, IA, voyages" → trop dispersé, pas identifiable

Valider la ligne éditoriale avant de continuer.

---

### Étape 2 — Créer le backlog d'idées (Brain Dump → 50+ sujets triés)

**Phase 1 — Brain Dump (5-10 min, zéro filtre)**

> "Pendant 5 minutes, liste tout ce dont tu pourrais parler : expériences vécues, convictions, questions de tes clients, choses qui t'énervent dans ton domaine, observations récentes. Zéro jugement."

Demander la liste brute, puis l'organiser.

**Phase 2 — Trier par niveau TOFU / MOFU / BOFU**

| Niveau | Objectif | Questions pour générer |
|--------|----------|----------------------|
| **TOFU** (Top of Funnel) | Toucher des inconnus, viralité | Qu'est-ce qui surprendrait quelqu'un qui ne me connaît pas ? |
| **MOFU** (Middle of Funnel) | Éduquer l'audience existante | Quelle méthode ou framework j'utilise et peu de gens connaissent ? |
| **BOFU** (Bottom of Funnel) | Convertir, fidéliser | Quelle preuve concrète ou résultat client je peux partager ? |

**10 sources d'idées infinies à exploiter :**
1. Page ouverte quotidienne (capture brute, sans filtre)
2. Notes de lecture (concepts qui résonnent)
3. Contradictions dans ta thématique
4. Questions récurrentes de tes clients
5. Ce qui t'énerve dans ton domaine
6. Application d'un concept à un nouveau contexte
7. Combinaison d'idées de 2 domaines différents
8. Observations de la vie quotidienne
9. Reformulation d'une idée connue avec ton angle
10. Réaction à l'actualité de ton domaine

Objectif minimum : 50 idées triées (au moins 20 TOFU, 20 MOFU, 10 BOFU) avant de passer à l'étape suivante.

Valider le backlog (ou une version partielle) avant de continuer.

---

### Étape 3 — Définir le calendrier éditorial et la fréquence

**Règle de base : choisir une fréquence tenable sur 6 mois, pas une fréquence "idéale".**

Demander :

> "Combien de temps par semaine peux-tu consacrer à la création de contenu ? (sois honnête sur ta contrainte réelle)"

**Fréquences recommandées par canal :**

| Canal | Minimum viable | Idéal | Objectif ambitieux |
|-------|---------------|-------|-------------------|
| LinkedIn / posts courts | 2/semaine | 3-5/semaine | 7/semaine |
| Newsletter / articles | 1/mois | 1/semaine | — |
| YouTube | 2/mois | 1/semaine | — |

**Structure du calendrier éditorial — thématiques par jour :**

Proposer un modèle de calendrier adapté au nombre de publications validé. Exemple pour 3 posts/semaine :
- Lundi → TOFU (observation, opinion forte, histoire)
- Mercredi → MOFU (concept, framework, méthode)
- Vendredi → BOFU ou MOFU (retour d'expérience, résultat client, invitation)

**Règle d'avance** : toujours avoir 1 semaine de contenu produit d'avance. Écrire semaine N pour publier semaine N+1. Évite le flux tendu.

Valider la fréquence et le calendrier avant de continuer.

---

### Étape 4 — Organiser le système de production (les légos)

La création de contenu doit être décomposée en étapes séparées — ne jamais tout faire en même temps.

**Le système en légos :**

```
Brain Dump → Backlog → Angles → Pré-écriture → V1 → Édition → Programmation
```

**Détail de chaque étape :**

1. **Brain Dump** : document toujours ouvert, 0 friction, capturer sans juger (idéalement dans l'app la plus accessible de ton téléphone)
2. **Backlog** : vue Kanban — Idée brute | Angle défini | V1 | Éditée | Programmée | Publiée. Trier le Brain Dump 1x/semaine.
3. **Angles** : préparer l'angle et le squelette (3-5 bullet points) avant d'écrire. 80% du travail est déjà fait à cette étape.
4. **Pré-écriture** : angle + 3-5 bullet points = le plan du post
5. **V1** : flux libre, zéro correction. La règle de Hemingway : séparer écriture et édition.
6. **Édition** : couper tout ce qui n'ajoute pas d'information. Maximum de valeur par mot.
7. **Programmation** : publier à l'avance, dissocier création et publication.

**Travail en batch** : écrire tous les posts d'un coup, éditer tous d'un coup. Réduit la charge cognitive et évite les changements de mode (création → analyse → création).

Demander :

> "Quel outil utilises-tu pour gérer ton backlog ? (Notion, Trello, autre) — ou as-tu besoin d'une recommandation ?"

**Journées types recommandées :**
- Lundi : angles + pré-écriture (mode réflexion)
- Mardi-Mercredi : V1 batch writing (mode production)
- Jeudi : édition + programmation (mode technique)

Valider le système avant de continuer.

---

### Étape 5 — Définir l'axe de pratique délibérée hebdomadaire

**Volume seul = croissance linéaire. Volume + pratique délibérée = croissance exponentielle.**

La pratique délibérée = choisir **un seul axe de progression** par semaine. Pas d'amélioration diffuse sur tout.

Demander :

> "Quel est ton point faible actuel dans la création de contenu ?
> 1. Les accroches (hooks) — personne ne s'arrête
> 2. La structure — le contenu manque de fil conducteur
> 3. La régularité — tu publies par rafales puis tu t'arrêtes
> 4. La génération d'idées — tu bloques souvent sur quoi écrire
> 5. L'édition — tes posts sont trop longs / trop vagues"

**Questions de pratique délibérée à se poser chaque semaine :**
- "Sur quoi je compte progresser cette semaine ?"
- "Qu'est-ce qui a fonctionné dans mes derniers posts ?"
- "Qu'est-ce que je peux arrêter ?"
- "Qui pourrait me donner du feedback sur mon défi actuel ?"

Recommander un axe de travail précis et une action concrète pour la semaine.

Valider l'axe de progression avant de clore.

---

## Rappels permanents

- **3 thématiques max** : l'audience aime pouvoir "te ranger" dans quelques sujets
- **Brain Dump quotidien** : document toujours ouvert, zéro friction — la capture régulière > les sessions forcées
- **Un post = une idée** : si l'idée en contient plusieurs, les séparer en posts distincts
- **Règle de Hemingway** : écriture et édition sont deux modes incompatibles — ne jamais les mélanger
- **1 semaine d'avance** : produire avant de publier, ne jamais être en flux tendu
- **Fréquence tenable sur 6 mois > fréquence idéale tenue 3 semaines**
- **Pratique délibérée** : 1 axe de progression par semaine, jamais tout à la fois
