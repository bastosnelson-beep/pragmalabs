---
name: ad-scripts
description: Écrit des scripts publicitaires vidéo en structure AIDA avec hooks interchangeables. Utiliser quand "écris des pubs pour [produit]", "scripts vidéo publicitaires", "je veux lancer une campagne pub", "génère des hooks pour mes ads".
domaine: Acquisition
---

# Écrire des scripts de pub vidéo

Génère des scripts publicitaires vidéo complets en structure AIDA, organisés en blocs thématiques avec hooks interchangeables.

## Arguments

- `$ARGUMENTS` : Le produit/projet pour lequel écrire les pubs + contexte optionnel

---

## ÉTAPE 1 — Charger le contexte

### Trouver tout le contenu disponible

Chercher dans les documents disponibles TOUT ce qui concerne le produit mentionné :
- **Bases marketing** : persona, AVANT/APRÈS, problème, cible, objections, ton
- **Pages de vente** : arguments, structure, pricing, témoignages
- **Emails de vente** : séquences, angles, objections traitées
- **Pubs existantes** : scripts déjà écrits, résultats si disponibles
- **Contenu produit** : ce qu'on enseigne, les modules, les livrables
- **Post-mortems** : ce qui a marché, ce qui n'a pas marché, objections récurrentes
- **Guides de pub** : style d'écriture, anti-patterns, exemples validés

Charger les documents marketing disponibles pour le produit concerné et le contexte de la boîte.

### Construire l'arsenal de faits

Extraire et lister :
- **Chiffres clés** : nombre de participants, résultats concrets, prix, durée
- **Preuves sociales** : témoignages, cas d'usage, situations réelles
- **Analogies puissantes** : métaphores et reframings qui marchent
- **Objections principales** : les 3-5 freins à l'achat les plus fréquents
- **Use cases concrets** : démos, résultats avant/après, situations précises

---

## ÉTAPE 2 — Questions de clarification

**AVANT d'écrire quoi que ce soit, poser ces questions :**

1. **Quel est le CTA ?** (inscription webinaire gratuit, page de vente, waiting list, lead magnet, etc.)
2. **Qui filme ?** (face cam, screencast démo, UGC participant, avatar IA)
3. **Combien de scripts ?** (batch de 15, 20, 30 ?)
4. **Y a-t-il des angles obligatoires ?** (ex: "je veux au moins 10 démos screencast")
5. **Y a-t-il des anti-patterns ?** (ex: "pas de ton trop agressif", "pas de phrases courtes vides")
6. **Contexte supplémentaire ?** (ex: chiffres de preuve sociale disponibles, dates importantes)

**Demander aussi un brain dump libre :** "Dis-moi tout ce qui te vient en tête sur cette campagne — angles, idées, frustrations, ce que tu veux transmettre."

**→ ATTENDRE LES RÉPONSES AVANT DE CONTINUER**

---

## ÉTAPE 3 — Proposer les blocs thématiques

Proposer une architecture de campagne en **blocs thématiques**. Chaque bloc = un angle/émotion principal avec plusieurs hooks interchangeables et un corps IDA (Intérêt-Désir-Action) partagé.

### Types de blocs à considérer :

| Type | Objectif | Émotion cible |
|------|----------|---------------|
| **Douleur** | Nommer la situation de la cible, créer l'identification | Frustration, lassitude, agacement |
| **Reframing** | Changer le cadre mental, montrer le vrai problème | Surprise, prise de conscience, clarté |
| **Démonstration** | Show don't tell — montrer le résultat en direct | Envie, fascination |
| **Preuve sociale** | Montrer que d'autres l'ont fait | FOMO, projection, confiance |
| **Objection killer** | Détruire les freins à l'action | Soulagement, surprise |
| **Autorité / histoire** | Positionnement, crédibilité, parcours | Respect, curiosité |
| **Contrarian** | Position provocante, contre-intuitive | Provocation, curiosité |

### Format de proposition :

Pour chaque bloc, proposer :
- **Nom du bloc** + type + émotion
- **3-6 hooks** (les 1-2 premières phrases qui arrêtent le scroll)
- **1 ligne résumant le corps IDA**

**Les démos sont un cas particulier** : chaque démo est un script autonome (le hook EST la démo). Les lister séparément avec le use case précis.

**→ PRÉSENTER LES BLOCS ET ATTENDRE LA VALIDATION AVANT DE RÉDIGER**

L'utilisateur peut :
- Valider tout
- Virer des blocs
- Demander plus de hooks sur un bloc
- Réorienter un angle
- Ajouter des blocs manquants

---

## ÉTAPE 4 — Rédiger les scripts complets

Après validation des blocs, rédiger les scripts complets.

### Structure par bloc (hooks interchangeables)

```markdown
## BLOC [X] — "[Nom]" ([Type])

### Hooks ([N] variantes)

**[X1].** "[Hook complet — 1-3 phrases]"

**[X2].** "[Hook complet — 1-3 phrases]"

[...]

### [I] Intérêt (3-12s)

[Texte narratif complet — développement du problème, empathie, identification. Des VRAIES phrases longues, pas des bullet points.]

### [D] Désir (12-25s)

[Texte narratif complet — la solution, la preuve, le résultat concret. Chiffres, détails, visualisation.]

### [A] Action (25-30s)

[CTA clair — dire à quoi on s'inscrit et où.]
```

### Structure par démo (script autonome)

```markdown
### DÉMO [N] — [Use case]

**[A] Hook (0-3s) :**
"[Phrase d'accroche liée au résultat qu'on va montrer]"

**[I] Intérêt (3-12s) :**
*(Écran visible)* [Contexte : comment c'était avant, pourquoi c'est pénible]

**[D] Désir (12-25s) :**
*(Démo en direct)* [Description de ce qu'on voit à l'écran + commentaire voix off]

**[A] Action (25-30s) :**
[CTA vers le webinaire/offre]
```

### Règles d'écriture (NON NÉGOCIABLES)

1. **Des VRAIES phrases longues, narratives.** On raconte, on n'écrit pas un brief. Si une phrase fait 5 mots, elle est probablement trop courte.

2. **Du concret, jamais du vide.** Chaque phrase contient une information, un détail, une émotion, un chiffre. Si tu enlèves la phrase et que rien ne manque, elle ne sert à rien.

3. **80% empathie et histoire, 20% CTA.** La connexion émotionnelle d'abord, le pitch à la fin.

4. **Ton ami autour d'un feu de camp.** Direct, brut, honnête. Humour autodérisionnaire bienvenu. Pas de ton de coach, pas de ton de vendeur.

5. **Zéro jargon marketing.** Pas de "découvrez notre méthode exclusive", pas de "transformez votre vie", pas de "opportunité unique". Parler comme un être humain.

6. **Spécificité maximale.** Si tu peux mettre la phrase dans n'importe quelle pub d'un autre projet et que ça marche toujours, c'est que la phrase est trop générique. Chaque phrase doit être spécifiquement liée au produit.

7. **Le CTA doit arriver avant 30 secondes.** On peut continuer après, mais le premier appel à l'action doit tomber dans les 30 premières secondes.

8. **Test final :** Relis le script à voix haute. Si ça sonne comme un post LinkedIn ou une page de vente, recommence. Ça doit sonner comme quelqu'un qui parle face caméra avec sincérité.

### Anti-patterns (CE QU'ON NE FAIT JAMAIS)

- Phrases courtes vides : "On a créé un système. C'est puissant. Rejoins-nous." → INTERDIT
- Le vague : "On a aidé des gens à transformer leur façon de travailler" → QUELS gens ? COMBIEN ? COMMENT ?
- Le mode liste : Transformer le script en bullet points → C'est un récit
- Le pitch prématuré : Parler du produit avant d'avoir connecté émotionnellement
- Les phrases génériques interchangeables
- Les superlatifs creux : "incroyable", "révolutionnaire", "game-changer"

---

## ÉTAPE 5 — Sauvegarder

Sauvegarder le résultat dans le dossier marketing du produit concerné ou à l'emplacement indiqué par l'utilisateur.

**Format du fichier :**

```markdown
# Publicités [Produit] — [Mois Année]

> [Description courte : CTA, contexte, nombre de scripts]

**Total : [N] combinaisons possibles**
- [Résumé par bloc]

---

[Contenu des blocs et démos]
```

**→ Confirmer le chemin de sauvegarde avec l'utilisateur avant d'écrire le fichier.**
