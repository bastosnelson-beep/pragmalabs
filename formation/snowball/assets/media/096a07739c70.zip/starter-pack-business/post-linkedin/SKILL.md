---
name: linkedin-post
description: Creer un ou plusieurs posts LinkedIn de A a Z — angles, hooks, redaction, reecriture. Utiliser quand "je veux ecrire un post LinkedIn", "ecris-moi un post sur X", "transforme cette idee en post LinkedIn".
---

# LinkedIn -- Redaction de posts

Flux complet : configuration auteur -> idee -> angle (ToFu/MoFu/BoFu) -> hook -> redaction -> edition -> livraison.

---

## PHASE 0 -- Configuration

### 0.1 -- Pour qui ecrit-on ?

Demande : **"Pour qui est ce post ?"**

Si une strategie de contenu existe, la consulter dans Outline (MCP) pour charger la ligne editoriale de l'auteur choisi. Extraire : archetype, role, ton, sujets, formats, test avant publication.

Presenter un resume operationnel :
```
Auteur : [nom]
Archetype : [ex: Le Penseur-Operateur]
Positionnement : [1 phrase]
Ton : [description]
Formats LinkedIn : [liste des formats specifiques]
Test avant publication : [la question-test de l'auteur]
```

Confirmer avant de continuer.

### 0.2 -- D'ou part-on ?

Demande : **"D'ou part-on ?"**
- **A.** J'ai une idee (ou un brain dump)
- **B.** J'ai un contenu existant + un angle en tete
- **C.** J'ai un contenu existant mais pas d'angle
- **D.** Je veux faire un braindump guide pour trouver une idee

**Si option D -- braindump guide :** poser ces questions une par une :
- "Quelle est ta thematique principale ?"
- "Qu'est-ce qui t'a marque cette semaine dans ton travail ou ta vie ?"
- "Quelle croyance de ton secteur t'enerve ou te semble fausse ?"
- "Quelle question revient souvent de tes clients ou de ton audience ?"
- "Quel insight as-tu eu recemment que tu n'as encore dit a personne ?"

Selectionner la reponse avec le plus fort potentiel et proposer le sujet.

---

## PHASE 1 -- Angles

### Branche A -- Partir d'une idee

Demande l'idee brute + le contexte. Generer **10 angles** en combinant :

**Machine 1 -- 30 Proven Approaches (Cole)**
Tips, Mistakes, Lessons, Steps, Frameworks, Stories, Habits, Questions, Secrets, Insights, Benefits, Reasons, Examples, Challenges, Routines, Tools, Skills, Traits, Goals, Books, Quotes, Creators, Podcasts, Inventions, Templates, Resources, Companies, Data Points, Realizations, Presentations.

**Machine 2 -- Content Roadmap (Cole)**
Croiser avec 3 dimensions :
- Forme : Actionable Guide / Opinion / Curated List / Story / Credibility
- Idee : Explication / Habitudes / Erreurs / Lecons / Tips / Stories / Evenement actuel
- Pourquoi moi : Expert / J'ai cure les experts / Mon opinion est la plus articulee

Presenter chaque angle :
```
Angle 1 : [Titre de travail]
- Approach : [ex: Mistakes]
- Forme : [ex: Opinion]
- Tension : [ce que le lecteur croit vs la realite]
```

-> **Demande : "Quel(s) angle(s) tu choisis ?"**

### Branche B/C -- Contenu existant

Lire/analyser le contenu source. Extraire les idees avec Notecard Stacks (Cole) : trier en piles (erreurs, lecons, tips, frameworks, opinions, histoires). Generer 10 angles.

---

## PHASE 1.5 -- Classification ToFu / MoFu / BoFu

| Niveau | Objectif | Formats adaptes |
|--------|----------|-----------------|
| **ToFu** | Toucher des inconnus, viralite | Opinion forte, stat choc, histoire, coup de gueule, portrait |
| **MoFu** | Eduquer l'audience existante | Concept nomme, framework, analyse, insight profond |
| **BoFu** | Convertir, fideliser | Conseil specifique, coulisses, invitation, retour d'experience intime |

Proposer l'angle et le niveau. Justifier en une phrase.

**Score de validation rapide (6 criteres) :**
1. Skin in the game -- experience directe sur le sujet ?
2. Chiffre specifique -- un nombre concret possible ?
3. Tension -- paradoxe, contrarian, croyance a casser ?
4. Durabilite -- pertinent dans 2 ans ?
5. Narration possible -- peut-on raconter une histoire ?
6. Cree de la curiosite ou du FOMO ?

Score minimum conseille : 4/6. Si en dessous, proposer un angle alternatif.

---

## PHASE 2 -- Hooks (accroches)

Generer **15-20 hooks** depuis 3 sources distinctes.

### Source 1 -- Hooks originaux (5 hooks)

Regles : resumer le point du post en 10 mots ou moins. Resoudre 3 questions vite : C'est sur quoi ? C'est pour moi ? Quelle promesse ? Toujours ouvrir avec UNE seule phrase. Creer un curiosity gap.

### Source 2 -- 11 formats Cole/PGA (5-10 hooks)

| # | Format | Principe |
|---|--------|----------|
| 1 | Most Powerful | Declaration forte + parenthese credibilite |
| 2 | Big Number vs Small Number | Contraste resultat massif / investissement minimal |
| 3 | The Call Out | Interpelle l'audience + nombre actionable |
| 4 | The Secret | Preuve impressionnante + "Le secret ?" |
| 5 | The Oddly Ignored | Contrarian + FOMO |
| 6 | The Struggle | Avant/apres + transformation avec preuve |
| 7 | How To | Peur/benefice + solution dans un delai |
| 8 | Belief Flip | Croyance limitante -> preuve contradictoire |
| 9 | The List | Liste a puces qui se coupe au "See More" |
| 10 | The Crazy Part | Credibilite + "The crazy part?" |
| 11 | Everyone Should | Empowerment universel + FOMO |

### Source 3 -- 9 templates Maud Alaves (5 hooks)

| # | Template | Structure |
|---|----------|-----------|
| 1 | Lecon | "J'ai fait Y. X lecons apprises :" |
| 2 | Contrarian | "Fait X. Pourtant Y." |
| 3 | De A a B sans C | "[Situation negative]. Aujourd'hui, [denouement positif]." |
| 4 | Methode | "J'ai reussi a [benefice]. Sans [probleme]. Grace a Z :" |
| 5 | Analyse | "[Avant]. [Apres]. Ce qui a change :" |
| 6 | Contre-Courant | "Tout le monde fait X. Pourtant, je fais Y." |
| 7 | Decryptage | "[Fait d'actualite]. Ce que cela veut dire :" |
| 8 | Demonstration | "J'ai fait [preuve]. Je remarque [probleme]." |
| 9 | Liste inachevee | Annoncer une liste sans la terminer |

-> **Demande : "Quel hook tu choisis ?"**

---

## PHASE 3 -- Plan (Skeleton First)

Choisir la structure :

**Structure A -- Liste a puces** : Accroche + 3-5 bullet points, valeur croissante + observation finale

**Structure B -- Storytelling -> Lecon** : Accroche + anecdote concrete (70% du post) + pivot + lecon finale

**Structure C -- Observation -> Analyse -> Action** : Accroche + vecu + pourquoi c'est important + ce que ca implique

**Structure D -- Contrarian** : Accroche (croyance dominante) + preuve inverse + nouveau cadre + tagline

**Structure E -- Insight pur** : Accroche qui cree la curiosite sans nommer le concept + concept explique simplement + pourquoi ca change quelque chose + observation finale

-> **Demande : "Ce plan te convient ?"**

---

## PHASE 4 -- Premiere redaction (V1)

**Regles de redaction :**
- Rate of Revelation : chaque phrase apporte une info NOUVELLE
- Rythme 1/3/1 par section
- Langage confiant (pas de "je pense que", "peut-etre")
- Specificite (chiffres, dates, situations precises)
- Credibilite ("For Context" pour les humble brags)
- Self-promotion (Golden Intersection) : le lecteur est le personnage principal
- Variation de longueur (Gary Provost)
- Alternance format (Cole PGA) : sections impaires = listes, paires = paragraphe

**Limite : 2000-2800 caracteres.**

-> **Demande : "Qu'est-ce que tu en penses ?"**

---

## PHASE 5 -- Reecriture (V2)

### 5.1 -- Couper
Chaque phrase apporte une info nouvelle ? Eliminer les petits mots inutiles.

### 5.2 -- Rythme
Variation courte/longue verifiee. Phrase isolee avant ET apres un long paragraphe.

### 5.3 -- Formatting LinkedIn
Paragraphes 1-2 phrases. Tirets `-`. Fleches `->`. 0 emoji.

### 5.4 -- Check POP (Perell)
Personal / Observational / Playful / Shiny Dime.

### 5.5 -- Check anti-IA (23 regles)
- Pas de "tout le monde" / "les gens"
- Pas de question rhetorique ("Resultat ?")
- Pas de "C'est ca, le vrai X"
- Pas de prediction menacante
- Pas de rythme ternaire monomot
- Pas de rythme ternaire anaphore
- Pas de comparaisons tarabiscotees
- Pas de "Imaginez un monde ou..."
- Contraste "Ce n'est pas X. C'est Y." : max 1 fois
- Pas d'emojis, pas de gras, pas de hashtags
- Pas de hype ("game-changer", "revolutionnaire")
- Pas de mots faibles ("peut-etre", "il semble que")

### 5.6 -- Test lecture a voix haute

### 5.7 -- Test final (selon l'auteur)

---

## CE QU'ON NE FAIT JAMAIS

- Emojis (0, jamais)
- Unicode bold/italic
- Tirets cadratins
- Mots en MAJUSCULES
- "Et vous, qu'en pensez-vous ?"
- Pitcher un produit dans le corps du post
- Phrases sans sujet ni verbe conjugue comme accroche
- Listes de 10+ tips generiques
- Hashtags (sauf demande explicite)
- Title Case

---

## TRACABILITE

A la fin, generer une fiche :

```
**Auteur :** [nom]
**Date :** [date]
**Angle :** [angle choisi]
**Hook :** [source + format]
**Niveau :** [ToFu / MoFu / BoFu]
**Style :** [Steps / Stats / Mistakes / Lessons / Examples / Libre]
**Caracteres :** [nombre]
```
