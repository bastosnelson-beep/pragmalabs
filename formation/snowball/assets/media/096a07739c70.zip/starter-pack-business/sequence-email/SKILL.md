---
name: sequence-email-lancement
description: Crée une séquence email de lancement complète. Utiliser quand "prépare la séquence pour le lancement", "on lance [produit]", "écris les emails de vente", "séquence pré-lancement", "emails de nurturing avant ouverture".
domaine: Acquisition
---

# Séquence email de lancement

Skill dialogique — chaque étape demande une validation avant de passer à la suivante.

---

## Étape 1 — Cadrer la séquence

Si les informations sont partiellement fournies, poser les questions manquantes en une seule fois :

> "Pour construire la séquence, j'ai besoin de :
> 1. Le produit ou l'offre à lancer (nom + description en 1-2 phrases)
> 2. L'audience cible (froide, tiède, chaude — et ce qu'elle sait déjà du sujet)
> 3. Les dates clés : ouverture des inscriptions, fermeture, deadline
> 4. L'objectif de la séquence — éduquer d'abord, convertir directement, ou nurturing B2B ?"

Attendre la réponse avant de continuer.

---

## Étape 2 — Proposer l'arc narratif

Présenter les 3 options génériques. Recommander celle qui correspond au contexte cadré. Demander confirmation avant de continuer.

**Arc vente (audience chaude — 6 emails)**
Utiliser quand l'audience connaît déjà le problème et est prête à acheter.

| # | Rôle | Angle |
|---|------|-------|
| 1 | Problème | Le problème formulé avec les mots de l'audience |
| 2 | Insight | Le concept clé qui change la donne |
| 3 | Méthode | Comment ça marche concrètement (3 étapes) |
| 4 | Preuve | Résultats, témoignages, cas concrets |
| 5 | Vision | Ce que ça change dans 6 mois / 1 an |
| 6 | Décision | Dernière chance, deadline explicite, les 2 chemins |

**Arc éducation (audience froide ou pré-lancement — 7 emails)**
Utiliser pour éduquer une audience avant d'ouvrir les inscriptions.

| # | Rôle | Angle |
|---|------|-------|
| 1 | Problème invisible | Le problème que personne ne voit |
| 2 | Insight | Ce que font les meilleurs |
| 3 | Méthode étape 1 | Premier pilier de la méthode |
| 4 | Méthode étape 2 | Deuxième pilier de la méthode |
| 5 | Méthode étape 3 | Troisième pilier de la méthode |
| 6 | Résultats | Preuves concrètes — témoignages, cas réels |
| 7 | Invitation | Transition naturelle vers la vente |

**Arc B2B / nurturing dirigeants (6 emails)**
Utiliser pour des séquences vers des décideurs ou prospects professionnels.

| # | Rôle | Angle |
|---|------|-------|
| 1 | Coût réel | Le coût de ne rien faire |
| 2 | Erreur commune | Ce que la plupart ratent |
| 3 | Méthode | L'approche qui change tout |
| 4 | Cas client | La preuve concrète — résultats chiffrés |
| 5 | Vision | Ce que ça débloque à long terme |
| 6 | Proposition | L'invitation à agir — CTA direct |

Demander : "Quel arc correspond à votre situation ? Je peux adapter la structure si nécessaire."

---

## Étape 3 — Définir la progression de chaleur

Une fois l'arc validé, présenter la progression de chaleur et confirmer qu'elle convient :

**Règle fondamentale :** les premiers emails éduquent et créent la confiance. Les derniers convertissent avec urgence. Ne jamais inverser.

| Phase | Emails | Longueur | Ton |
|-------|--------|----------|-----|
| Éducation / contexte | 1-3 | 800-1200 mots | Patient, pédagogue, généreux |
| Transition / preuve | 4-5 | 600-800 mots | Concret, factuel, testimonial |
| Urgence / décision | 6-7 | 300-500 mots | Direct, bref, sans ornement |

Demander : "Cette progression vous semble juste ? Des ajustements sur les longueurs ou le calendrier ?"

---

## Étape 4 — Rédiger email par email

Rédiger un email à la fois. Présenter pour chaque email :

**A. 2-3 options d'objet + preview text**
- ≤ 42 caractères (mobile-first)
- Sentence case ou minuscules — jamais Title Case
- Curiosity gap sans clickbait
- Varier les approches entre les emails : déclaratif / question / chiffre / contraste / teaser
- Le preview text ne répète pas l'objet — il ajoute du contexte

**B. Le corps de l'email**

Structure standard :
1. Accroche (in media res — jamais "Bonjour" ou "J'espère que vous allez bien")
2. Corps principal selon l'angle de l'email
3. CTA unique — un seul lien, une seule action demandée

Règles non négociables pour chaque email :
- Un email = un angle = un CTA
- Ton cohérent avec le ton établi (ne jamais mélanger)
- Longueur proportionnelle à la phase
- Pas plusieurs CTAs dans un email

Formatage interdit dans tous les emails :
- Gras, emojis, tirets cadratins
- Title Case
- Questions rhétoriques comme transitions ("Résultat ?", "Le plus fascinant ?")
- "Et vous, qu'en pensez-vous ?" comme conclusion
- Rythme ternaire monomot, anaphore
- Mots faibles : "peut-être", "il semble que", "on pourrait"

Après chaque email : "Cet email vous convient ? On ajuste avant de passer au suivant."

---

## Étape 5 — Vérification de cohérence globale

Une fois tous les emails rédigés et validés, passer la séquence complète en revue :

**Checklist séquence :**
- [ ] Chaque email a un angle différent (pas de répétition de sujet ni de structure)
- [ ] La progression de chaleur est respectée (long/éducation → court/urgence)
- [ ] Un seul CTA par email
- [ ] Tous les objets sont ≤ 42 caractères (mobile-first)
- [ ] Ton cohérent avec le ton établi dans toute la séquence
- [ ] L'arc narratif est cohérent du début à la fin
- [ ] Le dernier email inclut la deadline explicite
- [ ] Aucun email ne commence par "Bonjour" ou "J'espère que vous allez bien"
- [ ] Check anti-IA passé sur chaque email (23 règles — voir skill `newsletter`)

**Règles anti-IA critiques (appliquer à chaque email) :**
- Pas d'emojis (0, jamais)
- Pas de gras
- Pas de "Et vous, qu'en pensez-vous ?" comme conclusion
- Pas de questions rhétoriques ("Résultat ?", "Le plus fascinant ?")
- Pas de rythme ternaire ("Analyser, comprendre, agir.")
- Pas de hype : "game-changer", "révolutionnaire", "disruptif"

Livrer : séquence dans l'ordre chronologique, avec une ligne de séparation entre chaque email. Indiquer pour chaque email : numéro, rôle dans l'arc, objet retenu, longueur en mots.
