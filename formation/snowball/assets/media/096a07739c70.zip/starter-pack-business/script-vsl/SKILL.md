---
name: script-webinaire-vsl
description: Écrit le script d'un webinaire ou d'une vidéo de vente (VSL). Utiliser quand "je veux créer un webinaire", "aide-moi à structurer ma VSL", "rédige mon script de présentation de vente", "je veux faire un webinaire de lancement".
domaine: Vente
---

# SKILL — Script Webinaire / VSL

## Ce que ce skill fait

Ce skill guide la création complète d'un script de webinaire ou de VSL (Video Sales Letter), de la définition du Big Domino jusqu'à la structure du tunnel de diffusion.

---

## ÉTAPE 0 — Clarifier le format

Avant tout, poser cette question :

> **"C'est pour un webinaire en direct ou une VSL automatisée ?"**

| Format | Caractéristiques | Quand l'utiliser |
|---|---|---|
| **Webinaire** | En direct, interaction audience, Q&R à la fin | Lancement, haute conversion, logistique |
| **VSL** | Préenregistré, tourne en automatique 24h/24 | Tunnel evergreen, scalabilité |

**Règle :** Les deux utilisent la **même structure** (psycho-structure en 5 histoires). La différence est stratégique, pas structurelle. Une fois le webinaire rodé, le transformer en VSL pour l'automatiser.

---

## ÉTAPE 1 — Définir le Big Domino

C'est la priorité absolue. **Ne pas écrire une seule ligne de script avant d'avoir ce Big Domino.**

Poser ces questions :

1. Quelle est votre méthode / votre véhicule unique ? (pas "le sport" → "la méthode X en 3 phases")
2. Quel est le résultat le plus désiré par votre cible ?
3. Pourquoi votre solution est-elle la SEULE façon d'atteindre ce résultat ?

**Formule à compléter :**
> "Si j'arrive à faire croire que [mon véhicule unique] est la clé pour [résultat le plus désiré] ET que la seule façon de l'appliquer est par [ma solution], alors toutes les autres objections deviennent impertinentes et ils achètent."

**Règle d'or :** Chaque phrase, chaque exemple, chaque slide doit faire avancer vers ce Big Domino. Si une section n'y contribue pas → la supprimer.

---

## ÉTAPE 2 — Cartographie psychologique (avant d'écrire)

Remplir ces 5 éléments sur le prospect cible :

1. **Situation actuelle** : frustrations, habitudes, problèmes concrets au quotidien
2. **Situation désirée** : objectif concret et mesurable (pas "être heureux")
3. **Croyance véhicule** : pourquoi pense-t-il que votre méthode ne marcherait pas ?
4. **Croyance interne** : pourquoi pense-t-il ne pas pouvoir y arriver personnellement ?
5. **Croyance externe** : qu'est-ce qui dans son environnement l'en empêche ?

Ces 5 éléments correspondent exactement aux 5 histoires de la psycho-structure.

**Valider les 4 éléments collectés avant de passer aux 5 histoires.**

---

## ÉTAPE 3 — La psycho-structure en 5 histoires

Le prospect doit croire que : son effort produira un résultat / ce résultat est atteignable / ce résultat est désirable.

---

### Histoire 1 — Histoire d'origine

**Objectif :** Transmettre ta crédibilité sur ce sujet.

> "Raconte-moi l'histoire de comment tu as découvert ou développé cette méthode. La structure à suivre : situation avant → désir → mur rencontré → épiphanie → résultat obtenu."

Attendre l'histoire. Puis aider à la structurer selon l'arc.

**Structure obligatoire :**
- **Avant** : situation initiale (douleur, impasse)
- **Désir** : ce que vous vouliez vraiment atteindre
- **Mur** : ce qui bloquait, l'échec ou la frustration
- **Épiphanie** : la découverte qui a tout changé
- **Résultat** : où vous en êtes aujourd'hui

**Règle :** Transmettre l'ÉMOTION de la découverte, pas les faits techniques. L'émotion crée le désir pour le framework.

---

### Histoire 2 — L'histoire du véhicule

**Objectif :** Lever l'objection *"Cette méthode marche-t-elle encore aujourd'hui ?"*

> "Raconte-moi comment tu as découvert ce framework ou cette méthode spécifique — pas la méthode en général, mais CE mécanisme précis. Structure : comment tu l'as trouvé → les étapes concrètes → un exemple où ça a marché."

Attendre l'histoire. Puis aider à la structurer selon l'arc.

**Structure pour chaque framework présenté :**
1. **Micro-histoire d'origine** : comment vous avez découvert CE framework spécifique
2. **Framework** : les étapes concrètes (étape 1, étape 2, étape 3)
3. **Exemples** : preuves que ça fonctionne (votre cas + cas d'autres personnes)

**Règle capitale :** Enseigner les **"quoi"** (frameworks, principes) — jamais les **"comment"** (méthodes détaillées, étapes précises). Le "comment" est dans le produit payant.

---

### Histoire 3 — L'histoire interne

**Objectif :** Lever l'objection *"Moi, je ne peux pas y arriver parce que [croyance limitante]"*

> "Quelle est la croyance limitante principale que ta cible a sur elle-même ? (identifiée en Étape 2, point 4) Raconte-moi une histoire — la tienne ou celle d'un client — qui prouve que même avec cette croyance, c'est possible. Structure : situation avec la croyance → obstacle rencontré → ce qui a changé → résultat."

Attendre l'histoire. Puis aider à la structurer selon l'arc.

Même structure : micro-histoire d'origine du framework → étapes → exemples qui prouvent que même avec cette croyance, c'est possible.

---

### Histoire 4 — L'histoire externe

**Objectif :** Lever l'objection *"Mon contexte ne permet pas ça (famille, économie, pas le temps…)"*

> "Quel est l'obstacle environnemental principal de ta cible ? (identifié en Étape 2, point 5) Raconte-moi une histoire d'une personne dans cette même contrainte qui y est quand même arrivée. Structure : l'obstacle concret → ce qui semblait bloquant → le pivot ou le framework → le résultat malgré la contrainte."

Attendre l'histoire. Puis aider à la structurer selon l'arc.

Même structure : framework qui neutralise l'obstacle + exemples de personnes dans la même situation qui y sont arrivées.

---

### Histoire 5 — L'histoire de la solution

**Objectif :** Présenter l'offre avec le stack de valeur.

> "C'est ici qu'on présente l'offre. Décris-moi chaque composant de ce que tu vends — module par module, bonus par bonus. Pour chaque élément : ce que c'est + le bénéfice concret que ça apporte."

Attendre la liste. Puis aider à construire le stack de valeur avec bénéfices et prix perçus.

**Règle absolue :** C'est UNIQUEMENT ici qu'on vend. Pas avant. Les 4 histoires précédentes détruisent toutes les résistances — l'histoire 5 n'a plus qu'à présenter l'offre à quelqu'un qui est prêt.

**Structure du stack de valeur :**
- Présenter chaque composant avec son bénéfice (formule : [composant] **pour** [bénéfice concret])
- Donner une valeur perçue à chaque élément
- Annoncer le prix global du stack, puis le vrai prix
- Garantie
- Urgence avec timer (sans urgence : pas de décision)

---

## ÉTAPE 4 — Timing du webinaire (2h)

| Section | Durée | Objectif |
|---|---|---|
| Introduction + promesse | 5-10 min | Capter l'attention, annoncer la promesse |
| Histoire d'origine | 15 min | Crédibilité + désir pour la méthode |
| Histoire du véhicule | 15 min | Casser "ça ne marche pas pour moi" |
| Histoire interne | 15 min | Casser la croyance limitante interne |
| Histoire externe | 15 min | Casser les obstacles environnementaux |
| Histoire de la solution | 30 min | Présenter l'offre + stack de valeur |
| Q&R | 30 min | Casser les dernières objections |

Pour un webinaire court (15-45 min) : réduire proportionnellement chaque section.

---

## ÉTAPE 5 — Structure du PowerPoint / slides VSL

1. Slide de promesse (headline)
2. Slides histoire d'origine (bullet points + visuels)
3. Slides frameworks (schémas simples)
4. Slides exemples + témoignages
5. Slides présentation de l'offre (stack de valeur détaillé)
6. Slide pricing (triptyque)
7. Slide garantie + Q&R

**Conseils de production :**
- Filmer l'écran + voix (pas besoin d'être face caméra)
- Parler lentement, articuler
- Durée typique : 30-60 min pour un mid-ticket, 60-90 min pour un high-ticket

---

## ÉTAPE 6 — Le tunnel webinaire complet

```
Publicité
    ↓
Page d'inscription (date/heure)
    ↓
Page de confirmation + infos pratiques
    ↓
[Séquence 4 emails avant le webinaire]
    ↓
WEBINAIRE EN DIRECT
    ↓
[Séquence emails après]
```

### Séquence emails avant (J-5 → J0)
- **J-5** : confirmation d'inscription + ce que vous allez apprendre
- **J-3** : "pourquoi j'ai créé ce webinaire" (histoire d'origine courte) + excitation
- **J-1** : rappel pratique — heure, lien, ce qu'on va apprendre
- **J0 (2h avant)** : "On se retrouve dans 2h" + lien direct

### Séquence emails après
- **J+0 (soir) — participants** : résumé de l'offre + lien paiement
- **J+0 (soir) — absents** : lien replay + offre
- **J+1** : urgence + rareté → "il reste X places / la promo expire demain"
- **J+2 (si pas acheté)** : dernière chance

Si vous ne pouvez pas distinguer participants vs absents → envoyer résumé offre + replay en même temps à toute la liste.

**Pour la séquence email complète**, utiliser le skill `sequence-email-lancement` — cette étape donne uniquement le squelette arc.

---

## Checklist finale avant de filmer

- [ ] Big Domino défini en une phrase
- [ ] Les 5 croyances à casser identifiées
- [ ] Les 5 histoires rédigées (émotion + framework + exemples)
- [ ] Stack de valeur complet avec bénéfices + prix perçus
- [ ] Urgence intégrée (timer, places limitées, promo à durée fixe)
- [ ] Séquence emails avant + après prête
- [ ] Slides créées dans l'ordre de la structure
