---
name: offre-minimum-viable
description: Guide la création et le lancement d'une offre minimum viable sans infrastructure. Utiliser quand "je veux lancer rapidement", "comment tester mon offre sans site", "je veux mes premiers clients en 30 jours", "aide-moi à créer une première offre".
domaine: Vente
---

# Skill : Offre Minimum Viable

## Principe directeur

Ce skill est dialogique. Chaque étape pose une question, attend la réponse, valide avant d'avancer.

Une offre minimum viable (MVE) est la version minimale d'une offre qui apporte la transformation souhaitée au client, testable en 3 à 7 jours — pas en 3 mois. Elle se présente souvent sous la forme d'un nombre défini de sessions qui font passer le client d'un problème précis (point A) à une situation désirée (point B).

**Objectif de ce skill :** premiers clients dans les 30 jours, sans site web, sans tunnel, sans audience.

---

## Étape 1 — Partir du problème marché, pas de la méthode

**Demander :** "Quel est le problème urgent et douloureux que tu veux aider à résoudre ? Décris-le tel que ta cible le vivrait."

**Règle :** Ne jamais partir de sa méthode ou de son expertise pour construire la MVE. Partir du problème marché.

**Les problèmes ne se valent pas. Chercher les "problèmes de niveau 3" :**
- **Niveau 1** : inconfort léger ("ce serait bien d'améliorer ça")
- **Niveau 2** : gêne régulière ("ça m'embête souvent")
- **Niveau 3** : coût d'inaction fort — financier, émotionnel ou identitaire ("si je ne règle pas ça, ça me coûte X€/an ou ça détruit X dans ma vie")

> **Bon exemple de niveau 3 :** "Je perds 3 clients par mois parce que mon onboarding est chaotique — ça représente 15 000€/an qui partent."
> **Mauvais exemple :** "J'aimerais être plus organisé." (niveau 1, pas assez douloureux pour un achat premium)

**Signal d'alerte :** Si la cible ne ressent pas le coût d'inaction, le problème n'est pas assez douloureux. Le calculer ensemble pendant les entretiens de vente.

**Valider le problème avant de continuer.**

---

## Étape 2 — Définir le point A → point B avec précision

**Demander :** "Décris le point A (où est la cible maintenant) et le point B (où elle veut aller) de la façon la plus précise possible."

**Point A — Recenser :**
- La situation concrète actuelle
- Les frustrations spécifiques
- Les blocages récurrents
- Ce que ça coûte (temps, argent, énergie, relations)

**Point B — Recenser :**
- Le résultat tangible et mesurable
- La situation concrète après transformation
- Ce que ça change dans le quotidien

> **Bon point B :** "Elle signe 2 clients/mois en B2B sans faire de cold calling, en 30 jours."
> **Mauvais point B :** "Elle se sent plus confiante dans sa business." (pas mesurable, pas concret)

**La MVE = le chemin minimal et viable entre A et B.** Rien de plus.

**Valider la précision du A → B avant de continuer.**

---

## Étape 3 — Construire le monopole personnel

**Demander :** "Quelles sont tes compétences principales ? Tes domaines d'intérêt ? Et quels traits de personnalité ressortent dans ton travail ?"

**Expliquer la matrice du monopole personnel :**

```
COMPÉTENCES × INTÉRÊTS × PERSONNALITÉ = MONOPOLE PERSONNEL
```

Le monopole personnel est un avantage concurrentiel inattaquable car personne d'autre ne peut le répliquer. Le multi-passionné n'est pas une faiblesse — c'est un avantage : la diversité d'intérêts crée une perspective unique inaccessible aux spécialistes mono-domaine.

**Processus en 3 étapes :**
1. Lister toutes ses expertises et passions
2. Identifier les intersections créatrices de valeur pour la cible
3. Choisir 1 focus MVE pour les 30 prochains jours

> **Exemple :** Expert Notion + OKR + scaling start-up = consultant en "OS organisationnel pour start-up post-série A"

**Demander :** "Quelle intersection entre tes compétences, intérêts et personnalité est la plus pertinente pour ce problème de niveau 3 ?"

**Valider le monopole personnel avant de continuer.**

---

## Étape 4 — Structurer l'offre minimale

**Demander :** "Combien de sessions, à quelle fréquence, dans quel format, pour quel livrable concret ?"

**Structure type d'une MVE :**
- **Sessions** : 4 à 8 séances de 1h (à ajuster selon le problème)
- **Fréquence** : hebdomadaire ou bi-mensuelle
- **Format** : coaching 1:1, petit groupe (3-5), ou asynchrone
- **Livrable(s) concret(s)** : ce que le client repart avec à chaque session et à la fin

**Règle absolue :** prix fixé à la valeur de la transformation, **jamais au temps passé**.

> **Mauvais raisonnement :** 4 sessions × 400€/jour = 1 600€
> **Bon raisonnement :** si la transformation vaut 20 000€ au client, 3 000-5 000€ est une évidence

**Nommer la méthode** : une méthode nommée = une propriété intellectuelle qui justifie un pricing premium et sort de la commodité.

**Valider l'architecture de l'offre avant de continuer.**

---

## Étape 5 — Calculer la valeur de la transformation et fixer le prix

**Demander :** "Calcule le coût du problème pour ta cible : coût financier direct, coût en temps, coût émotionnel du statu quo."

**Méthode de calcul :**

| Dimension | Calcul | Exemple |
|---|---|---|
| **Coût financier** | Argent perdu ou non gagné par an | 3 clients perdus × 5 000€ = 15 000€/an |
| **Coût temps** | Heures perdues × valeur horaire | 10h/sem × 50€ × 52 = 26 000€/an |
| **Coût émotionnel** | Difficile à chiffrer, mais réel | Stress, perte de confiance, relations dégradées |

**Règle de pricing :**
- Prix = pourcentage de la valeur de la transformation (typiquement 10-20%)
- Jamais inférieur au coût annuel du problème
- Un prix trop bas nuit aux résultats clients : le client low-ticket ne s'engage pas autant qu'un client high-ticket

**Processus d'ascension :**
1. Tester à prix bas pour valider (500-1 000€)
2. Augmenter après 3-5 clients satisfaits (2 000-5 000€)
3. Structurer l'offre premium une fois mature (5 000-30 000€)

**Demander :** "Quel prix reflète entre 10 et 20% de la valeur de la transformation calculée ?"

---

## Étape 6 — Formuler la promesse en 4 parties

**Format :** `[Résultat désiré] + [Délai crédible] + [Pour qui] + [Sans obstacle principal]`

> **Exemple :** "Obtenir 3 premiers clients qualifiés en 30 jours sans audience ni cold calling"

**Les 4 composantes d'une promesse qui convertit :**
1. **Bénéfice principal tangible** : ce que la cible obtient concrètement
2. **Vitesse/facilité** : effort réduit, délai crédible (pas "en 24h" si c'est impossible)
3. **Spécificité crédible** : chiffres précis, pas de vague
4. **Réduction du risque perçu** : ce qu'elle n'aura pas à faire ou à subir

**Règle :** co-construire la promesse avec les mots exacts des prospects dans leurs conversations. Leurs mots = meilleur copywriting possible.

**Demander :** "Formule ta promesse avec ce format. Je vais te donner un feedback sur les 4 composantes."

---

## Étape 7 — Les 5 composantes d'une offre à haute valeur perçue

**Présenter et vérifier que chaque composante est présente :**

1. **Une promesse claire de transformation** (formulée à l'étape 6)
2. **Un processus nommé et structuré** (les étapes A → B avec un nom propriétaire)
3. **Un résultat mesurable** (quantifiable, observable)
4. **Des preuves** : témoignages, cas concrets, résultats chiffrés — même 1 seul cas suffit pour démarrer
5. **Une garantie ou réducteur de risque** : satisfait ou remboursé, garantie conditionnelle, ou simple engagement verbal

**Demander :** "Lesquelles de ces 5 composantes sont déjà présentes dans ton offre ? Lesquelles manquent ?"

**Travail sur les manquantes avant de passer au packaging.**

---

## Étape 8 — Packager sans infrastructure

**Demander :** "Es-tu prêt à lancer sans site web, sans tunnel de vente, sans audience ?"

**Ce qui est indispensable — et seulement ça :**
- **Paiement** : Stripe (lien de paiement en 10 minutes) ou PayPal
- **Delivery** : Notion, Google Doc (programme structuré), Zoom (sessions)
- **Offre exprimable en 2-3 phrases** : la promesse (étape 6) suffit

**Ce qui n'est PAS indispensable au démarrage :**
- Site web
- Tunnel de vente
- Page de vente élaborée
- Audience sur les réseaux
- Infrastructure technique

**Règle :** le contenant de l'offre (comment elle est packagée) se maîtrise dès le départ. Le contenu (ce qui est délivré) se standardise progressivement avec les itérations.

**Valider le setup minimal avant de passer à la prospection.**

---

## Étape 9 — Aller chercher les premiers clients

### Méthode 30 conversations en 30 jours

**Demander :** "Dresse la liste de toutes les personnes dans ton réseau qui pourraient correspondre à ta cible ou connaître quelqu'un qui y correspond."

**Règle :** contacter 1 personne par jour dans son réseau existant — pas de cold calling. Chaque interaction est potentiellement un client, un ambassadeur, ou un prescripteur.

**3 stratégies immédiates sans audience :**

1. **Réseau chaud** : ex-collègues, clients passés, contacts LinkedIn dormants — cartographier et contacter

2. **Communautés actives** : rejoindre 2-3 espaces (Slack, Discord, groupes Facebook, LinkedIn) où la cible est active — apporter de la valeur avant de proposer quoi que ce soit

3. **Partenariats complémentaires** : identifier qui travaille déjà avec ta cible idéale sans être en concurrence → proposer une collaboration

**Outil de suivi obligatoire :**

| Nom | Source | Date contact | Statut | Prochaine action |
|---|---|---|---|---|
| ... | ... | ... | ... | ... |

Sans tracking, pas de système. Un tableur simple suffit.

**Valider : 10 contacts identifiés minimum avant de lancer.**

---

## Étape 10 — Distinguer signal d'intérêt vs signal d'achat + cycle OTI

### Signal d'intérêt vs signal d'achat

**Signal d'intérêt** (ne compte pas pour valider l'offre) :
- "C'est intéressant"
- "Bonne idée"
- "Je pense que ça peut marcher"
- "Je te suis"

**Signal d'achat** (le seul qui compte) :
- "Combien ça coûte ?"
- "Comment on fait pour commencer ?"
- "Tu as de la place ce mois-ci ?"
- Un virement ou une demande de lien de paiement

**Règle :** ne jamais compter les signaux d'intérêt comme validation. Seul le signal d'achat confirme que le problème est assez douloureux et l'offre assez désirable.

### Cycle OTI pour itérer

Chaque client est un laboratoire. Après chaque prestation :

```
HYPOTHÈSE → OBSERVATION → TEST → ITÉRATION
```

**Questions à poser après chaque client :**
- Ce qui a bien marché (à conserver)
- Ce qui n'a pas marché (à modifier)
- Ce qu'il manquait (à ajouter)

**Documenter systématiquement.** L'offre MVE n'est pas parfaite au départ — c'est un avantage : elle force à apprendre vite. L'imperfection est une fonctionnalité, pas un bug.

**Demander :** "Après tes 3 premiers clients, qu'est-ce que tu as appris sur ce qui doit changer ?"

---

## Synthèse finale

À la fin du processus, produire ce récapitulatif :

```
PROBLÈME (niveau 3) : [Description + coût d'inaction]
POINT A : [Situation actuelle précise]
POINT B : [Résultat mesurable]
MONOPOLE PERSONNEL : [Intersection compétences × intérêts × personnalité]
OFFRE : [Sessions, fréquence, format, livrables]
PRIX : [Montant + % de la valeur de transformation]
PROMESSE : [Résultat] + [Délai] + [Pour qui] + [Sans obstacle]
SETUP : Stripe + Notion/Google Doc + Zoom
PREMIER CONTACT : [Liste des 10 premières personnes à contacter]
```
